# Quick Start Guide

## ⚡ Fast Setup (5 minutes)

### Step 1: Install Flutter (if needed)

**Option A - Download Binary (Fastest):**
```bash
# Windows
# Download from: https://docs.flutter.dev/get-started/install/windows

# Linux
cd ~
wget https://storage.googleapis.com/flutter_infra_release/releases/stable/linux/flutter_linux_3.24.5-stable.tar.xz
tar xf flutter_linux_3.24.5-stable.tar.xz
export PATH="$PATH:`pwd`/flutter/bin"
```

**Option B - Already Installed:**
```bash
flutter --version  # Check if Flutter is installed
```

### Step 2: Enable Desktop Support

```bash
flutter config --enable-windows-desktop  # Windows
# OR
flutter config --enable-macos-desktop    # macOS
# OR  
flutter config --enable-linux-desktop    # Linux
```

### Step 3: Install Dependencies

```bash
cd /home/ubuntu/pos_backoffice_app
flutter pub get
```

### Step 4: Run the Application

```bash
# For Windows
flutter run -d windows

# For Linux
flutter run -d linux

# For macOS
flutter run -d macos
```

## 🎮 Try It Out

### Test Back Office

1. Click **"Back Office Login"**
2. Enter:
   - Username: `admin`
   - Password: `admin123`
3. Explore the dashboard and features

### Test POS

1. Click **"POS Login"**
2. Select **"Main Store"**
3. Enter PIN: `1234`
4. Click **"Start Shift"** → Enter `100.00` as starting cash
5. Add products to ticket
6. Process a payment

## 🔍 What You'll See

### Login Screen
Two options: Back Office or POS login

### Back Office Dashboard
- Today's sales: $0 (initially)
- Total inventory: 20 products
- Active stores: 3
- Top selling products (empty until sales are made)

### POS Interface
- Left: Product grid (20 products in 5 categories)
- Right: Ticket panel
- Products color-coded by category
- Stock levels visible on each tile

## 📊 Sample Data Included

- **Stores**: Main Store, Branch A, Branch B
- **Products**: 20 items (Electronics, Clothing, Food, Beverages, Accessories)
- **Employees**: 5 users with different roles
- **Stock**: Each store has 50-100+ units per product

## 🎯 Quick Actions to Test

1. **Make a Sale** (POS):
   - Add "Smartphone X1" ($599.99) to ticket
   - Add "T-Shirt Classic" ($19.99)
   - Click "Pay Cash" → Enter $700 → Complete

2. **View Dashboard** (Back Office):
   - See the sale reflected in today's sales
   - Check top selling products

3. **Manage Inventory** (Back Office):
   - Go to Inventory
   - Update stock for a product
   - See low stock warnings

4. **Generate Report** (Back Office):
   - Go to Sales Reports
   - Set date range to today
   - Generate report
   - Export to CSV

## 🐛 Common Issues

**Issue**: Flutter not found
**Solution**: Add Flutter to PATH or use full path

**Issue**: Desktop not enabled
**Solution**: Run `flutter config --enable-PLATFORM-desktop`

**Issue**: Build fails
**Solution**: Run `flutter clean && flutter pub get`

**Issue**: Database error
**Solution**: Delete the database folder and restart

## 📱 Next Steps

- Review the full README.md for detailed documentation
- Explore all Back Office features
- Process multiple sales in POS
- Generate and export reports
- Customize settings

## 💡 Tips

- Use **Ctrl+F** in POS to quickly search products
- Click category chips to filter products
- Right-click on data tables for more options
- All changes save automatically to SQLite

---

**Need Help?** Check README.md or examine the code comments!
