import 'package:flutter/material.dart';
import 'utils/documentation_generator.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  
  print('Generating Cell Tech POS System Documentation PDF...');
  
  try {
    await DocumentationGenerator.generatePDF();
    print('✅ Documentation PDF generated successfully!');
    print('📄 File saved as: CELL_TECH_POS_DOCUMENTATION.pdf');
  } catch (e) {
    print('❌ Error generating PDF: $e');
  }
}