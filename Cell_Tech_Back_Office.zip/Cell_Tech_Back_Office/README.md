# POS & Back Office Desktop Application

A comprehensive Flutter desktop application combining Point of Sale (POS) and Back Office functionality with offline support using SQLite.

## 🎯 Features

### Back Office Module
- **Dashboard**: Real-time business overview with sales metrics, inventory alerts, and top products
- **Products Management**: Complete CRUD operations with category assignment, pricing, and stock tracking
- **Categories Management**: Visual category cards with color coding
- **Inventory Management**: Multi-store stock tracking with color-coded status indicators
- **Employees Management**: User accounts with role-based access control and PIN authentication
- **Sales Reports**: Comprehensive reporting with filtering and CSV export
- **Stores Management**: Multi-location management
- **Settings**: Business configuration including tax rates and inventory policies

### POS Module
- **Store Selection**: Choose operating location
- **PIN Login**: Quick 4-digit PIN authentication
- **Product Grid**: Color-coded category tiles with real-time stock levels
- **Ticket Panel**: Dynamic cart management with quantity adjustments
- **Multiple Payment Methods**: Cash (with change calculation), EcoCash USD/ZIG, Card
- **Shift Management**: Start/end shifts with cash reconciliation
- **Receipts History**: View past transactions

## 🛠️ Technology Stack

- **Framework**: Flutter (Desktop - Windows/Mac/Linux)
- **Database**: SQLite (sqflite_common_ffi)
- **State Management**: Provider
- **UI Components**: Material Design 3
- **Charts**: fl_chart
- **Data Export**: CSV package
- **Security**: Crypto (password hashing)

## 📋 Prerequisites

- Flutter SDK 3.0 or higher
- Dart 3.0 or higher
- Desktop development tools for your platform:
  - **Windows**: Visual Studio 2022 with C++ desktop development
  - **macOS**: Xcode
  - **Linux**: CMake, Ninja, GTK development libraries

## 🚀 Installation

### 1. Install Flutter (if not already installed)

**Windows/Linux:**
```bash
# Download Flutter SDK
git clone https://github.com/flutter/flutter.git -b stable
export PATH="$PATH:`pwd`/flutter/bin"

# Verify installation
flutter doctor
```

**macOS:**
```bash
# Using Homebrew
brew install flutter

# Or download from flutter.dev
```

### 2. Enable Desktop Support

```bash
# Enable desktop for your platform
flutter config --enable-windows-desktop  # Windows
flutter config --enable-macos-desktop    # macOS
flutter config --enable-linux-desktop    # Linux
```

### 3. Clone and Setup Project

```bash
cd /home/ubuntu/pos_backoffice_app

# Get dependencies
flutter pub get

# Run the application
flutter run -d windows  # or macos, linux
```

## 🔐 Default Login Credentials

### Back Office Login

**Administrator Account:**
- Username: `admin`
- Password: `admin123`
- Role: Full access to all features

**Manager Accounts:**
- Username: `manager1` / Password: `manager123` (Main Store)
- Username: `manager2` / Password: `manager123` (Branch A)

**Cashier Accounts:**
- Username: `cashier1` / Password: `cashier123`
- Username: `cashier2` / Password: `cashier123`

### POS Login (PIN-based)

After selecting a store, use these PINs:

- **Admin**: `1234` (All stores)
- **Manager 1**: `2345` (Main Store)
- **Manager 2**: `3456` (Branch A)
- **Cashier 1**: `4567` (Main Store, Branch A)
- **Cashier 2**: `5678` (Branch A, Branch B)

## 📊 Sample Data

The application comes pre-populated with:

- **3 Stores**: Main Store, Branch A, Branch B
- **5 Categories**: Electronics, Clothing, Food, Beverages, Accessories
- **20 Products**: Diverse product catalog with varying stock levels
- **5 Employees**: 1 Admin, 2 Managers, 2 Cashiers
- **3 Customers**: Sample customer records
- **Default Settings**: 15% tax rate, USD currency

## 🎮 Usage Guide

### Starting a POS Session

1. **Launch Application** → Select "POS Login"
2. **Choose Store** → Select your operating location
3. **Enter PIN** → Use 4-digit PIN to authenticate
4. **Start Shift** → Enter starting cash amount (e.g., 100.00)
5. **Begin Sales** → Add products to ticket and process payments

### Making a Sale (POS)

1. **Search/Browse Products**: Use search bar or category filters
2. **Add to Ticket**: Click product tiles to add items
3. **Adjust Quantities**: Use +/- buttons on ticket items
4. **Process Payment**: Select payment method (Cash/Card/EcoCash)
5. **Complete Transaction**: System updates inventory and shift totals

### Managing Inventory (Back Office)

1. **Login** → Use admin/manager credentials
2. **Navigate to Inventory** → View stock levels across stores
3. **Update Stock** → Click edit icon to adjust quantities
4. **Monitor Alerts** → Check low stock and out-of-stock items

### Generating Reports

1. **Go to Sales Reports**
2. **Set Filters**: Date range, store, employee, payment method
3. **Generate Report**: Click "Generate Report" button
4. **Export**: Use "Export to CSV" for external analysis

## 📁 Project Structure

```
lib/
├── main.dart                 # Application entry point
├── models/                   # Data models
│   ├── category.dart
│   ├── product.dart
│   ├── store.dart
│   ├── employee.dart
│   ├── customer.dart
│   ├── sale.dart
│   ├── shift.dart
│   └── settings.dart
├── services/
│   └── database_service.dart # SQLite operations
├── screens/
│   ├── login/
│   │   └── login_screen.dart
│   ├── back_office/
│   │   ├── dashboard_screen.dart
│   │   ├── products_screen.dart
│   │   ├── categories_screen.dart
│   │   ├── inventory_screen.dart
│   │   ├── employees_screen.dart
│   │   ├── sales_reports_screen.dart
│   │   ├── stores_screen.dart
│   │   └── settings_screen.dart
│   └── pos/
│       ├── store_selection_screen.dart
│       ├── pin_login_screen.dart
│       └── main_pos_screen.dart
└── widgets/
    └── back_office_layout.dart
```

## 🗄️ Database Schema

### Main Tables

- **categories**: Product groupings with colors
- **products**: Master product catalog
- **stores**: Retail locations
- **store_stock**: Per-store inventory levels
- **employees**: User accounts with authentication
- **customers**: Customer information
- **sales**: Transaction records
- **sale_items**: Line items for each sale
- **shifts**: Cashier work sessions
- **settings**: System configuration

## 🔧 Configuration

### Tax Settings

Navigate to Back Office → Settings:
- Default Tax Rate: 15% (modifiable)
- Applied automatically to all sales

### Inventory Policies

- **Allow Negative Stock**: Enable/disable selling when out of stock
- **Minimum Stock Levels**: Set alerts for low inventory

### Business Information

- Business Name (appears on receipts)
- Currency (USD, EUR, GBP, etc.)

## 🐛 Troubleshooting

### Database Issues

If you encounter database errors:

```bash
# Delete database and restart (resets to seed data)
rm -rf ~/.local/share/pos_backoffice_app/
flutter run
```

### Build Issues

```bash
# Clean and rebuild
flutter clean
flutter pub get
flutter build windows  # or macos, linux
```

### Performance Issues

- Reduce number of products displayed per page
- Close unused background applications
- Ensure adequate RAM (minimum 4GB recommended)

## 🔄 Future Enhancements

The codebase is structured for easy integration with:
- **Supabase**: Cloud database synchronization
- **Barcode Scanning**: USB/camera scanner support
- **Receipt Printing**: Thermal printer integration
- **Multi-currency**: Real-time exchange rates
- **Advanced Analytics**: Sales forecasting and trends

## 📝 License

This is a demonstration application for educational purposes.

## 🤝 Support

For issues or questions:
- Check the troubleshooting section above
- Review inline code comments
- Examine the reference document at `Uploads/user_message_2025-10-01_06-11-44.txt`

## ✅ Feature Checklist

### Back Office ✓
- [x] Login with username/password
- [x] Dashboard with real-time metrics
- [x] Products CRUD operations
- [x] Categories management
- [x] Inventory tracking
- [x] Employee management
- [x] Sales reports with filters
- [x] Store management
- [x] Settings configuration

### POS ✓
- [x] Store selection
- [x] PIN authentication
- [x] Product grid with search
- [x] Category filtering
- [x] Ticket management
- [x] Quantity adjustments
- [x] Multiple payment methods
- [x] Cash change calculation
- [x] Shift management
- [x] Stock level warnings

## 🎯 Key Features Demonstrated

1. **Clean Architecture**: Separation of models, services, and UI
2. **Offline-First**: Full functionality without internet
3. **Role-Based Access**: Different permissions for different users
4. **Real-Time Updates**: Inventory updates immediately after sales
5. **Financial Controls**: Shift reconciliation and cash tracking
6. **Responsive UI**: Works on various screen sizes
7. **Data Integrity**: Transaction safety with proper error handling
8. **Security**: Password hashing, PIN authentication

---

**Built with Flutter** 💙
