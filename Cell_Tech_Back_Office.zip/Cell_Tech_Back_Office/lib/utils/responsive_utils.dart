import 'package:flutter/material.dart';
import 'dart:math' as math;

class ResponsiveUtils {
  static double screenWidth(BuildContext context) => MediaQuery.of(context).size.width;
  static double screenHeight(BuildContext context) => MediaQuery.of(context).size.height;
  
  // Responsive breakpoints
  static bool isMobile(BuildContext context) => screenWidth(context) < 600;
  static bool isTablet(BuildContext context) => screenWidth(context) >= 600 && screenWidth(context) < 1024;
  static bool isDesktop(BuildContext context) => screenWidth(context) >= 1024;
  
  // Responsive values
  static double responsiveValue(BuildContext context, {
    required double mobile,
    required double tablet,
    required double desktop,
  }) {
    if (isMobile(context)) return mobile;
    if (isTablet(context)) return tablet;
    return desktop;
  }
  
  // Responsive padding/margins
  static EdgeInsets responsivePadding(BuildContext context, {
    double? mobile,
    double? tablet, 
    double? desktop,
  }) {
    final value = responsiveValue(
      context,
      mobile: mobile ?? 8.0,
      tablet: tablet ?? 16.0,
      desktop: desktop ?? 24.0,
    );
    return EdgeInsets.all(value);
  }
  
  // Percentage-based dimensions
  static double wp(BuildContext context, double percentage) {
    return screenWidth(context) * (percentage / 100);
  }
  
  static double hp(BuildContext context, double percentage) {
    return screenHeight(context) * (percentage / 100);
  }
  
  // Adaptive font sizes
  static double adaptiveFontSize(BuildContext context, double baseFontSize) {
    return baseFontSize * math.min(screenWidth(context) / 1200, 1.2);
  }
  
  // Icon sizes
  static double adaptiveIconSize(BuildContext context, double baseSize) {
    return baseSize * math.min(screenWidth(context) / 1200, 1.3);
  }
  
  // Grid columns based on screen size
  static int getGridColumns(BuildContext context) {
    if (isMobile(context)) return 1;
    if (isTablet(context)) return 2;
    return math.min((screenWidth(context) / 300).floor(), 6);
  }
  
  // Container constraints
  static BoxConstraints adaptiveConstraints(BuildContext context, {
    double? maxWidthRatio,
    double? minWidth,
    double? maxWidth,
  }) {
    final screenW = screenWidth(context);
    return BoxConstraints(
      minWidth: minWidth ?? 0,
      maxWidth: maxWidth ?? (maxWidthRatio != null ? screenW * maxWidthRatio : double.infinity),
    );
  }
  
  // Flexible grid item sizing
  static double getFlexibleItemWidth(BuildContext context, {
    int desiredColumns = 3,
    double spacing = 16.0,
    double padding = 24.0,
  }) {
    final availableWidth = screenWidth(context) - (padding * 2) - (spacing * (desiredColumns - 1));
    return availableWidth / desiredColumns;
  }
  
  // Safe area aware heights
  static double safeAreaHeight(BuildContext context) {
    final mediaQuery = MediaQuery.of(context);
    return mediaQuery.size.height - mediaQuery.padding.top - mediaQuery.padding.bottom;
  }
  
  // Button sizes
  static Size adaptiveButtonSize(BuildContext context, {
    Size? mobile,
    Size? tablet,
    Size? desktop,
  }) {
    if (isMobile(context)) return mobile ?? const Size(double.infinity, 48);
    if (isTablet(context)) return tablet ?? const Size(200, 50);
    return desktop ?? const Size(250, 56);
  }
}

// Responsive widgets
class ResponsiveBuilder extends StatelessWidget {
  final Widget Function(BuildContext context, bool isMobile, bool isTablet, bool isDesktop) builder;
  
  const ResponsiveBuilder({super.key, required this.builder});

  @override
  Widget build(BuildContext context) {
    return builder(
      context,
      ResponsiveUtils.isMobile(context),
      ResponsiveUtils.isTablet(context),
      ResponsiveUtils.isDesktop(context),
    );
  }
}

class ResponsiveContainer extends StatelessWidget {
  final Widget child;
  final EdgeInsets? mobilePadding;
  final EdgeInsets? tabletPadding;
  final EdgeInsets? desktopPadding;
  final double? maxWidthRatio;
  
  const ResponsiveContainer({
    super.key,
    required this.child,
    this.mobilePadding,
    this.tabletPadding,
    this.desktopPadding,
    this.maxWidthRatio,
  });

  @override
  Widget build(BuildContext context) {
    EdgeInsets padding = ResponsiveUtils.responsivePadding(
      context,
      mobile: mobilePadding?.top ?? 16,
      tablet: tabletPadding?.top ?? 24,
      desktop: desktopPadding?.top ?? 32,
    );
    
    if (ResponsiveUtils.isMobile(context) && mobilePadding != null) {
      padding = mobilePadding!;
    } else if (ResponsiveUtils.isTablet(context) && tabletPadding != null) {
      padding = tabletPadding!;
    } else if (ResponsiveUtils.isDesktop(context) && desktopPadding != null) {
      padding = desktopPadding!;
    }
    
    return Container(
      constraints: ResponsiveUtils.adaptiveConstraints(
        context,
        maxWidthRatio: maxWidthRatio,
      ),
      padding: padding,
      child: child,
    );
  }
}

class ResponsiveText extends StatelessWidget {
  final String text;
  final double baseFontSize;
  final TextStyle? style;
  final TextAlign? textAlign;
  final int? maxLines;
  final TextOverflow? overflow;
  
  const ResponsiveText(
    this.text, {
    super.key,
    this.baseFontSize = 16.0,
    this.style,
    this.textAlign,
    this.maxLines,
    this.overflow,
  });

  @override
  Widget build(BuildContext context) {
    return Text(
      text,
      style: (style ?? const TextStyle()).copyWith(
        fontSize: ResponsiveUtils.adaptiveFontSize(context, baseFontSize),
      ),
      textAlign: textAlign,
      maxLines: maxLines,
      overflow: overflow ?? TextOverflow.ellipsis,
    );
  }
}

class ResponsiveRow extends StatelessWidget {
  final List<Widget> children;
  final MainAxisAlignment mainAxisAlignment;
  final CrossAxisAlignment crossAxisAlignment;
  final bool wrapOnSmallScreen;
  final WrapAlignment wrapAlignment;
  final double spacing;
  final double runSpacing;
  
  const ResponsiveRow({
    super.key,
    required this.children,
    this.mainAxisAlignment = MainAxisAlignment.start,
    this.crossAxisAlignment = CrossAxisAlignment.center,
    this.wrapOnSmallScreen = true,
    this.wrapAlignment = WrapAlignment.start,
    this.spacing = 8.0,
    this.runSpacing = 8.0,
  });

  @override
  Widget build(BuildContext context) {
    if (wrapOnSmallScreen && ResponsiveUtils.isMobile(context)) {
      return Wrap(
        alignment: wrapAlignment,
        spacing: spacing,
        runSpacing: runSpacing,
        children: children,
      );
    }
    
    return Row(
      mainAxisAlignment: mainAxisAlignment,
      crossAxisAlignment: crossAxisAlignment,
      children: children,
    );
  }
}

class ResponsiveGrid extends StatelessWidget {
  final List<Widget> children;
  final int? forceColumns;
  final double spacing;
  final double runSpacing;
  final double childAspectRatio;
  
  const ResponsiveGrid({
    super.key,
    required this.children,
    this.forceColumns,
    this.spacing = 16.0,
    this.runSpacing = 16.0,
    this.childAspectRatio = 1.0,
  });

  @override
  Widget build(BuildContext context) {
    final columns = forceColumns ?? ResponsiveUtils.getGridColumns(context);
    
    return GridView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: columns,
        crossAxisSpacing: spacing,
        mainAxisSpacing: runSpacing,
        childAspectRatio: childAspectRatio,
      ),
      itemCount: children.length,
      itemBuilder: (context, index) => children[index],
    );
  }
}