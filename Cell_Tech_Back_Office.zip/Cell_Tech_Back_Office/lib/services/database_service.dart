import 'dart:convert';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';
import 'package:path/path.dart';
import 'package:crypto/crypto.dart';
import 'package:path_provider/path_provider.dart';
import 'dart:io';
import '../models/category.dart';
import '../models/product.dart';
import '../models/store.dart';
import '../models/employee.dart';
import '../models/customer.dart';
import '../models/sale.dart';
import '../models/shift.dart';
import '../models/supplier.dart';
import '../models/purchase_order.dart';
import '../models/purchase_order_item.dart';
import '../models/stock_adjustment.dart';
import '../models/stock_adjustment_item.dart';

class DatabaseService {
  static Database? _database;
  static bool _isInitializing = false;
  
  // Force database reset
  static void resetDatabase() {
    _database = null;
    _isInitializing = false;
  }
  
  static Future<Database> get database async {
    // Prevent concurrent initialization
    if (_isInitializing) {
      while (_isInitializing) {
        await Future.delayed(const Duration(milliseconds: 50));
      }
    }
    
    if (_database != null) return _database!;
    
    _isInitializing = true;
    try {
      _database = await _initDatabase();
      
      // Test database connectivity
      try {
        await _database!.rawQuery('SELECT 1');
        print('Database connectivity test passed');
      } catch (e) {
        print('Database connectivity test failed: $e');
        _database = null;
        throw Exception('Database is not accessible: $e');
      }
      
      return _database!;
    } finally {
      _isInitializing = false;
    }
  }

  // Safe query execution with retry logic
  static Future<List<Map<String, dynamic>>> safeQuery(String sql, [List<Object?>? arguments]) async {
    for (int attempt = 0; attempt < 3; attempt++) {
      try {
        final db = await database;
        return await db.rawQuery(sql, arguments);
      } catch (e) {
        if (e.toString().contains('read only') || e.toString().contains('database is locked')) {
          print('Database lock detected, attempt ${attempt + 1}: $e');
          if (attempt < 2) {
            await Future.delayed(Duration(milliseconds: 100 * (attempt + 1)));
            continue;
          }
        }
        rethrow;
      }
    }
    return [];
  }

  // Safe update execution with retry logic
  static Future<int> safeUpdate(String sql, [List<Object?>? arguments]) async {
    for (int attempt = 0; attempt < 3; attempt++) {
      try {
        final db = await database;
        return await db.rawUpdate(sql, arguments);
      } catch (e) {
        if (e.toString().contains('read only') || e.toString().contains('database is locked')) {
          print('Database update lock detected, attempt ${attempt + 1}: $e');
          if (attempt < 2) {
            await Future.delayed(Duration(milliseconds: 100 * (attempt + 1)));
            // Force database recreation on read-only error
            if (e.toString().contains('read only')) {
              _database = null;
              _isInitializing = false;
            }
            continue;
          }
        }
        rethrow;
      }
    }
    return 0;
  }

  // Safe update with parameters - for use in other classes
  static Future<int> safeUpdateSales(String updateQuery, List<Object?> arguments) async {
    return await safeUpdate(updateQuery, arguments);
  }

  static Future<Database> _initDatabase({bool force = false}) async {
    // Initialize FFI first
    sqfliteFfiInit();
    
    // Use explicit factory to ensure write mode
    final databaseFactory = databaseFactoryFfi;
    final dbPath = await databaseFactory.getDatabasesPath();
    final path = join(dbPath, 'pos_backoffice_rw.db'); // Different name to force recreation
    
    print('Database path: $path');

    try {
      // Always delete existing database to ensure clean state, or when forced
      final dbFile = File(path);
      if (await dbFile.exists() && (force || true)) { // Always delete for now to ensure clean state
        print('Deleting existing database to ensure clean state');
        await dbFile.delete();
      }

      // Ensure database directory exists and is writable
      final dbDir = Directory(dirname(path));
      if (!await dbDir.exists()) {
        await dbDir.create(recursive: true);
      }

        // Create new database with explicit write permissions
        final db = await databaseFactory.openDatabase(
          path,
          options: OpenDatabaseOptions(
            version: 7,
            onCreate: _onCreate,
            onUpgrade: _onUpgrade,
            readOnly: false, // Explicitly ensure read-write mode
            singleInstance: false, // Allow multiple connections if needed
          ),
        );      // Test write capability immediately
      try {
        await db.execute('CREATE TABLE IF NOT EXISTS _test_write (id INTEGER)');
        await db.execute('INSERT INTO _test_write (id) VALUES (1)');
        await db.execute('DELETE FROM _test_write WHERE id = 1');
        await db.execute('DROP TABLE _test_write');
        print('Database write test passed');
      } catch (e) {
        print('Database write test failed: $e');
        throw Exception('Database is not writable: $e');
      }

      return db;
    } catch (e) {
      print('Database initialization error: $e');
      print('Attempting to recover by deleting and recreating database...');
      
      // If database is corrupted or has permission issues, delete and recreate
      try {
        final file = File(path);
        if (await file.exists()) {
          await file.delete();
        }
        
        // Try to create a new database
        return await databaseFactory.openDatabase(
          path,
          options: OpenDatabaseOptions(
            version: 7,
            onCreate: _onCreate,
            onUpgrade: _onUpgrade,
            readOnly: false,
          ),
        );
      } catch (e2) {
        print('Database recovery failed: $e2');
        rethrow;
      }
    }
  }

  static Future<void> _onCreate(Database db, int version) async {
    // Create categories table
    await db.execute('''
      CREATE TABLE categories (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        color TEXT NOT NULL,
        description TEXT,
        active INTEGER NOT NULL DEFAULT 1,
        sort_order INTEGER,
        created_at TEXT NOT NULL
      )
    ''');

    // Create products table
    await db.execute('''
      CREATE TABLE products (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        description TEXT,
        sku TEXT NOT NULL UNIQUE,
        handle TEXT,
        barcode TEXT,
        category_id INTEGER NOT NULL,
        price REAL NOT NULL,
        cost REAL,
        track_stock INTEGER NOT NULL DEFAULT 1,
        active INTEGER NOT NULL DEFAULT 1,
        sold_by_weight INTEGER DEFAULT 0,
        image_url TEXT,
        store_availability TEXT,
        available_stores TEXT,
        store_settings TEXT,
        stock INTEGER NOT NULL DEFAULT 0,
        created_at TEXT NOT NULL,
        FOREIGN KEY (category_id) REFERENCES categories (id)
      )
    ''');

    // Create stores table
    await db.execute('''
      CREATE TABLE stores (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        address TEXT NOT NULL,
        phone TEXT NOT NULL,
        manager_id INTEGER,
        type TEXT NOT NULL DEFAULT 'store',
        capacity INTEGER,
        active INTEGER NOT NULL DEFAULT 1,
        created_at TEXT NOT NULL
      )
    ''');

    // Create store_stock table
    await db.execute('''
      CREATE TABLE store_stock (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        store_id INTEGER NOT NULL,
        product_id INTEGER NOT NULL,
        stock_quantity INTEGER NOT NULL DEFAULT 0,
        min_stock_level INTEGER NOT NULL DEFAULT 5,
        FOREIGN KEY (store_id) REFERENCES stores (id),
        FOREIGN KEY (product_id) REFERENCES products (id),
        UNIQUE(store_id, product_id)
      )
    ''');

    // Create employees table
    await db.execute('''
      CREATE TABLE employees (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        email TEXT NOT NULL UNIQUE,
        phone TEXT NOT NULL,
        username TEXT NOT NULL UNIQUE,
        password_hash TEXT NOT NULL,
        pin TEXT NOT NULL,
        role TEXT NOT NULL,
        assigned_store_ids TEXT NOT NULL DEFAULT '[]',
        active INTEGER NOT NULL DEFAULT 1,
        created_at TEXT NOT NULL
      )
    ''');

    // Create customers table
    await db.execute('''
      CREATE TABLE customers (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        phone TEXT NOT NULL,
        email TEXT,
        total_purchases REAL NOT NULL DEFAULT 0,
        created_at TEXT NOT NULL
      )
    ''');

    // Create sales table
    await db.execute('''
      CREATE TABLE sales (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        ticket_number TEXT NOT NULL UNIQUE,
        store_id INTEGER NOT NULL,
        employee_id INTEGER NOT NULL,
        customer_id INTEGER,
        shift_id INTEGER,
        sale_date TEXT NOT NULL,
        subtotal REAL NOT NULL,
        tax_amount REAL NOT NULL,
        discount_amount REAL NOT NULL DEFAULT 0,
        total_amount REAL NOT NULL,
        payment_method TEXT NOT NULL,
        status TEXT NOT NULL DEFAULT 'completed',
        refund_reason TEXT,
        refunded_at TEXT,
        created_at TEXT NOT NULL,
        FOREIGN KEY (store_id) REFERENCES stores (id),
        FOREIGN KEY (employee_id) REFERENCES employees (id),
        FOREIGN KEY (customer_id) REFERENCES customers (id),
        FOREIGN KEY (shift_id) REFERENCES shifts (id)
      )
    ''');

    // Create sale_items table
    await db.execute('''
      CREATE TABLE sale_items (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        sale_id INTEGER NOT NULL,
        product_id INTEGER NOT NULL,
        quantity INTEGER NOT NULL,
        unit_price REAL NOT NULL,
        line_total REAL NOT NULL,
        FOREIGN KEY (sale_id) REFERENCES sales (id),
        FOREIGN KEY (product_id) REFERENCES products (id)
      )
    ''');

    // Create shifts table
    await db.execute('''
      CREATE TABLE shifts (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        store_id INTEGER NOT NULL,
        employee_id INTEGER NOT NULL,
        start_time TEXT NOT NULL,
        end_time TEXT,
        starting_cash REAL NOT NULL,
        ending_cash REAL,
        cash_variance REAL,
        gross_sales REAL NOT NULL DEFAULT 0,
        status TEXT NOT NULL DEFAULT 'open',
        total_sales REAL NOT NULL DEFAULT 0,
        total_transactions INTEGER NOT NULL DEFAULT 0,
        created_at TEXT NOT NULL,
        FOREIGN KEY (store_id) REFERENCES stores (id),
        FOREIGN KEY (employee_id) REFERENCES employees (id)
      )
    ''');

    // Create settings table
    await db.execute('''
      CREATE TABLE settings (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        key TEXT NOT NULL UNIQUE,
        value TEXT NOT NULL
      )
    ''');

    // Create suppliers table
    await db.execute('''
      CREATE TABLE suppliers (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        contact_person TEXT,
        email TEXT,
        phone TEXT,
        address TEXT,
        notes TEXT,
        active INTEGER NOT NULL DEFAULT 1,
        created_at TEXT NOT NULL
      )
    ''');

    // Create purchase_orders table
    await db.execute('''
      CREATE TABLE purchase_orders (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        po_number TEXT NOT NULL UNIQUE,
        supplier_id INTEGER,
        status TEXT NOT NULL,
        destination_stores TEXT,
        expected_delivery_date TEXT,
        total_amount REAL NOT NULL DEFAULT 0,
        notes TEXT,
        created_by INTEGER,
        created_at TEXT NOT NULL,
        received_at TEXT,
        FOREIGN KEY (supplier_id) REFERENCES suppliers (id),
        FOREIGN KEY (created_by) REFERENCES employees (id)
      )
    ''');

    // Create purchase_order_items table
    await db.execute('''
      CREATE TABLE purchase_order_items (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        purchase_order_id INTEGER NOT NULL,
        product_id INTEGER NOT NULL,
        quantity INTEGER NOT NULL,
        unit_cost REAL NOT NULL,
        total_cost REAL NOT NULL,
        FOREIGN KEY (purchase_order_id) REFERENCES purchase_orders (id),
        FOREIGN KEY (product_id) REFERENCES products (id)
      )
    ''');

    // Create stock_adjustments table
    await db.execute('''
      CREATE TABLE stock_adjustments (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        adjustment_number TEXT NOT NULL UNIQUE,
        reference_number TEXT,
        reason TEXT NOT NULL,
        status TEXT NOT NULL,
        store_id INTEGER,
        employee_id INTEGER,
        total_cost REAL NOT NULL DEFAULT 0,
        notes TEXT,
        created_at TEXT NOT NULL,
        completed_at TEXT,
        FOREIGN KEY (store_id) REFERENCES stores (id),
        FOREIGN KEY (employee_id) REFERENCES employees (id)
      )
    ''');

    // Create stock_adjustment_items table
    await db.execute('''
      CREATE TABLE stock_adjustment_items (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        adjustment_id INTEGER NOT NULL,
        product_id INTEGER NOT NULL,
        quantity_before INTEGER NOT NULL,
        quantity_after INTEGER NOT NULL,
        quantity_change INTEGER NOT NULL,
        notes TEXT,
        FOREIGN KEY (adjustment_id) REFERENCES stock_adjustments (id),
        FOREIGN KEY (product_id) REFERENCES products (id)
      )
    ''');

    // Create inventory_counts tables (separate from stock adjustments)
    await db.execute('''
      CREATE TABLE inventory_counts (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        count_number TEXT NOT NULL UNIQUE,
        store_id INTEGER NOT NULL,
        count_type TEXT NOT NULL, -- 'full_count' | 'partial_count'
        status TEXT NOT NULL, -- 'in_progress' | 'completed' | 'cancelled'
        notes TEXT,
        started_at TEXT NOT NULL,
        completed_at TEXT,
        FOREIGN KEY (store_id) REFERENCES stores (id)
      )
    ''');
    await db.execute('''
      CREATE TABLE inventory_count_items (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        count_id INTEGER NOT NULL,
        product_id INTEGER NOT NULL,
        expected_qty INTEGER NOT NULL,
        counted_qty INTEGER,
        UNIQUE(count_id, product_id),
        FOREIGN KEY (count_id) REFERENCES inventory_counts (id),
        FOREIGN KEY (product_id) REFERENCES products (id)
      )
    ''');

    // Insert seed data
    await _insertSeedData(db);
  }

  static Future<void> _onUpgrade(Database db, int oldVersion, int newVersion) async {
    if (oldVersion < 2) {
      // Add inventory management tables
      await db.execute('''
        CREATE TABLE IF NOT EXISTS suppliers (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          name TEXT NOT NULL,
          contact_person TEXT,
          email TEXT,
          phone TEXT,
          address TEXT,
          notes TEXT,
          active INTEGER NOT NULL DEFAULT 1,
          created_at TEXT NOT NULL
        )
      ''');

      await db.execute('''
        CREATE TABLE IF NOT EXISTS purchase_orders (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          po_number TEXT NOT NULL UNIQUE,
          supplier_id INTEGER,
          status TEXT NOT NULL,
          destination_stores TEXT,
          expected_delivery_date TEXT,
          total_amount REAL NOT NULL DEFAULT 0,
          notes TEXT,
          created_by INTEGER,
          created_at TEXT NOT NULL,
          received_at TEXT,
          FOREIGN KEY (supplier_id) REFERENCES suppliers (id),
          FOREIGN KEY (created_by) REFERENCES employees (id)
        )
      ''');

      await db.execute('''
        CREATE TABLE IF NOT EXISTS purchase_order_items (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          purchase_order_id INTEGER NOT NULL,
          product_id INTEGER NOT NULL,
          quantity INTEGER NOT NULL,
          unit_cost REAL NOT NULL,
          total_cost REAL NOT NULL,
          FOREIGN KEY (purchase_order_id) REFERENCES purchase_orders (id),
          FOREIGN KEY (product_id) REFERENCES products (id)
        )
      ''');

      await db.execute('''
        CREATE TABLE IF NOT EXISTS stock_adjustments (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          adjustment_number TEXT NOT NULL UNIQUE,
          reference_number TEXT,
          reason TEXT NOT NULL,
          status TEXT NOT NULL,
          store_id INTEGER,
          employee_id INTEGER,
          total_cost REAL NOT NULL DEFAULT 0,
          notes TEXT,
          created_at TEXT NOT NULL,
          completed_at TEXT,
          FOREIGN KEY (store_id) REFERENCES stores (id),
          FOREIGN KEY (employee_id) REFERENCES employees (id)
        )
      ''');

      await db.execute('''
        CREATE TABLE IF NOT EXISTS stock_adjustment_items (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          adjustment_id INTEGER NOT NULL,
          product_id INTEGER NOT NULL,
          quantity_before INTEGER NOT NULL,
          quantity_after INTEGER NOT NULL,
          quantity_change INTEGER NOT NULL,
          notes TEXT,
          FOREIGN KEY (adjustment_id) REFERENCES stock_adjustments (id),
          FOREIGN KEY (product_id) REFERENCES products (id)
        )
      ''');
    }

    if (oldVersion < 3) {
      // Add missing fields to stock_adjustments table
      try {
        await db.execute('ALTER TABLE stock_adjustments ADD COLUMN reference_number TEXT');
      } catch (e) {
        // Column may already exist
      }
      
      try {
        await db.execute('ALTER TABLE stock_adjustments ADD COLUMN total_cost REAL NOT NULL DEFAULT 0');
      } catch (e) {
        // Column may already exist
      }
    }

    if (oldVersion < 4) {
      // Add inventory counts tables if upgrading from older versions
      await db.execute('''
        CREATE TABLE IF NOT EXISTS inventory_counts (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          count_number TEXT NOT NULL UNIQUE,
          store_id INTEGER NOT NULL,
          count_type TEXT NOT NULL,
          status TEXT NOT NULL,
          notes TEXT,
          started_at TEXT NOT NULL,
          completed_at TEXT,
          FOREIGN KEY (store_id) REFERENCES stores (id)
        )
      ''');
      await db.execute('''
        CREATE TABLE IF NOT EXISTS inventory_count_items (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          count_id INTEGER NOT NULL,
          product_id INTEGER NOT NULL,
          expected_qty INTEGER NOT NULL,
          counted_qty INTEGER,
          UNIQUE(count_id, product_id),
          FOREIGN KEY (count_id) REFERENCES inventory_counts (id),
          FOREIGN KEY (product_id) REFERENCES products (id)
        )
      ''');
    }

    if (oldVersion < 5) {
      // Add store type/capacity and ensure a warehouse exists
      try {
        await db.execute("ALTER TABLE stores ADD COLUMN type TEXT NOT NULL DEFAULT 'store'");
      } catch (_) {}
      try {
        await db.execute('ALTER TABLE stores ADD COLUMN capacity INTEGER');
      } catch (_) {}

      // Warehouses are now managed independently via UI - no hardcoded warehouse needed
    }

    if (oldVersion < 6) {
      // Add new columns to shifts table for enhanced POS functionality
      try {
        await db.execute('ALTER TABLE shifts ADD COLUMN total_sales REAL NOT NULL DEFAULT 0');
      } catch (_) {}
      try {
        await db.execute('ALTER TABLE shifts ADD COLUMN total_transactions INTEGER NOT NULL DEFAULT 0');
      } catch (_) {}
      try {
        await db.execute('ALTER TABLE shifts ADD COLUMN created_at TEXT NOT NULL DEFAULT ""');
      } catch (_) {}
      
      // Update existing shifts to have proper created_at values
      await db.execute('''
        UPDATE shifts 
        SET created_at = start_time 
        WHERE created_at = "" OR created_at IS NULL
      ''');

      // Add stock column to products table for enhanced POS functionality
      try {
        await db.execute('ALTER TABLE products ADD COLUMN stock INTEGER NOT NULL DEFAULT 0');
      } catch (_) {}
    }

    if (oldVersion < 7) {
      // Add refund columns to sales table
      try {
        await db.execute('ALTER TABLE sales ADD COLUMN refund_reason TEXT');
      } catch (_) {}
      try {
        await db.execute('ALTER TABLE sales ADD COLUMN refunded_at TEXT');
      } catch (_) {}
    }
  }

  static String _hashPassword(String password) {
    final bytes = utf8.encode(password);
    final digest = sha256.convert(bytes);
    return digest.toString();
  }

  static Future<void> _insertSeedData(Database db) async {
    // Insert production stores (no hardcoded warehouses)
    final stores = [
      {'name': 'Cell Tech', 'address': 'Main Location', 'phone': '+263 123 4567', 'manager_id': null, 'type': 'store', 'active': 1, 'created_at': DateTime.now().toIso8601String()},
      {'name': 'Cell Tech 6th Ave', 'address': '6th Avenue Location', 'phone': '+263 234 5678', 'manager_id': null, 'type': 'store', 'active': 1, 'created_at': DateTime.now().toIso8601String()},
    ];
    for (var store in stores) {
      await db.insert('stores', store);
    }

    // Insert production user (back office access)
    final employees = [
      {'name': 'CellTech Admin', 'email': 'admin@celltech.com', 'phone': '+263 111 1111', 'username': 'CellTech', 'password_hash': _hashPassword('Snowie1993#'), 'pin': '1234', 'role': 'Administrator', 'assigned_store_ids': '[1,2,3]', 'active': 1, 'created_at': DateTime.now().toIso8601String()},
    ];
    for (var employee in employees) {
      await db.insert('employees', employee);
    }

    // Insert production settings
    final settings = [
      {'key': 'business_name', 'value': 'Cell Tech'},
      {'key': 'tax_rate', 'value': '15'},
      {'key': 'allow_negative_stock', 'value': 'false'},
      {'key': 'currency', 'value': 'USD'},
    ];
    for (var setting in settings) {
      await db.insert('settings', setting);
    }
  }

  // Categories CRUD
  static Future<int> insertCategory(Category category) async {
    try {
      final db = await database;
      return await db.insert('categories', category.toMap());
    } catch (e) {
      if (e.toString().contains('read-only')) {
        // Force database recreation and retry
        await _initDatabase(force: true);
        final db = await database;
        return await db.insert('categories', category.toMap());
      }
      rethrow;
    }
  }

  static Future<List<Category>> getCategories() async {
    final db = await database;
    final List<Map<String, dynamic>> maps = await db.query('categories', orderBy: 'name ASC');
    return List.generate(maps.length, (i) => Category.fromMap(maps[i]));
  }

  static Future<int> updateCategory(Category category) async {
    final db = await database;
    return await db.update('categories', category.toMap(), where: 'id = ?', whereArgs: [category.id]);
  }

  static Future<int> deleteCategory(int id) async {
    final db = await database;
    return await db.delete('categories', where: 'id = ?', whereArgs: [id]);
  }

  // Products CRUD
  static Future<String> generateNextSku() async {
    final db = await database;
    
    // Get the highest numeric SKU that starts with "115"
    final List<Map<String, dynamic>> result = await db.rawQuery('''
      SELECT sku FROM products 
      WHERE sku GLOB '115[0-9][0-9]' 
      ORDER BY CAST(SUBSTR(sku, 4) AS INTEGER) DESC 
      LIMIT 1
    ''');
    
    int nextNumber = 0;
    if (result.isNotEmpty) {
      final lastSku = result.first['sku'] as String;
      final lastNumber = int.tryParse(lastSku.substring(3)) ?? 0;
      nextNumber = lastNumber + 1;
    }
    
    // Format as 115XX (where XX starts from 00)
    return '115${nextNumber.toString().padLeft(2, '0')}';
  }
  
  static Future<int> insertProduct(Product product, {Map<String, dynamic>? storeStockData}) async {
    print('DatabaseService.insertProduct: METHOD CALLED with storeStockData: $storeStockData');
    try {
      final db = await database;
      int productId = await db.insert('products', product.toMap());
      print('DatabaseService.insertProduct: Product inserted with ID: $productId');
      
      print('DatabaseService.insertProduct: Received storeStockData: $storeStockData');

      // If imageUrl is a data URI, persist it to a local file and update the product row
      if (product.imageUrl != null && product.imageUrl!.startsWith('data:image')) {
        try {
          final savedPath = await _persistProductImage(productId, product.imageUrl!);
          if (savedPath != null) {
            await db.update(
              'products',
              {'image_url': savedPath},
              where: 'id = ?',
              whereArgs: [productId],
            );
          }
        } catch (e) {
          // Non-fatal: keep original data URL in DB
          print('DatabaseService.insertProduct: Failed to persist image: $e');
        }
      }
      
      // Create stock entries for stores only (exclude warehouses)
      final stores = await getStores(active: true);
      final storesOnly = stores.where((store) => store.type != 'warehouse').toList();
      for (var store in storesOnly) {
        // Use stock data from form if available, otherwise default to 0
        int stockQuantity = 0;
        int minStockLevel = 5;
        
        if (storeStockData != null && storeStockData.containsKey(store.id.toString())) {
          final storeData = storeStockData[store.id.toString()] as Map<String, dynamic>;
          stockQuantity = (storeData['in_stock'] as int?) ?? 0;
          minStockLevel = (storeData['low_stock'] as int?) ?? 5;
          print('DatabaseService: Using form data for store ${store.name} (${store.id}): stock=$stockQuantity, min=$minStockLevel');
        } else {
          print('DatabaseService: No form data for store ${store.name} (${store.id}), using defaults: stock=$stockQuantity, min=$minStockLevel');
        }
        
        await db.insert('store_stock', {
          'store_id': store.id,
          'product_id': productId,
          'stock_quantity': stockQuantity,
          'min_stock_level': minStockLevel,
        });
      }
      
      return productId;
    } catch (e) {
      if (e.toString().contains('read-only')) {
        // Force database recreation and retry
        await _initDatabase(force: true);
        final db = await database;
        int productId = await db.insert('products', product.toMap());
        print('DatabaseService.insertProduct: Product inserted with ID: $productId (after retry)');
        
        // If imageUrl is a data URI, persist it to a local file and update the product row
        if (product.imageUrl != null && product.imageUrl!.startsWith('data:image')) {
          try {
            final savedPath = await _persistProductImage(productId, product.imageUrl!);
            if (savedPath != null) {
              await db.update(
                'products',
                {'image_url': savedPath},
                where: 'id = ?',
                whereArgs: [productId],
              );
            }
          } catch (e) {
            // Non-fatal: keep original data URL in DB
            print('DatabaseService.insertProduct: Failed to persist image: $e');
          }
        }
        
        // Create stock entries for all stores
        final stores = await getStores();
        for (var store in stores) {
          // Use stock data from form if available, otherwise default to 0
          int stockQuantity = 0;
          int minStockLevel = 5;
          
          if (storeStockData != null && storeStockData.containsKey(store.id.toString())) {
            final storeData = storeStockData[store.id.toString()] as Map<String, dynamic>;
            stockQuantity = (storeData['in_stock'] as int?) ?? 0;
            minStockLevel = (storeData['low_stock'] as int?) ?? 5;
            print('DatabaseService: Using form data for store ${store.name} (${store.id}): stock=$stockQuantity, min=$minStockLevel');
          } else {
            print('DatabaseService: No form data for store ${store.name} (${store.id}), using defaults: stock=$stockQuantity, min=$minStockLevel');
          }
          
          await db.insert('store_stock', {
            'store_id': store.id,
            'product_id': productId,
            'stock_quantity': stockQuantity,
            'min_stock_level': minStockLevel,
          });
        }
        
        return productId;
      } else {
        rethrow;
      }
    }
  }

  static Future<List<Product>> getProducts({int? categoryId, bool? active}) async {
    final db = await database;
    String whereClause = '';
    List<dynamic> whereArgs = [];
    
    if (categoryId != null) {
      whereClause = 'category_id = ?';
      whereArgs.add(categoryId);
    }
    
    if (active != null) {
      if (whereClause.isNotEmpty) whereClause += ' AND ';
      whereClause += 'active = ?';
      whereArgs.add(active ? 1 : 0);
    }
    
    final List<Map<String, dynamic>> maps = await db.query(
      'products',
      where: whereClause.isEmpty ? null : whereClause,
      whereArgs: whereArgs.isEmpty ? null : whereArgs,
      orderBy: 'name ASC',
    );
    return List.generate(maps.length, (i) => Product.fromMap(maps[i]));
  }

  static Future<int> updateProduct(Product product, {Map<String, dynamic>? storeStockData}) async {
    final db = await database;
    
    // Prepare updated map possibly rewriting image_url if data URI provided
    final updateMap = product.toMap();
    if (product.imageUrl != null && product.imageUrl!.startsWith('data:image') && product.id != null) {
      try {
        final savedPath = await _persistProductImage(product.id!, product.imageUrl!);
        if (savedPath != null) {
          updateMap['image_url'] = savedPath;
        }
      } catch (e) {
        // Keep original value if persisting fails
        print('DatabaseService.updateProduct: Failed to persist image: $e');
      }
    }

    // Update product details
    final result = await db.update('products', updateMap, where: 'id = ?', whereArgs: [product.id]);
    
    // Update stock data if provided
    if (storeStockData != null && product.id != null) {
      for (final storeIdStr in storeStockData.keys) {
        final storeId = int.tryParse(storeIdStr);
        if (storeId != null) {
          final storeData = storeStockData[storeIdStr] as Map<String, dynamic>;
          final stockQuantity = (storeData['in_stock'] as int?) ?? 0;
          final minStockLevel = (storeData['low_stock'] as int?) ?? 5;
          
          // Update or insert store stock record
          final existing = await db.query(
            'store_stock',
            where: 'product_id = ? AND store_id = ?',
            whereArgs: [product.id, storeId],
          );
          
          if (existing.isNotEmpty) {
            // Update existing record
            await db.update(
              'store_stock',
              {
                'stock_quantity': stockQuantity,
                'min_stock_level': minStockLevel,
              },
              where: 'product_id = ? AND store_id = ?',
              whereArgs: [product.id, storeId],
            );
          } else {
            // Insert new record
            await db.insert('store_stock', {
              'product_id': product.id,
              'store_id': storeId,
              'stock_quantity': stockQuantity,
              'min_stock_level': minStockLevel,
            });
          }
        }
      }
    }
    
    return result;
  }

  // Save a data URI image to a local file and return the file path
  static Future<String?> _persistProductImage(int productId, String dataUri) async {
    try {
      // Extract mime/type and base64 bytes
      // Format: data:image/png;base64,xxxx
      final headerEnd = dataUri.indexOf(',');
      if (headerEnd == -1) return null;
      final header = dataUri.substring(0, headerEnd);
      final base64Str = dataUri.substring(headerEnd + 1);
      final bytes = base64Decode(base64Str);

      // Determine file extension
      String ext = 'png';
      final mimeStart = header.indexOf('image/');
      if (mimeStart != -1) {
        final mime = header.substring(mimeStart + 6); // after 'image/'
        final semi = mime.indexOf(';');
        final type = semi != -1 ? mime.substring(0, semi) : mime;
        if (type.isNotEmpty) ext = type;
      }

      // Build a safe app directory for images
      final dir = await getApplicationSupportDirectory();
      final imagesDir = Directory(join(dir.path, 'images', 'products'));
      if (!await imagesDir.exists()) {
        await imagesDir.create(recursive: true);
      }

      final filename = 'product_${productId}_${DateTime.now().millisecondsSinceEpoch}.$ext';
      final filePath = join(imagesDir.path, filename);
      final file = File(filePath);
      await file.writeAsBytes(bytes, flush: true);
      return file.path;
    } catch (e) {
      print('DatabaseService._persistProductImage error: $e');
      return null;
    }
  }

  static Future<int> deleteProduct(int id) async {
    final db = await database;
    
    // First delete related store_stock records
    await db.delete('store_stock', where: 'product_id = ?', whereArgs: [id]);
    
    // Then delete the product
    return await db.delete('products', where: 'id = ?', whereArgs: [id]);
  }

  // Stores CRUD
  static Future<int> insertStore(Store store) async {
    final db = await database;
    return await db.insert('stores', store.toMap());
  }

  static Future<List<Store>> getStores({bool? active}) async {
    final db = await database;
    String whereClause = '(type = ? OR type IS NULL) AND type != ?';
    List<dynamic> whereArgs = ['store', 'warehouse'];
    
    if (active != null) {
      whereClause += ' AND active = ?';
      whereArgs.add(active ? 1 : 0);
    }
    
    final List<Map<String, dynamic>> maps = await db.query(
      'stores',
      where: whereClause,
      whereArgs: whereArgs,
      orderBy: 'name ASC',
    );
    return List.generate(maps.length, (i) => Store.fromMap(maps[i]));
  }

  static Future<List<Store>> getWarehouses() async {
    final db = await database;
    final maps = await db.query('stores', where: 'type = ? AND active = 1', whereArgs: ['warehouse'], orderBy: 'name ASC');
    return List.generate(maps.length, (i) => Store.fromMap(maps[i]));
  }

  static Future<Store?> getMainWarehouse() async {
    final db = await database;
    final maps = await db.query('stores', where: 'type = ? AND active = 1', whereArgs: ['warehouse'], limit: 1);
    if (maps.isEmpty) return null;
    return Store.fromMap(maps.first);
  }

  // Get all stores and warehouses for management purposes
  static Future<List<Store>> getAllStoresAndWarehouses({bool? active}) async {
    final db = await database;
    String whereClause = '';
    List<dynamic> whereArgs = [];
    
    if (active != null) {
      whereClause = 'WHERE active = ?';
      whereArgs.add(active ? 1 : 0);
    }
    
    final List<Map<String, dynamic>> maps = await db.query(
      'stores',
      where: whereClause.isEmpty ? null : whereClause,
      whereArgs: whereArgs.isEmpty ? null : whereArgs,
      orderBy: 'type ASC, name ASC',
    );
    return List.generate(maps.length, (i) => Store.fromMap(maps[i]));
  }

  static Future<int> updateStore(Store store) async {
    final db = await database;
    return await db.update('stores', store.toMap(), where: 'id = ?', whereArgs: [store.id]);
  }

  // Store Stock
  static Future<List<Map<String, dynamic>>> getStoreStock(int storeId) async {
    final db = await database;
    final result = await db.rawQuery('''
      SELECT p.id, p.name, p.sku, p.price, p.category_id, p.active,
             ss.stock_quantity, ss.min_stock_level,
             c.name as category_name, c.color as category_color
      FROM products p
      JOIN store_stock ss ON p.id = ss.product_id
      JOIN categories c ON p.category_id = c.id
      WHERE ss.store_id = ? AND p.active = 1
      ORDER BY c.name ASC, p.name ASC
    ''', [storeId]);
    return result;
  }

  static Future<List<Map<String, dynamic>>> getAllStoreStock() async {
    final db = await database;
    final result = await db.rawQuery('''
      SELECT p.*, ss.product_id as product_id, ss.store_id as store_id,
             ss.stock_quantity as ss_stock_quantity,
             ss.min_stock_level as ss_min_stock_level,
             c.name as category_name, c.color as category_color, s.name as store_name
      FROM products p
      JOIN store_stock ss ON p.id = ss.product_id
      JOIN categories c ON p.category_id = c.id
      JOIN stores s ON ss.store_id = s.id
      WHERE p.active = 1
      ORDER BY p.name ASC, s.name ASC
    ''');
    return result;
  }

  // Search products for a specific store, returning product basics and current stock (default 0 if no record)
  static Future<List<Map<String, dynamic>>> searchProductsInStore({
    required int storeId,
    required String query,
    int limit = 20,
  }) async {
    final db = await database;
    final like = '%${query.replaceAll('%', '\\%').replaceAll('_', '\\_')}%';
    final result = await db.rawQuery('''
      SELECT 
        p.id AS product_id,
        p.name,
        p.sku,
        COALESCE(ss.stock_quantity, 0) AS ss_stock_quantity
      FROM products p
      LEFT JOIN store_stock ss ON ss.product_id = p.id AND ss.store_id = ?
      WHERE p.active = 1 AND (LOWER(p.name) LIKE LOWER(?) OR LOWER(p.sku) LIKE LOWER(?))
      ORDER BY p.name ASC
      LIMIT ?
    ''', [storeId, like, like, limit]);
    return result;
  }

  static Future<int> updateStoreStock(int storeId, int productId, int quantity) async {
    final db = await database;
    return await db.update(
      'store_stock',
      {'stock_quantity': quantity},
      where: 'store_id = ? AND product_id = ?',
      whereArgs: [storeId, productId],
    );
  }

  static Future<int> getProductStock(int productId, int? storeId) async {
    final db = await database;
    
    if (storeId == null) {
      // Get warehouse stock (assuming products table has a stock_quantity field for warehouse)
      final result = await db.query(
        'products',
        columns: ['stock_quantity'],
        where: 'id = ?',
        whereArgs: [productId],
      );
      if (result.isNotEmpty) {
        return result.first['stock_quantity'] as int? ?? 0;
      }
      return 0;
    } else {
      // Get store stock
      final result = await db.query(
        'store_stock',
        columns: ['stock_quantity'],
        where: 'product_id = ? AND store_id = ?',
        whereArgs: [productId, storeId],
      );
      if (result.isNotEmpty) {
        return result.first['stock_quantity'] as int? ?? 0;
      }
      return 0;
    }
  }

  // Aggregate total stock across all stores for each product
  static Future<Map<int, int>> getProductTotals({bool activeOnly = true}) async {
    final db = await database;
    final where = activeOnly ? 'WHERE p.active = 1' : '';
    final result = await db.rawQuery('''
      SELECT p.id as product_id, COALESCE(SUM(ss.stock_quantity), 0) as total_qty
      FROM products p
      LEFT JOIN store_stock ss ON ss.product_id = p.id
      LEFT JOIN stores s ON ss.store_id = s.id
      $where ${activeOnly ? 'AND' : 'WHERE'} (s.type = 'store' OR s.type IS NULL)
      GROUP BY p.id
    ''');
    final Map<int, int> totals = {};
    for (final row in result) {
      final pid = row['product_id'];
      final qty = row['total_qty'];
      final int? productId = pid is int ? pid : int.tryParse(pid?.toString() ?? '');
      final int total = qty is int
          ? qty
          : (qty is num ? qty.toInt() : int.tryParse(qty?.toString() ?? '0') ?? 0);
      if (productId != null) totals[productId] = total;
    }
    return totals;
  }

  // ==================== STOCK ADJUSTMENT HELPERS ====================
  static Future<String> getNextStockAdjustmentNumber() async {
    final db = await database;
    final now = DateTime.now();
    final dateStr = '${now.year.toString().padLeft(4, '0')}'
        '${now.month.toString().padLeft(2, '0')}'
        '${now.day.toString().padLeft(2, '0')}';
    final prefix = 'SA-$dateStr-';

    // Find the highest sequence for today
    final result = await db.rawQuery(
      'SELECT adjustment_number FROM stock_adjustments WHERE adjustment_number LIKE ? ORDER BY adjustment_number DESC LIMIT 1',
      ['$prefix%'],
    );

    int nextSeq = 1;
    if (result.isNotEmpty) {
      final last = result.first['adjustment_number']?.toString() ?? '';
      final parts = last.split('-');
      if (parts.isNotEmpty) {
        final seqStr = parts.last;
        final parsed = int.tryParse(seqStr);
        if (parsed != null) nextSeq = parsed + 1;
      }
    }

    final seqPadded = nextSeq.toString().padLeft(4, '0');
    return '$prefix$seqPadded';
  }

  // ==================== INVENTORY COUNT HELPERS ====================
  static Future<String> getNextInventoryCountNumber() async {
    final db = await database;
    final now = DateTime.now();
    final dateStr = '${now.year.toString().padLeft(4, '0')}'
        '${now.month.toString().padLeft(2, '0')}'
        '${now.day.toString().padLeft(2, '0')}';
    final prefix = 'IC-$dateStr-';

    final result = await db.rawQuery(
      'SELECT count_number FROM inventory_counts WHERE count_number LIKE ? ORDER BY count_number DESC LIMIT 1',
      ['$prefix%'],
    );

    int nextSeq = 1;
    if (result.isNotEmpty) {
      final last = result.first['count_number']?.toString() ?? '';
      final parts = last.split('-');
      if (parts.isNotEmpty) {
        final seqStr = parts.last;
        final parsed = int.tryParse(seqStr);
        if (parsed != null) nextSeq = parsed + 1;
      }
    }

    final seqPadded = nextSeq.toString().padLeft(4, '0');
    return '$prefix$seqPadded';
  }

  static Future<int> insertInventoryCount({
    required String countNumber,
    required int storeId,
    required String countType, // 'full_count' | 'partial_count'
    required String status, // 'in_progress' | 'completed' | 'cancelled'
    String? notes,
    required DateTime startedAt,
    DateTime? completedAt,
  }) async {
    try {
      final db = await database;
      return await db.insert('inventory_counts', {
        'count_number': countNumber,
        'store_id': storeId,
        'count_type': countType,
        'status': status,
        'notes': notes,
        'started_at': startedAt.toIso8601String(),
        'completed_at': completedAt?.toIso8601String(),
      });
    } catch (e) {
      if (e.toString().contains('read-only')) {
        // Force database recreation and retry
        await _initDatabase(force: true);
        final db = await database;
        return await db.insert('inventory_counts', {
          'count_number': countNumber,
          'store_id': storeId,
          'count_type': countType,
          'status': status,
          'notes': notes,
          'started_at': startedAt.toIso8601String(),
          'completed_at': completedAt?.toIso8601String(),
        });
      }
      rethrow;
    }
  }

  static Future<int> updateInventoryCount({
    required int id,
    int? storeId,
    String? countType,
    String? status,
    String? notes,
    DateTime? startedAt,
    DateTime? completedAt,
  }) async {
    try {
      final db = await database;
      final values = <String, Object?>{};
      if (storeId != null) values['store_id'] = storeId;
      if (countType != null) values['count_type'] = countType;
      if (status != null) values['status'] = status;
      if (notes != null) values['notes'] = notes;
      if (startedAt != null) values['started_at'] = startedAt.toIso8601String();
      if (completedAt != null) values['completed_at'] = completedAt.toIso8601String();
      return await db.update('inventory_counts', values, where: 'id = ?', whereArgs: [id]);
    } catch (e) {
      if (e.toString().contains('read-only')) {
        // Force database recreation and retry
        await _initDatabase(force: true);
        final db = await database;
        final values = <String, Object?>{};
        if (storeId != null) values['store_id'] = storeId;
        if (countType != null) values['count_type'] = countType;
        if (status != null) values['status'] = status;
        if (notes != null) values['notes'] = notes;
        if (startedAt != null) values['started_at'] = startedAt.toIso8601String();
        if (completedAt != null) values['completed_at'] = completedAt.toIso8601String();
        return await db.update('inventory_counts', values, where: 'id = ?', whereArgs: [id]);
      }
      rethrow;
    }
  }

  static Future<List<Map<String, dynamic>>> getInventoryCounts({
    String? status,
    int? storeId,
    String? countType,
  }) async {
    final db = await database;
    String whereClause = '';
    List<dynamic> whereArgs = [];
    if (status != null) {
      whereClause += '${whereClause.isEmpty ? '' : ' AND '}ic.status = ?';
      whereArgs.add(status);
    }
    if (storeId != null) {
      whereClause += '${whereClause.isEmpty ? '' : ' AND '}ic.store_id = ?';
      whereArgs.add(storeId);
    }
    if (countType != null) {
      whereClause += '${whereClause.isEmpty ? '' : ' AND '}ic.count_type = ?';
      whereArgs.add(countType);
    }

    final query = '''
      SELECT ic.*, s.name as store_name,
        (SELECT COUNT(*) FROM inventory_count_items ici WHERE ici.count_id = ic.id) as total_items,
        (SELECT COUNT(*) FROM inventory_count_items ici WHERE ici.count_id = ic.id AND ici.counted_qty IS NOT NULL) as counted_items
      FROM inventory_counts ic
      LEFT JOIN stores s ON ic.store_id = s.id
      ${whereClause.isNotEmpty ? 'WHERE $whereClause' : ''}
      ORDER BY ic.started_at DESC
    ''';
    return await db.rawQuery(query, whereArgs.isEmpty ? null : whereArgs);
  }

  static Future<Map<String, dynamic>?> getInventoryCount(int id) async {
    final db = await database;
    final header = await db.rawQuery('''
      SELECT ic.*, s.name as store_name
      FROM inventory_counts ic
      LEFT JOIN stores s ON ic.store_id = s.id
      WHERE ic.id = ?
    ''', [id]);
    if (header.isEmpty) return null;
    final items = await db.rawQuery('''
      SELECT ici.*, p.name as product_name, p.sku
      FROM inventory_count_items ici
      JOIN products p ON ici.product_id = p.id
      WHERE ici.count_id = ?
      ORDER BY p.name ASC
    ''', [id]);
    return {
      ...header.first,
      'items': items,
    };
  }

  static Future<void> saveInventoryCountItems(int countId, List<Map<String, dynamic>> items) async {
    try {
      final db = await database;
      final batch = db.batch();
      for (final it in items) {
        batch.insert(
          'inventory_count_items',
          {
            'count_id': countId,
            'product_id': it['product_id'],
            'expected_qty': it['expected_qty'] ?? it['expected'] ?? 0,
            'counted_qty': it['counted_qty'] ?? it['counted'],
          },
          conflictAlgorithm: ConflictAlgorithm.replace,
        );
      }
      await batch.commit(noResult: true);
    } catch (e) {
      if (e.toString().contains('read-only')) {
        // Force database recreation and retry
        await _initDatabase(force: true);
        final db = await database;
        final batch = db.batch();
        for (final it in items) {
          batch.insert(
            'inventory_count_items',
            {
              'count_id': countId,
              'product_id': it['product_id'],
              'expected_qty': it['expected_qty'] ?? it['expected'] ?? 0,
              'counted_qty': it['counted_qty'] ?? it['counted'],
            },
            conflictAlgorithm: ConflictAlgorithm.replace,
          );
        }
        await batch.commit(noResult: true);
      } else {
        rethrow;
      }
    }
  }

  static Future<void> completeInventoryCount(int countId) async {
    try {
      final db = await database;
      // Load items
      final items = await db.rawQuery('SELECT product_id, counted_qty FROM inventory_count_items WHERE count_id = ?', [countId]);
      // Get store
      final header = await db.query('inventory_counts', columns: ['store_id'], where: 'id = ?', whereArgs: [countId]);
      if (header.isEmpty) return;
      final storeId = header.first['store_id'] as int;

      // Apply counted quantities to store_stock
      for (final row in items) {
        final pid = row['product_id'] as int;
        final counted = row['counted_qty'] as int? ?? 0;
        await db.update('store_stock', {'stock_quantity': counted}, where: 'store_id = ? AND product_id = ?', whereArgs: [storeId, pid]);
      }

      // Update header
      await db.update(
        'inventory_counts',
        {
          'status': 'completed',
          'completed_at': DateTime.now().toIso8601String(),
        },
        where: 'id = ?',
        whereArgs: [countId],
      );
    } catch (e) {
      if (e.toString().contains('read-only')) {
        // Force database recreation and retry
        await _initDatabase(force: true);
        final db = await database;
        // Load items
        final items = await db.rawQuery('SELECT product_id, counted_qty FROM inventory_count_items WHERE count_id = ?', [countId]);
        // Get store
        final header = await db.query('inventory_counts', columns: ['store_id'], where: 'id = ?', whereArgs: [countId]);
        if (header.isEmpty) return;
        final storeId = header.first['store_id'] as int;

        // Apply counted quantities to store_stock
        for (final row in items) {
          final pid = row['product_id'] as int;
          final counted = row['counted_qty'] as int? ?? 0;
          await db.update('store_stock', {'stock_quantity': counted}, where: 'store_id = ? AND product_id = ?', whereArgs: [storeId, pid]);
        }

        // Update header
        await db.update(
          'inventory_counts',
          {
            'status': 'completed',
            'completed_at': DateTime.now().toIso8601String(),
          },
          where: 'id = ?',
          whereArgs: [countId],
        );
      } else {
        rethrow;
      }
    }
  }

  // Employees CRUD
  static Future<int> insertEmployee(Employee employee) async {
    final db = await database;
    return await db.insert('employees', employee.toMap());
  }

  static Future<List<Employee>> getEmployees({bool? active}) async {
    final db = await database;
    final List<Map<String, dynamic>> maps = await db.query(
      'employees',
      where: active != null ? 'active = ?' : null,
      whereArgs: active != null ? [active ? 1 : 0] : null,
      orderBy: 'name ASC',
    );
    return List.generate(maps.length, (i) => Employee.fromMap(maps[i]));
  }

  static Future<Employee?> authenticateEmployee(String username, String password) async {
    final db = await database;
    final hashedPassword = _hashPassword(password);
    final List<Map<String, dynamic>> maps = await db.query(
      'employees',
      where: 'username = ? AND password_hash = ? AND active = 1',
      whereArgs: [username, hashedPassword],
    );
    if (maps.isEmpty) return null;
    return Employee.fromMap(maps.first);
  }

  static Future<Employee?> authenticateByPin(String pin, int storeId) async {
    final db = await database;
    final List<Map<String, dynamic>> maps = await db.query(
      'employees',
      where: 'pin = ? AND active = 1',
      whereArgs: [pin],
    );
    
    if (maps.isEmpty) return null;
    
    final employee = Employee.fromMap(maps.first);
    final assignedStores = (jsonDecode(employee.assignedStoreIds) as List).cast<int>();
    
    if (assignedStores.contains(storeId)) {
      return employee;
    }
    
    return null;
  }

  static Future<int> updateEmployee(Employee employee) async {
    final db = await database;
    return await db.update('employees', employee.toMap(), where: 'id = ?', whereArgs: [employee.id]);
  }

  // Customers CRUD
  static Future<int> insertCustomer(Customer customer) async {
    final db = await database;
    return await db.insert('customers', customer.toMap());
  }

  static Future<List<Customer>> getCustomers() async {
    final db = await database;
    final List<Map<String, dynamic>> maps = await db.query('customers', orderBy: 'name ASC');
    return List.generate(maps.length, (i) => Customer.fromMap(maps[i]));
  }

  static Future<int> updateCustomer(Customer customer) async {
    final db = await database;
    return await db.update('customers', customer.toMap(), where: 'id = ?', whereArgs: [customer.id]);
  }

  static Future<int> deleteCustomer(int id) async {
    final db = await database;
    return await db.delete('customers', where: 'id = ?', whereArgs: [id]);
  }

  // Sales
  static Future<int> insertSale(Sale sale, List<SaleItem> items) async {
    final db = await database;
    
    // Insert sale
    int saleId = await db.insert('sales', sale.toMap());
    
    // Insert sale items
    for (var item in items) {
      await db.insert('sale_items', item.toMap());
      
      // Update stock
      await safeUpdate('''
        UPDATE store_stock 
        SET stock_quantity = stock_quantity - ? 
        WHERE store_id = ? AND product_id = ?
      ''', [item.quantity, sale.storeId, item.productId]);
    }
    
    // Update shift if exists
    if (sale.shiftId != null) {
      await safeUpdate('''
        UPDATE shifts 
        SET gross_sales = gross_sales + ? 
        WHERE id = ?
      ''', [sale.totalAmount, sale.shiftId]);
    }
    
    return saleId;
  }

  static Future<List<Map<String, dynamic>>> getSales({
    int? storeId,
    int? employeeId,
    String? paymentMethod,
    DateTime? startDate,
    DateTime? endDate,
  }) async {
    final db = await database;
    String whereClause = '';
    List<dynamic> whereArgs = [];
    
    if (storeId != null) {
      whereClause = 'store_id = ?';
      whereArgs.add(storeId);
    }
    
    if (employeeId != null) {
      if (whereClause.isNotEmpty) whereClause += ' AND ';
      whereClause += 'employee_id = ?';
      whereArgs.add(employeeId);
    }
    
    if (paymentMethod != null) {
      if (whereClause.isNotEmpty) whereClause += ' AND ';
      whereClause += 'payment_method = ?';
      whereArgs.add(paymentMethod);
    }
    
    if (startDate != null) {
      if (whereClause.isNotEmpty) whereClause += ' AND ';
      whereClause += 'sale_date >= ?';
      whereArgs.add(startDate.toIso8601String());
    }
    
    if (endDate != null) {
      if (whereClause.isNotEmpty) whereClause += ' AND ';
      whereClause += 'sale_date <= ?';
      whereArgs.add(endDate.toIso8601String());
    }
    
    return await db.query(
      'sales',
      where: whereClause.isEmpty ? null : whereClause,
      whereArgs: whereArgs.isEmpty ? null : whereArgs,
      orderBy: 'sale_date DESC',
    );
  }

  static Future<List<Map<String, dynamic>>> getSaleItems(int saleId) async {
    final db = await database;
    return await db.rawQuery('''
      SELECT si.*, p.name as product_name
      FROM sale_items si
      JOIN products p ON si.product_id = p.id
      WHERE si.sale_id = ?
    ''', [saleId]);
  }

  // Shifts
  static Future<int> startShift(Shift shift) async {
    final db = await database;
    return await db.insert('shifts', shift.toMap());
  }

  static Future<Shift?> getOpenShift(int employeeId, int storeId) async {
    final db = await database;
    final List<Map<String, dynamic>> maps = await db.query(
      'shifts',
      where: 'employee_id = ? AND store_id = ? AND status = ?',
      whereArgs: [employeeId, storeId, 'open'],
    );
    if (maps.isEmpty) return null;
    return Shift.fromMap(maps.first);
  }

  static Future<int> endShift(int shiftId, double endingCash) async {
    final db = await database;
    
    // Get shift details
    final shift = await db.query('shifts', where: 'id = ?', whereArgs: [shiftId]);
    if (shift.isEmpty) return 0;
    
  final startingCash = (shift.first['starting_cash'] as num).toDouble();
  // grossSales is already reflected in sales rows; keep for future use if needed
  // final grossSales = (shift.first['gross_sales'] as num).toDouble();
    
    // Calculate expected cash (starting + cash sales)
    final cashSales = await db.rawQuery('''
      SELECT COALESCE(SUM(total_amount), 0) as total
      FROM sales
      WHERE shift_id = ? AND payment_method = 'Cash'
    ''', [shiftId]);
    
    final expectedCash = startingCash + ((cashSales.first['total'] as num).toDouble());
    final variance = endingCash - expectedCash;
    
    return await db.update(
      'shifts',
      {
        'end_time': DateTime.now().toIso8601String(),
        'ending_cash': endingCash,
        'cash_variance': variance,
        'status': 'closed',
      },
      where: 'id = ?',
      whereArgs: [shiftId],
    );
  }

  static Future<List<Shift>> getShifts({int? employeeId, int? storeId}) async {
    final db = await database;
    String whereClause = '';
    List<dynamic> whereArgs = [];
    
    if (employeeId != null) {
      whereClause = 'employee_id = ?';
      whereArgs.add(employeeId);
    }
    
    if (storeId != null) {
      if (whereClause.isNotEmpty) whereClause += ' AND ';
      whereClause += 'store_id = ?';
      whereArgs.add(storeId);
    }
    
    final List<Map<String, dynamic>> maps = await db.query(
      'shifts',
      where: whereClause.isEmpty ? null : whereClause,
      whereArgs: whereArgs.isEmpty ? null : whereArgs,
      orderBy: 'start_time DESC',
    );
    return List.generate(maps.length, (i) => Shift.fromMap(maps[i]));
  }

  // Get active shift for today only
  static Future<Shift?> getActiveShift({required int employeeId, required int storeId}) async {
    final db = await database;
    
    // Get today's date range
    final now = DateTime.now();
    final startOfDay = DateTime(now.year, now.month, now.day);
    final endOfDay = DateTime(now.year, now.month, now.day, 23, 59, 59);
    
    final List<Map<String, dynamic>> maps = await db.query(
      'shifts',
      where: 'employee_id = ? AND store_id = ? AND status = ? AND start_time >= ? AND start_time <= ?',
      whereArgs: [
        employeeId,
        storeId,
        'open',
        startOfDay.toIso8601String(),
        endOfDay.toIso8601String(),
      ],
      limit: 1,
    );
    
    if (maps.isEmpty) return null;
    return Shift.fromMap(maps.first);
  }

  // Insert new shift
  static Future<int> insertShift(Shift shift) async {
    final db = await database;
    return await db.insert('shifts', shift.toMap());
  }

  // Update shift
  static Future<int> updateShift(Shift shift) async {
    final db = await database;
    return await db.update('shifts', shift.toMap(), where: 'id = ?', whereArgs: [shift.id]);
  }

  // Close shift
  static Future<int> closeShift(int shiftId, {required double endingCash}) async {
    final db = await database;
    final shift = await getShiftById(shiftId);
    if (shift == null) throw 'Shift not found';
    
    final closedShift = shift.copyWith(
      endTime: DateTime.now(),
      endingCash: endingCash,
      cashVariance: endingCash - shift.startingCash,
      status: 'closed',
    );
    
    return await db.update('shifts', closedShift.toMap(), where: 'id = ?', whereArgs: [shiftId]);
  }

  // Get shift by ID
  static Future<Shift?> getShiftById(int id) async {
    final db = await database;
    final List<Map<String, dynamic>> maps = await db.query(
      'shifts',
      where: 'id = ?',
      whereArgs: [id],
      limit: 1,
    );
    
    if (maps.isEmpty) return null;
    return Shift.fromMap(maps.first);
  }

  // Record sale in shift
  static Future<void> updateShiftSales(int shiftId, double saleAmount) async {
    await safeUpdate('''
      UPDATE shifts 
      SET total_sales = total_sales + ?, 
          total_transactions = total_transactions + 1,
          gross_sales = gross_sales + ?
      WHERE id = ?
    ''', [saleAmount, saleAmount, shiftId]);
  }

  // Get sales for current shift - simplified approach
  static Future<List<Map<String, dynamic>>> getShiftSales(int shiftId) async {
    try {
      final db = await database;
      
      // Use simple table queries instead of complex JOINs
      final List<Map<String, dynamic>> sales = await db.query(
        'sales',
        where: 'shift_id = ?',
        whereArgs: [shiftId],
        orderBy: 'created_at DESC',
      );
      
      if (sales.isEmpty) {
        return [];
      }
      
      // Get customer names separately
      final customerIds = sales
          .where((s) => s['customer_id'] != null)
          .map((s) => s['customer_id'])
          .toSet();
      
      Map<int, String> customerNames = {};
      if (customerIds.isNotEmpty) {
        final customers = await db.query(
          'customers',
          where: 'id IN (${customerIds.join(',')})',
        );
        for (var customer in customers) {
          customerNames[customer['id'] as int] = customer['name'] as String;
        }
      }
      
      // Get sale items separately
      final saleIds = sales.map((s) => s['id'] as int).toList();
      final Map<int, List<Map<String, dynamic>>> itemsBySaleId = {};
      
      for (var saleId in saleIds) {
        final saleItems = await db.query(
          'sale_items',
          where: 'sale_id = ?',
          whereArgs: [saleId],
        );
        
        // Get product names for items
        for (var item in saleItems) {
          final productId = item['product_id'] as int;
          final product = await db.query(
            'products',
            where: 'id = ?',
            whereArgs: [productId],
            limit: 1,
          );
          if (product.isNotEmpty) {
            item['product_name'] = product.first['name'];
            item['sku'] = product.first['sku'];
          }
        }
        
        itemsBySaleId[saleId] = saleItems;
      }
      
      // Combine data
      final result = <Map<String, dynamic>>[];
      for (var sale in sales) {
        final saleId = sale['id'] as int;
        final customerId = sale['customer_id'] as int?;
        
        final enrichedSale = Map<String, dynamic>.from(sale);
        enrichedSale['customer_name'] = customerId != null ? customerNames[customerId] : null;
        enrichedSale['items'] = itemsBySaleId[saleId] ?? [];
        
        result.add(enrichedSale);
      }
      
      return result;
      
    } catch (e) {
      print('Error loading shift sales: $e');
      return [];
    }
  }

  // Settings
  static Future<String?> getSetting(String key) async {
    final db = await database;
    final List<Map<String, dynamic>> maps = await db.query(
      'settings',
      where: 'key = ?',
      whereArgs: [key],
    );
    if (maps.isEmpty) return null;
    return maps.first['value'] as String;
  }

  static Future<int> setSetting(String key, String value) async {
    final db = await database;
    final existing = await getSetting(key);
    
    if (existing != null) {
      return await db.update(
        'settings',
        {'value': value},
        where: 'key = ?',
        whereArgs: [key],
      );
    } else {
      return await db.insert('settings', {'key': key, 'value': value});
    }
  }

  // Dashboard Stats
  static Future<Map<String, dynamic>> getDashboardStats(int? storeId) async {
    final db = await database;
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);
    final weekStart = today.subtract(Duration(days: today.weekday - 1));
    final monthStart = DateTime(now.year, now.month, 1);
    
    // Total sales today
    final todaySales = await db.rawQuery('''
      SELECT COALESCE(SUM(total_amount), 0) as total
      FROM sales
      WHERE sale_date >= ?
      ${storeId != null ? 'AND store_id = ?' : ''}
    ''', storeId != null ? [today.toIso8601String(), storeId] : [today.toIso8601String()]);
    
    // Total sales this week
    final weekSales = await db.rawQuery('''
      SELECT COALESCE(SUM(total_amount), 0) as total
      FROM sales
      WHERE sale_date >= ?
      ${storeId != null ? 'AND store_id = ?' : ''}
    ''', storeId != null ? [weekStart.toIso8601String(), storeId] : [weekStart.toIso8601String()]);
    
    // Total sales this month
    final monthSales = await db.rawQuery('''
      SELECT COALESCE(SUM(total_amount), 0) as total
      FROM sales
      WHERE sale_date >= ?
      ${storeId != null ? 'AND store_id = ?' : ''}
    ''', storeId != null ? [monthStart.toIso8601String(), storeId] : [monthStart.toIso8601String()]);
    
    // Active inventory count
    final inventoryCount = await db.rawQuery('SELECT COUNT(*) as count FROM products WHERE active = 1');
    
    // Low stock alerts
    final lowStockCount = await db.rawQuery('''
      SELECT COUNT(*) as count
      FROM store_stock ss
      JOIN products p ON ss.product_id = p.id
      WHERE ss.stock_quantity <= ss.min_stock_level 
      AND p.active = 1
      ${storeId != null ? 'AND ss.store_id = ?' : ''}
    ''', storeId != null ? [storeId] : null);
    
    // Active stores count
    final storesCount = await db.rawQuery('SELECT COUNT(*) as count FROM stores WHERE active = 1');
    
    // Top 5 selling products
    final topProducts = await db.rawQuery('''
      SELECT p.name, SUM(si.quantity) as total_sold, SUM(si.line_total) as revenue
      FROM sale_items si
      JOIN products p ON si.product_id = p.id
      JOIN sales s ON si.sale_id = s.id
      ${storeId != null ? 'WHERE s.store_id = ?' : ''}
      GROUP BY p.id
      ORDER BY total_sold DESC
      LIMIT 5
    ''', storeId != null ? [storeId] : null);
    
    // Recent transactions
    final recentTransactions = await db.rawQuery('''
      SELECT s.*, e.name as employee_name, st.name as store_name
      FROM sales s
      JOIN employees e ON s.employee_id = e.id
      JOIN stores st ON s.store_id = st.id
      ${storeId != null ? 'WHERE s.store_id = ?' : ''}
      ORDER BY s.sale_date DESC
      LIMIT 10
    ''', storeId != null ? [storeId] : null);
    
    return {
      'todaySales': (todaySales.first['total'] as num).toDouble(),
      'weekSales': (weekSales.first['total'] as num).toDouble(),
      'monthSales': (monthSales.first['total'] as num).toDouble(),
      'inventoryCount': inventoryCount.first['count'] as int,
      'lowStockCount': lowStockCount.first['count'] as int,
      'storesCount': storesCount.first['count'] as int,
      'topProducts': topProducts,
      'recentTransactions': recentTransactions,
    };
  }

  // ==================== SUPPLIERS ====================

  static Future<int> insertSupplier(Supplier supplier) async {
    final db = await database;
    return await db.insert('suppliers', supplier.toMap());
  }

  static Future<List<Supplier>> getSuppliers({bool activeOnly = false}) async {
    final db = await database;
    final List<Map<String, dynamic>> maps = await db.query(
      'suppliers',
      where: activeOnly ? 'active = ?' : null,
      whereArgs: activeOnly ? [1] : null,
      orderBy: 'name ASC',
    );
    return List.generate(maps.length, (i) => Supplier.fromMap(maps[i]));
  }

  static Future<Supplier?> getSupplier(int id) async {
    final db = await database;
    final List<Map<String, dynamic>> maps = await db.query(
      'suppliers',
      where: 'id = ?',
      whereArgs: [id],
    );
    if (maps.isEmpty) return null;
    return Supplier.fromMap(maps.first);
  }

  static Future<int> updateSupplier(Supplier supplier) async {
    final db = await database;
    return await db.update(
      'suppliers',
      supplier.toMap(),
      where: 'id = ?',
      whereArgs: [supplier.id],
    );
  }

  static Future<int> deleteSupplier(int id) async {
    final db = await database;
    return await db.delete(
      'suppliers',
      where: 'id = ?',
      whereArgs: [id],
    );
  }

  // ==================== PURCHASE ORDERS ====================

  static Future<int> insertPurchaseOrder(PurchaseOrder po, List<PurchaseOrderItem> items) async {
    final db = await database;

    // Insert purchase order
    final poId = await db.insert('purchase_orders', po.toMap());

    // Insert items
    for (var item in items) {
      await db.insert('purchase_order_items', {
        ...item.toMap(),
        'purchase_order_id': poId,
      });
    }

    return poId;
  }

  static Future<List<Map<String, dynamic>>> getPurchaseOrders({
    String? status,
    int? supplierId,
  }) async {
    final db = await database;

    String whereClause = '';
    List<dynamic> whereArgs = [];

    if (status != null) {
      whereClause = 'po.status = ?';
      whereArgs.add(status);
    }

    if (supplierId != null) {
      if (whereClause.isNotEmpty) whereClause += ' AND ';
      whereClause += 'po.supplier_id = ?';
      whereArgs.add(supplierId);
    }

    final query = '''
      SELECT po.*, s.name as supplier_name, e.name as created_by_name
      FROM purchase_orders po
      LEFT JOIN suppliers s ON po.supplier_id = s.id
      LEFT JOIN employees e ON po.created_by = e.id
      ${whereClause.isNotEmpty ? 'WHERE $whereClause' : ''}
      ORDER BY po.created_at DESC
    ''';

    return await db.rawQuery(query, whereArgs.isNotEmpty ? whereArgs : null);
  }

  static Future<Map<String, dynamic>?> getPurchaseOrder(int id) async {
    final db = await database;

    final poResult = await db.rawQuery('''
      SELECT po.*, s.name as supplier_name, e.name as created_by_name
      FROM purchase_orders po
      LEFT JOIN suppliers s ON po.supplier_id = s.id
      LEFT JOIN employees e ON po.created_by = e.id
      WHERE po.id = ?
    ''', [id]);

    if (poResult.isEmpty) return null;

    final items = await db.rawQuery('''
      SELECT poi.*, p.name as product_name, p.sku
      FROM purchase_order_items poi
      JOIN products p ON poi.product_id = p.id
      WHERE poi.purchase_order_id = ?
    ''', [id]);

    return {
      ...poResult.first,
      'items': items,
    };
  }

  static Future<int> updatePurchaseOrder(PurchaseOrder po) async {
    final db = await database;
    return await db.update(
      'purchase_orders',
      po.toMap(),
      where: 'id = ?',
      whereArgs: [po.id],
    );
  }

  static Future<void> receivePurchaseOrder(int poId, int storeId) async {
    final db = await database;

    // Get PO items
    final items = await db.query(
      'purchase_order_items',
      where: 'purchase_order_id = ?',
      whereArgs: [poId],
    );

    // Update stock for each item
    for (var item in items) {
      final productId = item['product_id'] as int;
      final quantity = item['quantity'] as int;

      // Get current stock
      final currentStock = await db.query(
        'store_stock',
        where: 'store_id = ? AND product_id = ?',
        whereArgs: [storeId, productId],
      );

      if (currentStock.isEmpty) {
        // Insert new stock record
        await db.insert('store_stock', {
          'store_id': storeId,
          'product_id': productId,
          'stock_quantity': quantity,
          'min_stock_level': 5,
        });
      } else {
        // Update existing stock
        final currentQty = currentStock.first['stock_quantity'] as int;
        await db.update(
          'store_stock',
          {'stock_quantity': currentQty + quantity},
          where: 'store_id = ? AND product_id = ?',
          whereArgs: [storeId, productId],
        );
      }
    }

    // Update PO status
    await db.update(
      'purchase_orders',
      {
        'status': 'received',
        'received_at': DateTime.now().toIso8601String(),
      },
      where: 'id = ?',
      whereArgs: [poId],
    );
  }

  // ==================== STOCK ADJUSTMENTS ====================

  static Future<int> insertStockAdjustment(StockAdjustment adjustment) async {
    try {
      final db = await database;
      return await db.insert('stock_adjustments', adjustment.toMap());
    } catch (e) {
      if (e.toString().contains('read-only')) {
        // Force database recreation and retry
        await _initDatabase(force: true);
        final db = await database;
        return await db.insert('stock_adjustments', adjustment.toMap());
      }
      rethrow;
    }
  }

  static Future<int> insertStockAdjustmentItem(StockAdjustmentItem item) async {
    try {
      final db = await database;
      return await db.insert('stock_adjustment_items', item.toMap());
    } catch (e) {
      if (e.toString().contains('read-only')) {
        // Force database recreation and retry
        await _initDatabase(force: true);
        final db = await database;
        return await db.insert('stock_adjustment_items', item.toMap());
      }
      rethrow;
    }
  }

  static Future<List<Map<String, dynamic>>> getStockAdjustments({
    String? reason,
    String? status,
    int? storeId,
    int? employeeId,
  }) async {
    final db = await database;

    String whereClause = '';
    List<dynamic> whereArgs = [];

    if (reason != null) {
      whereClause = 'sa.reason = ?';
      whereArgs.add(reason);
    }

    if (status != null) {
      if (whereClause.isNotEmpty) whereClause += ' AND ';
      whereClause += 'sa.status = ?';
      whereArgs.add(status);
    }

    if (storeId != null) {
      if (whereClause.isNotEmpty) whereClause += ' AND ';
      whereClause += 'sa.store_id = ?';
      whereArgs.add(storeId);
    }

    if (employeeId != null) {
      if (whereClause.isNotEmpty) whereClause += ' AND ';
      whereClause += 'sa.employee_id = ?';
      whereArgs.add(employeeId);
    }

    final query = '''
      SELECT sa.*, s.name as store_name, e.name as employee_name
      FROM stock_adjustments sa
      LEFT JOIN stores s ON sa.store_id = s.id
      LEFT JOIN employees e ON sa.employee_id = e.id
      ${whereClause.isNotEmpty ? 'WHERE $whereClause' : ''}
      ORDER BY sa.created_at DESC
    ''';

    return await db.rawQuery(query, whereArgs.isNotEmpty ? whereArgs : null);
  }

  static Future<Map<String, dynamic>?> getStockAdjustment(int id) async {
    final db = await database;

    final adjustmentResult = await db.rawQuery('''
      SELECT sa.*, s.name as store_name, e.name as employee_name
      FROM stock_adjustments sa
      LEFT JOIN stores s ON sa.store_id = s.id
      LEFT JOIN employees e ON sa.employee_id = e.id
      WHERE sa.id = ?
    ''', [id]);

    if (adjustmentResult.isEmpty) return null;

    final items = await db.rawQuery('''
      SELECT sai.*, p.name as product_name, p.sku
      FROM stock_adjustment_items sai
      JOIN products p ON sai.product_id = p.id
      WHERE sai.adjustment_id = ?
    ''', [id]);

    return {
      ...adjustmentResult.first,
      'items': items,
    };
  }

  static Future<int> updateStockAdjustment(StockAdjustment adjustment) async {
    final db = await database;
    return await db.update(
      'stock_adjustments',
      adjustment.toMap(),
      where: 'id = ?',
      whereArgs: [adjustment.id],
    );
  }

  static Future<List<Map<String, dynamic>>> getStockAdjustmentItems(int adjustmentId) async {
    final db = await database;
    return await db.rawQuery('''
      SELECT sai.*, p.name as product_name, p.sku
      FROM stock_adjustment_items sai
      JOIN products p ON sai.product_id = p.id
      WHERE sai.adjustment_id = ?
    ''', [adjustmentId]);
  }

  static Future<void> completeStockAdjustment(int adjustmentId, int storeId, List<Map<String, dynamic>> items) async {
    try {
      final db = await database;

      // Insert adjustment items and update stock
      for (var item in items) {
        final productId = item['product_id'] as int;
        final quantityBefore = item['quantity_before'] as int;
        final quantityAfter = item['quantity_after'] as int;
        final quantityChange = quantityAfter - quantityBefore;

        // Insert adjustment item
        await db.insert('stock_adjustment_items', {
          'adjustment_id': adjustmentId,
          'product_id': productId,
          'quantity_before': quantityBefore,
          'quantity_after': quantityAfter,
          'quantity_change': quantityChange,
          'notes': item['notes'],
        });

        // Update stock quantity
        await db.update(
          'store_stock',
          {'stock_quantity': quantityAfter},
          where: 'store_id = ? AND product_id = ?',
          whereArgs: [storeId, productId],
        );
      }

      // Update adjustment status
      await db.update(
        'stock_adjustments',
        {
          'status': 'completed',
          'completed_at': DateTime.now().toIso8601String(),
        },
        where: 'id = ?',
        whereArgs: [adjustmentId],
      );
    } catch (e) {
      if (e.toString().contains('read-only')) {
        // Force database recreation and retry
        await _initDatabase(force: true);
        final db = await database;

        // Insert adjustment items and update stock
        for (var item in items) {
          final productId = item['product_id'] as int;
          final quantityBefore = item['quantity_before'] as int;
          final quantityAfter = item['quantity_after'] as int;
          final quantityChange = quantityAfter - quantityBefore;

          // Insert adjustment item
          await db.insert('stock_adjustment_items', {
            'adjustment_id': adjustmentId,
            'product_id': productId,
            'quantity_before': quantityBefore,
            'quantity_after': quantityAfter,
            'quantity_change': quantityChange,
            'notes': item['notes'],
          });

          // Update stock quantity
          await db.update(
            'store_stock',
            {'stock_quantity': quantityAfter},
            where: 'store_id = ? AND product_id = ?',
            whereArgs: [storeId, productId],
          );
        }

        // Update adjustment status
        await db.update(
          'stock_adjustments',
          {
            'status': 'completed',
            'completed_at': DateTime.now().toIso8601String(),
          },
          where: 'id = ?',
          whereArgs: [adjustmentId],
        );
      } else {
        rethrow;
      }
    }
  }

  // Receive stock into a location (warehouse or store). Creates and completes an adjustment.
  static Future<int> receiveStock({
    required int storeId,
    required List<Map<String, dynamic>> items, // [{product_id, quantity}]
    String? notes,
  }) async {
    final adjNumber = await getNextStockAdjustmentNumber();
    final adjId = await insertStockAdjustment(StockAdjustment(
      adjustmentNumber: adjNumber,
      reason: 'receive_items',
      status: 'in_progress',
      storeId: storeId,
      employeeId: null,
      notes: notes,
      createdAt: DateTime.now(),
    ));

    // Build items with before/after
    final List<Map<String, dynamic>> adjItems = [];
    for (final it in items) {
      final pid = it['product_id'] as int;
      final qty = (it['quantity'] as num).toInt();
      final before = await getProductStock(pid, storeId);
      final after = before + qty;
      adjItems.add({
        'product_id': pid,
        'quantity_before': before,
        'quantity_after': after,
        'notes': null,
      });
    }

    await completeStockAdjustment(adjId, storeId, adjItems);
    return adjId;
  }

  // Transfer stock between locations by creating paired adjustments.
  static Future<Map<String, int>> transferStock({
    required int fromStoreId,
    required int toStoreId,
    required List<Map<String, dynamic>> items, // [{product_id, quantity}]
    String? notes,
  }) async {
    // Transfer out from source
    final outNumber = await getNextStockAdjustmentNumber();
    final outId = await insertStockAdjustment(StockAdjustment(
      adjustmentNumber: outNumber,
      reason: 'transfer_out',
      status: 'in_progress',
      storeId: fromStoreId,
      employeeId: null,
      notes: notes,
      createdAt: DateTime.now(),
    ));
    final List<Map<String, dynamic>> outItems = [];
    for (final it in items) {
      final pid = it['product_id'] as int;
      final qty = (it['quantity'] as num).toInt();
      final before = await getProductStock(pid, fromStoreId);
      final after = (before - qty).clamp(0, 1 << 31);
      outItems.add({
        'product_id': pid,
        'quantity_before': before,
        'quantity_after': after,
        'notes': null,
      });
    }
    await completeStockAdjustment(outId, fromStoreId, outItems);

    // Transfer in to destination
    final inNumber = await getNextStockAdjustmentNumber();
    final inId = await insertStockAdjustment(StockAdjustment(
      adjustmentNumber: inNumber,
      reason: 'transfer_in',
      status: 'in_progress',
      storeId: toStoreId,
      employeeId: null,
      notes: notes,
      createdAt: DateTime.now(),
    ));
    final List<Map<String, dynamic>> inItems = [];
    for (final it in items) {
      final pid = it['product_id'] as int;
      final qty = (it['quantity'] as num).toInt();
      final before = await getProductStock(pid, toStoreId);
      final after = before + qty;
      inItems.add({
        'product_id': pid,
        'quantity_before': before,
        'quantity_after': after,
        'notes': null,
      });
    }
    await completeStockAdjustment(inId, toStoreId, inItems);

    return {'transfer_out': outId, 'transfer_in': inId};
  }

  static Future<int> deleteStockAdjustment(int id) async {
    final db = await database;

    // Delete items first
    await db.delete(
      'stock_adjustment_items',
      where: 'adjustment_id = ?',
      whereArgs: [id],
    );

    // Delete adjustment
    return await db.delete(
      'stock_adjustments',
      where: 'id = ?',
      whereArgs: [id],
    );
  }

  // ==================== INVENTORY VALUATION ====================

  static Future<Map<String, dynamic>> getInventoryValuation({int? storeId}) async {
    final db = await database;

    String whereClause = storeId != null ? 'WHERE ss.store_id = ?' : '';
    List<dynamic> whereArgs = storeId != null ? [storeId] : [];

    final result = await db.rawQuery('''
      SELECT
        p.id,
        p.name,
        p.sku,
        p.price,
        p.cost,
        c.name as category_name,
        SUM(ss.stock_quantity) as total_quantity,
        SUM(ss.stock_quantity * COALESCE(p.cost, 0)) as total_cost,
        SUM(ss.stock_quantity * p.price) as total_retail
      FROM products p
      JOIN categories c ON p.category_id = c.id
      LEFT JOIN store_stock ss ON p.id = ss.product_id
      $whereClause
      GROUP BY p.id
      HAVING total_quantity > 0
      ORDER BY total_cost DESC
    ''', whereArgs.isNotEmpty ? whereArgs : null);

    double totalUnits = 0;
    double totalCost = 0;
    double totalRetail = 0;

    for (var row in result) {
      totalUnits += (row['total_quantity'] as num).toDouble();
      totalCost += (row['total_cost'] as num).toDouble();
      totalRetail += (row['total_retail'] as num).toDouble();
    }

    return {
      'items': result,
      'totalUnits': totalUnits,
      'totalCost': totalCost,
      'totalRetail': totalRetail,
      'grossMargin': totalRetail > 0 ? ((totalRetail - totalCost) / totalRetail * 100) : 0,
    };
  }

  static Future<void> updateProductStock(int productId, int storeId, int newQuantity) async {
    final db = await database;
    
    // Check if store_stock record exists
    final existing = await db.query(
      'store_stock',
      where: 'product_id = ? AND store_id = ?',
      whereArgs: [productId, storeId],
    );

    if (existing.isNotEmpty) {
      // Update existing store_stock
      await db.update(
        'store_stock',
        {'stock_quantity': newQuantity},
        where: 'product_id = ? AND store_id = ?',
        whereArgs: [productId, storeId],
      );
    } else {
      // Create new store_stock record
      await db.insert('store_stock', {
        'product_id': productId,
        'store_id': storeId,
        'stock_quantity': newQuantity,
        'min_stock_level': 5,
      });
    }
  }

  static Future<void> ensureAllProductsHaveStockRecords() async {
    final db = await database;
    
    // Get all products and stores
    final products = await db.query('products', where: 'active = 1');
    final stores = await db.query('stores', where: 'active = 1');
    
    for (final product in products) {
      final productId = product['id'] as int;
      
      for (final store in stores) {
        final storeId = store['id'] as int;
        
        // Check if stock record exists
        final existing = await db.query(
          'store_stock',
          where: 'product_id = ? AND store_id = ?',
          whereArgs: [productId, storeId],
        );
        
        if (existing.isEmpty) {
          // Create missing stock record with 0 quantity
          await db.insert('store_stock', {
            'product_id': productId,
            'store_id': storeId,
            'stock_quantity': 0,
            'min_stock_level': 5,
          });
        }
      }
    }
  }

  static Future<List<Map<String, dynamic>>> getLowStockProducts([int? storeId]) async {
    final db = DatabaseService._database;
    
    // Get all low stock products with their details
    final lowStockProducts = await db!.rawQuery('''
      SELECT 
        p.name,
        p.sku,
        ss.stock_quantity,
        ss.min_stock_level,
        s.name as store_name
      FROM store_stock ss
      JOIN products p ON ss.product_id = p.id
      JOIN stores s ON ss.store_id = s.id
      WHERE ss.stock_quantity <= ss.min_stock_level
      AND p.active = 1
      ${storeId != null ? 'AND ss.store_id = ?' : ''}
      ORDER BY p.name ASC
    ''', storeId != null ? [storeId] : null);
    
    return lowStockProducts;
  }

  static Future<int> deleteStore(int storeId) async {
    final db = await database;
    
    // First delete related store_stock records
    await db.delete('store_stock', where: 'store_id = ?', whereArgs: [storeId]);
    
    // Then delete the store
    return await db.delete('stores', where: 'id = ?', whereArgs: [storeId]);
  }

  static Future<int> deleteEmployee(int employeeId) async {
    final db = await database;
    
    // Note: We should check if this employee is referenced as a manager in any stores
    // and potentially update those stores to have null manager_id before deleting
    await db.update('stores', {'manager_id': null}, where: 'manager_id = ?', whereArgs: [employeeId]);
    
    // Delete the employee
    return await db.delete('employees', where: 'id = ?', whereArgs: [employeeId]);
  }

  static Future<void> cleanupOrphanedStockRecords() async {
    final db = await database;
    
    // Delete store_stock records that reference non-existent or inactive products
    await db.rawDelete('''
      DELETE FROM store_stock 
      WHERE product_id NOT IN (
        SELECT id FROM products WHERE active = 1
      )
    ''');
  }

  // Sales Reporting Methods
  static Future<List<Map<String, dynamic>>> getSalesByPaymentType({
    DateTime? startDate,
    DateTime? endDate,
    int? storeId,
    int? employeeId,
  }) async {
    final db = await database;
    
    String whereClause = '';
    List<dynamic> whereArgs = [];
    
    if (startDate != null) {
      whereClause = 'sale_date >= ?';
      whereArgs.add(startDate.toIso8601String());
    }
    
    if (endDate != null) {
      if (whereClause.isNotEmpty) whereClause += ' AND ';
      whereClause += 'sale_date <= ?';
      whereArgs.add(endDate.toIso8601String());
    }
    
    if (storeId != null) {
      if (whereClause.isNotEmpty) whereClause += ' AND ';
      whereClause += 'store_id = ?';
      whereArgs.add(storeId);
    }
    
    if (employeeId != null) {
      if (whereClause.isNotEmpty) whereClause += ' AND ';
      whereClause += 'employee_id = ?';
      whereArgs.add(employeeId);
    }
    
    return await db.rawQuery('''
      SELECT 
        payment_method as payment_type,
        COUNT(CASE WHEN total_amount >= 0 THEN 1 END) as payment_transactions,
        SUM(CASE WHEN total_amount >= 0 THEN total_amount ELSE 0 END) as payment_amount,
        COUNT(CASE WHEN total_amount < 0 THEN 1 END) as refund_transactions,
        SUM(CASE WHEN total_amount < 0 THEN ABS(total_amount) ELSE 0 END) as refund_amount,
        SUM(total_amount) as net_amount
      FROM sales
      ${whereClause.isNotEmpty ? 'WHERE $whereClause' : ''}
      GROUP BY payment_method
      ORDER BY net_amount DESC
    ''', whereArgs.isEmpty ? null : whereArgs);
  }

  static Future<List<Map<String, dynamic>>> getSalesByEmployee({
    DateTime? startDate,
    DateTime? endDate,
    int? storeId,
  }) async {
    final db = await database;
    
    String whereClause = '';
    List<dynamic> whereArgs = [];
    
    if (startDate != null) {
      whereClause = 's.sale_date >= ?';
      whereArgs.add(startDate.toIso8601String());
    }
    
    if (endDate != null) {
      if (whereClause.isNotEmpty) whereClause += ' AND ';
      whereClause += 's.sale_date <= ?';
      whereArgs.add(endDate.toIso8601String());
    }
    
    if (storeId != null) {
      if (whereClause.isNotEmpty) whereClause += ' AND ';
      whereClause += 's.store_id = ?';
      whereArgs.add(storeId);
    }
    
    return await db.rawQuery('''
      SELECT 
        e.name as employee_name,
        SUM(CASE WHEN s.total_amount >= 0 THEN s.subtotal ELSE 0 END) as gross_sales,
        SUM(CASE WHEN s.total_amount < 0 THEN ABS(s.total_amount) ELSE 0 END) as refunds,
        SUM(CASE WHEN s.total_amount >= 0 THEN COALESCE(s.discount_amount, 0) ELSE 0 END) as discounts,
        SUM(CASE WHEN s.total_amount >= 0 THEN s.total_amount ELSE 0 END) as net_sales,
        COUNT(CASE WHEN s.total_amount >= 0 THEN 1 END) as receipts,
        SUM(CASE WHEN s.total_amount >= 0 THEN s.total_amount ELSE 0 END) / NULLIF(COUNT(CASE WHEN s.total_amount >= 0 THEN 1 END), 0) as average_sale,
        0 as customers_signed_up
      FROM sales s
      JOIN employees e ON s.employee_id = e.id
      ${whereClause.isNotEmpty ? 'WHERE $whereClause' : ''}
      GROUP BY s.employee_id, e.name
      ORDER BY net_sales DESC
    ''', whereArgs.isEmpty ? null : whereArgs);
  }

  static Future<List<Map<String, dynamic>>> getSalesByCategory({
    DateTime? startDate,
    DateTime? endDate,
    int? storeId,
    int? employeeId,
  }) async {
    final db = await database;
    
    String whereClause = '';
    List<dynamic> whereArgs = [];
    
    if (startDate != null) {
      whereClause = 's.sale_date >= ?';
      whereArgs.add(startDate.toIso8601String());
    }
    
    if (endDate != null) {
      if (whereClause.isNotEmpty) whereClause += ' AND ';
      whereClause += 's.sale_date <= ?';
      whereArgs.add(endDate.toIso8601String());
    }
    
    if (storeId != null) {
      if (whereClause.isNotEmpty) whereClause += ' AND ';
      whereClause += 's.store_id = ?';
      whereArgs.add(storeId);
    }
    
    if (employeeId != null) {
      if (whereClause.isNotEmpty) whereClause += ' AND ';
      whereClause += 's.employee_id = ?';
      whereArgs.add(employeeId);
    }
    
    return await db.rawQuery('''
      SELECT 
        COALESCE(c.name, 'Uncategorized') as category,
        SUM(CASE WHEN si.quantity >= 0 THEN si.quantity ELSE 0 END) as products_sold,
        SUM(CASE WHEN si.quantity >= 0 THEN si.line_total ELSE 0 END) as gross_sales,
        SUM(CASE WHEN si.quantity < 0 THEN ABS(si.quantity) ELSE 0 END) as products_refunded,
        SUM(CASE WHEN si.quantity < 0 THEN ABS(si.line_total) ELSE 0 END) as refunds,
        SUM(CASE WHEN si.quantity >= 0 THEN COALESCE(s.discount_amount, 0) * (si.line_total / NULLIF(s.subtotal, 0)) ELSE 0 END) as discounts,
        SUM(CASE WHEN si.quantity >= 0 THEN si.line_total ELSE 0 END) as net_sales,
        SUM(CASE WHEN si.quantity >= 0 THEN si.quantity * COALESCE(p.cost, 0) ELSE 0 END) as cost_of_goods,
        SUM(CASE WHEN si.quantity >= 0 THEN si.line_total ELSE 0 END) - SUM(CASE WHEN si.quantity >= 0 THEN si.quantity * COALESCE(p.cost, 0) ELSE 0 END) as gross_profit
      FROM sales s
      JOIN sale_items si ON s.id = si.sale_id
      JOIN products p ON si.product_id = p.id
      LEFT JOIN categories c ON p.category_id = c.id
      ${whereClause.isNotEmpty ? 'WHERE $whereClause' : ''}
      GROUP BY c.id, c.name
      ORDER BY net_sales DESC
    ''', whereArgs.isEmpty ? null : whereArgs);
  }

  static Future<List<Map<String, dynamic>>> getSalesByProduct({
    DateTime? startDate,
    DateTime? endDate,
    int? storeId,
    int? employeeId,
  }) async {
    final db = await database;
    
    String whereClause = '';
    List<dynamic> whereArgs = [];
    
    if (startDate != null) {
      whereClause = 's.sale_date >= ?';
      whereArgs.add(startDate.toIso8601String());
    }
    
    if (endDate != null) {
      if (whereClause.isNotEmpty) whereClause += ' AND ';
      whereClause += 's.sale_date <= ?';
      whereArgs.add(endDate.toIso8601String());
    }
    
    if (storeId != null) {
      if (whereClause.isNotEmpty) whereClause += ' AND ';
      whereClause += 's.store_id = ?';
      whereArgs.add(storeId);
    }
    
    if (employeeId != null) {
      if (whereClause.isNotEmpty) whereClause += ' AND ';
      whereClause += 's.employee_id = ?';
      whereArgs.add(employeeId);
    }
    
    return await db.rawQuery('''
      SELECT 
        p.name as product,
        p.sku,
        COALESCE(c.name, 'Uncategorized') as category,
        SUM(CASE WHEN si.quantity >= 0 THEN si.quantity ELSE 0 END) as products_sold,
        SUM(CASE WHEN si.quantity >= 0 THEN si.line_total ELSE 0 END) as gross_sales,
        SUM(CASE WHEN si.quantity < 0 THEN ABS(si.quantity) ELSE 0 END) as products_refunded,
        SUM(CASE WHEN si.quantity < 0 THEN ABS(si.line_total) ELSE 0 END) as refunds,
        SUM(CASE WHEN si.quantity >= 0 THEN COALESCE(s.discount_amount, 0) * (si.line_total / NULLIF(s.subtotal, 0)) ELSE 0 END) as discounts,
        SUM(CASE WHEN si.quantity >= 0 THEN si.line_total ELSE 0 END) as net_sales,
        SUM(CASE WHEN si.quantity >= 0 THEN si.quantity * COALESCE(p.cost, 0) ELSE 0 END) as cost_of_goods,
        SUM(CASE WHEN si.quantity >= 0 THEN si.line_total ELSE 0 END) - SUM(CASE WHEN si.quantity >= 0 THEN si.quantity * COALESCE(p.cost, 0) ELSE 0 END) as gross_profit
      FROM sales s
      JOIN sale_items si ON s.id = si.sale_id
      JOIN products p ON si.product_id = p.id
      LEFT JOIN categories c ON p.category_id = c.id
      ${whereClause.isNotEmpty ? 'WHERE $whereClause' : ''}
      GROUP BY p.id, p.name, p.sku, c.name
      ORDER BY net_sales DESC
    ''', whereArgs.isEmpty ? null : whereArgs);
  }

  // Add sample stock and sales data for demo purposes
  static Future<void> addSampleData() async {
    final db = await database;
    
    try {
      // Clean up any warehouse stock records first
      await cleanupWarehouseStockRecords();
      
      // Update stock quantities for first 10 products (stores only)
      await db.execute('''
        UPDATE store_stock 
        SET stock_quantity = CASE product_id 
          WHEN 1 THEN 25
          WHEN 2 THEN 30
          WHEN 3 THEN 15
          WHEN 4 THEN 40
          WHEN 5 THEN 8
          WHEN 6 THEN 22
          WHEN 7 THEN 35
          WHEN 8 THEN 12
          WHEN 9 THEN 28
          WHEN 10 THEN 18
          ELSE stock_quantity
        END
        WHERE product_id <= 10
        AND store_id IN (SELECT id FROM stores WHERE type = 'store' OR type IS NULL)
      ''');

      // Add some sample sales for last 30 days
      final now = DateTime.now();
      for (int i = 0; i < 50; i++) {
        final saleDate = now.subtract(Duration(days: i % 30));
        final paymentMethod = ['Cash', 'Card', 'EcoCash USD'][i % 3];
        final amount = 10.0 + (i % 20) * 5.0;
        
        await db.insert('sales', {
          'ticket_number': 'DEMO${1000 + i}',
          'store_id': 1,
          'employee_id': 1,
          'subtotal': amount,
          'tax_amount': amount * 0.15,
          'discount_amount': i % 5 == 0 ? 5.0 : 0.0,
          'total_amount': amount + (amount * 0.15) - (i % 5 == 0 ? 5.0 : 0.0),
          'payment_method': paymentMethod,
          'sale_date': saleDate.toIso8601String(),
          'created_at': saleDate.toIso8601String(),
        });
      }
      
      print('Sample data added successfully');
    } catch (e) {
      print('Error adding sample data: $e');
    }
  }

  // Clean up warehouse stock records to prevent POS issues
  static Future<void> cleanupWarehouseStockRecords() async {
    final db = await database;
    try {
      // Delete all stock records for warehouses
      await db.execute('''
        DELETE FROM store_stock 
        WHERE store_id IN (
          SELECT id FROM stores WHERE type = 'warehouse'
        )
      ''');
      print('Warehouse stock records cleaned up');
    } catch (e) {
      print('Error cleaning up warehouse stock records: $e');
    }
  }
}