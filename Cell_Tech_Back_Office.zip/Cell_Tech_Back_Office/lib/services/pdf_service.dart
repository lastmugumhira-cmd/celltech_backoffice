import 'dart:typed_data';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';
import 'package:intl/intl.dart';
import 'database_service.dart';

class PdfService {
  static final DateFormat _dateFormat = DateFormat('yyyy-MM-dd HH:mm:ss');
  static final DateFormat _shortDateFormat = DateFormat('dd/MM/yyyy');

  // Generate Stock Adjustment PDF Report
  static Future<Uint8List> generateStockAdjustmentPdf(
    Map<String, dynamic> adjustment,
  ) async {
    final pdf = pw.Document();
    
    // Get adjustment items
    final adjustmentItems = await DatabaseService.getStockAdjustmentItems(adjustment['id']);
    
    pdf.addPage(
      pw.MultiPage(
        pageFormat: PdfPageFormat.a4,
        margin: const pw.EdgeInsets.all(40),
        build: (pw.Context context) {
          return [
            // Header
            _buildHeader('STOCK ADJUSTMENT REPORT'),
            pw.SizedBox(height: 20),
            
            // Adjustment Details
            _buildStockAdjustmentDetails(adjustment),
            pw.SizedBox(height: 20),
            
            // Items Table
            _buildStockAdjustmentItemsTable(adjustmentItems),
            pw.SizedBox(height: 20),
            
            // Summary
            _buildStockAdjustmentSummary(adjustmentItems),
            
            // Footer
            pw.Spacer(),
            _buildFooter(),
          ];
        },
      ),
    );

    return pdf.save();
  }

  // Generate Inventory Count PDF Report
  static Future<Uint8List> generateInventoryCountPdf(
    Map<String, dynamic> count,
  ) async {
    final pdf = pw.Document();
    
    pdf.addPage(
      pw.MultiPage(
        pageFormat: PdfPageFormat.a4,
        margin: const pw.EdgeInsets.all(40),
        build: (pw.Context context) {
          return [
            // Header
            _buildHeader('INVENTORY COUNT REPORT'),
            pw.SizedBox(height: 20),
            
            // Count Details
            _buildInventoryCountDetails(count),
            pw.SizedBox(height: 20),
            
            // Progress Summary
            _buildInventoryCountProgress(count),
            pw.SizedBox(height: 20),
            
            // Notes
            if (count['notes'] != null && count['notes'].toString().isNotEmpty)
              _buildNotesSection(count['notes']),
            
            // Footer
            pw.Spacer(),
            _buildFooter(),
          ];
        },
      ),
    );

    return pdf.save();
  }

  // Download PDF to device
  static Future<void> downloadPdf(Uint8List pdfData, String filename) async {
    await Printing.sharePdf(bytes: pdfData, filename: filename);
  }

  // Print PDF directly
  static Future<void> printPdf(Uint8List pdfData, String title) async {
    await Printing.layoutPdf(
      onLayout: (PdfPageFormat format) async => pdfData,
      name: title,
    );
  }

  // Private helper methods
  static pw.Widget _buildHeader(String title) {
    return pw.Container(
      width: double.infinity,
      decoration: pw.BoxDecoration(
        color: PdfColor.fromHex('#FF8C00'),
        borderRadius: pw.BorderRadius.circular(8),
      ),
      padding: const pw.EdgeInsets.all(16),
      child: pw.Column(
        crossAxisAlignment: pw.CrossAxisAlignment.start,
        children: [
          pw.Text(
            'POS Back Office',
            style: pw.TextStyle(
              color: PdfColors.white,
              fontSize: 12,
              fontWeight: pw.FontWeight.normal,
            ),
          ),
          pw.SizedBox(height: 4),
          pw.Text(
            title,
            style: pw.TextStyle(
              color: PdfColors.white,
              fontSize: 20,
              fontWeight: pw.FontWeight.bold,
            ),
          ),
        ],
      ),
    );
  }

  static pw.Widget _buildStockAdjustmentDetails(Map<String, dynamic> adjustment) {
    return pw.Container(
      width: double.infinity,
      decoration: pw.BoxDecoration(
        border: pw.Border.all(color: PdfColors.grey300),
        borderRadius: pw.BorderRadius.circular(8),
      ),
      padding: const pw.EdgeInsets.all(16),
      child: pw.Column(
        crossAxisAlignment: pw.CrossAxisAlignment.start,
        children: [
          pw.Text(
            'Adjustment Details',
            style: pw.TextStyle(fontSize: 16, fontWeight: pw.FontWeight.bold),
          ),
          pw.SizedBox(height: 12),
          pw.Row(
            crossAxisAlignment: pw.CrossAxisAlignment.start,
            children: [
              pw.Expanded(
                child: pw.Column(
                  crossAxisAlignment: pw.CrossAxisAlignment.start,
                  children: [
                    _buildDetailRow('Adjustment Number:', adjustment['adjustment_number']),
                    _buildDetailRow('Store:', adjustment['store_name'] ?? 'Unknown'),
                    _buildDetailRow('Reason:', _formatReason(adjustment['reason'])),
                  ],
                ),
              ),
              pw.Expanded(
                child: pw.Column(
                  crossAxisAlignment: pw.CrossAxisAlignment.start,
                  children: [
                    _buildDetailRow('Status:', adjustment['status'].toString().toUpperCase()),
                    _buildDetailRow('Created:', _shortDateFormat.format(DateTime.parse(adjustment['created_at']))),
                    if (adjustment['completed_at'] != null)
                      _buildDetailRow('Completed:', _shortDateFormat.format(DateTime.parse(adjustment['completed_at']))),
                  ],
                ),
              ),
            ],
          ),
          if (adjustment['notes'] != null && adjustment['notes'].toString().isNotEmpty) ...[
            pw.SizedBox(height: 12),
            _buildDetailRow('Notes:', adjustment['notes']),
          ],
        ],
      ),
    );
  }

  static pw.Widget _buildInventoryCountDetails(Map<String, dynamic> count) {
    return pw.Container(
      width: double.infinity,
      decoration: pw.BoxDecoration(
        border: pw.Border.all(color: PdfColors.grey300),
        borderRadius: pw.BorderRadius.circular(8),
      ),
      padding: const pw.EdgeInsets.all(16),
      child: pw.Column(
        crossAxisAlignment: pw.CrossAxisAlignment.start,
        children: [
          pw.Text(
            'Count Details',
            style: pw.TextStyle(fontSize: 16, fontWeight: pw.FontWeight.bold),
          ),
          pw.SizedBox(height: 12),
          pw.Row(
            crossAxisAlignment: pw.CrossAxisAlignment.start,
            children: [
              pw.Expanded(
                child: pw.Column(
                  crossAxisAlignment: pw.CrossAxisAlignment.start,
                  children: [
                    _buildDetailRow('Count Number:', count['count_number']),
                    _buildDetailRow('Store:', count['store_name'] ?? 'Unknown'),
                    _buildDetailRow('Count Type:', _formatCountType(count['count_type'])),
                  ],
                ),
              ),
              pw.Expanded(
                child: pw.Column(
                  crossAxisAlignment: pw.CrossAxisAlignment.start,
                  children: [
                    _buildDetailRow('Status:', count['status'].toString().toUpperCase()),
                    _buildDetailRow('Started:', _shortDateFormat.format(DateTime.parse(count['started_at']))),
                    if (count['completed_at'] != null)
                      _buildDetailRow('Completed:', _shortDateFormat.format(DateTime.parse(count['completed_at']))),
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  static pw.Widget _buildInventoryCountProgress(Map<String, dynamic> count) {
    // Some callers may not include summary fields; compute if missing.
    int totalItems;
    int countedItems;
    if (count.containsKey('total_items') && count.containsKey('counted_items')) {
      totalItems = (count['total_items'] as num).toInt();
      countedItems = (count['counted_items'] as num).toInt();
    } else if (count['items'] is List) {
      final items = (count['items'] as List).cast<Map<String, dynamic>>();
      totalItems = items.length;
      countedItems = items.where((it) => it['counted_qty'] != null).length;
    } else {
      totalItems = 0;
      countedItems = 0;
    }
    final progress = totalItems > 0 ? (countedItems / totalItems * 100).round() : 0;

    return pw.Container(
      width: double.infinity,
      decoration: pw.BoxDecoration(
        border: pw.Border.all(color: PdfColors.grey300),
        borderRadius: pw.BorderRadius.circular(8),
      ),
      padding: const pw.EdgeInsets.all(16),
      child: pw.Column(
        crossAxisAlignment: pw.CrossAxisAlignment.start,
        children: [
          pw.Text(
            'Progress Summary',
            style: pw.TextStyle(fontSize: 16, fontWeight: pw.FontWeight.bold),
          ),
          pw.SizedBox(height: 12),
          pw.Row(
            children: [
              pw.Expanded(
                child: _buildDetailRow('Total Items:', totalItems.toString()),
              ),
              pw.Expanded(
                child: _buildDetailRow('Counted Items:', countedItems.toString()),
              ),
              pw.Expanded(
                child: _buildDetailRow('Progress:', '$progress%'),
              ),
            ],
          ),
        ],
      ),
    );
  }

  static pw.Widget _buildStockAdjustmentItemsTable(List<Map<String, dynamic>> items) {
    if (items.isEmpty) {
      return pw.Container(
        padding: const pw.EdgeInsets.all(16),
        child: pw.Text('No items in this adjustment.'),
      );
    }

    return pw.Column(
      crossAxisAlignment: pw.CrossAxisAlignment.start,
      children: [
        pw.Text(
          'Adjustment Items',
          style: pw.TextStyle(fontSize: 16, fontWeight: pw.FontWeight.bold),
        ),
        pw.SizedBox(height: 12),
        pw.Table(
          border: pw.TableBorder.all(color: PdfColors.grey300),
          columnWidths: {
            0: const pw.FlexColumnWidth(3),
            1: const pw.FlexColumnWidth(2),
            2: const pw.FlexColumnWidth(2),
            3: const pw.FlexColumnWidth(2),
          },
          children: [
            // Header
            pw.TableRow(
              decoration: const pw.BoxDecoration(color: PdfColors.grey100),
              children: [
                _buildTableCell('Product', isHeader: true),
                _buildTableCell('Before', isHeader: true),
                _buildTableCell('After', isHeader: true),
                _buildTableCell('Change', isHeader: true),
              ],
            ),
            // Data rows
            ...items.map((item) => pw.TableRow(
              children: [
                _buildTableCell(item['product_name'] ?? 'Unknown Product'),
                _buildTableCell(item['quantity_before'].toString()),
                _buildTableCell(item['quantity_after'].toString()),
                _buildTableCell(_formatQuantityChange(item['quantity_change'])),
              ],
            )),
          ],
        ),
      ],
    );
  }

  static pw.Widget _buildStockAdjustmentSummary(List<Map<String, dynamic>> items) {
    final totalItems = items.length;
    final totalIncrease = items.where((item) => (item['quantity_change'] ?? 0) > 0).length;
    final totalDecrease = items.where((item) => (item['quantity_change'] ?? 0) < 0).length;

    return pw.Container(
      width: double.infinity,
      decoration: pw.BoxDecoration(
        border: pw.Border.all(color: PdfColors.grey300),
        borderRadius: pw.BorderRadius.circular(8),
      ),
      padding: const pw.EdgeInsets.all(16),
      child: pw.Column(
        crossAxisAlignment: pw.CrossAxisAlignment.start,
        children: [
          pw.Text(
            'Summary',
            style: pw.TextStyle(fontSize: 16, fontWeight: pw.FontWeight.bold),
          ),
          pw.SizedBox(height: 12),
          pw.Row(
            children: [
              pw.Expanded(
                child: _buildDetailRow('Total Items:', totalItems.toString()),
              ),
              pw.Expanded(
                child: _buildDetailRow('Increases:', totalIncrease.toString()),
              ),
              pw.Expanded(
                child: _buildDetailRow('Decreases:', totalDecrease.toString()),
              ),
            ],
          ),
        ],
      ),
    );
  }

  static pw.Widget _buildNotesSection(String notes) {
    return pw.Container(
      width: double.infinity,
      decoration: pw.BoxDecoration(
        border: pw.Border.all(color: PdfColors.grey300),
        borderRadius: pw.BorderRadius.circular(8),
      ),
      padding: const pw.EdgeInsets.all(16),
      child: pw.Column(
        crossAxisAlignment: pw.CrossAxisAlignment.start,
        children: [
          pw.Text(
            'Notes',
            style: pw.TextStyle(fontSize: 16, fontWeight: pw.FontWeight.bold),
          ),
          pw.SizedBox(height: 8),
          pw.Text(notes),
        ],
      ),
    );
  }

  static pw.Widget _buildFooter() {
    return pw.Container(
      width: double.infinity,
      padding: const pw.EdgeInsets.only(top: 16),
      decoration: const pw.BoxDecoration(
        border: pw.Border(top: pw.BorderSide(color: PdfColors.grey300)),
      ),
      child: pw.Row(
        mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
        children: [
          pw.Text(
            'Generated on ${_dateFormat.format(DateTime.now())}',
            style: const pw.TextStyle(fontSize: 10, color: PdfColors.grey),
          ),
          pw.Text(
            'POS Back Office System',
            style: const pw.TextStyle(fontSize: 10, color: PdfColors.grey),
          ),
        ],
      ),
    );
  }

  static pw.Widget _buildDetailRow(String label, String value) {
    return pw.Padding(
      padding: const pw.EdgeInsets.only(bottom: 4),
      child: pw.Row(
        crossAxisAlignment: pw.CrossAxisAlignment.start,
        children: [
          pw.SizedBox(
            width: 100,
            child: pw.Text(
              label,
              style: pw.TextStyle(fontWeight: pw.FontWeight.bold),
            ),
          ),
          pw.Expanded(
            child: pw.Text(value),
          ),
        ],
      ),
    );
  }

  static pw.Widget _buildTableCell(String text, {bool isHeader = false}) {
    return pw.Container(
      padding: const pw.EdgeInsets.all(8),
      child: pw.Text(
        text,
        style: pw.TextStyle(
          fontWeight: isHeader ? pw.FontWeight.bold : pw.FontWeight.normal,
          fontSize: isHeader ? 12 : 10,
        ),
      ),
    );
  }

  static String _formatReason(String reason) {
    switch (reason) {
      case 'receive_items':
        return 'Receive Items';
      case 'inventory_count':
        return 'Inventory Count';
      case 'loss':
        return 'Loss';
      case 'damage':
        return 'Damage';
      default:
        return reason;
    }
  }

  static String _formatCountType(String countType) {
    switch (countType) {
      case 'full_count':
        return 'Full Count';
      case 'cycle_count':
        return 'Cycle Count';
      case 'spot_count':
        return 'Spot Count';
      default:
        return countType;
    }
  }

  static String _formatQuantityChange(dynamic change) {
    final changeValue = change as int? ?? 0;
    if (changeValue > 0) {
      return '+$changeValue';
    } else if (changeValue < 0) {
      return changeValue.toString();
    } else {
      return '0';
    }
  }

  // Generate Stock Transfer PDF Report
  static Future<void> generateTransferPdf({
    required String fromLocation,
    required String toLocation,
    required List<Map<String, dynamic>> items,
    required String notes,
    required DateTime date,
  }) async {
    final pdf = pw.Document();
    
    pdf.addPage(
      pw.MultiPage(
        pageFormat: PdfPageFormat.a4,
        margin: const pw.EdgeInsets.all(40),
        build: (pw.Context context) {
          return [
            // Header
            _buildHeader('STOCK TRANSFER REPORT'),
            pw.SizedBox(height: 20),
            
            // Transfer Details
            _buildTransferDetails(fromLocation, toLocation, date, notes),
            pw.SizedBox(height: 20),
            
            // Items Table
            _buildTransferItemsTable(items),
            pw.SizedBox(height: 20),
            
            // Summary
            _buildTransferSummary(items),
            
            // Footer
            pw.Spacer(),
            _buildFooter(),
          ];
        },
      ),
    );

    final bytes = await pdf.save();
    
    // Create filename-safe date format (yyyy-MM-dd instead of dd/MM/yyyy)
    final filenameDateFormat = DateFormat('yyyy-MM-dd');
    final safeFilename = 'stock_transfer_${filenameDateFormat.format(date)}.pdf';
    
    await Printing.sharePdf(
      bytes: bytes,
      filename: safeFilename,
    );
  }

  static pw.Widget _buildTransferDetails(String fromLocation, String toLocation, DateTime date, String notes) {
    return pw.Container(
      padding: const pw.EdgeInsets.all(15),
      decoration: pw.BoxDecoration(
        border: pw.Border.all(),
        borderRadius: pw.BorderRadius.circular(5),
      ),
      child: pw.Column(
        crossAxisAlignment: pw.CrossAxisAlignment.start,
        children: [
          pw.Text('TRANSFER DETAILS', style: pw.TextStyle(fontSize: 14, fontWeight: pw.FontWeight.bold)),
          pw.SizedBox(height: 10),
          pw.Row(
            children: [
              pw.Expanded(
                child: pw.Column(
                  crossAxisAlignment: pw.CrossAxisAlignment.start,
                  children: [
                    pw.Text('From Location:', style: pw.TextStyle(fontWeight: pw.FontWeight.bold)),
                    pw.Text(fromLocation),
                  ],
                ),
              ),
              pw.Expanded(
                child: pw.Column(
                  crossAxisAlignment: pw.CrossAxisAlignment.start,
                  children: [
                    pw.Text('To Location:', style: pw.TextStyle(fontWeight: pw.FontWeight.bold)),
                    pw.Text(toLocation),
                  ],
                ),
              ),
            ],
          ),
          pw.SizedBox(height: 10),
          pw.Text('Transfer Date:', style: pw.TextStyle(fontWeight: pw.FontWeight.bold)),
          pw.Text(_dateFormat.format(date)),
          if (notes.isNotEmpty) ...[
            pw.SizedBox(height: 10),
            pw.Text('Notes:', style: pw.TextStyle(fontWeight: pw.FontWeight.bold)),
            pw.Text(notes),
          ],
        ],
      ),
    );
  }

  static pw.Widget _buildTransferItemsTable(List<Map<String, dynamic>> items) {
    return pw.Column(
      crossAxisAlignment: pw.CrossAxisAlignment.start,
      children: [
        pw.Text('TRANSFERRED ITEMS', style: pw.TextStyle(fontSize: 14, fontWeight: pw.FontWeight.bold)),
        pw.SizedBox(height: 10),
        pw.Table(
          border: pw.TableBorder.all(),
          columnWidths: {
            0: const pw.FlexColumnWidth(3), // Product Name
            1: const pw.FlexColumnWidth(2), // SKU
            2: const pw.FlexColumnWidth(1), // Quantity
          },
          children: [
            // Header
            pw.TableRow(
              decoration: const pw.BoxDecoration(color: PdfColors.grey300),
              children: [
                pw.Padding(
                  padding: const pw.EdgeInsets.all(8),
                  child: pw.Text('Product Name', style: pw.TextStyle(fontWeight: pw.FontWeight.bold)),
                ),
                pw.Padding(
                  padding: const pw.EdgeInsets.all(8),
                  child: pw.Text('SKU', style: pw.TextStyle(fontWeight: pw.FontWeight.bold)),
                ),
                pw.Padding(
                  padding: const pw.EdgeInsets.all(8),
                  child: pw.Text('Quantity', style: pw.TextStyle(fontWeight: pw.FontWeight.bold), textAlign: pw.TextAlign.right),
                ),
              ],
            ),
            // Data rows
            ...items.map((item) => pw.TableRow(
              children: [
                pw.Padding(
                  padding: const pw.EdgeInsets.all(8),
                  child: pw.Text(item['name']?.toString() ?? ''),
                ),
                pw.Padding(
                  padding: const pw.EdgeInsets.all(8),
                  child: pw.Text(item['sku']?.toString() ?? ''),
                ),
                pw.Padding(
                  padding: const pw.EdgeInsets.all(8),
                  child: pw.Text((item['quantity'] ?? 0).toString(), textAlign: pw.TextAlign.right),
                ),
              ],
            )),
          ],
        ),
      ],
    );
  }

  static pw.Widget _buildTransferSummary(List<Map<String, dynamic>> items) {
    final totalItems = items.length;
    final totalQuantity = items.fold<int>(0, (sum, item) => sum + ((item['quantity'] as int?) ?? 0));
    
    return pw.Container(
      padding: const pw.EdgeInsets.all(15),
      decoration: pw.BoxDecoration(
        border: pw.Border.all(),
        borderRadius: pw.BorderRadius.circular(5),
        color: PdfColors.grey100,
      ),
      child: pw.Row(
        children: [
          pw.Expanded(
            child: pw.Column(
              crossAxisAlignment: pw.CrossAxisAlignment.start,
              children: [
                pw.Text('TRANSFER SUMMARY', style: pw.TextStyle(fontSize: 12, fontWeight: pw.FontWeight.bold)),
                pw.SizedBox(height: 8),
                pw.Text('Total Items: $totalItems'),
                pw.Text('Total Quantity: $totalQuantity'),
              ],
            ),
          ),
        ],
      ),
    );
  }
}