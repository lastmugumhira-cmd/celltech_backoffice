class StockAdjustment {
  final int? id;
  final String adjustmentNumber;
  final String
      reason; // 'inventory_count', 'receive_items', 'transfer_in', 'transfer_out', 'loss', 'damage', 'found'
  final String status; // 'in_progress', 'completed', 'cancelled'
  final int? storeId;
  final int? employeeId;
  final String? notes;
  final DateTime createdAt;
  final DateTime? completedAt;

  StockAdjustment({
    this.id,
    required this.adjustmentNumber,
    required this.reason,
    required this.status,
    this.storeId,
    this.employeeId,
    this.notes,
    required this.createdAt,
    this.completedAt,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'adjustment_number': adjustmentNumber,
      'reason': reason,
      'status': status,
      'store_id': storeId,
      'employee_id': employeeId,
      'notes': notes,
      'created_at': createdAt.toIso8601String(),
      'completed_at': completedAt?.toIso8601String(),
    };
  }

  factory StockAdjustment.fromMap(Map<String, dynamic> map) {
    return StockAdjustment(
      id: map['id'],
      adjustmentNumber: map['adjustment_number'],
      reason: map['reason'],
      status: map['status'],
      storeId: map['store_id'],
      employeeId: map['employee_id'],
      notes: map['notes'],
      createdAt: DateTime.parse(map['created_at']),
      completedAt: map['completed_at'] != null
          ? DateTime.parse(map['completed_at'])
          : null,
    );
  }
}
