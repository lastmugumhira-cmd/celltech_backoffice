class Supplier {
  final int? id;
  final String name;
  final String? contactPerson;
  final String? email;
  final String? phone;
  final String? address;
  final String? notes;
  final bool active;
  final DateTime createdAt;

  Supplier({
    this.id,
    required this.name,
    this.contactPerson,
    this.email,
    this.phone,
    this.address,
    this.notes,
    this.active = true,
    required this.createdAt,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'name': name,
      'contact_person': contactPerson,
      'email': email,
      'phone': phone,
      'address': address,
      'notes': notes,
      'active': active ? 1 : 0,
      'created_at': createdAt.toIso8601String(),
    };
  }

  factory Supplier.fromMap(Map<String, dynamic> map) {
    return Supplier(
      id: map['id'],
      name: map['name'],
      contactPerson: map['contact_person'],
      email: map['email'],
      phone: map['phone'],
      address: map['address'],
      notes: map['notes'],
      active: map['active'] == 1,
      createdAt: DateTime.parse(map['created_at']),
    );
  }
}
