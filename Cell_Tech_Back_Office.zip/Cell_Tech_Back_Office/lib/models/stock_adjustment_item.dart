class StockAdjustmentItem {
  final int? id;
  final int adjustmentId;
  final int productId;
  final int quantityBefore;
  final int quantityAfter;
  final int quantityChange;
  final String? notes;

  StockAdjustmentItem({
    this.id,
    required this.adjustmentId,
    required this.productId,
    required this.quantityBefore,
    required this.quantityAfter,
    required this.quantityChange,
    this.notes,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'adjustment_id': adjustmentId,
      'product_id': productId,
      'quantity_before': quantityBefore,
      'quantity_after': quantityAfter,
      'quantity_change': quantityChange,
      'notes': notes,
    };
  }

  factory StockAdjustmentItem.fromMap(Map<String, dynamic> map) {
    return StockAdjustmentItem(
      id: map['id'],
      adjustmentId: map['adjustment_id'],
      productId: map['product_id'],
      quantityBefore: map['quantity_before'],
      quantityAfter: map['quantity_after'],
      quantityChange: map['quantity_change'],
      notes: map['notes'],
    );
  }
}
