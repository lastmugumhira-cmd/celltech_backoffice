class Customer {
  final int? id;
  final String name;
  final String? phone;
  final String? email;
  final double totalPurchases;
  final DateTime createdAt;

  Customer({
    this.id,
    required this.name,
    this.phone,
    this.email,
    this.totalPurchases = 0.0,
    DateTime? createdAt,
  }) : createdAt = createdAt ?? DateTime.now();

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'name': name,
      'phone': phone,
      'email': email,
      'total_purchases': totalPurchases,
      'created_at': createdAt.toIso8601String(),
    };
  }

  factory Customer.fromMap(Map<String, dynamic> map) {
    return Customer(
      id: map['id'] is int ? map['id'] as int : null,
      name: map['name'] as String,
      phone: map['phone'] as String?,
      email: map['email'] as String?,
      totalPurchases: (map['total_purchases'] as num).toDouble(),
      createdAt: DateTime.parse(map['created_at'] as String),
    );
  }

  Customer copyWith({
    int? id,
    String? name,
    String? phone,
    String? email,
    double? totalPurchases,
    DateTime? createdAt,
  }) {
    return Customer(
      id: id ?? this.id,
      name: name ?? this.name,
      phone: phone ?? this.phone,
      email: email ?? this.email,
      totalPurchases: totalPurchases ?? this.totalPurchases,
      createdAt: createdAt ?? this.createdAt,
    );
  }
}
