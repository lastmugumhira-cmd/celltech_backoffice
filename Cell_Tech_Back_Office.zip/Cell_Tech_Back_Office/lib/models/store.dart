class Store {
  final int? id;
  final String name;
  final String address;
  final String phone;
  final int? managerId;
  final String type; // 'store' | 'warehouse'
  final int? capacity;
  final bool active;
  final DateTime createdAt;

  Store({
    this.id,
    required this.name,
    required this.address,
    required this.phone,
    this.managerId,
    this.type = 'store',
    this.capacity,
    this.active = true,
    DateTime? createdAt,
  }) : createdAt = createdAt ?? DateTime.now();

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'name': name,
      'address': address,
      'phone': phone,
      'manager_id': managerId,
      'type': type,
      'capacity': capacity,
      'active': active ? 1 : 0,
      'created_at': createdAt.toIso8601String(),
    };
  }

  factory Store.fromMap(Map<String, dynamic> map) {
    return Store(
      id: map['id'] is int ? map['id'] as int : null,
      name: map['name'] as String,
      address: map['address'] as String,
      phone: map['phone'] as String,
      managerId: map['manager_id'] is int ? map['manager_id'] as int : null,
      type: (map['type'] as String?) ?? 'store',
      capacity: map['capacity'] is int ? map['capacity'] as int : null,
      active: map['active'] is int ? map['active'] == 1 : (map['active'] is String ? map['active'] == '1' : true),
      createdAt: DateTime.parse(map['created_at'] as String),
    );
  }
}

class StoreStock {
  final int? id;
  final int storeId;
  final int productId;
  final int stockQuantity;
  final int minStockLevel;

  StoreStock({
    this.id,
    required this.storeId,
    required this.productId,
    this.stockQuantity = 0,
    this.minStockLevel = 5,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'store_id': storeId,
      'product_id': productId,
      'stock_quantity': stockQuantity,
      'min_stock_level': minStockLevel,
    };
  }

  factory StoreStock.fromMap(Map<String, dynamic> map) {
    return StoreStock(
      id: map['id'] is int ? map['id'] as int : null,
      storeId: map['store_id'] is int ? map['store_id'] as int : (map['store_id'] is String ? int.tryParse(map['store_id']) ?? 0 : 0),
      productId: map['product_id'] is int ? map['product_id'] as int : (map['product_id'] is String ? int.tryParse(map['product_id']) ?? 0 : 0),
      stockQuantity: map['stock_quantity'] is int ? map['stock_quantity'] as int : (map['stock_quantity'] is String ? int.tryParse(map['stock_quantity']) ?? 0 : 0),
      minStockLevel: map['min_stock_level'] is int ? map['min_stock_level'] as int : (map['min_stock_level'] is String ? int.tryParse(map['min_stock_level']) ?? 5 : 5),
    );
  }
}
