class Category {
  final int? id;
  final String name;
  final String color;
  final String? description;
  final bool active;
  final int? sortOrder;
  final DateTime createdAt;

  Category({
    this.id,
    required this.name,
    required this.color,
    this.description,
    this.active = true,
    this.sortOrder,
    DateTime? createdAt,
  }) : createdAt = createdAt ?? DateTime.now();

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'name': name,
      'color': color,
      'description': description,
      'active': active ? 1 : 0,
      'sort_order': sortOrder,
      'created_at': createdAt.toIso8601String(),
    };
  }

  factory Category.fromMap(Map<String, dynamic> map) {
    return Category(
      id: map['id'] is int ? map['id'] as int : null,
      name: (map['name'] ?? '') as String,
      color: (map['color'] ?? '#FF9800') as String,
      description: map['description'] as String?,
      active: map['active'] is int ? (map['active'] as int) == 1 : (map['active'] is String ? map['active'] == '1' : true),
      sortOrder: map['sort_order'] is int ? map['sort_order'] as int : (map['sort_order'] is String ? int.tryParse(map['sort_order']) : null),
      createdAt: map['created_at'] != null
          ? DateTime.parse(map['created_at'] as String)
          : DateTime.now(),
    );
  }
}