class Sale {
  final int? id;
  final String ticketNumber;
  final int storeId;
  final int employeeId;
  final int? customerId;
  final int? shiftId;
  final DateTime saleDate;
  final double subtotal;
  final double taxAmount;
  final double discountAmount;
  final double totalAmount;
  final String paymentMethod;
  final String status;
  final DateTime createdAt;

  Sale({
    this.id,
    required this.ticketNumber,
    required this.storeId,
    required this.employeeId,
    this.customerId,
    this.shiftId,
    DateTime? saleDate,
    required this.subtotal,
    required this.taxAmount,
    required this.discountAmount,
    required this.totalAmount,
    required this.paymentMethod,
    this.status = 'completed',
    DateTime? createdAt,
  })  : saleDate = saleDate ?? DateTime.now(),
        createdAt = createdAt ?? DateTime.now();

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'ticket_number': ticketNumber,
      'store_id': storeId,
      'employee_id': employeeId,
      'customer_id': customerId,
      'shift_id': shiftId,
      'sale_date': saleDate.toIso8601String(),
      'subtotal': subtotal,
      'tax_amount': taxAmount,
      'discount_amount': discountAmount,
      'total_amount': totalAmount,
      'payment_method': paymentMethod,
      'status': status,
      'created_at': createdAt.toIso8601String(),
    };
  }

  factory Sale.fromMap(Map<String, dynamic> map) {
    return Sale(
      id: map['id'] is int ? map['id'] as int : null,
      ticketNumber: map['ticket_number'] as String,
      storeId: map['store_id'] is int ? map['store_id'] as int : (map['store_id'] is String ? int.tryParse(map['store_id']) ?? 0 : 0),
      employeeId: map['employee_id'] is int ? map['employee_id'] as int : (map['employee_id'] is String ? int.tryParse(map['employee_id']) ?? 0 : 0),
      customerId: map['customer_id'] is int ? map['customer_id'] as int : (map['customer_id'] is String ? int.tryParse(map['customer_id']) : null),
      shiftId: map['shift_id'] is int ? map['shift_id'] as int : (map['shift_id'] is String ? int.tryParse(map['shift_id']) : null),
      saleDate: DateTime.parse(map['sale_date'] as String),
      subtotal: (map['subtotal'] as num).toDouble(),
      taxAmount: (map['tax_amount'] as num).toDouble(),
      discountAmount: (map['discount_amount'] as num).toDouble(),
      totalAmount: (map['total_amount'] as num).toDouble(),
      paymentMethod: map['payment_method'] as String,
      status: map['status'] as String,
      createdAt: DateTime.parse(map['created_at'] as String),
    );
  }
}

class SaleItem {
  final int? id;
  final int saleId;
  final int productId;
  final int quantity;
  final double unitPrice;
  final double lineTotal;

  SaleItem({
    this.id,
    required this.saleId,
    required this.productId,
    required this.quantity,
    required this.unitPrice,
    required this.lineTotal,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'sale_id': saleId,
      'product_id': productId,
      'quantity': quantity,
      'unit_price': unitPrice,
      'line_total': lineTotal,
    };
  }

  factory SaleItem.fromMap(Map<String, dynamic> map) {
    return SaleItem(
      id: map['id'] is int ? map['id'] as int : null,
      saleId: map['sale_id'] is int ? map['sale_id'] as int : (map['sale_id'] is String ? int.tryParse(map['sale_id']) ?? 0 : 0),
      productId: map['product_id'] is int ? map['product_id'] as int : (map['product_id'] is String ? int.tryParse(map['product_id']) ?? 0 : 0),
      quantity: map['quantity'] is int ? map['quantity'] as int : (map['quantity'] is String ? int.tryParse(map['quantity']) ?? 1 : 1),
      unitPrice: (map['unit_price'] as num).toDouble(),
      lineTotal: (map['line_total'] as num).toDouble(),
    );
  }
}
