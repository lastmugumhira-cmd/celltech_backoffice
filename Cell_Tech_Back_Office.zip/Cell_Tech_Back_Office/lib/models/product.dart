import 'dart:convert';

class Product {
  final int? id;
  final String name;
  final String? description;
  final String sku;
  final String? handle;
  final String? barcode;
  final int categoryId;
  final double price;
  final double? cost;
  final bool trackStock;
  final bool active;
  final DateTime createdAt;
  
  // New fields for enhanced functionality
  final bool? soldByWeight;
  final String? imageUrl;
  final String? storeAvailability; // 'all_stores' or 'specific_stores'
  final List<int>? availableStores;
  final Map<String, dynamic>? storeSettings;
  
  // Stock tracking
  final int stock;

  Product({
    this.id,
    required this.name,
    this.description,
    required this.sku,
    this.handle,
    this.barcode,
    required this.categoryId,
    required this.price,
    this.cost,
    this.trackStock = true,
    this.active = true,
    DateTime? createdAt,
    this.soldByWeight,
    this.imageUrl,
    this.storeAvailability,
    this.availableStores,
    this.storeSettings,
    this.stock = 0,
  }) : createdAt = createdAt ?? DateTime.now();

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'name': name,
      'description': description,
      'sku': sku,
      'handle': handle,
      'barcode': barcode,
      'category_id': categoryId,
      'price': price,
      'cost': cost,
      'track_stock': trackStock ? 1 : 0,
      'active': active ? 1 : 0,
      'created_at': createdAt.toIso8601String(),
      'sold_by_weight': soldByWeight == true ? 1 : 0,
      'image_url': imageUrl,
      'store_availability': storeAvailability,
      'available_stores': availableStores?.join(','),
      'store_settings': storeSettings != null ? 
          jsonEncode(storeSettings) : null,
      'stock': stock,
    };
  }

  factory Product.fromMap(Map<String, dynamic> map) {
    Map<String, dynamic>? storeSettings;
    if (map['store_settings'] != null && map['store_settings'].toString().isNotEmpty) {
      try {
        storeSettings = jsonDecode(map['store_settings'].toString()) as Map<String, dynamic>;
      } catch (e) {
        storeSettings = null;
      }
    }

    return Product(
      id: map['id'] is int ? map['id'] as int : null,
      name: (map['name'] ?? '') as String,
      description: map['description'] as String?,
      sku: (map['sku'] ?? '') as String,
      handle: map['handle'] as String?,
      barcode: map['barcode'] as String?,
      categoryId: map['category_id'] is int ? map['category_id'] as int : (map['category_id'] is String ? int.tryParse(map['category_id']) ?? 0 : 0),
      price: map['price'] != null ? (map['price'] as num).toDouble() : 0.0,
      cost: map['cost'] != null ? (map['cost'] as num).toDouble() : null,
      trackStock: map['track_stock'] is int ? (map['track_stock'] as int) == 1 : (map['track_stock'] is String ? map['track_stock'] == '1' : true),
      active: map['active'] is int ? (map['active'] as int) == 1 : (map['active'] is String ? map['active'] == '1' : true),
      createdAt: map['created_at'] != null
          ? DateTime.parse(map['created_at'] as String)
          : DateTime.now(),
      soldByWeight: map['sold_by_weight'] is int ? (map['sold_by_weight'] as int) == 1 : (map['sold_by_weight'] is String ? map['sold_by_weight'] == '1' : false),
      imageUrl: map['image_url'] as String?,
      storeAvailability: map['store_availability'] as String?,
      availableStores: map['available_stores'] != null && map['available_stores'].toString().isNotEmpty
          ? map['available_stores'].toString().split(',').map(int.parse).toList()
          : null,
      storeSettings: storeSettings,
      stock: map['stock'] is int ? map['stock'] as int : (map['stock'] is String ? int.tryParse(map['stock']) ?? 0 : 0),
    );
  }

  Product copyWith({
    int? id,
    String? name,
    String? description,
    String? sku,
    String? handle,
    String? barcode,
    int? categoryId,
    double? price,
    double? cost,
    bool? trackStock,
    bool? active,
    DateTime? createdAt,
    bool? soldByWeight,
    String? imageUrl,
    String? storeAvailability,
    List<int>? availableStores,
    Map<String, dynamic>? storeSettings,
    int? stock,
  }) {
    return Product(
      id: id ?? this.id,
      name: name ?? this.name,
      description: description ?? this.description,
      sku: sku ?? this.sku,
      handle: handle ?? this.handle,
      barcode: barcode ?? this.barcode,
      categoryId: categoryId ?? this.categoryId,
      price: price ?? this.price,
      cost: cost ?? this.cost,
      trackStock: trackStock ?? this.trackStock,
      active: active ?? this.active,
      createdAt: createdAt ?? this.createdAt,
      soldByWeight: soldByWeight ?? this.soldByWeight,
      imageUrl: imageUrl ?? this.imageUrl,
      storeAvailability: storeAvailability ?? this.storeAvailability,
      availableStores: availableStores ?? this.availableStores,
      storeSettings: storeSettings ?? this.storeSettings,
      stock: stock ?? this.stock,
    );
  }
}