class Employee {
  final int? id;
  final String name;
  final String email;
  final String phone;
  final String username;
  final String passwordHash;
  final String pin;
  final String role;
  final String assignedStoreIds;
  final bool active;
  final DateTime createdAt;

  Employee({
    this.id,
    required this.name,
    required this.email,
    required this.phone,
    required this.username,
    required this.passwordHash,
    required this.pin,
    required this.role,
    this.assignedStoreIds = '[]',
    this.active = true,
    DateTime? createdAt,
  }) : createdAt = createdAt ?? DateTime.now();

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'name': name,
      'email': email,
      'phone': phone,
      'username': username,
      'password_hash': passwordHash,
      'pin': pin,
      'role': role,
      'assigned_store_ids': assignedStoreIds,
      'active': active ? 1 : 0,
      'created_at': createdAt.toIso8601String(),
    };
  }

  factory Employee.fromMap(Map<String, dynamic> map) {
    return Employee(
      id: map['id'] is int ? map['id'] as int : null,
      name: map['name'] as String,
      email: map['email'] as String,
      phone: map['phone'] as String,
      username: map['username'] as String,
      passwordHash: map['password_hash'] as String,
      pin: map['pin'] as String,
      role: map['role'] as String,
      assignedStoreIds: map['assigned_store_ids'] as String? ?? '[]',
      active: map['active'] is int ? map['active'] == 1 : (map['active'] is String ? map['active'] == '1' : true),
      createdAt: DateTime.parse(map['created_at'] as String),
    );
  }
}
