class Shift {
  final int? id;
  final int storeId;
  final int employeeId;
  final DateTime startTime;
  final DateTime? endTime;
  final double startingCash;
  final double? endingCash;
  final double? cashVariance;
  final double grossSales;
  final String status;
  final double totalSales;
  final int totalTransactions;
  final DateTime createdAt;

  Shift({
    this.id,
    this.storeId = 1,
    required this.employeeId,
    DateTime? startTime,
    this.endTime,
    this.startingCash = 0.0,
    this.endingCash,
    this.cashVariance,
    this.grossSales = 0.0,
    this.status = 'open',
    this.totalSales = 0.0,
    this.totalTransactions = 0,
    DateTime? createdAt,
  }) : startTime = startTime ?? DateTime.now(),
       createdAt = createdAt ?? DateTime.now();

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'store_id': storeId,
      'employee_id': employeeId,
      'start_time': startTime.toIso8601String(),
      'end_time': endTime?.toIso8601String(),
      'starting_cash': startingCash,
      'ending_cash': endingCash,
      'cash_variance': cashVariance,
      'gross_sales': grossSales,
      'status': status,
      'total_sales': totalSales,
      'total_transactions': totalTransactions,
      'created_at': createdAt.toIso8601String(),
    };
  }

  factory Shift.fromMap(Map<String, dynamic> map) {
    return Shift(
      id: map['id'] is int ? map['id'] as int : null,
      storeId: map['store_id'] is int ? map['store_id'] as int : (map['store_id'] is String ? int.tryParse(map['store_id']) ?? 0 : 0),
      employeeId: map['employee_id'] is int ? map['employee_id'] as int : (map['employee_id'] is String ? int.tryParse(map['employee_id']) ?? 0 : 0),
      startTime: DateTime.parse(map['start_time'] as String),
      endTime: map['end_time'] != null ? DateTime.parse(map['end_time'] as String) : null,
      startingCash: (map['starting_cash'] as num).toDouble(),
      endingCash: map['ending_cash'] != null ? (map['ending_cash'] as num).toDouble() : null,
      cashVariance: map['cash_variance'] != null ? (map['cash_variance'] as num).toDouble() : null,
      grossSales: (map['gross_sales'] as num).toDouble(),
      status: map['status'] as String,
      totalSales: (map['total_sales'] as num?)?.toDouble() ?? 0.0,
      totalTransactions: map['total_transactions'] is int ? map['total_transactions'] as int : (map['total_transactions'] is String ? int.tryParse(map['total_transactions']) ?? 0 : 0),
      createdAt: map['created_at'] != null ? DateTime.parse(map['created_at'] as String) : DateTime.now(),
    );
  }

  Shift copyWith({
    int? id,
    int? storeId,
    int? employeeId,
    DateTime? startTime,
    DateTime? endTime,
    double? startingCash,
    double? endingCash,
    double? cashVariance,
    double? grossSales,
    String? status,
    double? totalSales,
    int? totalTransactions,
    DateTime? createdAt,
  }) {
    return Shift(
      id: id ?? this.id,
      storeId: storeId ?? this.storeId,
      employeeId: employeeId ?? this.employeeId,
      startTime: startTime ?? this.startTime,
      endTime: endTime ?? this.endTime,
      startingCash: startingCash ?? this.startingCash,
      endingCash: endingCash ?? this.endingCash,
      cashVariance: cashVariance ?? this.cashVariance,
      grossSales: grossSales ?? this.grossSales,
      status: status ?? this.status,
      totalSales: totalSales ?? this.totalSales,
      totalTransactions: totalTransactions ?? this.totalTransactions,
      createdAt: createdAt ?? this.createdAt,
    );
  }
}
