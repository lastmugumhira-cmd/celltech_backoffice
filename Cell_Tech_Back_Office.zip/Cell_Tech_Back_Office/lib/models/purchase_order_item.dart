class PurchaseOrderItem {
  final int? id;
  final int purchaseOrderId;
  final int productId;
  final int quantity;
  final double unitCost;
  final double totalCost;

  PurchaseOrderItem({
    this.id,
    required this.purchaseOrderId,
    required this.productId,
    required this.quantity,
    required this.unitCost,
    required this.totalCost,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'purchase_order_id': purchaseOrderId,
      'product_id': productId,
      'quantity': quantity,
      'unit_cost': unitCost,
      'total_cost': totalCost,
    };
  }

  factory PurchaseOrderItem.fromMap(Map<String, dynamic> map) {
    return PurchaseOrderItem(
      id: map['id'],
      purchaseOrderId: map['purchase_order_id'],
      productId: map['product_id'],
      quantity: map['quantity'],
      unitCost: map['unit_cost']?.toDouble() ?? 0.0,
      totalCost: map['total_cost']?.toDouble() ?? 0.0,
    );
  }
}
