class Settings {
  final int? id;
  final String key;
  final String value;

  Settings({
    this.id,
    required this.key,
    required this.value,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'key': key,
      'value': value,
    };
  }

  factory Settings.fromMap(Map<String, dynamic> map) {
    return Settings(
      id: map['id'] is int ? map['id'] as int : null,
      key: map['key'] as String,
      value: map['value'] as String,
    );
  }
}
