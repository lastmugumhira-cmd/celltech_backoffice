class Receipt {
  final int? id;
  final String receiptNumber;
  final int storeId;
  final int employeeId;
  final int? customerId;
  final DateTime saleDate;
  final String transactionType; // 'sale' or 'refund'
  final String paymentStatus; // 'completed', 'refunded', 'pending'
  final double subtotal;
  final double taxAmount;
  final double discountAmount;
  final double totalAmount;
  final String paymentMethod;
  final List<Map<String, dynamic>>? items;
  final String? notes;
  final DateTime createdAt;

  Receipt({
    this.id,
    required this.receiptNumber,
    required this.storeId,
    required this.employeeId,
    this.customerId,
    required this.saleDate,
    this.transactionType = 'sale',
    this.paymentStatus = 'completed',
    required this.subtotal,
    this.taxAmount = 0.0,
    this.discountAmount = 0.0,
    required this.totalAmount,
    required this.paymentMethod,
    this.items,
    this.notes,
    DateTime? createdAt,
  }) : createdAt = createdAt ?? DateTime.now();

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'receipt_number': receiptNumber,
      'store_id': storeId,
      'employee_id': employeeId,
      'customer_id': customerId,
      'sale_date': saleDate.toIso8601String(),
      'transaction_type': transactionType,
      'payment_status': paymentStatus,
      'subtotal': subtotal,
      'tax_amount': taxAmount,
      'discount_amount': discountAmount,
      'total_amount': totalAmount,
      'payment_method': paymentMethod,
      'items': items?.toString(),
      'notes': notes,
      'created_at': createdAt.toIso8601String(),
    };
  }

  factory Receipt.fromMap(Map<String, dynamic> map) {
    return Receipt(
      id: map['id'] is int ? map['id'] as int : null,
      receiptNumber: map['receipt_number'] as String,
      storeId: map['store_id'] is int ? map['store_id'] as int : (map['store_id'] is String ? int.tryParse(map['store_id']) ?? 0 : 0),
      employeeId: map['employee_id'] is int ? map['employee_id'] as int : (map['employee_id'] is String ? int.tryParse(map['employee_id']) ?? 0 : 0),
      customerId: map['customer_id'] is int ? map['customer_id'] as int : (map['customer_id'] is String ? int.tryParse(map['customer_id']) : null),
      saleDate: DateTime.parse(map['sale_date'] as String),
      transactionType: map['transaction_type'] as String? ?? 'sale',
      paymentStatus: map['payment_status'] as String? ?? 'completed',
      subtotal: (map['subtotal'] as num).toDouble(),
      taxAmount: (map['tax_amount'] as num?)?.toDouble() ?? 0.0,
      discountAmount: (map['discount_amount'] as num?)?.toDouble() ?? 0.0,
      totalAmount: (map['total_amount'] as num).toDouble(),
      paymentMethod: map['payment_method'] as String,
      notes: map['notes'] as String?,
      createdAt: DateTime.parse(map['created_at'] as String),
    );
  }

  Receipt copyWith({
    int? id,
    String? receiptNumber,
    int? storeId,
    int? employeeId,
    int? customerId,
    DateTime? saleDate,
    String? transactionType,
    String? paymentStatus,
    double? subtotal,
    double? taxAmount,
    double? discountAmount,
    double? totalAmount,
    String? paymentMethod,
    List<Map<String, dynamic>>? items,
    String? notes,
    DateTime? createdAt,
  }) {
    return Receipt(
      id: id ?? this.id,
      receiptNumber: receiptNumber ?? this.receiptNumber,
      storeId: storeId ?? this.storeId,
      employeeId: employeeId ?? this.employeeId,
      customerId: customerId ?? this.customerId,
      saleDate: saleDate ?? this.saleDate,
      transactionType: transactionType ?? this.transactionType,
      paymentStatus: paymentStatus ?? this.paymentStatus,
      subtotal: subtotal ?? this.subtotal,
      taxAmount: taxAmount ?? this.taxAmount,
      discountAmount: discountAmount ?? this.discountAmount,
      totalAmount: totalAmount ?? this.totalAmount,
      paymentMethod: paymentMethod ?? this.paymentMethod,
      items: items ?? this.items,
      notes: notes ?? this.notes,
      createdAt: createdAt ?? this.createdAt,
    );
  }

  bool get isRefund => transactionType == 'refund' || paymentStatus == 'refunded';

  @override
  String toString() {
    return 'Receipt(id: $id, receiptNumber: $receiptNumber, totalAmount: $totalAmount, transactionType: $transactionType)';
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) return true;
    return other is Receipt &&
        other.id == id &&
        other.receiptNumber == receiptNumber &&
        other.storeId == storeId &&
        other.employeeId == employeeId &&
        other.customerId == customerId &&
        other.saleDate == saleDate &&
        other.transactionType == transactionType &&
        other.paymentStatus == paymentStatus &&
        other.totalAmount == totalAmount;
  }

  @override
  int get hashCode {
    return Object.hash(
      id,
      receiptNumber,
      storeId,
      employeeId,
      customerId,
      saleDate,
      transactionType,
      paymentStatus,
      totalAmount,
    );
  }
}