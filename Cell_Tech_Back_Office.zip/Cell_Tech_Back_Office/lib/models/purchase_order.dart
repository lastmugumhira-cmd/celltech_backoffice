import 'dart:convert';

class PurchaseOrder {
  final int? id;
  final String poNumber;
  final int? supplierId;
  final String status; // 'draft', 'pending', 'received', 'cancelled'
  final List<int>? destinationStores;
  final DateTime? expectedDeliveryDate;
  final double totalAmount;
  final String? notes;
  final int? createdBy;
  final DateTime createdAt;
  final DateTime? receivedAt;

  PurchaseOrder({
    this.id,
    required this.poNumber,
    this.supplierId,
    required this.status,
    this.destinationStores,
    this.expectedDeliveryDate,
    this.totalAmount = 0.0,
    this.notes,
    this.createdBy,
    required this.createdAt,
    this.receivedAt,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'po_number': poNumber,
      'supplier_id': supplierId,
      'status': status,
      'destination_stores':
          destinationStores != null ? jsonEncode(destinationStores) : null,
      'expected_delivery_date': expectedDeliveryDate?.toIso8601String(),
      'total_amount': totalAmount,
      'notes': notes,
      'created_by': createdBy,
      'created_at': createdAt.toIso8601String(),
      'received_at': receivedAt?.toIso8601String(),
    };
  }

  factory PurchaseOrder.fromMap(Map<String, dynamic> map) {
    return PurchaseOrder(
      id: map['id'],
      poNumber: map['po_number'],
      supplierId: map['supplier_id'],
      status: map['status'],
      destinationStores: map['destination_stores'] != null
          ? List<int>.from(jsonDecode(map['destination_stores']))
          : null,
      expectedDeliveryDate: map['expected_delivery_date'] != null
          ? DateTime.parse(map['expected_delivery_date'])
          : null,
      totalAmount: map['total_amount']?.toDouble() ?? 0.0,
      notes: map['notes'],
      createdBy: map['created_by'],
      createdAt: DateTime.parse(map['created_at']),
      receivedAt: map['received_at'] != null
          ? DateTime.parse(map['received_at'])
          : null,
    );
  }
}
