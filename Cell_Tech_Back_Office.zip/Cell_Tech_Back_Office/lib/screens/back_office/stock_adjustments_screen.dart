import 'package:flutter/material.dart';
import '../../services/database_service.dart';
import '../../services/pdf_service.dart';
import '../../models/store.dart';
import '../../widgets/back_office_layout.dart';
import '../../widgets/components/advanced_stock_adjustment_dialog.dart';

class StockAdjustmentsScreen extends StatefulWidget {
  const StockAdjustmentsScreen({super.key});

  @override
  State<StockAdjustmentsScreen> createState() => _StockAdjustmentsScreenState();
}

class _StockAdjustmentsScreenState extends State<StockAdjustmentsScreen> {
  List<Map<String, dynamic>> _adjustments = [];
  List<Store> _stores = [];
  bool _loading = true;
  String _search = '';
  String _reason = 'all';
  String _status = 'all';
  int? _storeId;

  // pagination
  int _page = 0;
  int _rowsPerPage = 25;
  final _rowsOptions = const [10, 25, 50, 100];

  final Map<String, Map<String, dynamic>> _reasonConfig = const {
    'receive_items': {'label': 'Receive Items', 'icon': Icons.add_circle, 'color': Colors.green},
    'loss': {'label': 'Loss', 'icon': Icons.remove_circle, 'color': Colors.red},
    'damage': {'label': 'Damage', 'icon': Icons.broken_image, 'color': Colors.orange},
  };

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    try {
      final adjustments = await DatabaseService.getStockAdjustments();
      final stores = await DatabaseService.getStores();
      setState(() {
        _adjustments = adjustments;
        _stores = stores;
        _loading = false;
      });
    } catch (e) {
      setState(() => _loading = false);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Failed to load: $e')));
      }
    }
  }

  List<Map<String, dynamic>> get _filtered {
    var list = _adjustments.where((a) {
      final q = _search.toLowerCase();
      final matchQ = q.isEmpty ||
          a['adjustment_number'].toString().toLowerCase().contains(q) ||
          (a['notes']?.toString().toLowerCase().contains(q) ?? false);
      final matchReason = _reason == 'all' || a['reason'] == _reason;
      final matchStatus = _status == 'all' || a['status'] == _status;
      final matchStore = _storeId == null || a['store_id'] == _storeId;
      return matchQ && matchReason && matchStatus && matchStore;
    }).toList();
    list.sort((a, b) => DateTime.parse(b['created_at']).compareTo(DateTime.parse(a['created_at'])));
    return list;
  }

  List<Map<String, dynamic>> get _pageItems {
    final filtered = _filtered;
    final start = _page * _rowsPerPage;
    final end = (start + _rowsPerPage).clamp(0, filtered.length);
    if (start >= filtered.length) return [];
    return filtered.sublist(start, end);
  }

  void _openCreate() async {
    final saved = await showDialog<bool>(
      context: context,
      barrierDismissible: false,
      builder: (context) => const AdvancedStockAdjustmentDialog(),
    );
    if (saved == true) {
      await _load();
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Stock adjustment created successfully')));
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return BackOfficeLayout(
      title: 'Stock Adjustments',
      currentRoute: '/backoffice/inventory/adjustments',
      child: _loading ? const Center(child: CircularProgressIndicator()) : _buildContent(),
    );
  }

  Widget _buildContent() {
    final total = _filtered.length;
    final totalPages = (total / _rowsPerPage).ceil().clamp(1, 999999);

    return Column(
      children: [
        _buildHeader(),
        const SizedBox(height: 16),
        _buildFilters(),
        const SizedBox(height: 16),
        Expanded(child: _buildTable()),
        _buildPager(total, totalPages),
      ],
    );
  }

  Widget _buildHeader() {
    return Row(
      children: [
        Container(
          padding: const EdgeInsets.all(10),
          decoration: BoxDecoration(
            gradient: const LinearGradient(colors: [Color(0xFFFF8C00), Color(0xFFFF6B35)]),
            borderRadius: BorderRadius.circular(10),
          ),
          child: const Icon(Icons.tune, color: Colors.white),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('Stock Adjustments', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
              Text('Manage inventory adjustments and corrections', style: TextStyle(color: Colors.grey.shade600)),
            ],
          ),
        ),
        ElevatedButton.icon(
          onPressed: _openCreate,
          icon: const Icon(Icons.add),
          label: const Text('Create Adjustment'),
          style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFFFF8C00), foregroundColor: Colors.white),
        ),
      ],
    );
  }

  Widget _buildFilters() {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Wrap(
          spacing: 12,
          runSpacing: 12,
          crossAxisAlignment: WrapCrossAlignment.center,
          children: [
            SizedBox(
              width: 320,
              child: TextField(
                decoration: const InputDecoration(labelText: 'Search by number or notes', prefixIcon: Icon(Icons.search), border: OutlineInputBorder(), isDense: true),
                onChanged: (v) => setState(() {
                  _search = v;
                  _page = 0;
                }),
              ),
            ),
            SizedBox(
              width: 220,
              child: DropdownButtonFormField<String>(
                initialValue: _reason,
                decoration: const InputDecoration(labelText: 'Reason', border: OutlineInputBorder(), isDense: true),
                items: const [
                  DropdownMenuItem(value: 'all', child: Text('All Reasons')),
                  DropdownMenuItem(value: 'receive_items', child: Text('Receive Items')),
                  DropdownMenuItem(value: 'loss', child: Text('Loss')),
                  DropdownMenuItem(value: 'damage', child: Text('Damage')),
                ],
                onChanged: (v) => setState(() {
                  _reason = v ?? 'all';
                  _page = 0;
                }),
              ),
            ),
            SizedBox(
              width: 200,
              child: DropdownButtonFormField<String>(
                initialValue: _status,
                decoration: const InputDecoration(labelText: 'Status', border: OutlineInputBorder(), isDense: true),
                items: const [
                  DropdownMenuItem(value: 'all', child: Text('All Status')),
                  DropdownMenuItem(value: 'completed', child: Text('Completed')),
                  DropdownMenuItem(value: 'in_progress', child: Text('In Progress')),
                  DropdownMenuItem(value: 'cancelled', child: Text('Cancelled')),
                ],
                onChanged: (v) => setState(() {
                  _status = v ?? 'all';
                  _page = 0;
                }),
              ),
            ),
            SizedBox(
              width: 220,
              child: DropdownButtonFormField<int?>(
                initialValue: _storeId,
                decoration: const InputDecoration(labelText: 'Store', border: OutlineInputBorder(), isDense: true),
                items: [
                  const DropdownMenuItem(value: null, child: Text('All Stores')),
                  ..._stores.map((s) => DropdownMenuItem(value: s.id, child: Text(s.name))),
                ],
                onChanged: (v) => setState(() {
                  _storeId = v;
                  _page = 0;
                }),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTable() {
    final items = _pageItems;
    if (items.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.tune, size: 64, color: Colors.grey.shade400),
            const SizedBox(height: 10),
            Text('No stock adjustments found', style: TextStyle(color: Colors.grey.shade600)),
          ],
        ),
      );
    }

    return Card(
      child: Column(
        children: [
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(color: Colors.grey.shade100, borderRadius: const BorderRadius.vertical(top: Radius.circular(8))),
            child: const Row(
              children: [
                Expanded(flex: 2, child: Text('Date', style: TextStyle(fontWeight: FontWeight.bold))),
                Expanded(flex: 2, child: Text('Adjustment #', style: TextStyle(fontWeight: FontWeight.bold))),
                Expanded(flex: 2, child: Text('Store', style: TextStyle(fontWeight: FontWeight.bold))),
                Expanded(flex: 2, child: Text('Reason', style: TextStyle(fontWeight: FontWeight.bold))),
                Expanded(flex: 1, child: Text('Status', style: TextStyle(fontWeight: FontWeight.bold))),
                Expanded(flex: 3, child: Text('Notes', style: TextStyle(fontWeight: FontWeight.bold))),
                Expanded(flex: 1, child: Text('Actions', style: TextStyle(fontWeight: FontWeight.bold))),
              ],
            ),
          ),
          Expanded(
            child: ListView.separated(
              itemCount: items.length,
              separatorBuilder: (_, __) => Divider(height: 1, color: Colors.grey.shade200),
              itemBuilder: (context, index) {
                final a = items[index];
                final date = DateTime.parse(a['created_at']);
                final reason = a['reason'] as String;
                final cfg = _reasonConfig[reason];
                final storeName = _stores
                    .firstWhere(
                      (s) => s.id == a['store_id'],
                      orElse: () => Store(name: 'Unknown', address: '-', phone: '-', active: true, createdAt: DateTime.now()),
                    )
                    .name;
                return Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                  child: Row(
                    children: [
                      Expanded(flex: 2, child: Text('${date.day}/${date.month}/${date.year}', style: TextStyle(color: Colors.grey.shade700))),
                      Expanded(flex: 2, child: Text(a['adjustment_number'], style: const TextStyle(fontWeight: FontWeight.w500))),
                      Expanded(flex: 2, child: Text(storeName, overflow: TextOverflow.ellipsis, style: TextStyle(color: Colors.grey.shade700))),
                      Expanded(
                        flex: 2,
                        child: Align(
                          alignment: Alignment.centerLeft,
                          child: Container(
                            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                            decoration: BoxDecoration(color: (cfg?['color'] as Color?)?.withOpacity(0.1) ?? Colors.grey.withOpacity(0.1), borderRadius: BorderRadius.circular(12)),
                            child: Row(mainAxisSize: MainAxisSize.min, children: [
                              Icon(cfg?['icon'] ?? Icons.help, size: 14, color: cfg?['color'] ?? Colors.grey),
                              const SizedBox(width: 4),
                              Text(cfg?['label'] ?? reason, style: TextStyle(fontSize: 12, color: cfg?['color'] ?? Colors.grey)),
                            ]),
                          ),
                        ),
                      ),
                      Expanded(
                        flex: 1,
                        child: Align(
                          alignment: Alignment.centerLeft,
                          child: Container(
                            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                            decoration: BoxDecoration(color: _statusColor(a['status']).withOpacity(0.1), borderRadius: BorderRadius.circular(12)),
                            child: Text(a['status'].toString().toUpperCase(), style: TextStyle(fontSize: 12, color: _statusColor(a['status']), fontWeight: FontWeight.bold)),
                          ),
                        ),
                      ),
                      Expanded(flex: 3, child: Text(a['notes'] ?? '-', maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(color: Colors.grey.shade700))),
                      Expanded(
                        flex: 1,
                        child: Align(
                          alignment: Alignment.centerRight,
                          child: Wrap(
                            spacing: 4,
                            children: [
                              IconButton(
                                tooltip: 'Download PDF',
                                icon: const Icon(Icons.download, size: 18),
                                onPressed: () => _downloadPdf(a),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  Color _statusColor(String status) {
    switch (status) {
      case 'completed':
        return Colors.green;
      case 'in_progress':
        return Colors.orange;
      case 'cancelled':
        return Colors.red;
      default:
        return Colors.grey;
    }
  }

  Future<void> _downloadPdf(Map<String, dynamic> adjustment) async {
    try {
      final data = await PdfService.generateStockAdjustmentPdf(adjustment);
      final filename = 'stock_adjustment_${adjustment['adjustment_number']}.pdf';
      await PdfService.downloadPdf(data, filename);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('PDF generated')));
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('PDF error: $e')));
      }
    }
  }

  Widget _buildPager(int total, int totalPages) {
    final start = _page * _rowsPerPage + 1;
    final end = ((_page + 1) * _rowsPerPage).clamp(0, total);
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(color: Colors.grey.shade50, border: Border(top: BorderSide(color: Colors.grey.shade200))),
      child: Row(
        children: [
          Text('Showing $start-$end of $total', style: TextStyle(color: Colors.grey.shade700)),
          const Spacer(),
          Row(children: [
            const Text('Rows per page:'),
            const SizedBox(width: 8),
            DropdownButton<int>(
              value: _rowsPerPage,
              underline: Container(),
              items: _rowsOptions.map((r) => DropdownMenuItem(value: r, child: Text('$r'))).toList(),
              onChanged: (v) => setState(() {
                _rowsPerPage = v ?? 25;
                _page = 0;
              }),
            ),
            const SizedBox(width: 12),
            IconButton(onPressed: _page > 0 ? () => setState(() => _page--) : null, icon: const Icon(Icons.chevron_left)),
            Text('${_page + 1} of $totalPages', style: TextStyle(color: Colors.grey.shade700)),
            IconButton(onPressed: _page < totalPages - 1 ? () => setState(() => _page++) : null, icon: const Icon(Icons.chevron_right)),
          ]),
        ],
      ),
    );
  }
}
