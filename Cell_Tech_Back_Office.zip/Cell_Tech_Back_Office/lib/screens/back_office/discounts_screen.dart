import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../../services/database_service.dart';
import '../../models/store.dart';
import '../../models/employee.dart';
import '../../widgets/back_office_layout.dart';
import 'dart:math' as math;

class DiscountsScreen extends StatefulWidget {
  const DiscountsScreen({super.key});

  @override
  State<DiscountsScreen> createState() => _DiscountsScreenState();
}

class _DiscountsScreenState extends State<DiscountsScreen> {
  List<Store> _stores = [];
  List<Employee> _employees = [];
  List<Map<String, dynamic>> _discountData = [];
  bool _isLoading = false;

  // Date filters
  DateTime _startDate = DateTime.now().subtract(const Duration(days: 7));
  DateTime _endDate = DateTime.now();
  int? _filterStoreId;
  int? _filterEmployeeId;
  String _datePreset = 'Last 7 Days';

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  Future<void> _loadData() async {
    setState(() => _isLoading = true);
    
    try {
      // Load stores and employees
      final stores = await DatabaseService.getStores();
      final employees = await DatabaseService.getEmployees();
      
      setState(() {
        _stores = stores;
        _employees = employees;
      });
      
      _generateMockDiscountData();
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error loading data: $e')),
        );
      }
    } finally {
      setState(() => _isLoading = false);
    }
  }

  void _generateMockDiscountData() {
    final random = math.Random();
    final discountTypes = [
      'Student Discount',
      'Senior Discount',
      'Seasonal Sale',
      'Employee Discount',
      'Bulk Purchase',
      'First Time Customer',
      'Loyalty Rewards',
      'Happy Hour',
      'Clearance Sale',
      'Holiday Special',
    ];

    final data = discountTypes.map((name) {
      final appliedCount = random.nextInt(50) + 1;
      final averageDiscount = 5 + random.nextDouble() * 25; // $5-$30 average
      final totalAmount = appliedCount * averageDiscount * (0.8 + random.nextDouble() * 0.4);

      return {
        'name': name,
        'discounts_applied': appliedCount,
        'amount_discounted': totalAmount,
      };
    }).toList();

    // Sort by amount discounted (descending)
    data.sort((a, b) => (b['amount_discounted'] as double).compareTo(a['amount_discounted'] as double));

    setState(() {
      _discountData = data;
    });
  }

  void _setDatePreset(String preset) {
    DateTime start;
    DateTime end = DateTime.now();
    
    switch (preset) {
      case 'Today':
        start = DateTime(end.year, end.month, end.day);
        break;
      case 'Yesterday':
        start = DateTime(end.year, end.month, end.day - 1);
        end = DateTime(end.year, end.month, end.day - 1, 23, 59, 59);
        break;
      case 'Last 7 Days':
        start = end.subtract(const Duration(days: 7));
        break;
      case 'Last 30 Days':
        start = end.subtract(const Duration(days: 30));
        break;
      case 'This Month':
        start = DateTime(end.year, end.month, 1);
        break;
      case 'Last Month':
        start = DateTime(end.year, end.month - 1, 1);
        end = DateTime(end.year, end.month, 0, 23, 59, 59);
        break;
      default:
        start = end.subtract(const Duration(days: 7));
    }
    
    setState(() {
      _datePreset = preset;
      _startDate = start;
      _endDate = end;
    });
    
    // In a real implementation, this would refetch discount data
    _generateMockDiscountData();
  }

  void _exportData() {
    // Mock export functionality
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Export functionality - would export discount data to CSV/Excel'),
        duration: Duration(seconds: 2),
      ),
    );
    print('Exporting discount data...');
  }

  @override
  Widget build(BuildContext context) {
    return BackOfficeLayout(
      title: 'Discounts',
      currentRoute: '/backoffice/discounts',
      child: _isLoading 
        ? const Center(child: CircularProgressIndicator())
        : SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _buildHeader(),
                const SizedBox(height: 24),
                _buildFilters(),
                const SizedBox(height: 24),
                _buildDiscountTable(),
              ],
            ),
          ),
    );
  }

  Widget _buildHeader() {
    return Row(
      children: [
        IconButton(
          onPressed: () => Navigator.of(context).pushReplacementNamed('/backoffice/dashboard'),
          icon: const Icon(Icons.arrow_back),
          tooltip: 'Back to Dashboard',
        ),
        const SizedBox(width: 8),
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Discounts',
              style: TextStyle(
                fontSize: 28,
                fontWeight: FontWeight.bold,
              ),
            ),
            Text(
              'Discount usage and impact analysis',
              style: TextStyle(
                fontSize: 14,
                color: Colors.grey.shade600,
              ),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildFilters() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.grey.shade50,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.grey.shade200),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Filters',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 16),
          
          // Date presets
          Wrap(
            spacing: 8,
            children: [
              'Today', 'Yesterday', 'Last 7 Days', 'Last 30 Days', 'This Month', 'Last Month'
            ].map((preset) => 
              FilterChip(
                label: Text(preset),
                selected: _datePreset == preset,
                onSelected: (selected) => selected ? _setDatePreset(preset) : null,
                selectedColor: Colors.blue.shade100,
              )
            ).toList(),
          ),
          
          const SizedBox(height: 16),
          
          // Custom date range and dropdowns
          Row(
            children: [
              Expanded(
                flex: 2,
                child: _buildDatePicker('Start Date', _startDate, (date) {
                  setState(() {
                    _startDate = date;
                    _datePreset = 'Custom';
                  });
                  _generateMockDiscountData();
                }),
              ),
              const SizedBox(width: 16),
              Expanded(
                flex: 2,
                child: _buildDatePicker('End Date', _endDate, (date) {
                  setState(() {
                    _endDate = date;
                    _datePreset = 'Custom';
                  });
                  _generateMockDiscountData();
                }),
              ),
              const SizedBox(width: 16),
              Expanded(
                flex: 2,
                child: DropdownButtonFormField<int?>(
                  initialValue: _filterStoreId,
                  decoration: const InputDecoration(
                    labelText: 'Store',
                    border: OutlineInputBorder(),
                    isDense: true,
                  ),
                  items: [
                    const DropdownMenuItem(value: null, child: Text('All Stores')),
                    ..._stores.map((store) => DropdownMenuItem(
                          value: store.id,
                          child: Text(store.name),
                        )),
                  ],
                  onChanged: (value) {
                    setState(() => _filterStoreId = value);
                    _generateMockDiscountData();
                  },
                ),
              ),
              const SizedBox(width: 16),
              Expanded(
                flex: 2,
                child: DropdownButtonFormField<int?>(
                  initialValue: _filterEmployeeId,
                  decoration: const InputDecoration(
                    labelText: 'Employee',
                    border: OutlineInputBorder(),
                    isDense: true,
                  ),
                  items: [
                    const DropdownMenuItem(value: null, child: Text('All Employees')),
                    ..._employees.map((emp) => DropdownMenuItem(
                          value: emp.id,
                          child: Text(emp.name),
                        )),
                  ],
                  onChanged: (value) {
                    setState(() => _filterEmployeeId = value);
                    _generateMockDiscountData();
                  },
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildDatePicker(String label, DateTime date, Function(DateTime) onDateSelected) {
    return InkWell(
      onTap: () async {
        final picked = await showDatePicker(
          context: context,
          initialDate: date,
          firstDate: DateTime(2020),
          lastDate: DateTime.now(),
        );
        if (picked != null) {
          onDateSelected(picked);
        }
      },
      child: InputDecorator(
        decoration: InputDecoration(
          labelText: label,
          border: const OutlineInputBorder(),
          isDense: true,
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(DateFormat('yyyy-MM-dd').format(date)),
            const Icon(Icons.calendar_today, size: 18),
          ],
        ),
      ),
    );
  }

  Widget _buildDiscountTable() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.grey.shade200),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Text(
                'Discount Usage',
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const Spacer(),
              ElevatedButton.icon(
                onPressed: _exportData,
                icon: const Icon(Icons.download),
                label: const Text('Export'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.green,
                  foregroundColor: Colors.white,
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          
          if (_discountData.isNotEmpty)
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: DataTable(
                columns: const [
                  DataColumn(
                    label: Text(
                      'Name',
                      style: TextStyle(fontWeight: FontWeight.bold),
                    ),
                  ),
                  DataColumn(
                    label: Text(
                      'Discounts Applied',
                      style: TextStyle(fontWeight: FontWeight.bold),
                    ),
                    numeric: true,
                  ),
                  DataColumn(
                    label: Text(
                      'Amount Discounted',
                      style: TextStyle(fontWeight: FontWeight.bold),
                    ),
                    numeric: true,
                  ),
                ],
                rows: _discountData.map((discount) {
                  final currencyFormat = NumberFormat.currency(symbol: '\$');
                  return DataRow(
                    cells: [
                      DataCell(
                        Row(
                          children: [
                            Container(
                              width: 8,
                              height: 8,
                              margin: const EdgeInsets.only(right: 8),
                              decoration: BoxDecoration(
                                color: Colors.orange.shade400,
                                shape: BoxShape.circle,
                              ),
                            ),
                            Text(discount['name']),
                          ],
                        ),
                      ),
                      DataCell(
                        Text(
                          discount['discounts_applied'].toString(),
                          style: const TextStyle(fontWeight: FontWeight.w500),
                        ),
                      ),
                      DataCell(
                        Text(
                          currencyFormat.format(discount['amount_discounted']),
                          style: TextStyle(
                            fontWeight: FontWeight.w500,
                            color: Colors.red.shade600,
                          ),
                        ),
                      ),
                    ],
                  );
                }).toList(),
              ),
            )
          else
            const SizedBox(
              height: 200,
              child: Center(
                child: Text('No discount data available for the selected period'),
              ),
            ),
        ],
      ),
    );
  }
}