import 'package:flutter/material.dart';
import '../../services/database_service.dart';
import '../../models/store.dart';
import '../../widgets/back_office_layout.dart';

class InventoryHistoryScreen extends StatefulWidget {
  const InventoryHistoryScreen({super.key});

  @override
  State<InventoryHistoryScreen> createState() => _InventoryHistoryScreenState();
}

class _InventoryHistoryScreenState extends State<InventoryHistoryScreen> {
  List<Map<String, dynamic>> _adjustments = [];
  List<Store> _stores = [];
  bool _isLoading = true;
  String _searchQuery = '';
  String _reasonFilter = 'all';
  int? _storeFilter;
  
  // Pagination
  int _currentPage = 0;
  int _rowsPerPage = 25;
  final List<int> _availableRowsPerPage = [25, 50, 100];

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  Future<void> _loadData() async {
    setState(() => _isLoading = true);
    try {
      final adjustments = await DatabaseService.getStockAdjustments();
      final stores = await DatabaseService.getStores();
      
      setState(() {
        _adjustments = adjustments;
        _stores = stores;
        _isLoading = false;
      });
    } catch (e) {
      setState(() => _isLoading = false);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error loading data: $e')),
        );
      }
    }
  }

  List<Map<String, dynamic>> get _filteredAdjustments {
    var filtered = _adjustments.where((adj) {
      final matchesSearch = _searchQuery.isEmpty ||
          adj['adjustment_number'].toString().toLowerCase().contains(_searchQuery.toLowerCase());
      
      final matchesReason = _reasonFilter == 'all' || adj['reason'] == _reasonFilter;
      final matchesStore = _storeFilter == null || adj['store_id'] == _storeFilter;
      
      return matchesSearch && matchesReason && matchesStore;
    }).toList();
    
    filtered.sort((a, b) => DateTime.parse(b['created_at']).compareTo(DateTime.parse(a['created_at'])));
    
    return filtered;
  }

  List<Map<String, dynamic>> get _paginatedAdjustments {
    final filtered = _filteredAdjustments;
    final startIndex = _currentPage * _rowsPerPage;
    final endIndex = (startIndex + _rowsPerPage).clamp(0, filtered.length);
    
    if (startIndex >= filtered.length) return [];
    return filtered.sublist(startIndex, endIndex);
  }

  @override
  Widget build(BuildContext context) {
    return BackOfficeLayout(
      title: 'Inventory History',
      currentRoute: '/backoffice/inventory/history',
      child: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : _buildContent(),
    );
  }

  Widget _buildContent() {
    final totalAdjustments = _filteredAdjustments.length;
    final totalPages = (totalAdjustments / _rowsPerPage).ceil().clamp(1, 999999);
    final startIndex = _currentPage * _rowsPerPage;
    final endIndex = (startIndex + _rowsPerPage).clamp(0, totalAdjustments);

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Header
        Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'Stock Movement History',
                style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 8),
              Text(
                'View all stock adjustments and movements',
                style: TextStyle(fontSize: 14, color: Colors.grey.shade600),
              ),
            ],
          ),
        ),

        // Filters
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 24),
          child: Wrap(
            spacing: 16,
            runSpacing: 16,
            children: [
              SizedBox(
                width: 300,
                child: TextField(
                  decoration: InputDecoration(
                    hintText: 'Search...',
                    prefixIcon: const Icon(Icons.search),
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
                    contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                  ),
                  onChanged: (value) => setState(() {
                    _searchQuery = value;
                    _currentPage = 0;
                  }),
                ),
              ),
              SizedBox(
                width: 200,
                child: DropdownButtonFormField<String>(
                  initialValue: _reasonFilter,
                  decoration: InputDecoration(
                    labelText: 'Reason',
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
                    contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                  ),
                  items: const [
                    DropdownMenuItem(value: 'all', child: Text('All Reasons')),
                    DropdownMenuItem(value: 'inventory_count', child: Text('Inventory Count')),
                    DropdownMenuItem(value: 'damage', child: Text('Damage')),
                    DropdownMenuItem(value: 'loss', child: Text('Loss')),
                    DropdownMenuItem(value: 'found', child: Text('Found')),
                    DropdownMenuItem(value: 'correction', child: Text('Correction')),
                  ],
                  onChanged: (value) => setState(() {
                    _reasonFilter = value!;
                    _currentPage = 0;
                  }),
                ),
              ),
              SizedBox(
                width: 200,
                child: DropdownButtonFormField<int?>(
                  initialValue: _storeFilter,
                  decoration: InputDecoration(
                    labelText: 'Store',
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
                    contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                  ),
                  items: [
                    const DropdownMenuItem(value: null, child: Text('All Stores')),
                    ..._stores.map((store) => DropdownMenuItem(
                      value: store.id,
                      child: Text(store.name),
                    )),
                  ],
                  onChanged: (value) => setState(() {
                    _storeFilter = value;
                    _currentPage = 0;
                  }),
                ),
              ),
            ],
          ),
        ),

        const SizedBox(height: 24),

        // History Table
        Expanded(
          child: Card(
            margin: const EdgeInsets.symmetric(horizontal: 24),
            child: Column(
              children: [
                Expanded(
                  child: SingleChildScrollView(
                    scrollDirection: Axis.horizontal,
                    child: SingleChildScrollView(
                      child: DataTable(
                        columns: const [
                          DataColumn(label: Text('Adjustment #')),
                          DataColumn(label: Text('Store')),
                          DataColumn(label: Text('Reason')),
                          DataColumn(label: Text('Status')),
                          DataColumn(label: Text('Date')),
                        ],
                        rows: _paginatedAdjustments.map((adj) {
                          final store = _stores.firstWhere(
                            (s) => s.id == adj['store_id'],
                            orElse: () => Store(name: 'Unknown', address: '', phone: ''),
                          );
                          
                          return DataRow(
                            cells: [
                              DataCell(Text(adj['adjustment_number'] ?? '')),
                              DataCell(Text(store.name)),
                              DataCell(_buildReasonChip(adj['reason'])),
                              DataCell(_buildStatusChip(adj['status'])),
                              DataCell(Text(_formatDate(adj['created_at']))),
                            ],
                          );
                        }).toList(),
                      ),
                    ),
                  ),
                ),

                // Pagination
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: Colors.grey.shade50,
                    border: Border(top: BorderSide(color: Colors.grey.shade300)),
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Row(
                        children: [
                          const Text('Rows per page:'),
                          const SizedBox(width: 8),
                          DropdownButton<int>(
                            value: _rowsPerPage,
                            items: _availableRowsPerPage.map((rows) {
                              return DropdownMenuItem<int>(
                                value: rows,
                                child: Text('$rows'),
                              );
                            }).toList(),
                            onChanged: (value) {
                              if (value != null) {
                                setState(() {
                                  _rowsPerPage = value;
                                  _currentPage = 0;
                                });
                              }
                            },
                          ),
                        ],
                      ),
                      Row(
                        children: [
                          Text(
                            'Showing ${startIndex + 1}-$endIndex of $totalAdjustments',
                            style: const TextStyle(fontSize: 14),
                          ),
                          const SizedBox(width: 16),
                          IconButton(
                            onPressed: _currentPage > 0
                                ? () => setState(() => _currentPage--)
                                : null,
                            icon: const Icon(Icons.chevron_left),
                            tooltip: 'Previous page',
                          ),
                          Text(
                            'Page ${_currentPage + 1} of $totalPages',
                            style: const TextStyle(fontSize: 14),
                          ),
                          IconButton(
                            onPressed: _currentPage < totalPages - 1
                                ? () => setState(() => _currentPage++)
                                : null,
                            icon: const Icon(Icons.chevron_right),
                            tooltip: 'Next page',
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),

        const SizedBox(height: 24),
      ],
    );
  }

  Widget _buildReasonChip(String reason) {
    String label = reason.replaceAll('_', ' ').toUpperCase();
    
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        color: Colors.blue.withOpacity(0.1),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Text(
        label,
        style: const TextStyle(
          color: Colors.blue,
          fontSize: 12,
          fontWeight: FontWeight.w500,
        ),
      ),
    );
  }

  Widget _buildStatusChip(String status) {
    Color color;
    String label;
    
    switch (status) {
      case 'in_progress':
        color = Colors.orange;
        label = 'In Progress';
        break;
      case 'completed':
        color = Colors.green;
        label = 'Completed';
        break;
      default:
        color = Colors.grey;
        label = status;
    }
    
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        color: color.withOpacity(0.1),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Text(
        label,
        style: TextStyle(
          color: color,
          fontSize: 12,
          fontWeight: FontWeight.w500,
        ),
      ),
    );
  }

  String _formatDate(String? dateStr) {
    if (dateStr == null) return '-';
    try {
      final date = DateTime.parse(dateStr);
      return '${date.day}/${date.month}/${date.year} ${date.hour}:${date.minute.toString().padLeft(2, '0')}';
    } catch (e) {
      return dateStr;
    }
  }
}
