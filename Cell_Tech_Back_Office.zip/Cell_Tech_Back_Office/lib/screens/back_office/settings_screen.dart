import 'package:flutter/material.dart';
import '../../services/database_service.dart';
import '../../widgets/back_office_layout.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  final _businessNameController = TextEditingController();
  final _taxRateController = TextEditingController();
  final _currencyController = TextEditingController();
  bool _allowNegativeStock = false;
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadSettings();
  }

  @override
  void dispose() {
    _businessNameController.dispose();
    _taxRateController.dispose();
    _currencyController.dispose();
    super.dispose();
  }

  Future<void> _loadSettings() async {
    setState(() => _isLoading = true);
    try {
      final businessName = await DatabaseService.getSetting('business_name') ?? 'My Retail Business';
      final taxRate = await DatabaseService.getSetting('tax_rate') ?? '15';
      final currency = await DatabaseService.getSetting('currency') ?? 'USD';
      final allowNegStock = await DatabaseService.getSetting('allow_negative_stock') ?? 'false';

      setState(() {
        _businessNameController.text = businessName;
        _taxRateController.text = taxRate;
        _currencyController.text = currency;
        _allowNegativeStock = allowNegStock == 'true';
        _isLoading = false;
      });
    } catch (e) {
      setState(() => _isLoading = false);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error loading settings: $e')),
        );
      }
    }
  }

  Future<void> _saveSettings() async {
    try {
      await DatabaseService.setSetting('business_name', _businessNameController.text);
      await DatabaseService.setSetting('tax_rate', _taxRateController.text);
      await DatabaseService.setSetting('currency', _currencyController.text);
      await DatabaseService.setSetting('allow_negative_stock', _allowNegativeStock.toString());

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Settings saved successfully'),
            backgroundColor: Colors.green,
          ),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error saving settings: $e')),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return BackOfficeLayout(
      title: 'Settings',
      currentRoute: '/backoffice/settings',
      child: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : _buildContent(),
    );
  }

  Widget _buildContent() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(24),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildSection(
            'Business Information',
            [
              TextField(
                controller: _businessNameController,
                decoration: const InputDecoration(
                  labelText: 'Business Name',
                  border: OutlineInputBorder(),
                  helperText: 'This will appear on receipts and reports',
                ),
              ),
            ],
          ),
          const SizedBox(height: 32),
          _buildSection(
            'Tax Configuration',
            [
              TextField(
                controller: _taxRateController,
                decoration: const InputDecoration(
                  labelText: 'Default Tax Rate (%)',
                  border: OutlineInputBorder(),
                  helperText: 'Tax percentage applied to sales',
                  suffixText: '%',
                ),
                keyboardType: TextInputType.number,
              ),
            ],
          ),
          const SizedBox(height: 32),
          _buildSection(
            'Currency',
            [
              TextField(
                controller: _currencyController,
                decoration: const InputDecoration(
                  labelText: 'Currency Code',
                  border: OutlineInputBorder(),
                  helperText: 'e.g., USD, EUR, GBP',
                ),
              ),
            ],
          ),
          const SizedBox(height: 32),
          _buildSection(
            'Inventory Settings',
            [
              SwitchListTile(
                title: const Text('Allow Negative Stock'),
                subtitle: const Text(
                  'Allow selling products even when stock is 0 or negative',
                ),
                value: _allowNegativeStock,
                onChanged: (value) {
                  setState(() => _allowNegativeStock = value);
                },
              ),
            ],
          ),
          const SizedBox(height: 32),
          Row(
            children: [
              ElevatedButton.icon(
                onPressed: _saveSettings,
                icon: const Icon(Icons.save),
                label: const Text('Save Settings'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.blue,
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 24),
                ),
              ),
              const SizedBox(width: 16),
              TextButton.icon(
                onPressed: _loadSettings,
                icon: const Icon(Icons.refresh),
                label: const Text('Reset to Saved'),
              ),
            ],
          ),
          const SizedBox(height: 48),
          const Divider(),
          const SizedBox(height: 16),
          _buildSection(
            'System Information',
            [
              _buildInfoRow('Database', 'SQLite (Local)'),
              const SizedBox(height: 8),
              _buildInfoRow('Version', '1.0.0'),
              const SizedBox(height: 8),
              _buildInfoRow('Platform', 'Flutter Desktop'),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildSection(String title, List<Widget> children) {
    return Card(
      elevation: 2,
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              title,
              style: const TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 16),
            ...children,
          ],
        ),
      ),
    );
  }

  Widget _buildInfoRow(String label, String value) {
    return Row(
      children: [
        SizedBox(
          width: 120,
          child: Text(
            '$label:',
            style: const TextStyle(fontWeight: FontWeight.bold),
          ),
        ),
        Text(value),
      ],
    );
  }
}
