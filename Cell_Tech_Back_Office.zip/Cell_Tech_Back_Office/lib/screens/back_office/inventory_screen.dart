import 'package:flutter/material.dart';
import 'dart:io';
import 'package:csv/csv.dart';
import 'package:file_picker/file_picker.dart';
import 'package:path_provider/path_provider.dart';
import '../../services/database_service.dart';
import '../../models/store.dart';
import '../../models/product.dart';
import '../../models/category.dart';
import '../../widgets/back_office_layout.dart';
import '../../widgets/components/product_form.dart';

class InventoryScreen extends StatefulWidget {
  const InventoryScreen({super.key});

  @override
  State<InventoryScreen> createState() => _InventoryScreenState();
}

class _InventoryScreenState extends State<InventoryScreen> {
  List<Store> _stores = [];
  List<Category> _categories = [];
  List<Map<String, dynamic>> _inventory = [];
  bool _isLoading = true;
  int? _selectedStoreId; // null means "All Stores"
  String _searchQuery = '';
  String _statusFilter = 'All'; // All, In Stock, Low Stock, Out of Stock
  int? _categoryFilter; // null for All categories
  
  // Selection
  Set<int> _selectedProductIds = <int>{};
  bool _selectAll = false;
  
  // Pagination
  int _currentPage = 0;
  int _rowsPerPage = 25;
  final List<int> _availableRowsPerPage = [10, 25, 50, 100];

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  Future<void> _loadData() async {
    setState(() => _isLoading = true);
    try {
      final stores = await DatabaseService.getStores(active: true);
      final categories = await DatabaseService.getCategories();
      setState(() {
        _stores = stores;
        _categories = categories;
        // Keep _selectedStoreId as null for "All Stores" by default
        _isLoading = false;
      });
      _loadInventory(); // Always load inventory, even for "All Stores"
    } catch (e) {
      setState(() => _isLoading = false);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error loading data: $e')),
        );
      }
    }
  }

  Future<void> _loadInventory() async {
    try {
      List<Map<String, dynamic>> inventory;
      if (_selectedStoreId == null) {
        // Load inventory from all stores
        inventory = await DatabaseService.getAllStoreStock();
      } else {
        // Load inventory from specific store
        inventory = await DatabaseService.getStoreStock(_selectedStoreId!);
      }
      setState(() => _inventory = inventory);
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error loading inventory: $e')),
        );
      }
    }
  }

    List<Map<String, dynamic>> get _filteredInventory {
    return _inventory.where((item) {
      final name = (item['name'] as String).toLowerCase();
      final sku = (item['sku'] as String).toLowerCase();
      final query = _searchQuery.toLowerCase();
      
      // Search filter
      final matchesSearch = name.contains(query) || sku.contains(query);
      
      // Status filter
      final stockQty = item['stock_quantity'] as int;
      final minLevel = item['min_stock_level'] as int;
      final status = _getStockStatus(stockQty, minLevel);
      final matchesStatus = _statusFilter == 'All' || status == _statusFilter;
      
      // Category filter
      final categoryId = item['category_id'] as int?;
      final matchesCategory = _categoryFilter == null || categoryId == _categoryFilter;
      
      return matchesSearch && matchesStatus && matchesCategory;
    }).toList();
  }

  List<Map<String, dynamic>> get _paginatedInventory {
    final filtered = _filteredInventory;
    final startIndex = _currentPage * _rowsPerPage;
    final endIndex = (startIndex + _rowsPerPage).clamp(0, filtered.length);
    
    if (startIndex >= filtered.length) return [];
    return filtered.sublist(startIndex, endIndex);
  }

  @override
  Widget build(BuildContext context) {
    return BackOfficeLayout(
      title: 'Inventory Management',
      currentRoute: '/backoffice/inventory',
      child: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : _buildContent(),
    );
  }

  Widget _buildContent() {
    return Column(
      children: [
        _buildToolbar(),
        Expanded(child: _buildInventoryTable()),
      ],
    );
  }

  Widget _buildToolbar() {
    return Container(
      padding: const EdgeInsets.all(16),
      color: Colors.grey.shade50,
      child: Column(
        children: [
          // First row - Search and Store
          Row(
            children: [
              Expanded(
                flex: 3,
                child: TextField(
                  decoration: const InputDecoration(
                    hintText: 'Search products...',
                    prefixIcon: Icon(Icons.search),
                    border: OutlineInputBorder(),
                    isDense: true,
                  ),
                  onChanged: (value) {
                    setState(() {
                      _searchQuery = value;
                      _currentPage = 0; // Reset to first page
                    });
                  },
                ),
              ),
              const SizedBox(width: 16),
              Expanded(
                flex: 2,
                child: DropdownButtonFormField<int?>(
                  initialValue: _selectedStoreId,
                  decoration: const InputDecoration(
                    labelText: 'Store',
                    border: OutlineInputBorder(),
                    isDense: true,
                  ),
                  items: [
                    const DropdownMenuItem<int?>(
                      value: null,
                      child: Text('All'),
                    ),
                    ..._stores.map((store) => DropdownMenuItem<int?>(
                          value: store.id,
                          child: Text(store.name),
                        )),
                  ],
                  onChanged: (value) {
                    setState(() => _selectedStoreId = value);
                    _loadInventory();
                  },
                ),
              ),
              const SizedBox(width: 16),
              Expanded(
                flex: 2,
                child: DropdownButtonFormField<String>(
                  initialValue: _statusFilter,
                  decoration: const InputDecoration(
                    labelText: 'Status',
                    border: OutlineInputBorder(),
                    isDense: true,
                  ),
                  items: const [
                    DropdownMenuItem(value: 'All', child: Text('All')),
                    DropdownMenuItem(value: 'In Stock', child: Text('In Stock')),
                    DropdownMenuItem(value: 'Low Stock', child: Text('Low Stock')),
                    DropdownMenuItem(value: 'Out of Stock', child: Text('Out')),
                  ],
                  onChanged: (value) {
                    setState(() {
                      _statusFilter = value!;
                      _currentPage = 0; // Reset to first page
                    });
                  },
                ),
              ),
              const SizedBox(width: 16),
              Expanded(
                flex: 2,
                child: DropdownButtonFormField<int?>(
                  initialValue: _categoryFilter,
                  decoration: const InputDecoration(
                    labelText: 'Category',
                    border: OutlineInputBorder(),
                    isDense: true,
                  ),
                  items: [
                    const DropdownMenuItem<int?>(value: null, child: Text('All')),
                    ..._categories.map((category) => DropdownMenuItem<int?>(
                          value: category.id,
                          child: Text(category.name.length > 15 ? '${category.name.substring(0, 15)}...' : category.name),
                        )),
                  ],
                  onChanged: (value) {
                    setState(() {
                      _categoryFilter = value;
                      _currentPage = 0; // Reset to first page
                    });
                  },
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          // Second row - Action buttons
          Row(
            children: [
              ElevatedButton.icon(
                onPressed: _showAddProductDialog,
                icon: const Icon(Icons.add),
                label: const Text('Add Product'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.green,
                  foregroundColor: Colors.white,
                ),
              ),
              const SizedBox(width: 16),
              ElevatedButton.icon(
                onPressed: _importProducts,
                icon: const Icon(Icons.upload),
                label: const Text('Import'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.blue,
                  foregroundColor: Colors.white,
                ),
              ),
              const SizedBox(width: 16),
              ElevatedButton.icon(
                onPressed: _exportProducts,
                icon: const Icon(Icons.download),
                label: const Text('Export'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.orange,
                  foregroundColor: Colors.white,
                ),
              ),
              const SizedBox(width: 16),
              OutlinedButton.icon(
                onPressed: _downloadImportTemplate,
                icon: const Icon(Icons.description, size: 18),
                label: const Text('Template'),
                style: OutlinedButton.styleFrom(
                  foregroundColor: Colors.blue,
                ),
              ),
              const SizedBox(width: 16),
              ElevatedButton.icon(
                onPressed: _selectedProductIds.isEmpty ? null : _deleteSelectedProducts,
                icon: const Icon(Icons.delete),
                label: Text('Delete Selected (${_selectedProductIds.length})'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.red,
                  foregroundColor: Colors.white,
                ),
              ),
              const Spacer(),
              if (_selectedProductIds.isNotEmpty) ...[
                Text('${_selectedProductIds.length} selected'),
                const SizedBox(width: 16),
              ],
              ElevatedButton.icon(
                onPressed: _loadInventory,
                icon: const Icon(Icons.refresh),
                label: const Text('Refresh'),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildInventoryTable() {
    final filteredInventory = _filteredInventory;
    final inventory = _paginatedInventory;
    final totalItems = filteredInventory.length;
    final totalPages = (totalItems / _rowsPerPage).ceil().clamp(1, 999999);
    final startIndex = _currentPage * _rowsPerPage;
    final endIndex = (startIndex + _rowsPerPage).clamp(0, totalItems);

    if (filteredInventory.isEmpty) {
      return const Center(child: Text('No inventory items found'));
    }

    return Card(
      child: Column(
        children: [
          Expanded(
            child: SingleChildScrollView(
              child: SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: DataTable(
                  columns: [
                    DataColumn(
                      label: Checkbox(
                        value: _selectAll,
                        onChanged: _toggleSelectAll,
                      ),
                    ),
                    const DataColumn(label: Text('SKU', style: TextStyle(fontWeight: FontWeight.bold))),
                    const DataColumn(label: Text('Product', style: TextStyle(fontWeight: FontWeight.bold))),
                    const DataColumn(label: Text('Category', style: TextStyle(fontWeight: FontWeight.bold))),
                    if (_selectedStoreId == null) // Show store column only when showing all stores
                      const DataColumn(label: Text('Store', style: TextStyle(fontWeight: FontWeight.bold))),
                    const DataColumn(label: Text('Stock Qty', style: TextStyle(fontWeight: FontWeight.bold))),
                    const DataColumn(label: Text('Min Level', style: TextStyle(fontWeight: FontWeight.bold))),
                    const DataColumn(label: Text('Status', style: TextStyle(fontWeight: FontWeight.bold))),
                    const DataColumn(label: Text('Actions', style: TextStyle(fontWeight: FontWeight.bold))),
                  ],
                  rows: inventory.map((item) {
                    final stockQty = item['stock_quantity'] as int;
                    final minLevel = item['min_stock_level'] as int;
                    final status = _getStockStatus(stockQty, minLevel);
                    final productId = item['product_id'] as int? ?? item['id'] as int;
                    final isSelected = _selectedProductIds.contains(productId);

                    return DataRow(
                      selected: isSelected,
                      onSelectChanged: (selected) => _toggleProductSelection(productId, selected ?? false),
                      color: WidgetStateProperty.resolveWith<Color?>(
                        (Set<WidgetState> states) {
                          if (states.contains(WidgetState.selected)) return Colors.blue.shade50;
                          if (status == 'Out of Stock') return Colors.red.shade50;
                          if (status == 'Low Stock') return Colors.yellow.shade50;
                          return null;
                        },
                      ),
                      cells: [
                        DataCell(
                          Checkbox(
                            value: isSelected,
                            onChanged: (selected) => _toggleProductSelection(productId, selected ?? false),
                          ),
                        ),
                        DataCell(
                          InkWell(
                            onTap: () => _showEditProductDialog(item),
                            child: Text(
                              item['sku'] as String,
                              style: const TextStyle(
                                color: Colors.blue,
                                decoration: TextDecoration.underline,
                              ),
                            ),
                          ),
                        ),
                        DataCell(
                          InkWell(
                            onTap: () => _showEditProductDialog(item),
                            child: Text(
                              item['name'] as String,
                              style: const TextStyle(
                                color: Colors.blue,
                                decoration: TextDecoration.underline,
                              ),
                            ),
                          ),
                        ),
                        DataCell(
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                            decoration: BoxDecoration(
                              color: _parseColor(item['category_color'] as String).withOpacity(0.2),
                              borderRadius: BorderRadius.circular(4),
                            ),
                            child: Text(item['category_name'] as String),
                          ),
                        ),
                        if (_selectedStoreId == null) // Show store name only when showing all stores
                          DataCell(Text(item['store_name'] as String? ?? 'Unknown Store')),
                        DataCell(
                          Text(
                            stockQty.toString(),
                            style: TextStyle(
                              fontWeight: FontWeight.bold,
                              color: stockQty == 0 ? Colors.red : (stockQty <= minLevel ? Colors.orange : Colors.green),
                            ),
                          ),
                        ),
                        DataCell(Text(minLevel.toString())),
                        DataCell(_buildStatusChip(status)),
                        DataCell(
                          Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              IconButton(
                                icon: const Icon(Icons.edit, color: Colors.blue),
                                onPressed: () => _showEditProductDialog(item),
                                tooltip: 'Edit Product',
                              ),
                              IconButton(
                                icon: const Icon(Icons.inventory, color: Colors.orange),
                                onPressed: () => _showEditStockDialog(item),
                                tooltip: 'Edit Stock',
                              ),
                            ],
                          ),
                        ),
                      ],
                    );
                  }).toList(),
                ),
              ),
            ),
          ),
          // Pagination Controls
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Colors.grey.shade50,
              border: Border(top: BorderSide(color: Colors.grey.shade300)),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Row(
                  children: [
                    const Text('Rows per page:'),
                    const SizedBox(width: 8),
                    DropdownButton<int>(
                      value: _rowsPerPage,
                      items: _availableRowsPerPage.map((rows) {
                        return DropdownMenuItem<int>(
                          value: rows,
                          child: Text('$rows'),
                        );
                      }).toList(),
                      onChanged: (value) {
                        if (value != null) {
                          setState(() {
                            _rowsPerPage = value;
                            _currentPage = 0;
                          });
                        }
                      },
                    ),
                  ],
                ),
                Row(
                  children: [
                    Text(
                      'Showing ${totalItems > 0 ? startIndex + 1 : 0}-$endIndex of $totalItems',
                      style: const TextStyle(fontSize: 14),
                    ),
                    const SizedBox(width: 16),
                    IconButton(
                      onPressed: _currentPage > 0
                          ? () => setState(() => _currentPage--)
                          : null,
                      icon: const Icon(Icons.chevron_left),
                      tooltip: 'Previous page',
                    ),
                    Text(
                      'Page ${totalItems > 0 ? _currentPage + 1 : 0} of $totalPages',
                      style: const TextStyle(fontSize: 14),
                    ),
                    IconButton(
                      onPressed: _currentPage < totalPages - 1
                          ? () => setState(() => _currentPage++)
                          : null,
                      icon: const Icon(Icons.chevron_right),
                      tooltip: 'Next page',
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  String _getStockStatus(int stockQty, int minLevel) {
    if (stockQty == 0) return 'Out of Stock';
    if (stockQty <= minLevel) return 'Low Stock';
    return 'In Stock';
  }

  Widget _buildStatusChip(String status) {
    Color color;
    switch (status) {
      case 'Out of Stock':
        color = Colors.red;
        break;
      case 'Low Stock':
        color = Colors.orange;
        break;
      default:
        color = Colors.green;
    }

    return Chip(
      label: Text(status),
      backgroundColor: color,
      labelStyle: const TextStyle(color: Colors.white, fontSize: 12),
    );
  }

  Color _parseColor(String colorString) {
    try {
      return Color(int.parse(colorString.replaceFirst('#', '0xFF')));
    } catch (e) {
      return Colors.blue;
    }
  }

  Future<void> _showEditStockDialog(Map<String, dynamic> item) async {
    final productId = item['id'] as int;
    final currentQty = item['stock_quantity'] as int;
    final qtyController = TextEditingController(text: currentQty.toString());

    final result = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Update Stock - ${item['name']}'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text('SKU: ${item['sku']}'),
            const SizedBox(height: 16),
            Text('Current Stock: $currentQty'),
            const SizedBox(height: 16),
            TextField(
              controller: qtyController,
              decoration: const InputDecoration(
                labelText: 'New Stock Quantity',
                border: OutlineInputBorder(),
              ),
              keyboardType: TextInputType.number,
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () async {
              final newQty = int.tryParse(qtyController.text);
              if (newQty == null) {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Please enter a valid number')),
                );
                return;
              }

              try {
                await DatabaseService.updateStoreStock(
                  _selectedStoreId!,
                  productId,
                  newQty,
                );
                Navigator.pop(context, true);
              } catch (e) {
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text('Error: $e')),
                );
              }
            },
            child: const Text('Update'),
          ),
        ],
      ),
    );

    if (result == true) {
      _loadInventory();
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Stock updated successfully')),
        );
      }
    }
  }

  // Add Product Dialog
  void _showAddProductDialog() {
    showDialog(
      context: context,
      builder: (context) => Dialog(
        child: SizedBox(
          width: MediaQuery.of(context).size.width * 0.8,
          height: MediaQuery.of(context).size.height * 0.8,
          child: ProductForm(
            categories: _categories,
            stores: _stores,
            onSubmit: (product, storeSettings) async {
              try {
                // Convert storeSettings from Map<int, Map<String, dynamic>> to Map<String, Map<String, dynamic>>
                final storeStockData = <String, Map<String, dynamic>>{};
                storeSettings.forEach((storeId, settings) {
                  storeStockData[storeId.toString()] = settings;
                });
                
                await DatabaseService.insertProduct(product, storeStockData: storeStockData);
                Navigator.of(context).pop();
                _loadInventory();
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Product created successfully')),
                );
              } catch (e) {
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text('Error creating product: $e')),
                );
              }
            },
            onCancel: () => Navigator.of(context).pop(),
          ),
        ),
      ),
    );
  }

  // Import Products with Enhanced UI
  Future<void> _importProducts() async {
    // Check if a specific store is selected (not "All Stores")
    if (_selectedStoreId == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Please select a specific store before importing products'),
          backgroundColor: Colors.orange,
        ),
      );
      return;
    }
    
    _showImportDialog();
  }

  void _showImportDialog() {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => _ImportDialog(
        selectedStoreId: _selectedStoreId!,
        stores: _stores,
        onComplete: () {
          Navigator.pop(context);
          _loadInventory();
        },
        onCancel: () => Navigator.pop(context),
      ),
    );
  }

  Future<void> _downloadImportTemplate() async {
    try {
      // Create CSV template content
      final baseHeaders = [
        'Handle', 'SKU', 'Name', 'Category', 'Description', 'Sold by weight',
        'Option 1 name', 'Option 1 value', 'Option 2 name', 'Option 2 value',
        'Option 3 name', 'Option 3 value', 'Default price', 'Cost', 'Barcode',
        'SKU of included item', 'Quantity of included item', 'Track stock',
        'Use production', 'Supplier', 'Purchase cost',
      ];

      final headers = [...baseHeaders];
      
      // Add store-specific columns
      for (final store in _stores) {
        headers.addAll([
          'Available for sale [${store.name}]',
          'Price [${store.name}]',
          'In stock [${store.name}]',
          'Low stock [${store.name}]',
          'Optimal stock [${store.name}]',
        ]);
      }

      // Create sample data row
      final sampleRow = [
        'sample-product', 'SAMPLE001', 'Sample Product', 'Electronics',
        'This is a sample product for import', 'FALSE', 'Color', 'Blue',
        'Size', 'Medium', '', '', '29.99', '15.00', '1234567890123',
        '', '', 'TRUE', 'FALSE', 'Sample Supplier', '15.00',
      ];

      // Add sample store data
      for (int i = 0; i < _stores.length; i++) {
        sampleRow.addAll(['TRUE', '29.99', '50', '5', '20']);
      }

      final csvData = [headers, sampleRow];
      final csvString = const ListToCsvConverter().convert(csvData);

      // Save template to downloads
      final directory = await getApplicationDocumentsDirectory();
      final templateFile = File('${directory.path}/product_import_template.csv');
      await templateFile.writeAsString(csvString);

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Template saved to: ${templateFile.path}'),
          duration: const Duration(seconds: 3),
          action: SnackBarAction(
            label: 'Open Folder',
            onPressed: () async {
              await Process.run('explorer', [directory.path]);
            },
          ),
        ),
      );
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error creating template: $e')),
      );
    }
  }

  // Export Products
  Future<void> _exportProducts() async {
    try {
      if (_inventory.isEmpty) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('No products to export')),
        );
        return;
      }

      // Prepare CSV data
      final csvData = <List<String>>[];
      
      // Build headers - include all stores for stock data
      final baseHeaders = [
        'Handle',
        'SKU',
        'Name',
        'Category',
        'Description',
        'Sold by weight',
        'Option 1 name',
        'Option 1 value',
        'Option 2 name',
        'Option 2 value',
        'Option 3 name',
        'Option 3 value',
        'Default price',
        'Cost',
        'Barcode',
        'SKU of included item',
        'Quantity of included item',
        'Track stock',
        'Use production',
        'Supplier',
        'Purchase cost',
      ];
      
      final headers = [...baseHeaders];
      
      // Add store-specific columns
      for (final store in _stores) {
        headers.addAll([
          'Available for sale [${store.name}]',
          'Price [${store.name}]',
          'In stock [${store.name}]',
          'Low stock [${store.name}]',
          'Optimal stock [${store.name}]',
        ]);
      }
      
      csvData.add(headers);
      
      // Get all products with their stock data across all stores
      Map<int, Map<String, dynamic>> allProductsData = {};
      
      if (_selectedStoreId == null) {
        // Export from all stores
        final allStoreStock = await DatabaseService.getAllStoreStock();
        for (final item in allStoreStock) {
          final productId = item['product_id'] as int;
          if (!allProductsData.containsKey(productId)) {
            allProductsData[productId] = {
              ...item,
              'stores': <int, Map<String, dynamic>>{},
            };
          }
          final storeId = item['store_id'] as int;
          allProductsData[productId]!['stores'][storeId] = {
            'stock_quantity': item['stock_quantity'],
            'min_stock_level': item['min_stock_level'],
            'store_name': item['store_name'],
          };
        }
      } else {
        // Export from selected store only
        for (final item in _filteredInventory) {
          final productId = item['product_id'] as int? ?? item['id'] as int;
          allProductsData[productId] = {
            ...item,
            'stores': <int, Map<String, dynamic>>{
              _selectedStoreId!: {
                'stock_quantity': item['stock_quantity'],
                'min_stock_level': item['min_stock_level'],
                'store_name': _stores.firstWhere((s) => s.id == _selectedStoreId).name,
              }
            },
          };
        }
      }
      
      // Data rows
      for (final productData in allProductsData.values) {
        final handle = productData['name'].toString().toLowerCase().replaceAll(RegExp(r'[^a-z0-9]+'), '-');
        final row = <String>[];
        
        // Base product data
        row.addAll([
          handle, // Handle
          productData['sku'].toString(), // SKU
          productData['name'].toString(), // Name
          productData['category_name']?.toString() ?? '', // Category
          productData['description']?.toString() ?? '', // Description
          'FALSE', // Sold by weight
          '', // Option 1 name
          '', // Option 1 value
          '', // Option 2 name
          '', // Option 2 value
          '', // Option 3 name
          '', // Option 3 value
          productData['price']?.toString() ?? '0', // Default price
          productData['cost']?.toString() ?? '0', // Cost
          productData['barcode']?.toString() ?? '', // Barcode
          '', // SKU of included item
          '', // Quantity of included item
          (productData['track_stock'] == 1 || productData['track_stock'] == true) ? 'TRUE' : 'FALSE', // Track stock
          'FALSE', // Use production
          '', // Supplier
          productData['cost']?.toString() ?? '0', // Purchase cost
        ]);
        
        // Store-specific data
        final storesData = productData['stores'] as Map<int, Map<String, dynamic>>;
        for (final store in _stores) {
          final storeData = storesData[store.id];
          if (storeData != null) {
            final stockQty = storeData['stock_quantity'] as int;
            final minLevel = storeData['min_stock_level'] as int;
            
            row.addAll([
              'TRUE', // Available for sale
              productData['price']?.toString() ?? '0', // Price
              stockQty.toString(), // In stock
              minLevel.toString(), // Low stock
              (minLevel * 2).toString(), // Optimal stock (default to 2x min level)
            ]);
          } else {
            row.addAll([
              'FALSE', // Available for sale
              '0', // Price
              '0', // In stock
              '0', // Low stock
              '0', // Optimal stock
            ]);
          }
        }
        
        csvData.add(row);
      }
      
      // Convert to CSV string
      final csvString = const ListToCsvConverter().convert(csvData);
      
      // Get documents directory
      final directory = await getApplicationDocumentsDirectory();
      final timestamp = DateTime.now().millisecondsSinceEpoch;
      final fileName = _selectedStoreId == null 
          ? 'products_all_stores_$timestamp.csv'
          : 'products_${_stores.firstWhere((s) => s.id == _selectedStoreId).name.replaceAll(' ', '_')}_$timestamp.csv';
      final file = File('${directory.path}/$fileName');
      
      await file.writeAsString(csvString);
      
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Exported ${allProductsData.length} products'),
              Text('File: $fileName'),
              Text('Location: ${directory.path}'),
            ],
          ),
          duration: const Duration(seconds: 4),
        ),
      );
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Export failed: $e')),
      );
    }
  }

  // Selection Methods
  void _toggleSelectAll(bool? selected) {
    setState(() {
      _selectAll = selected ?? false;
      if (_selectAll) {
        _selectedProductIds = _filteredInventory
            .map((item) => item['product_id'] as int? ?? item['id'] as int)
            .toSet();
      } else {
        _selectedProductIds.clear();
      }
    });
  }

  void _toggleProductSelection(int productId, bool selected) {
    setState(() {
      if (selected) {
        _selectedProductIds.add(productId);
      } else {
        _selectedProductIds.remove(productId);
      }
      _selectAll = _selectedProductIds.length == _filteredInventory.length;
    });
  }

  // Delete Selected Products
  Future<void> _deleteSelectedProducts() async {
    if (_selectedProductIds.isEmpty) return;

    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Delete Products'),
        content: Text(
          'Are you sure you want to delete ${_selectedProductIds.length} selected product(s)? This action cannot be undone.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () => Navigator.pop(context, true),
            style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
            child: const Text('Delete', style: TextStyle(color: Colors.white)),
          ),
        ],
      ),
    );

    if (confirmed == true) {
      try {
        int deletedCount = 0;
        for (final productId in _selectedProductIds) {
          await DatabaseService.deleteProduct(productId);
          deletedCount++;
        }

        _selectedProductIds.clear();
        _selectAll = false;
        _loadInventory();

        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Deleted $deletedCount product(s) successfully')),
        );
      } catch (e) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error deleting products: $e')),
        );
      }
    }
  }

  // Edit Product Dialog
  void _showEditProductDialog(Map<String, dynamic> item) {
    final productId = item['product_id'] as int? ?? item['id'] as int;
    
    // Find the product
    DatabaseService.getProducts().then((products) {
      final product = products.firstWhere((p) => p.id == productId);
      
      showDialog(
        context: context,
        builder: (context) => Dialog(
          child: SizedBox(
            width: MediaQuery.of(context).size.width * 0.8,
            height: MediaQuery.of(context).size.height * 0.8,
            child: ProductForm(
              product: product,
              categories: _categories,
              stores: _stores,
              onSubmit: (updatedProduct, storeSettings) async {
                try {
                  // Convert storeSettings from Map<int, Map<String, dynamic>> to Map<String, Map<String, dynamic>>
                  final storeStockData = <String, Map<String, dynamic>>{};
                  storeSettings.forEach((storeId, settings) {
                    storeStockData[storeId.toString()] = settings;
                  });
                  
                  await DatabaseService.updateProduct(updatedProduct, storeStockData: storeStockData);
                  Navigator.of(context).pop();
                  _loadInventory();
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('Product updated successfully')),
                  );
                } catch (e) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text('Error updating product: $e')),
                  );
                }
              },
              onCancel: () => Navigator.of(context).pop(),
            ),
          ),
        ),
      );
    }).catchError((e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error loading product: $e')),
      );
    });
  }
}

class _ImportDialog extends StatefulWidget {
  final int selectedStoreId;
  final List<Store> stores;
  final VoidCallback onComplete;
  final VoidCallback onCancel;

  const _ImportDialog({
    required this.selectedStoreId,
    required this.stores,
    required this.onComplete,
    required this.onCancel,
  });

  @override
  State<_ImportDialog> createState() => _ImportDialogState();
}

class _ImportDialogState extends State<_ImportDialog> {
  File? _selectedFile;
  String _status = 'idle'; // idle, uploading, extracting, processing, saving, success, error
  double _progress = 0.0;
  String _errorMessage = '';
  int _importedCount = 0;
  int _skippedCount = 0;

  Future<void> _handleFileSelection() async {
    try {
      final result = await FilePicker.platform.pickFiles(
        type: FileType.custom,
        allowedExtensions: ['csv'],
      );

      if (result != null && result.files.isNotEmpty) {
        setState(() {
          _selectedFile = File(result.files.first.path!);
          _status = 'idle';
          _errorMessage = '';
        });
      }
    } catch (e) {
      setState(() {
        _errorMessage = 'Error selecting file: $e';
        _status = 'error';
      });
    }
  }

  Future<void> _downloadTemplate() async {
    try {
      // Create CSV template content
      final baseHeaders = [
        'Handle', 'SKU', 'Name', 'Category', 'Description', 'Sold by weight',
        'Option 1 name', 'Option 1 value', 'Option 2 name', 'Option 2 value',
        'Option 3 name', 'Option 3 value', 'Default price', 'Cost', 'Barcode',
        'SKU of included item', 'Quantity of included item', 'Track stock',
        'Use production', 'Supplier', 'Purchase cost',
      ];

      final headers = [...baseHeaders];
      
      // Add store-specific columns
      for (final store in widget.stores) {
        headers.addAll([
          'Available for sale [${store.name}]',
          'Price [${store.name}]',
          'In stock [${store.name}]',
          'Low stock [${store.name}]',
          'Optimal stock [${store.name}]',
        ]);
      }

      // Create sample data row
      final sampleRow = [
        'sample-product', // Handle
        'SAMPLE001', // SKU
        'Sample Product', // Name
        'Electronics', // Category
        'This is a sample product for import', // Description
        'FALSE', // Sold by weight
        'Color', // Option 1 name
        'Blue', // Option 1 value
        'Size', // Option 2 name
        'Medium', // Option 2 value
        '', // Option 3 name
        '', // Option 3 value
        '29.99', // Default price
        '15.00', // Cost
        '1234567890123', // Barcode
        '', // SKU of included item
        '', // Quantity of included item
        'TRUE', // Track stock
        'FALSE', // Use production
        'Sample Supplier', // Supplier
        '15.00', // Purchase cost
      ];

      // Add sample store data
      for (int i = 0; i < widget.stores.length; i++) {
        sampleRow.addAll([
          'TRUE', // Available for sale
          '29.99', // Price
          '50', // In stock
          '5', // Low stock
          '20', // Optimal stock
        ]);
      }

      final csvData = [headers, sampleRow];
      final csvString = const ListToCsvConverter().convert(csvData);

      // Save template to downloads
      final directory = await getApplicationDocumentsDirectory();
      final templateFile = File('${directory.path}/product_import_template.csv');
      await templateFile.writeAsString(csvString);

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Template saved to: ${templateFile.path}'),
          duration: const Duration(seconds: 3),
          action: SnackBarAction(
            label: 'Open Folder',
            onPressed: () async {
              await Process.run('explorer', [directory.path]);
            },
          ),
        ),
      );
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error creating template: $e')),
      );
    }
  }

  Future<void> _handleImport() async {
    if (_selectedFile == null) return;

    try {
      setState(() {
        _status = 'uploading';
        _progress = 10;
        _errorMessage = '';
      });

      // Read and parse CSV
      final csvString = await _selectedFile!.readAsString();
      final csvData = const CsvToListConverter().convert(csvString);
      
      if (csvData.isEmpty) {
        throw Exception('CSV file is empty');
      }

      setState(() {
        _status = 'extracting';
        _progress = 30;
      });

      // Get headers from first row
      final headers = csvData.first.map((e) => e.toString().trim()).toList();
      _importedCount = 0;
      _skippedCount = 0;
      
      // Get all existing categories for mapping
      final categories = await DatabaseService.getCategories();
      final categoryMap = <String, int>{};
      for (final category in categories) {
        categoryMap[category.name.toLowerCase()] = category.id!;
      }
      
      // Ensure we have at least one category
      int defaultCategoryId = 1;
      if (categories.isNotEmpty) {
        defaultCategoryId = categories.first.id!;
      } else {
        final defaultCategory = Category(
          name: 'General',
          color: '#2196F3',
          active: true,
        );
        defaultCategoryId = await DatabaseService.insertCategory(defaultCategory);
        categoryMap['general'] = defaultCategoryId;
      }

      setState(() {
        _status = 'processing';
        _progress = 50;
      });

      final totalRows = csvData.length - 1; // Exclude header
      
      for (int i = 1; i < csvData.length; i++) {
        try {
          final row = csvData[i];
          if (row.isEmpty || (row.length == 1 && row[0].toString().trim().isEmpty)) {
            continue;
          }
          
          // Create a map from headers to values
          final rowData = <String, dynamic>{};
          for (int j = 0; j < headers.length && j < row.length; j++) {
            if (row[j] != null && row[j].toString().trim().isNotEmpty) {
              rowData[headers[j]] = row[j].toString().trim();
            }
          }
          
          // Extract product information
          final sku = rowData['SKU'] ?? '';
          final name = rowData['Name'] ?? '';
          final categoryName = rowData['Category'] ?? 'General';
          final description = rowData['Description'] ?? '';
          final price = double.tryParse(rowData['Default price']?.toString().replaceAll('\$', '') ?? '0') ?? 0.0;
          final cost = double.tryParse(rowData['Cost']?.toString().replaceAll('\$', '') ?? '0') ?? 0.0;
          final barcode = rowData['Barcode'] ?? '';
          final trackStock = rowData['Track stock']?.toString().toUpperCase() == 'TRUE';
          
          if (sku.isEmpty || name.isEmpty) {
            _skippedCount++;
            continue;
          }
          
          // Find or create category
          int categoryId = categoryMap[categoryName.toLowerCase()] ?? defaultCategoryId;
          if (!categoryMap.containsKey(categoryName.toLowerCase()) && categoryName.isNotEmpty) {
            final newCategory = Category(
              name: categoryName,
              color: '#2196F3',
              active: true,
            );
            categoryId = await DatabaseService.insertCategory(newCategory);
            categoryMap[categoryName.toLowerCase()] = categoryId;
          }
          
          // Create product
          final product = Product(
            sku: sku,
            name: name,
            description: description,
            price: price,
            cost: cost,
            categoryId: categoryId,
            barcode: barcode.isNotEmpty ? barcode : null,
            active: true,
            trackStock: trackStock,
            imageUrl: null,
          );
          
          // Extract stock data
          Map<String, Map<String, dynamic>>? storeStockData = {};
          
          // Look for store-specific stock data
          for (final store in widget.stores) {
            final storeInStockKey = 'In stock [${store.name}]';
            final storeLowStockKey = 'Low stock [${store.name}]';
            final storeAvailableKey = 'Available for sale [${store.name}]';
            
            if (rowData.containsKey(storeInStockKey)) {
              final inStock = int.tryParse(rowData[storeInStockKey]?.toString() ?? '0') ?? 0;
              final lowStock = int.tryParse(rowData[storeLowStockKey]?.toString() ?? '5') ?? 5;
              final available = rowData[storeAvailableKey]?.toString().toUpperCase() == 'TRUE';
              
              if (available) {
                storeStockData[store.id.toString()] = {
                  'in_stock': inStock,
                  'low_stock': lowStock,
                };
              }
            }
          }
          
          // If no store-specific data found, use default for selected store
          if (storeStockData.isEmpty) {
            storeStockData[widget.selectedStoreId.toString()] = {
              'in_stock': 0,
              'low_stock': 5,
            };
          }
          
          await DatabaseService.insertProduct(product, storeStockData: storeStockData);
          _importedCount++;
          
          // Update progress
          final currentProgress = 50 + ((i / totalRows) * 40);
          setState(() {
            _progress = currentProgress;
          });
        } catch (e) {
          print('Error importing row $i: $e');
          _skippedCount++;
        }
      }

      setState(() {
        _status = 'success';
        _progress = 100;
      });

      // Auto close after 2 seconds
      Future.delayed(const Duration(seconds: 2), () {
        if (mounted) {
          widget.onComplete();
        }
      });
      
    } catch (e) {
      setState(() {
        _status = 'error';
        _errorMessage = e.toString();
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Dialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: Container(
        width: 500,
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Header
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text(
                  'Import Products from CSV',
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                ),
                IconButton(
                  onPressed: _status == 'idle' ? widget.onCancel : null,
                  icon: const Icon(Icons.close),
                ),
              ],
            ),
            const SizedBox(height: 24),

            // Content based on status
            if (_status == 'success') ...[
              // Success State
              Center(
                child: Column(
                  children: [
                    const Icon(Icons.check_circle, color: Colors.green, size: 64),
                    const SizedBox(height: 16),
                    const Text(
                      'Import Successful!',
                      style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      'Imported $_importedCount products${_skippedCount > 0 ? ', skipped $_skippedCount' : ''}',
                      style: const TextStyle(color: Colors.grey),
                    ),
                  ],
                ),
              ),
            ] else if (_status == 'error') ...[
              // Error State
              Center(
                child: Column(
                  children: [
                    const Icon(Icons.error, color: Colors.red, size: 64),
                    const SizedBox(height: 16),
                    const Text(
                      'Import Failed',
                      style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      _errorMessage,
                      style: const TextStyle(color: Colors.grey),
                      textAlign: TextAlign.center,
                    ),
                    const SizedBox(height: 16),
                    ElevatedButton(
                      onPressed: () {
                        setState(() {
                          _status = 'idle';
                          _errorMessage = '';
                          _progress = 0;
                        });
                      },
                      child: const Text('Try Again'),
                    ),
                  ],
                ),
              ),
            ] else ...[
              // File Selection and Progress
              Container(
                padding: const EdgeInsets.all(24),
                decoration: BoxDecoration(
                  border: Border.all(color: Colors.grey.shade300, width: 2),
                  borderRadius: BorderRadius.circular(12),
                  color: Colors.grey.shade50,
                ),
                child: Column(
                  children: [
                    Icon(
                      _selectedFile != null ? Icons.description : Icons.cloud_upload,
                      size: 48,
                      color: Colors.grey.shade600,
                    ),
                    const SizedBox(height: 16),
                    if (_selectedFile != null) ...[
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          const Icon(Icons.description, size: 20),
                          const SizedBox(width: 8),
                          Flexible(
                            child: Text(
                              _selectedFile!.path.split('/').last,
                              style: const TextStyle(fontWeight: FontWeight.w500),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 16),
                    ] else ...[
                      const Text(
                        'Select or drop a CSV file to import products',
                        textAlign: TextAlign.center,
                        style: TextStyle(fontSize: 16),
                      ),
                      const SizedBox(height: 16),
                    ],
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        ElevatedButton(
                          onPressed: _status == 'idle' ? _handleFileSelection : null,
                          child: const Text('Choose CSV File'),
                        ),
                        const SizedBox(width: 12),
                        OutlinedButton.icon(
                          onPressed: _downloadTemplate,
                          icon: const Icon(Icons.download, size: 16),
                          label: const Text('Download Template'),
                        ),
                      ],
                    ),
                  ],
                ),
              ),

              // Progress indicator
              if (['uploading', 'extracting', 'processing', 'saving'].contains(_status)) ...[
                const SizedBox(height: 24),
                Column(
                  children: [
                    LinearProgressIndicator(
                      value: _progress / 100,
                      backgroundColor: Colors.grey.shade300,
                    ),
                    const SizedBox(height: 8),
                    Text(
                      '${_status.substring(0, 1).toUpperCase()}${_status.substring(1)}... ${_progress.toInt()}%',
                      style: const TextStyle(color: Colors.grey),
                    ),
                  ],
                ),
              ],

              // Action buttons
              const SizedBox(height: 24),
              Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  TextButton(
                    onPressed: _status == 'idle' ? widget.onCancel : null,
                    child: const Text('Cancel'),
                  ),
                  const SizedBox(width: 12),
                  ElevatedButton(
                    onPressed: _selectedFile != null && _status == 'idle' ? _handleImport : null,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.blue,
                      foregroundColor: Colors.white,
                    ),
                    child: const Text('Import Products'),
                  ),
                ],
              ),
            ],
          ],
        ),
      ),
    );
  }
}
