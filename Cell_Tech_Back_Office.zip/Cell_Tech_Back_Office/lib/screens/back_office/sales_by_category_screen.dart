import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../../services/database_service.dart';
import '../../models/store.dart';
import '../../models/employee.dart';
import '../../widgets/back_office_layout.dart';
import '../../utils/responsive_utils.dart';

class SalesByCategoryScreen extends StatefulWidget {
  const SalesByCategoryScreen({super.key});

  @override
  State<SalesByCategoryScreen> createState() => _SalesByCategoryScreenState();
}

class _SalesByCategoryScreenState extends State<SalesByCategoryScreen> {
  List<Store> _stores = [];
  List<Employee> _employees = [];
  List<Map<String, dynamic>> _categoryData = [];
  bool _isLoading = false;

  // Filters
  DateTime _startDate = DateTime.now().subtract(const Duration(days: 7));
  DateTime _endDate = DateTime.now();
  int? _selectedStoreId;
  int? _selectedEmployeeId;
  String _period = 'Last 7 Days';

  // Column visibility state
  Set<String> _visibleColumns = {
    'category_name',
    'gross_sales',
    'cost_of_goods',
    'net_sales',
    'receipts',
    'items_sold',
    'profit_margin'
  };

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  Future<void> _loadData() async {
    setState(() => _isLoading = true);
    
    try {
      final stores = await DatabaseService.getStores();
      final employees = await DatabaseService.getEmployees();
      
      setState(() {
        _stores = stores;
        _employees = employees;
      });
      
      await _loadCategoryData();
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error loading data: $e')),
        );
      }
    } finally {
      setState(() => _isLoading = false);
    }
  }

  Future<void> _loadCategoryData() async {
    try {
      final data = await DatabaseService.getSalesByCategory(
        startDate: _startDate,
        endDate: _endDate,
        storeId: _selectedStoreId,
        employeeId: _selectedEmployeeId,
      );
      
      setState(() {
        _categoryData = data.map((item) {
          final netSales = item['net_sales'] ?? 0.0;
          final grossProfit = item['gross_profit'] ?? 0.0;
          final margin = netSales > 0 ? (grossProfit / netSales * 100) : 0.0;
          
          return {
            ...item,
            'margin': margin,
          };
        }).toList();
      });
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error loading category data: $e')),
        );
      }
    }
  }

  Future<void> _selectDateRange() async {
    final picked = await showDateRangePicker(
      context: context,
      firstDate: DateTime.now().subtract(const Duration(days: 365)),
      lastDate: DateTime.now(),
      initialDateRange: DateTimeRange(start: _startDate, end: _endDate),
    );
    
    if (picked != null) {
      setState(() {
        _startDate = picked.start;
        _endDate = picked.end;
        _period = 'Custom';
      });
      _loadCategoryData();
    }
  }

  void _applyDatePreset(String preset) {
    final now = DateTime.now();
    switch (preset) {
      case 'Today':
        _startDate = DateTime(now.year, now.month, now.day);
        _endDate = now;
        break;
      case 'Yesterday':
        final yesterday = now.subtract(const Duration(days: 1));
        _startDate = DateTime(yesterday.year, yesterday.month, yesterday.day);
        _endDate = DateTime(yesterday.year, yesterday.month, yesterday.day, 23, 59, 59);
        break;
      case 'Last 7 Days':
        _startDate = now.subtract(const Duration(days: 7));
        _endDate = now;
        break;
      case 'Last 30 Days':
        _startDate = now.subtract(const Duration(days: 30));
        _endDate = now;
        break;
      case 'This Month':
        _startDate = DateTime(now.year, now.month, 1);
        _endDate = now;
        break;
    }
    
    setState(() {
      _period = preset;
    });
    _loadCategoryData();
  }

  Map<String, dynamic> _calculateTotals() {
    if (_categoryData.isEmpty) {
      return {
        'products_sold': 0,
        'gross_sales': 0.0,
        'products_refunded': 0,
        'refunds': 0.0,
        'discounts': 0.0,
        'net_sales': 0.0,
        'cost_of_goods': 0.0,
        'gross_profit': 0.0,
      };
    }

    return _categoryData.fold<Map<String, dynamic>>(
      {
        'products_sold': 0,
        'gross_sales': 0.0,
        'products_refunded': 0,
        'refunds': 0.0,
        'discounts': 0.0,
        'net_sales': 0.0,
        'cost_of_goods': 0.0,
        'gross_profit': 0.0,
      },
      (totals, category) => {
        'products_sold': totals['products_sold'] + (category['products_sold'] ?? 0),
        'gross_sales': totals['gross_sales'] + (category['gross_sales'] ?? 0.0),
        'products_refunded': totals['products_refunded'] + (category['products_refunded'] ?? 0),
        'refunds': totals['refunds'] + (category['refunds'] ?? 0.0),
        'discounts': totals['discounts'] + (category['discounts'] ?? 0.0),
        'net_sales': totals['net_sales'] + (category['net_sales'] ?? 0.0),
        'cost_of_goods': totals['cost_of_goods'] + (category['cost_of_goods'] ?? 0.0),
        'gross_profit': totals['gross_profit'] + (category['gross_profit'] ?? 0.0),
      },
    );
  }

  double _calculateOverallMargin(Map<String, dynamic> totals) {
    if (totals['net_sales'] == 0.0) return 0.0;
    return totals['gross_profit'] / totals['net_sales'] * 100;
  }

  @override
  Widget build(BuildContext context) {
    final totals = _calculateTotals();
    final overallMargin = _calculateOverallMargin(totals);

    return BackOfficeLayout(
      title: 'Sales by Category',
      currentRoute: '/backoffice/sales-by-category',
      child: Column(
        children: [
          // Header and Filters
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Category Performance and Sales Analysis',
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 16),
                  
                  // Filters
                  ResponsiveUtils.isMobile(context)
                    ? _buildMobileFilters()
                    : _buildDesktopFilters(),
                ],
              ),
            ),
          ),
          
          const SizedBox(height: 16),
          

          
          const SizedBox(height: 16),
          
          // Category Performance Table
          Expanded(
            child: Card(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Padding(
                    padding: const EdgeInsets.all(16.0),
                    child: Row(
                      children: [
                        const Text(
                          'Category Performance',
                          style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        const Spacer(),
                        PopupMenuButton<String>(
                          child: Container(
                            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                            decoration: BoxDecoration(
                              border: Border.all(color: Colors.grey.shade300),
                              borderRadius: BorderRadius.circular(8),
                            ),
                            child: const Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Icon(Icons.view_column, size: 16),
                                SizedBox(width: 4),
                                Text('Columns'),
                                Icon(Icons.arrow_drop_down, size: 16),
                              ],
                            ),
                          ),
                          itemBuilder: (context) => [
                            _buildColumnCheckbox('category_name', 'Category Name'),
                            _buildColumnCheckbox('gross_sales', 'Gross Sales'),
                            _buildColumnCheckbox('cost_of_goods', 'Cost of Goods'),
                            _buildColumnCheckbox('net_sales', 'Net Sales'),
                            _buildColumnCheckbox('receipts', 'Receipts'),
                            _buildColumnCheckbox('items_sold', 'Items Sold'),
                            _buildColumnCheckbox('profit_margin', 'Profit Margin'),
                          ],
                        ),
                      ],
                    ),
                  ),
                  Expanded(
                    child: _isLoading
                      ? const Center(child: CircularProgressIndicator())
                      : _categoryData.isEmpty
                        ? const Center(
                            child: Text(
                              'No category sales data found for the selected period',
                              style: TextStyle(fontSize: 16, color: Colors.grey),
                            ),
                          )
                        : SingleChildScrollView(
                            scrollDirection: Axis.horizontal,
                            child: SingleChildScrollView(
                              child: Padding(
                                padding: const EdgeInsets.all(16.0),
                                child: _buildDataTable(totals, overallMargin),
                              ),
                            ),
                          ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }



  Widget _buildDataTable(Map<String, dynamic> totals, double overallMargin) {
    final columns = <DataColumn>[];
    final cellBuilders = <String, Widget Function(Map<String, dynamic>)>{};
    
    if (_visibleColumns.contains('category_name')) {
      columns.add(const DataColumn(label: Text('Category', style: TextStyle(fontWeight: FontWeight.bold))));
      cellBuilders['category_name'] = (item) => Text(item['category'] ?? 'Unknown');
    }
    
    if (_visibleColumns.contains('items_sold')) {
      columns.add(const DataColumn(label: Text('Items Sold', style: TextStyle(fontWeight: FontWeight.bold)), numeric: true));
      cellBuilders['items_sold'] = (item) => Text('${item['products_sold'] ?? 0}', style: const TextStyle(fontWeight: FontWeight.w500));
    }
    
    if (_visibleColumns.contains('gross_sales')) {
      columns.add(const DataColumn(label: Text('Gross Sales', style: TextStyle(fontWeight: FontWeight.bold)), numeric: true));
      cellBuilders['gross_sales'] = (item) => Text('\$${(item['gross_sales'] ?? 0.0).toStringAsFixed(2)}');
    }
    
    if (_visibleColumns.contains('receipts')) {
      columns.add(const DataColumn(label: Text('Receipts', style: TextStyle(fontWeight: FontWeight.bold)), numeric: true));
      cellBuilders['receipts'] = (item) => Text('${item['receipts'] ?? 0}', style: const TextStyle(fontWeight: FontWeight.w500));
    }
    
    if (_visibleColumns.contains('net_sales')) {
      columns.add(const DataColumn(label: Text('Net Sales', style: TextStyle(fontWeight: FontWeight.bold)), numeric: true));
      cellBuilders['net_sales'] = (item) => Text('\$${(item['net_sales'] ?? 0.0).toStringAsFixed(2)}', style: const TextStyle(fontWeight: FontWeight.bold));
    }
    
    if (_visibleColumns.contains('cost_of_goods')) {
      columns.add(const DataColumn(label: Text('Cost of Goods', style: TextStyle(fontWeight: FontWeight.bold)), numeric: true));
      cellBuilders['cost_of_goods'] = (item) => Text('\$${(item['cost_of_goods'] ?? 0.0).toStringAsFixed(2)}');
    }
    
    if (_visibleColumns.contains('gross_profit')) {
      columns.add(const DataColumn(label: Text('Gross Profit', style: TextStyle(fontWeight: FontWeight.bold)), numeric: true));
      cellBuilders['gross_profit'] = (item) => Text('\$${(item['gross_profit'] ?? 0.0).toStringAsFixed(2)}', style: const TextStyle(fontWeight: FontWeight.w500, color: Colors.green));
    }
    
    if (_visibleColumns.contains('profit_margin')) {
      columns.add(const DataColumn(label: Text('Profit Margin', style: TextStyle(fontWeight: FontWeight.bold)), numeric: true));
      cellBuilders['profit_margin'] = (item) => Text('${(item['margin'] ?? 0.0).toStringAsFixed(1)}%');
    }

    return DataTable(
      columns: columns,
      rows: [
        ..._categoryData.map((category) => DataRow(
          cells: _visibleColumns.map((key) => DataCell(cellBuilders[key]!(category))).toList(),
        )),
        
        // Totals Row
        DataRow(
          color: MaterialStateProperty.all(Colors.grey.shade100),
          cells: _visibleColumns.map((key) {
            switch (key) {
              case 'category_name':
                return const DataCell(Text('Total', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)));
              case 'items_sold':
                return DataCell(Text('${totals['products_sold']}', style: const TextStyle(fontWeight: FontWeight.bold)));
              case 'gross_sales':
                return DataCell(Text('\$${totals['gross_sales'].toStringAsFixed(2)}', style: const TextStyle(fontWeight: FontWeight.bold)));
              case 'receipts':
                return DataCell(Text('${totals['receipts'] ?? 0}', style: const TextStyle(fontWeight: FontWeight.bold)));
              case 'net_sales':
                return DataCell(Text('\$${totals['net_sales'].toStringAsFixed(2)}', style: const TextStyle(fontWeight: FontWeight.bold)));
              case 'cost_of_goods':
                return DataCell(Text('\$${totals['cost_of_goods'].toStringAsFixed(2)}', style: const TextStyle(fontWeight: FontWeight.bold)));
              case 'gross_profit':
                return DataCell(Text('\$${totals['gross_profit'].toStringAsFixed(2)}', style: const TextStyle(fontWeight: FontWeight.bold, color: Colors.green)));
              case 'profit_margin':
                return DataCell(Text('${overallMargin.toStringAsFixed(1)}%', style: const TextStyle(fontWeight: FontWeight.bold)));
              default:
                return const DataCell(Text(''));
            }
          }).toList(),
        ),
      ],
    );
  }

  Widget _buildMobileFilters() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Date Period Selector
        DropdownButtonFormField<String>(
          value: _period,
          decoration: const InputDecoration(
            labelText: 'Period',
            border: OutlineInputBorder(),
          ),
          items: ['Today', 'Yesterday', 'Last 7 Days', 'Last 30 Days', 'This Month', 'Custom']
              .map((period) => DropdownMenuItem(value: period, child: Text(period)))
              .toList(),
          onChanged: (value) {
            if (value == 'Custom') {
              _selectDateRange();
            } else if (value != null) {
              _applyDatePreset(value);
            }
          },
        ),
        
        const SizedBox(height: 16),
        
        // Store Filter
        DropdownButtonFormField<int?>(
          value: _selectedStoreId,
          decoration: const InputDecoration(
            labelText: 'Store',
            border: OutlineInputBorder(),
          ),
          items: [
            const DropdownMenuItem<int?>(value: null, child: Text('All Stores')),
            ..._stores.map((store) => DropdownMenuItem<int?>(
              value: store.id,
              child: Text(store.name),
            )),
          ],
          onChanged: (value) {
            setState(() => _selectedStoreId = value);
            _loadCategoryData();
          },
        ),
        
        const SizedBox(height: 16),
        
        // Employee Filter
        DropdownButtonFormField<int?>(
          value: _selectedEmployeeId,
          decoration: const InputDecoration(
            labelText: 'Employee',
            border: OutlineInputBorder(),
          ),
          items: [
            const DropdownMenuItem<int?>(value: null, child: Text('All Employees')),
            ..._employees.map((employee) => DropdownMenuItem<int?>(
              value: employee.id,
              child: Text(employee.name),
            )),
          ],
          onChanged: (value) {
            setState(() => _selectedEmployeeId = value);
            _loadCategoryData();
          },
        ),
        
        const SizedBox(height: 16),
        
        // Column Visibility Controls
        PopupMenuButton<String>(
          child: const Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(Icons.view_column),
              SizedBox(width: 8),
              Text('Column Visibility'),
              Icon(Icons.arrow_drop_down),
            ],
          ),
          itemBuilder: (context) => [
            _buildColumnCheckbox('category_name', 'Category Name'),
            _buildColumnCheckbox('gross_sales', 'Gross Sales'),
            _buildColumnCheckbox('cost_of_goods', 'Cost of Goods'),
            _buildColumnCheckbox('net_sales', 'Net Sales'),
            _buildColumnCheckbox('receipts', 'Receipts'),
            _buildColumnCheckbox('items_sold', 'Items Sold'),
            _buildColumnCheckbox('profit_margin', 'Profit Margin'),
          ],
        ),
      ],
    );
  }

  Widget _buildDesktopFilters() {
    return Row(
      children: [
        // Date Period Selector
        Expanded(
          flex: 2,
          child: DropdownButtonFormField<String>(
            value: _period,
            decoration: const InputDecoration(
              labelText: 'Period',
              border: OutlineInputBorder(),
            ),
            items: ['Today', 'Yesterday', 'Last 7 Days', 'Last 30 Days', 'This Month', 'Custom']
                .map((period) => DropdownMenuItem(value: period, child: Text(period)))
                .toList(),
            onChanged: (value) {
              if (value == 'Custom') {
                _selectDateRange();
              } else if (value != null) {
                _applyDatePreset(value);
              }
            },
          ),
        ),
        
        const SizedBox(width: 16),
        
        // Store Filter
        Expanded(
          flex: 2,
          child: DropdownButtonFormField<int?>(
            value: _selectedStoreId,
            decoration: const InputDecoration(
              labelText: 'Store',
              border: OutlineInputBorder(),
            ),
            items: [
              const DropdownMenuItem<int?>(value: null, child: Text('All Stores')),
              ..._stores.map((store) => DropdownMenuItem<int?>(
                value: store.id,
                child: Text(store.name),
              )),
            ],
            onChanged: (value) {
              setState(() => _selectedStoreId = value);
              _loadCategoryData();
            },
          ),
        ),
        
        const SizedBox(width: 16),
        
        // Employee Filter
        Expanded(
          flex: 2,
          child: DropdownButtonFormField<int?>(
            value: _selectedEmployeeId,
            decoration: const InputDecoration(
              labelText: 'Employee',
              border: OutlineInputBorder(),
            ),
            items: [
              const DropdownMenuItem<int?>(value: null, child: Text('All Employees')),
              ..._employees.map((employee) => DropdownMenuItem<int?>(
                value: employee.id,
                child: Text(employee.name),
              )),
            ],
            onChanged: (value) {
              setState(() => _selectedEmployeeId = value);
              _loadCategoryData();
            },
          ),
        ),
        
        const SizedBox(width: 16),
        
        // Custom Date Range Button
        ElevatedButton.icon(
          onPressed: _selectDateRange,
          icon: const Icon(Icons.date_range),
          label: Text('${DateFormat('MMM d').format(_startDate)} - ${DateFormat('MMM d').format(_endDate)}'),
        ),
        
        const SizedBox(width: 16),
        
        // Column Visibility Controls
        PopupMenuButton<String>(
          child: const Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(Icons.view_column),
              SizedBox(width: 8),
              Text('Columns'),
              Icon(Icons.arrow_drop_down),
            ],
          ),
          itemBuilder: (context) => [
            _buildColumnCheckbox('category_name', 'Category Name'),
            _buildColumnCheckbox('gross_sales', 'Gross Sales'),
            _buildColumnCheckbox('cost_of_goods', 'Cost of Goods'),
            _buildColumnCheckbox('net_sales', 'Net Sales'),
            _buildColumnCheckbox('receipts', 'Receipts'),
            _buildColumnCheckbox('items_sold', 'Items Sold'),
            _buildColumnCheckbox('profit_margin', 'Profit Margin'),
          ],
        ),
      ],
    );
  }

  PopupMenuItem<String> _buildColumnCheckbox(String key, String label) {
    return PopupMenuItem<String>(
      enabled: false,
      child: StatefulBuilder(
        builder: (context, setState) {
          return CheckboxListTile(
            title: Text(label),
            value: _visibleColumns.contains(key),
            onChanged: (value) {
              setState(() {
                if (value == true) {
                  _visibleColumns.add(key);
                } else {
                  _visibleColumns.remove(key);
                }
              });
              // Update the main widget state
              this.setState(() {});
            },
            dense: true,
            controlAffinity: ListTileControlAffinity.leading,
          );
        },
      ),
    );
  }
}