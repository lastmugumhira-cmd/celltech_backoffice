import 'package:flutter/material.dart';
import '../../services/database_service.dart';
import '../../models/store.dart';
import '../../models/employee.dart';
import '../../widgets/back_office_layout.dart';

class StoresScreen extends StatefulWidget {
  const StoresScreen({super.key});

  @override
  State<StoresScreen> createState() => _StoresScreenState();
}

class _StoresScreenState extends State<StoresScreen> {
  List<Store> _stores = [];
  List<Employee> _employees = [];
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  Future<void> _loadData() async {
    setState(() => _isLoading = true);
    try {
      final stores = await DatabaseService.getAllStoresAndWarehouses();
      final employees = await DatabaseService.getEmployees();
      setState(() {
        _stores = stores;
        _employees = employees;
        _isLoading = false;
      });
    } catch (e) {
      setState(() => _isLoading = false);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error loading data: $e')),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return BackOfficeLayout(
      title: 'Stores & Warehouses Management',
      currentRoute: '/backoffice/stores',
      child: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : _buildContent(),
    );
  }

  Widget _buildContent() {
    return Column(
      children: [
        _buildToolbar(),
        Expanded(child: _buildStoresGrid()),
      ],
    );
  }

  Widget _buildToolbar() {
    return Container(
      padding: const EdgeInsets.all(16),
      color: Colors.grey.shade50,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          const Text(
            'Manage Stores & Warehouses',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          Row(
            children: [
              ElevatedButton.icon(
                onPressed: () => _showAddEditDialog(null, type: 'store'),
                icon: const Icon(Icons.store),
                label: const Text('Add Store'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.blue,
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 20),
                ),
              ),
              const SizedBox(width: 12),
              ElevatedButton.icon(
                onPressed: () => _showAddEditDialog(null, type: 'warehouse'),
                icon: const Icon(Icons.warehouse),
                label: const Text('Add Warehouse'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.orange,
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 20),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildStoresGrid() {
    if (_stores.isEmpty) {
      return const Center(child: Text('No stores found'));
    }

    return GridView.builder(
      padding: const EdgeInsets.all(24),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 3,
        crossAxisSpacing: 16,
        mainAxisSpacing: 16,
        childAspectRatio: 1.2,
      ),
      itemCount: _stores.length,
      itemBuilder: (context, index) {
        final store = _stores[index];
        return _buildStoreCard(store);
      },
    );
  }

  Widget _buildStoreCard(Store store) {
    final manager = store.managerId != null
        ? _employees.where((e) => e.id == store.managerId).firstOrNull
        : null;

    return Card(
      elevation: 2,
      child: InkWell(
        onTap: () => _showAddEditDialog(store),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Expanded(
                    child: Text(
                      store.name,
                      style: const TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      Chip(
                        label: Text(store.type.toUpperCase()),
                        backgroundColor: store.type == 'warehouse' ? Colors.orange : Colors.blue,
                        labelStyle: const TextStyle(color: Colors.white, fontSize: 10),
                      ),
                      const SizedBox(height: 4),
                      Chip(
                        label: Text(store.active ? 'Active' : 'Inactive'),
                        backgroundColor: store.active ? Colors.green : Colors.grey,
                        labelStyle: const TextStyle(color: Colors.white, fontSize: 10),
                      ),
                    ],
                  ),
                ],
              ),
              const SizedBox(height: 12),
              Row(
                children: [
                  const Icon(Icons.location_on, size: 16, color: Colors.grey),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      store.address,
                      style: const TextStyle(fontSize: 14),
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 8),
              Row(
                children: [
                  const Icon(Icons.phone, size: 16, color: Colors.grey),
                  const SizedBox(width: 8),
                  Text(
                    store.phone,
                    style: const TextStyle(fontSize: 14),
                  ),
                ],
              ),
              const SizedBox(height: 8),
              Row(
                children: [
                  const Icon(Icons.person, size: 16, color: Colors.grey),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      manager != null ? manager.name : 'No manager assigned',
                      style: TextStyle(
                        fontSize: 14,
                        fontStyle: manager == null ? FontStyle.italic : FontStyle.normal,
                      ),
                    ),
                  ),
                ],
              ),
              const Spacer(),
              Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  IconButton(
                    icon: const Icon(Icons.edit, color: Colors.blue),
                    onPressed: () => _showAddEditDialog(store),
                    tooltip: 'Edit ${store.type == 'warehouse' ? 'Warehouse' : 'Store'}',
                  ),
                  IconButton(
                    icon: const Icon(Icons.delete, color: Colors.red),
                    onPressed: () => _showDeleteConfirmDialog(store),
                    tooltip: 'Delete ${store.type == 'warehouse' ? 'Warehouse' : 'Store'}',
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _showAddEditDialog(Store? store, {String? type}) async {
    final isEdit = store != null;
    final storeType = store?.type ?? type ?? 'store';
    final nameController = TextEditingController(text: store?.name ?? '');
    final addressController = TextEditingController(text: store?.address ?? '');
    final phoneController = TextEditingController(text: store?.phone ?? '');
    int? selectedManagerId = store?.managerId;
    bool active = store?.active ?? true;

    final result = await showDialog<bool>(
      context: context,
      builder: (context) => StatefulBuilder(
        builder: (context, setDialogState) => AlertDialog(
          title: Text(isEdit 
              ? 'Edit ${storeType == 'warehouse' ? 'Warehouse' : 'Store'}'
              : 'Add ${storeType == 'warehouse' ? 'Warehouse' : 'Store'}'),
          content: SizedBox(
            width: 400,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextField(
                  controller: nameController,
                  decoration: InputDecoration(
                    labelText: '${storeType == 'warehouse' ? 'Warehouse' : 'Store'} Name *',
                    border: const OutlineInputBorder(),
                  ),
                ),
                const SizedBox(height: 16),
                TextField(
                  controller: addressController,
                  decoration: const InputDecoration(
                    labelText: 'Address *',
                    border: OutlineInputBorder(),
                  ),
                  maxLines: 2,
                ),
                const SizedBox(height: 16),
                TextField(
                  controller: phoneController,
                  decoration: const InputDecoration(
                    labelText: 'Phone *',
                    border: OutlineInputBorder(),
                  ),
                ),
                const SizedBox(height: 16),
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: storeType == 'warehouse' ? Colors.orange.shade50 : Colors.blue.shade50,
                    border: Border.all(color: storeType == 'warehouse' ? Colors.orange : Colors.blue),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Row(
                    children: [
                      Icon(
                        storeType == 'warehouse' ? Icons.warehouse : Icons.store,
                        color: storeType == 'warehouse' ? Colors.orange : Colors.blue,
                      ),
                      const SizedBox(width: 8),
                      Text(
                        'Type: ${storeType == 'warehouse' ? 'Warehouse' : 'Store'}',
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          color: storeType == 'warehouse' ? Colors.orange.shade800 : Colors.blue.shade800,
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 16),
                DropdownButtonFormField<int?>(
                  initialValue: selectedManagerId,
                  decoration: const InputDecoration(
                    labelText: 'Manager',
                    border: OutlineInputBorder(),
                  ),
                  items: [
                    const DropdownMenuItem(value: null, child: Text('No manager')),
                    ..._employees
                        .where((e) => e.role == 'Manager' || e.role == 'Administrator')
                        .map((emp) => DropdownMenuItem(
                              value: emp.id,
                              child: Text(emp.name),
                            )),
                  ],
                  onChanged: (value) {
                    setDialogState(() => selectedManagerId = value);
                  },
                ),
                const SizedBox(height: 16),
                SwitchListTile(
                  title: const Text('Active'),
                  value: active,
                  onChanged: (value) {
                    setDialogState(() => active = value);
                  },
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context, false),
              child: const Text('Cancel'),
            ),
            ElevatedButton(
              onPressed: () async {
                if (nameController.text.isEmpty ||
                    addressController.text.isEmpty ||
                    phoneController.text.isEmpty) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('Please fill all required fields')),
                  );
                  return;
                }

                final newStore = Store(
                  id: store?.id,
                  name: nameController.text,
                  address: addressController.text,
                  phone: phoneController.text,
                  managerId: selectedManagerId,
                  type: storeType,
                  active: active,
                );

                try {
                  if (isEdit) {
                    await DatabaseService.updateStore(newStore);
                  } else {
                    await DatabaseService.insertStore(newStore);
                  }
                  Navigator.pop(context, true);
                } catch (e) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text('Error: $e')),
                  );
                }
              },
              child: Text(isEdit ? 'Update' : 'Add'),
            ),
          ],
        ),
      ),
    );

    if (result == true) {
      _loadData();
    }
  }

  Future<void> _showDeleteConfirmDialog(Store store) async {
    final result = await showDialog<bool>(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        title: const Text('Delete Store'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Are you sure you want to delete "${store.name}"?'),
            const SizedBox(height: 16),
            const Text(
              'This action will also delete:',
              style: TextStyle(fontWeight: FontWeight.bold),
            ),
            const Text('• All stock records for this store'),
            const SizedBox(height: 8),
            const Text(
              'This action cannot be undone.',
              style: TextStyle(color: Colors.red, fontWeight: FontWeight.bold),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context, true),
            style: TextButton.styleFrom(foregroundColor: Colors.red),
            child: const Text('Delete'),
          ),
        ],
      ),
    );

    if (result == true && mounted) {
      try {
        await DatabaseService.deleteStore(store.id!);
        _loadData(); // Refresh the stores list
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Store "${store.name}" deleted successfully')),
        );
      } catch (e) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error deleting store: $e')),
        );
      }
    }
  }
}
