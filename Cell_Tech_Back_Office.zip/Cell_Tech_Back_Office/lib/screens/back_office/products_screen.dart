import 'package:flutter/material.dart';
import 'dart:convert';
import 'dart:io';
import '../../services/database_service.dart';
import '../../models/product.dart';
import '../../models/category.dart';
import '../../models/store.dart';
import '../../widgets/back_office_layout.dart';
import '../../widgets/components/product_filters.dart';
import '../../widgets/components/product_form.dart';
import '../../widgets/components/product_import_modal.dart';

class ProductsScreen extends StatefulWidget {
  const ProductsScreen({super.key});

  @override
  State<ProductsScreen> createState() => _ProductsScreenState();
}

class _ProductsScreenState extends State<ProductsScreen> {
  // Data storage - matching React state structure
  List<Product> _products = [];
  List<Category> _categories = [];
  List<Store> _stores = [];
  Map<String, Map<String, dynamic>> _inventory = {};
  Map<int, int> _productTotals = {};
  bool _isLoading = true;
  bool _showForm = false;
  bool _showImportModal = false;
  Product? _editingProduct;
  String _searchTerm = '';
  Set<int> _selectedProducts = {};
  int _rowsPerPage = 25; // Default rows per page
  int _currentPage = 0; // Current page index
  
  // Filters - matching React filters structure
  Map<String, String> _filters = {
    'category': 'all',
    'status': 'all',
    'stockLevel': 'all',
  };

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  // Load data - matching React loadData function
  Future<void> _loadData() async {
    if (mounted) {
      setState(() => _isLoading = true);
    }
    try {
      // Load all data in parallel like React Promise.all
      final results = await Future.wait([
        DatabaseService.getProducts(),
        DatabaseService.getCategories(),
        DatabaseService.getStores(),
      ]);
      
      final products = results[0] as List<Product>;
      final categories = results[1] as List<Category>;
      final stores = results[2] as List<Store>;
      
  // Ensure all products have stock records for all stores
  await DatabaseService.ensureAllProductsHaveStockRecords();

      // Load inventory data for all stores - robust parsing
      Map<String, Map<String, dynamic>> inventory = {};
      int toSafeInt(dynamic v, {int fallback = 0}) {
        if (v == null) return fallback;
        if (v is int) return v;
        if (v is num) return v.toInt();
        final s = v.toString();
        return int.tryParse(s) ?? fallback;
      }

      for (final store in stores) {
        final storeId = store.id;
        if (storeId != null) {
          final storeStock = await DatabaseService.getStoreStock(storeId);
          for (final stock in storeStock) {
            // Prefer explicit product_id if present, else fallback to p.id from p.*
            final dynamic rawPid = stock.containsKey('product_id') ? stock['product_id'] : stock['id'];
            final int? productId = rawPid is int ? rawPid : int.tryParse(rawPid?.toString() ?? '');
            if (productId == null) {
              continue; // skip malformed row
            }

            final productIdStr = productId.toString();
            inventory.putIfAbsent(productIdStr, () => {});

      // Read using aliased column names when present to avoid collision with products.stock_quantity
      final qty = stock.containsKey('ss_stock_quantity')
        ? toSafeInt(stock['ss_stock_quantity'], fallback: 0)
        : toSafeInt(stock['stock_quantity'], fallback: 0);
      final minLevel = stock.containsKey('ss_min_stock_level')
        ? toSafeInt(stock['ss_min_stock_level'], fallback: 5)
        : toSafeInt(stock['min_stock_level'], fallback: 5);

            inventory[productIdStr]![storeId.toString()] = {
              'quantity': qty,
              'min_level': minLevel,
            };
          }
        }
      }

      // Also fetch DB-aggregated totals to ensure correctness
      final totals = await DatabaseService.getProductTotals(activeOnly: true);

      if (mounted) {
        setState(() {
          _products = products;
          _categories = categories;
          _stores = stores;
          _inventory = inventory;
          _productTotals = totals;
          _isLoading = false;
        });
      }
    } catch (e) {
      if (mounted) {
        setState(() => _isLoading = false);
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error loading products: $e')),
        );
      }
    }
  }

  // Handle product submission - matching React handleSubmit
  Future<void> _handleSubmit(Product product, Map<int, Map<String, dynamic>> storeSettings) async {
    try {
      final storeStockData = <String, Map<String, dynamic>>{};
      storeSettings.forEach((storeId, settings) {
        storeStockData[storeId.toString()] = settings;
      });
      
      if (_editingProduct != null) {
        await DatabaseService.updateProduct(product, storeStockData: storeStockData);
      } else {
        await DatabaseService.insertProduct(product, storeStockData: storeStockData);
      }
      
      setState(() {
        _showForm = false;
        _editingProduct = null;
      });
      _loadData();
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error saving product: $e')),
        );
      }
    }
  }

  // Handle edit - matching React handleEdit
  void _handleEdit(Product product) {
    setState(() {
      _editingProduct = product;
      _showForm = true;
    });
  }

  // Handle import complete - matching React handleImportComplete
  void _handleImportComplete() {
    setState(() {
      _showImportModal = false;
    });
    _loadData();
  }

  // Download template - matching React downloadTemplate
  void _downloadTemplate() {
    final baseHeaders = [
      "Handle", "SKU", "Name", "Category", "Description", "Sold by weight",
      "Option 1 name", "Option 1 value", "Option 2 name", "Option 2 value",
      "Option 3 name", "Option 3 value", "Default price", "Cost", "Barcode",
      "SKU of included item", "Quantity of included item", "Track stock",
      "Use production", "Supplier", "Purchase cost"
    ];
    
    List<String> allHeaders = [...baseHeaders];
    
    // Add store-specific columns
    for (final store in _stores) {
      allHeaders.addAll([
        "Available for sale [${store.name}]",
        "Price [${store.name}]",
        "In stock [${store.name}]",
        "Low stock [${store.name}]",
        "Optimal stock [${store.name}]"
      ]);
    }
    
    // TODO: Implement actual CSV download
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Template download would be implemented here')),
    );
  }

  // Handle export - matching React handleExport
  void _handleExport({bool exportAll = true}) {
    final productsToExport = exportAll ? _filteredProducts : 
        _filteredProducts.where((p) => _selectedProducts.contains(p.id)).toList();
    
    if (!exportAll && productsToExport.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please select products to export')),
      );
      return;
    }

    // TODO: Implement actual CSV export
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('Exporting ${productsToExport.length} products...')),
    );
  }

  // Handle product selection - matching React handleSelectProduct
  void _handleSelectProduct(int productId, bool checked) {
    setState(() {
      if (checked) {
        _selectedProducts.add(productId);
      } else {
        _selectedProducts.remove(productId);
      }
    });
  }

  // Handle select all - matching React handleSelectAll
  void _handleSelectAll(bool checked) {
    setState(() {
      if (checked) {
        _selectedProducts = _filteredProducts.map((p) => p.id!).toSet();
      } else {
        _selectedProducts.clear();
      }
    });
  }

  // Handle delete selected products
  Future<void> _handleDeleteSelected() async {
    if (_selectedProducts.isEmpty) return;

    final selectedCount = _selectedProducts.length;
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Delete Products'),
        content: Text(
          'Are you sure you want to delete $selectedCount selected product${selectedCount > 1 ? 's' : ''}? This action cannot be undone.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(false),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () => Navigator.of(context).pop(true),
            style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
            child: const Text('Delete', style: TextStyle(color: Colors.white)),
          ),
        ],
      ),
    );

    if (confirmed == true) {
      try {
        // Delete products from database
        for (final productId in _selectedProducts) {
          await DatabaseService.deleteProduct(productId);
        }
        
        // Clear selection and reload data
        setState(() {
          _selectedProducts.clear();
        });
        await _loadData();

        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text('Successfully deleted $selectedCount product${selectedCount > 1 ? 's' : ''}'),
              backgroundColor: Colors.green,
            ),
          );
        }
      } catch (e) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text('Error deleting products: $e'),
              backgroundColor: Colors.red,
            ),
          );
        }
      }
    }
  }

  // Get total stock for product across all stores - simplified
  int _getTotalStock(Product product) {
    final pid = product.id;
    if (pid != null && _productTotals.containsKey(pid)) {
      return _productTotals[pid] ?? 0;
    }
    // Fallback to in-memory inventory if totals not available yet
    final productInventory = _inventory[product.id!.toString()] ?? {};
    int totalStock = 0;
    for (final storeData in productInventory.values) {
      if (storeData is Map) {
        final q = storeData['quantity'];
        if (q is int) {
          totalStock += q;
        } else if (q is num) totalStock += q.toInt();
        else if (q != null) totalStock += int.tryParse(q.toString()) ?? 0;
      }
    }
    return totalStock;
  }

  // Filtered products - matching React filteredProducts
  List<Product> get _filteredProducts {
    return _products.where((product) {
      final matchesSearch = product.name.toLowerCase().contains(_searchTerm.toLowerCase()) ||
                           product.sku.toLowerCase().contains(_searchTerm.toLowerCase());
      final matchesCategory = _filters['category'] == 'all' || product.categoryId.toString() == _filters['category'];
      final matchesStatus = _filters['status'] == 'all' || 
                           (_filters['status'] == 'active' && product.active) ||
                           (_filters['status'] == 'inactive' && !product.active);
      
      // Calculate total stock across stores
      final totalStock = _getTotalStock(product);
      
      final matchesStockLevel = _filters['stockLevel'] == 'all' ||
                               (_filters['stockLevel'] == 'low' && totalStock <= 10 && totalStock > 0) ||
                               (_filters['stockLevel'] == 'out' && totalStock == 0) ||
                               (_filters['stockLevel'] == 'normal' && totalStock > 10);
      return matchesSearch && matchesCategory && matchesStatus && matchesStockLevel;
    }).toList();
  }

  // Paginated products - get products for current page
  List<Product> get _paginatedProducts {
    final filtered = _filteredProducts;
    final startIndex = _currentPage * _rowsPerPage;
    final endIndex = (startIndex + _rowsPerPage).clamp(0, filtered.length);
    return filtered.sublist(startIndex, endIndex);
  }

  // Total pages calculation
  int get _totalPages {
    final filtered = _filteredProducts;
    return (filtered.length / _rowsPerPage).ceil();
  }

  // Get stock status based on total quantity - simplified
  Map<String, dynamic> _getStockStatus(int totalStock) {
    if (totalStock == 0) return {'status': 'out', 'color': Colors.red.shade100, 'text': 'Out of Stock'};
    if (totalStock <= 10) return {'status': 'low', 'color': Colors.yellow.shade100, 'text': 'Low Stock'};
    return {'status': 'good', 'color': Colors.green.shade100, 'text': 'In Stock'};
  }





  // Product form overlay - matching React ProductForm modal
  Widget _buildProductFormOverlay() {
    return Container(
      color: Colors.black54,
      child: Center(
        child: ProductForm(
          product: _editingProduct,
          categories: _categories,
          stores: _stores,
          onSubmit: _handleSubmit,
          onCancel: () => setState(() {
            _showForm = false;
            _editingProduct = null;
          }),
        ),
      ),
    );
  }

  // Import modal overlay - matching React ProductImportModal
  Widget _buildImportModalOverlay() {
    return Container(
      color: Colors.black54,
      child: Center(
        child: ProductImportModal(
          stores: _stores,
          onComplete: _handleImportComplete,
        ),
      ),
    );
  }



  @override
  Widget build(BuildContext context) {
    // Selection state helpers - matching React allSelected and someSelected
    final allSelected = _filteredProducts.isNotEmpty && _selectedProducts.length == _filteredProducts.length;
    final someSelected = _selectedProducts.isNotEmpty && _selectedProducts.length < _filteredProducts.length;

    return BackOfficeLayout(
      title: 'Products Management',
      currentRoute: '/backoffice/products',
      child: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [Color(0xFFFFF3E0), Color(0xFFF5F5F5)],
          ),
        ),
        child: _isLoading
            ? const Center(child: CircularProgressIndicator())
            : _buildContent(allSelected, someSelected),
      ),
    );
  }

  Widget _buildContent(bool allSelected, bool someSelected) {
    final core = Padding(
      padding: const EdgeInsets.all(24),
      child: Column(
        spacing: 24,
        children: [
          _buildHeader(),
          _buildSearchCard(),
          Expanded(child: _buildProductsCard(allSelected, someSelected)),
        ],
      ),
    );

    return Stack(
      children: [
        core,
        if (_showForm) Positioned.fill(child: _buildProductFormOverlay()),
        if (_showImportModal) Positioned.fill(child: _buildImportModalOverlay()),
      ],
    );
  }

  // Header section - matching React header structure
  Widget _buildHeader() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Title section
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            ShaderMask(
              shaderCallback: (bounds) => const LinearGradient(
                colors: [Color(0xFFFF8C00), Color(0xFFFF7043)],
              ).createShader(bounds),
              child: const Text(
                'Products',
                style: TextStyle(
                  fontSize: 32,
                  fontWeight: FontWeight.bold,
                  color: Colors.white,
                ),
              ),
            ),
            const SizedBox(height: 4),
            Text(
              'Manage your product catalog and stock levels',
              style: TextStyle(
                fontSize: 16,
                color: Colors.grey.shade600,
              ),
            ),
          ],
        ),
        
        // Action buttons - make horizontally scrollable to avoid overflow on narrow widths
        Expanded(
          child: Align(
            alignment: Alignment.centerRight,
            child: SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(
                spacing: 12,
                children: [
            // Download Template button
            OutlinedButton.icon(
              onPressed: _downloadTemplate,
              icon: const Icon(Icons.download, size: 16),
              label: const Text('Download Template'),
              style: OutlinedButton.styleFrom(
                foregroundColor: const Color(0xFFFF8C00),
                side: const BorderSide(color: Color(0xFFFFF3E0)),
                backgroundColor: const Color(0xFFFFF3E0),
              ),
            ),
            
            // Import button
            OutlinedButton.icon(
              onPressed: () => setState(() => _showImportModal = true),
              icon: const Icon(Icons.upload, size: 16),
              label: const Text('Import'),
              style: OutlinedButton.styleFrom(
                foregroundColor: const Color(0xFFFF8C00),
                side: const BorderSide(color: Color(0xFFFFF3E0)),
                backgroundColor: const Color(0xFFFFF3E0),
              ),
            ),
            
            // Delete selected button
            OutlinedButton.icon(
              onPressed: _selectedProducts.isNotEmpty ? _handleDeleteSelected : null,
              icon: const Icon(Icons.delete_outline, size: 16),
              label: Text('Delete${_selectedProducts.isNotEmpty ? ' (${_selectedProducts.length})' : ''}'),
              style: OutlinedButton.styleFrom(
                foregroundColor: _selectedProducts.isNotEmpty ? Colors.red : Colors.grey,
                side: BorderSide(color: _selectedProducts.isNotEmpty ? Colors.red.shade200 : Colors.grey.shade300),
                backgroundColor: _selectedProducts.isNotEmpty ? Colors.red.shade50 : Colors.grey.shade50,
              ),
            ),
            
            // Export dropdown
            PopupMenuButton<String>(
              onSelected: (value) {
                switch (value) {
                  case 'all':
                    _handleExport(exportAll: true);
                    break;
                  case 'selected':
                    _handleExport(exportAll: false);
                    break;
                }
              },
              itemBuilder: (context) => [
                const PopupMenuItem(
                  value: 'all',
                  child: Text('Export All Products'),
                ),
                PopupMenuItem(
                  value: 'selected',
                  enabled: _selectedProducts.isNotEmpty,
                  child: Text('Export Selected (${_selectedProducts.length})'),
                ),
              ],
              child: OutlinedButton.icon(
                onPressed: null,
                icon: const Icon(Icons.download, size: 16),
                label: const Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text('Export'),
                    Icon(Icons.arrow_drop_down, size: 16),
                  ],
                ),
                style: OutlinedButton.styleFrom(
                  foregroundColor: const Color(0xFFFF8C00),
                  side: const BorderSide(color: Color(0xFFFFF3E0)),
                  backgroundColor: const Color(0xFFFFF3E0),
                ),
              ),
            ),
            
            // Add Product button
            ElevatedButton.icon(
              onPressed: () => setState(() => _showForm = true),
              icon: const Icon(Icons.add, size: 16),
              label: const Text('Add Product'),
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFFFF8C00),
                foregroundColor: Colors.white,
                elevation: 4,
                shadowColor: const Color(0xFFFF8C00).withOpacity(0.3),
                padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
              ),
            ),
                ],
              ),
            ),
          ),
        ),
      ],
    );
  }

  // Search card - matching React search card structure
  Widget _buildSearchCard() {
    return Card(
      elevation: 1,
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Row(
          children: [
            // Search input - matching React search input
            Expanded(
              child: Container(
                decoration: BoxDecoration(
                  border: Border.all(color: Colors.grey.shade300),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: TextField(
                  decoration: const InputDecoration(
                    hintText: 'Search products by name or SKU...',
                    prefixIcon: Icon(Icons.search, color: Colors.grey),
                    border: InputBorder.none,
                    contentPadding: EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                  ),
                  onChanged: (value) {
                    setState(() {
                      _searchTerm = value;
                      _currentPage = 0; // Reset to first page when search changes
                    });
                  },
                ),
              ),
            ),
            const SizedBox(width: 16),
            
            // Product filters - matching React ProductFilters component
            ProductFilters(
              filters: _filters.map((k, v) => MapEntry(k, v as dynamic)),
              categories: _categories,
              onFiltersChange: (newFilters) {
                setState(() {
                  _filters = newFilters.map((k, v) => MapEntry(k, v.toString()));
                  _currentPage = 0; // Reset to first page when filters change
                });
              },
              rowsPerPage: _rowsPerPage,
              onRowsPerPageChange: (value) {
                setState(() {
                  _rowsPerPage = value;
                  _currentPage = 0; // Reset to first page when changing page size
                });
              },
            ),
          ],
        ),
      ),
    );
  }

  // Products card - matching React products table card structure
  Widget _buildProductsCard(bool allSelected, bool someSelected) {
    final filteredProducts = _filteredProducts;
    final lowStockCount = filteredProducts.where((product) {
      final totalStock = _getTotalStock(product);
      final stockStatus = _getStockStatus(totalStock);
      return stockStatus['status'] != 'good';
    }).length;

    return Card(
      elevation: 1,
      child: Column(
        children: [
          // Card header - matching React CardHeader
          Container(
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              border: Border(bottom: BorderSide(color: Colors.grey.shade200)),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                // Title with count and selected badge
                Row(
                  children: [
                    const Icon(Icons.inventory_2, color: Colors.blue, size: 20),
                    const SizedBox(width: 8),
                    Text(
                      'Products (${filteredProducts.length})',
                      style: const TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    if (_selectedProducts.isNotEmpty) ...[
                      const SizedBox(width: 12),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                        decoration: BoxDecoration(
                          color: Colors.grey.shade200,
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Text(
                          '${_selectedProducts.length} selected',
                          style: const TextStyle(fontSize: 12),
                        ),
                      ),
                    ],
                  ],
                ),
                
                // Low stock badge - matching React AlertTriangle badge
                if (lowStockCount > 0)
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                    decoration: BoxDecoration(
                      color: Colors.red,
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const Icon(Icons.warning, color: Colors.white, size: 12),
                        const SizedBox(width: 4),
                        Text(
                          '$lowStockCount Items with Low/No Stock',
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 12,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ],
                    ),
                  ),
              ],
            ),
          ),
          
          // Table content - matching React table structure
          Expanded(
            child: _buildTableContent(_paginatedProducts, allSelected, someSelected),
          ),
          
          // Pagination controls
          if (_filteredProducts.isNotEmpty && _totalPages > 1)
            _buildPaginationControls(),
        ],
      ),
    );
  }

  // Table content - matching React Table structure
  Widget _buildTableContent(List<Product> filteredProducts, bool allSelected, bool someSelected) {
    if (_isLoading) {
      return _buildLoadingSkeleton();
    }

    if (filteredProducts.isEmpty) {
      return const Center(
        child: Padding(
          padding: EdgeInsets.all(32),
          child: Text(
            'No products match your criteria.',
            style: TextStyle(
              fontSize: 16,
              color: Colors.grey,
            ),
          ),
        ),
      );
    }

    return SingleChildScrollView(
      child: Table(
        columnWidths: const {
          0: FixedColumnWidth(50),    // Checkbox
          1: FixedColumnWidth(60),    // Image
          2: FlexColumnWidth(2),      // Product name
          3: FlexColumnWidth(1),      // SKU
          4: FlexColumnWidth(1),      // Category
          5: FlexColumnWidth(1),      // Price
          6: FlexColumnWidth(1),      // Total Qty
          7: FlexColumnWidth(1),      // Status
          8: FixedColumnWidth(60),    // Actions
        },
        children: [
          // Table header - matching React TableHeader
          TableRow(
            decoration: const BoxDecoration(
              color: Color(0xFFF8F9FA),
            ),
            children: [
              TableCell(
                child: Padding(
                  padding: const EdgeInsets.all(12),
                  child: Checkbox(
                    value: allSelected,
                    tristate: someSelected,
                    onChanged: (checked) => _handleSelectAll(checked ?? false),
                    activeColor: const Color(0xFFFF8C00),
                  ),
                ),
              ),
              const TableCell(
                child: Padding(
                  padding: EdgeInsets.all(12),
                  child: Text('', style: TextStyle(fontWeight: FontWeight.w600)),
                ),
              ),
              const TableCell(
                child: Padding(
                  padding: EdgeInsets.all(12),
                  child: Text('Product', style: TextStyle(fontWeight: FontWeight.w600)),
                ),
              ),
              const TableCell(
                child: Padding(
                  padding: EdgeInsets.all(12),
                  child: Text('SKU', style: TextStyle(fontWeight: FontWeight.w600)),
                ),
              ),
              const TableCell(
                child: Padding(
                  padding: EdgeInsets.all(12),
                  child: Text('Category', style: TextStyle(fontWeight: FontWeight.w600)),
                ),
              ),
              const TableCell(
                child: Padding(
                  padding: EdgeInsets.all(12),
                  child: Text('Price', style: TextStyle(fontWeight: FontWeight.w600)),
                ),
              ),
              const TableCell(
                child: Padding(
                  padding: EdgeInsets.all(12),
                  child: Text('Total Qty', style: TextStyle(fontWeight: FontWeight.w600)),
                ),
              ),
              const TableCell(
                child: Padding(
                  padding: EdgeInsets.all(12),
                  child: Text('Status', style: TextStyle(fontWeight: FontWeight.w600)),
                ),
              ),
              const TableCell(
                child: Padding(
                  padding: EdgeInsets.all(12),
                  child: Text('Actions', style: TextStyle(fontWeight: FontWeight.w600)),
                ),
              ),
            ],
          ),
          
          // Table rows - matching React table rows
          ...filteredProducts.map((product) => _buildProductRow(product)),
        ],
      ),
    );
  }

  // Product row - matching React TableRow structure
  TableRow _buildProductRow(Product product) {
    final totalStock = _getTotalStock(product);
    final stockStatus = _getStockStatus(totalStock);
    final category = _categories.firstWhere(
      (c) => c.id == product.categoryId,
      orElse: () => Category(name: 'Unknown', color: '#666666', active: true, createdAt: DateTime.now()),
    );

    return TableRow(
      decoration: const BoxDecoration(
        color: Colors.white,
        border: Border(bottom: BorderSide(color: Color(0xFFF0F0F0))),
      ),
      children: [
        // Checkbox cell
        TableCell(
          child: Padding(
            padding: const EdgeInsets.all(12),
            child: Checkbox(
              value: _selectedProducts.contains(product.id),
              onChanged: (checked) => _handleSelectProduct(product.id!, checked ?? false),
              activeColor: const Color(0xFFFF8C00),
            ),
          ),
        ),
        
        // Image cell - matching React image cell
        TableCell(
          child: Padding(
            padding: const EdgeInsets.all(12),
            child: Container(
              width: 48,
              height: 48,
              decoration: BoxDecoration(
                color: Colors.grey.shade100,
                borderRadius: BorderRadius.circular(8),
              ),
              child: _buildProductImage(product.imageUrl),
            ),
          ),
        ),
        
        // Product name cell - matching React product name cell
        TableCell(
          child: Padding(
            padding: const EdgeInsets.all(12),
            child: GestureDetector(
              onTap: () => _handleEdit(product),
              child: Text(
                product.name,
                style: const TextStyle(
                  fontWeight: FontWeight.w500,
                  color: Colors.black87,
                ),
              ),
            ),
          ),
        ),
        
        // SKU cell
        TableCell(
          child: Padding(
            padding: const EdgeInsets.all(12),
            child: Text(
              product.sku,
              style: const TextStyle(
                fontFamily: 'monospace',
                fontSize: 13,
              ),
            ),
          ),
        ),
        
        // Category cell - matching React category badge
        TableCell(
          child: Padding(
            padding: const EdgeInsets.all(12),
            child: category.name != 'Unknown'
                ? Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                    decoration: BoxDecoration(
                      border: Border.all(color: Colors.grey.shade300),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Text(
                      category.name,
                      style: const TextStyle(fontSize: 12),
                    ),
                  )
                : const Text('-', style: TextStyle(color: Colors.grey)),
          ),
        ),
        
        // Price cell
        TableCell(
          child: Padding(
            padding: const EdgeInsets.all(12),
            child: Text(
              '\$${product.price.toStringAsFixed(2)}',
              style: const TextStyle(fontWeight: FontWeight.w600),
            ),
          ),
        ),
        
        // Total Stock cell - simplified display
        TableCell(
          child: Padding(
            padding: const EdgeInsets.all(12),
            child: Center(
              child: Text(
                totalStock.toString(),
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w600,
                  color: stockStatus['status'] == 'good' ? Colors.green.shade600 : 
                         stockStatus['status'] == 'low' ? Colors.yellow.shade600 : Colors.red.shade600,
                ),
              ),
            ),
          ),
        ),
        
        // Status cell - matching React status badge
        TableCell(
          child: Padding(
            padding: const EdgeInsets.all(12),
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
              decoration: BoxDecoration(
                color: stockStatus['color'] as Color,
                borderRadius: BorderRadius.circular(12),
              ),
              child: Text(
                stockStatus['text'] as String,
                style: const TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ),
          ),
        ),
        
        // Actions cell - matching React actions
        TableCell(
          child: Padding(
            padding: const EdgeInsets.all(12),
            child: IconButton(
              onPressed: () => _handleEdit(product),
              icon: const Icon(
                Icons.edit,
                size: 16,
                color: Colors.grey,
              ),
              tooltip: 'Edit Product',
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildProductImage(String? imageUrl) {
    if (imageUrl == null || imageUrl.isEmpty) {
      return const Icon(Icons.image, color: Colors.grey);
    }
    final border = BorderRadius.circular(8);
    // Data URI
    if (imageUrl.startsWith('data:image')) {
      try {
        final base64Str = imageUrl.split(',').last;
        final bytes = base64Decode(base64Str);
        return ClipRRect(
          borderRadius: border,
          child: Image.memory(bytes, fit: BoxFit.cover),
        );
      } catch (_) {
        return const Icon(Icons.image, color: Colors.grey);
      }
    }
    // Local file path
    if (imageUrl.startsWith('C:') || imageUrl.startsWith('D:') || imageUrl.startsWith('E:') || imageUrl.startsWith('\\') || imageUrl.startsWith('/')) {
      return ClipRRect(
        borderRadius: border,
        child: Image.file(
          File(imageUrl),
          fit: BoxFit.cover,
          errorBuilder: (context, error, stackTrace) => const Icon(Icons.image, color: Colors.grey),
        ),
      );
    }
    // Network
    return ClipRRect(
      borderRadius: border,
      child: Image.network(
        imageUrl,
        fit: BoxFit.cover,
        errorBuilder: (context, error, stackTrace) => const Icon(Icons.image, color: Colors.grey),
      ),
    );
  }

  // Loading skeleton - matching React Skeleton components
  Widget _buildLoadingSkeleton() {
    return Padding(
      padding: const EdgeInsets.all(16),
      child: Column(
        children: List.generate(8, (index) => 
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 8),
            child: Row(
              children: [
                Container(width: 16, height: 16, color: Colors.grey.shade300),
                const SizedBox(width: 16),
                Container(width: 48, height: 48, color: Colors.grey.shade300),
                const SizedBox(width: 16),
                Expanded(child: Container(height: 16, color: Colors.grey.shade300)),
                const SizedBox(width: 16),
                Container(width: 80, height: 16, color: Colors.grey.shade300),
                const SizedBox(width: 16),
                Container(width: 60, height: 16, color: Colors.grey.shade300),
                const SizedBox(width: 16),
                Container(width: 60, height: 16, color: Colors.grey.shade300),
                const SizedBox(width: 16),
                Container(width: 100, height: 16, color: Colors.grey.shade300),
                const SizedBox(width: 16),
                Container(width: 80, height: 16, color: Colors.grey.shade300),
                const SizedBox(width: 16),
                Container(width: 32, height: 32, color: Colors.grey.shade300),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // Pagination controls
  Widget _buildPaginationControls() {
    final totalItems = _filteredProducts.length;
    final startItem = _currentPage * _rowsPerPage + 1;
    final endItem = ((_currentPage + 1) * _rowsPerPage).clamp(0, totalItems);

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        border: Border(top: BorderSide(color: Colors.grey.shade200)),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          // Items info
          Text(
            'Showing $startItem-$endItem of $totalItems items',
            style: TextStyle(
              color: Colors.grey.shade600,
              fontSize: 14,
            ),
          ),
          
          // Pagination buttons
          Row(
            children: [
              // Previous button
              IconButton(
                onPressed: _currentPage > 0 ? () {
                  setState(() {
                    _currentPage--;
                  });
                } : null,
                icon: const Icon(Icons.chevron_left),
                tooltip: 'Previous page',
              ),
              
              // Page numbers
              for (int i = 0; i < _totalPages; i++)
                if (i == _currentPage || 
                    (i >= _currentPage - 2 && i <= _currentPage + 2) ||
                    i == 0 || i == _totalPages - 1)
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 2),
                    child: TextButton(
                      onPressed: () {
                        setState(() {
                          _currentPage = i;
                        });
                      },
                      style: TextButton.styleFrom(
                        backgroundColor: i == _currentPage ? const Color(0xFFFF8C00) : null,
                        foregroundColor: i == _currentPage ? Colors.white : const Color(0xFFFF8C00),
                        minimumSize: const Size(32, 32),
                      ),
                      child: Text('${i + 1}'),
                    ),
                  )
                else if ((i == _currentPage - 3 && _currentPage > 3) ||
                         (i == _currentPage + 3 && _currentPage < _totalPages - 4))
                  const Padding(
                    padding: EdgeInsets.symmetric(horizontal: 4),
                    child: Text('...'),
                  ),
              
              // Next button
              IconButton(
                onPressed: _currentPage < _totalPages - 1 ? () {
                  setState(() {
                    _currentPage++;
                  });
                } : null,
                icon: const Icon(Icons.chevron_right),
                tooltip: 'Next page',
              ),
            ],
          ),
        ],
      ),
    );
  }
}