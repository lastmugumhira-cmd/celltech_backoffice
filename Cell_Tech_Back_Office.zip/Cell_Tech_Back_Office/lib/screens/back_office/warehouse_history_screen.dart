import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../../widgets/back_office_layout.dart';
import '../../services/database_service.dart';
import '../../services/pdf_service.dart';

class WarehouseHistoryScreen extends StatefulWidget {
  const WarehouseHistoryScreen({super.key});

  @override
  State<WarehouseHistoryScreen> createState() => _WarehouseHistoryScreenState();
}

class _WarehouseHistoryScreenState extends State<WarehouseHistoryScreen> {
  List<Map<String, dynamic>> _adjustments = [];
  bool _loading = true;
  String _search = '';
  final Map<int, int> _itemsCount = {}; // adjustmentId -> items count
  final DateFormat _dateFmt = DateFormat('yMMMd');
  // Paging
  int _rowsPerPage = 25; // 10,25,50,100
  int _page = 0;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    final data = await DatabaseService.getStockAdjustments();
    setState(() {
      _adjustments = data;
      _loading = false;
    });
  }

  Color _badgeColor(String reason) {
    switch (reason) {
      case 'receive_items':
        return Colors.green;
      case 'transfer_in':
        return Colors.blue;
      case 'transfer_out':
        return Colors.orange;
      case 'loss':
        return Colors.red;
      case 'damage':
        return Colors.red.shade700;
      default:
        return Colors.grey;
    }
  }

  @override
  Widget build(BuildContext context) {
    // Filter by search
    final filtered = _adjustments.where((it) {
      if (_search.isEmpty) return true;
      final text = '${it['adjustment_number'] ?? ''} ${it['reason'] ?? ''} ${it['employee_name'] ?? ''} ${it['store_name'] ?? ''}'.toLowerCase();
      return text.contains(_search);
    }).toList();

    return BackOfficeLayout(
      title: 'Warehouse History',
      currentRoute: '/backoffice/warehouse-history',
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          // Header with back button and title
          Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              OutlinedButton.icon(
                onPressed: () => Navigator.pushReplacementNamed(context, '/backoffice/warehouse-manager'),
                icon: const Icon(Icons.arrow_back),
                label: const Text('Back'),
              ),
              const SizedBox(width: 12),
              const Icon(Icons.history, size: 32, color: Color(0xFF4F46E5)),
              const SizedBox(width: 8),
              const Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Warehouse Transaction History', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                  SizedBox(height: 2),
                  Text('Track all inventory movements and adjustments', style: TextStyle(color: Colors.grey)),
                ],
              ),
              const Spacer(),
              IconButton(
                tooltip: 'Refresh',
                onPressed: _load,
                icon: const Icon(Icons.refresh),
              ),
            ],
          ),
          const SizedBox(height: 12),

          // Search card
          Card(
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Row(
                children: [
                  Expanded(
                    child: TextField(
                      decoration: const InputDecoration(
                        prefixIcon: Icon(Icons.search),
                        hintText: 'Search by adjustment number, reason, or employee…',
                        border: OutlineInputBorder(),
                      ),
                      onChanged: (v) => setState(() => _search = v.trim().toLowerCase()),
                    ),
                  ),
                ],
              ),
            ),
          ),

          const SizedBox(height: 8),

          // Table card
          Expanded(
            child: Card(
              child: _loading
                  ? _buildSkeletonTable()
                  : filtered.isEmpty
                      ? _buildEmptyState()
                      : _buildTable(filtered),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSkeletonTable() {
    return ListView.builder(
      itemCount: 10,
      itemBuilder: (context, index) {
        return Padding(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
          child: Row(
            children: [
              _skeletonBox(width: 90),
              const SizedBox(width: 12),
              _skeletonBox(width: 140),
              const SizedBox(width: 12),
              _skeletonBox(width: 100, height: 20, radius: 12),
              const SizedBox(width: 12),
              _skeletonBox(width: 120),
              const SizedBox(width: 12),
              _skeletonBox(width: 120),
              const SizedBox(width: 12),
              _skeletonBox(width: 48),
              const SizedBox(width: 40),
            ],
          ),
        );
      },
    );
  }

  Widget _buildEmptyState() {
    return const Center(
      child: Padding(
        padding: EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.inventory_2_outlined, size: 56, color: Colors.grey),
            SizedBox(height: 8),
            Text('No adjustments found', style: TextStyle(color: Colors.grey)),
          ],
        ),
      ),
    );
  }

  Widget _buildTable(List<Map<String, dynamic>> all) {
    final total = all.length;
    final start = (_page * _rowsPerPage).clamp(0, total);
    final end = (start + _rowsPerPage).clamp(0, total);
    final rows = all.sublist(start, end);
    return Column(
      children: [
        Expanded(
          child: ListView.separated(
            itemCount: rows.length + 1,
            separatorBuilder: (_, __) => const Divider(height: 1),
            itemBuilder: (context, index) {
              if (index == 0) {
                // Header row
                return const Padding(
                  padding: EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                  child: Row(
                    children: [
                      SizedBox(width: 90, child: _HeaderCell('Date')),
                      SizedBox(width: 12),
                      SizedBox(width: 140, child: _HeaderCell('Adjustment #')),
                      SizedBox(width: 12),
                      SizedBox(width: 100, child: _HeaderCell('Reason')),
                      SizedBox(width: 12),
                      SizedBox(width: 120, child: _HeaderCell('Location')),
                      SizedBox(width: 12),
                      SizedBox(width: 120, child: _HeaderCell('Employee')),
                      SizedBox(width: 12),
                      SizedBox(width: 48, child: Center(child: _HeaderCell('Items'))),
                      SizedBox(width: 40),
                    ],
                  ),
                );
              }
              final it = rows[index - 1];
              final createdAt = it['created_at'];
              String dateStr = 'N/A';
              if (createdAt is String) {
                try { dateStr = _dateFmt.format(DateTime.parse(createdAt)); } catch (_) {}
              }

              final adjId = it['id'] as int;
              // Lazy load items count if not present
              if (!_itemsCount.containsKey(adjId)) {
                Future.microtask(() async {
                  final items = await DatabaseService.getStockAdjustmentItems(adjId);
                  if (!mounted) return;
                  setState(() { _itemsCount[adjId] = items.length; });
                });
              }

              return InkWell(
                onTap: () => _openDetails(it),
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
                  child: Row(
                    children: [
                      SizedBox(width: 90, child: Text(dateStr)),
                      const SizedBox(width: 12),
                      SizedBox(width: 140, child: Text(it['adjustment_number'] ?? '', style: const TextStyle(fontFamily: 'monospace'))),
                      const SizedBox(width: 12),
                      SizedBox(width: 100, child: _reasonBadge(it['reason'] ?? '')),
                      const SizedBox(width: 12),
                      SizedBox(width: 120, child: Text(it['store_name'] ?? '', overflow: TextOverflow.ellipsis)),
                      const SizedBox(width: 12),
                      SizedBox(width: 120, child: Text(it['employee_name'] ?? 'N/A', overflow: TextOverflow.ellipsis)),
                      const SizedBox(width: 12),
                      SizedBox(
                        width: 48,
                        child: Center(
                          child: _itemsCount.containsKey(adjId)
                              ? Text('${_itemsCount[adjId]}')
                              : const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2)),
                        ),
                      ),
                      IconButton(
                        tooltip: 'View details',
                        icon: const Icon(Icons.visibility_outlined),
                        onPressed: () => _openDetails(it),
                      ),
                    ],
                  ),
                ),
              );
            },
          ),
        ),
        _paginationFooter(start, end, total),
      ],
    );
  }

  Widget _skeletonBox({double width = 80, double height = 16, double radius = 6}) {
    return Container(
      width: width,
      height: height,
      decoration: BoxDecoration(
        color: Colors.grey.shade200,
        borderRadius: BorderRadius.circular(radius),
      ),
    );
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
  }

  @override
  void setState(VoidCallback fn) {
    super.setState(fn);
  }

  Widget _paginationFooter(int start, int end, int total) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 8),
      child: Row(
        children: [
          const Text('Rows per page:'),
          const SizedBox(width: 8),
          DropdownButton<int>(
            value: _rowsPerPage,
            items: const [10, 25, 50, 100]
                .map((v) => DropdownMenuItem(value: v, child: Text('$v')))
                .toList(),
            onChanged: (v) => setState(() { _rowsPerPage = v ?? 25; _page = 0; }),
          ),
          const Spacer(),
          Text('${start + 1}-$end of $total'),
          IconButton(
            tooltip: 'Previous page',
            onPressed: _page > 0 ? () => setState(() => _page -= 1) : null,
            icon: const Icon(Icons.chevron_left),
          ),
          IconButton(
            tooltip: 'Next page',
            onPressed: end < total ? () => setState(() => _page += 1) : null,
            icon: const Icon(Icons.chevron_right),
          ),
        ],
      ),
    );
  }

  Widget _reasonBadge(String reason) {
    final color = _badgeColor(reason);
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: color.withOpacity(0.15),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Text(
        _formatReason(reason),
        style: TextStyle(color: color, fontWeight: FontWeight.w600, fontSize: 12),
        overflow: TextOverflow.ellipsis,
        maxLines: 1,
      ),
    );
  }

  String _formatReason(String reason) {
    switch (reason) {
      case 'receive_items':
        return 'Receive Items';
      case 'transfer_in':
        return 'Transfer In';
      case 'transfer_out':
        return 'Transfer Out';
      case 'inventory_count':
        return 'Inventory Count';
      case 'loss':
        return 'Loss';
      case 'damage':
        return 'Damage';
      default:
        return reason;
    }
  }

  Future<void> _openDetails(Map<String, dynamic> it) async {
    final details = await DatabaseService.getStockAdjustment(it['id']);
    if (!mounted || details == null) return;

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (_) {
        final items = (details['items'] as List).cast<Map<String, dynamic>>();
        return SizedBox(
          height: MediaQuery.of(context).size.height * 0.75,
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(details['adjustment_number'] ?? '', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                          const SizedBox(height: 4),
                          Text(
                            details['created_at'] != null
                                ? DateFormat('yMMMd, h:mm a').format(DateTime.parse(details['created_at']))
                                : 'N/A',
                            style: const TextStyle(color: Colors.grey),
                          ),
                        ],
                      ),
                    ),
                    ElevatedButton.icon(
                      onPressed: () async {
                        final data = await PdfService.generateStockAdjustmentPdf(details);
                        await PdfService.downloadPdf(data, 'adjustment-${details['adjustment_number']}.pdf');
                      },
                      icon: const Icon(Icons.download),
                      label: const Text('Download PDF'),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xFF4F46E5),
                        foregroundColor: Colors.white,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 16),
                Wrap(
                  spacing: 16,
                  runSpacing: 8,
                  children: [
                    _detailChip('Reason', _formatReason(details['reason'] ?? '')),
                    _detailChip('Employee', details['employee_name'] ?? 'N/A'),
                    _detailChip('Status', (details['status'] ?? '').toString().toUpperCase()),
                    _detailChip('Location', details['store_name'] ?? ''),
                  ],
                ),
                if ((details['notes'] ?? '').toString().isNotEmpty) ...[
                  const SizedBox(height: 12),
                  const Text('Notes', style: TextStyle(fontWeight: FontWeight.bold)),
                  const SizedBox(height: 6),
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: Colors.grey.shade50,
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(color: Colors.grey.shade200),
                    ),
                    child: Text(details['notes'] ?? ''),
                  ),
                ],
                const SizedBox(height: 12),
                const Text('Items', style: TextStyle(fontWeight: FontWeight.bold)),
                const SizedBox(height: 6),
                Expanded(
                  child: ListView.separated(
                    itemCount: items.length,
                    separatorBuilder: (_, __) => const Divider(height: 1),
                    itemBuilder: (c, i) {
                      final row = items[i];
                      final change = (row['quantity_change'] as int?) ?? ((row['quantity_after'] as int) - (row['quantity_before'] as int));
                      final changeStr = change > 0 ? '+$change' : change.toString();
                      final changeColor = change > 0 ? Colors.green : (change < 0 ? Colors.red : Colors.grey);
                      return ListTile(
                        dense: true,
                        title: Text(row['product_name'] ?? ''),
                        subtitle: Text('SKU: ${row['sku'] ?? ''}'),
                        trailing: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.end,
                          children: [
                            Text(changeStr, style: TextStyle(color: changeColor, fontWeight: FontWeight.w600)),
                            Text('Before: ${row['quantity_before']}  After: ${row['quantity_after']}', style: const TextStyle(fontSize: 12, color: Colors.grey)),
                          ],
                        ),
                      );
                    },
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _detailChip(String label, String value) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: Colors.grey.shade300),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text('$label: ', style: const TextStyle(fontWeight: FontWeight.w600)),
          Text(value),
        ],
      ),
    );
  }

}

class _HeaderCell extends StatelessWidget {
  final String label;
  const _HeaderCell(this.label);

  @override
  Widget build(BuildContext context) {
    return Text(
      label,
      style: const TextStyle(
        fontWeight: FontWeight.w600,
        color: Colors.black54,
      ),
    );
  }
}
