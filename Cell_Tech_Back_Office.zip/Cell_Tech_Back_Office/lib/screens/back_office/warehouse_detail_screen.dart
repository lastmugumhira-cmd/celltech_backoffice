import 'package:flutter/material.dart';
import '../../widgets/back_office_layout.dart';
import '../../services/database_service.dart';
import '../../models/store.dart';
import '../../models/employee.dart';

class WarehouseDetailScreen extends StatefulWidget {
  final int warehouseId;
  const WarehouseDetailScreen({super.key, required this.warehouseId});

  @override
  State<WarehouseDetailScreen> createState() => _WarehouseDetailScreenState();
}

class _WarehouseDetailScreenState extends State<WarehouseDetailScreen> {
  Store? _warehouse;
  String? _managerName;
  List<Map<String, dynamic>> _stock = [];
  bool _loading = true;
  // Paging
  int _rowsPerPage = 25; // 10,25,50,100
  int _page = 0;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    try {
      final stores = await DatabaseService.getWarehouses();
      _warehouse = stores.firstWhere((s) => s.id == widget.warehouseId, orElse: () => stores.isNotEmpty ? stores.first : Store(name: '', address: '', phone: ''));
      if (_warehouse?.managerId != null) {
        final emps = await DatabaseService.getEmployees(active: true);
        final m = emps.firstWhere((e) => e.id == _warehouse!.managerId, orElse: () => Employee(id: -1, name: '', email: '', phone: '', username: '', passwordHash: '', pin: '', role: '', assignedStoreIds: '[]', active: true, createdAt: DateTime.now()));
        _managerName = m.id != -1 ? m.name : null;
      }
      _stock = await DatabaseService.getStoreStock(widget.warehouseId);
    } catch (e) {
      // keep nulls; show not found UI
    }
    if (mounted) setState(() => _loading = false);
  }

  @override
  Widget build(BuildContext context) {
    return BackOfficeLayout(
      title: 'Warehouse Detail',
      currentRoute: '/backoffice/warehouse-detail',
      child: _loading
          ? _buildSkeleton()
          : (_warehouse == null || (_warehouse!.id != widget.warehouseId))
              ? _buildNotFound(context)
              : _buildContent(context),
    );
  }

  Widget _buildSkeleton() {
    return const Padding(
      padding: EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _GreySkeleton(width: 200, height: 24),
          SizedBox(height: 12),
          _GreySkeleton(width: double.infinity, height: 120),
          SizedBox(height: 12),
          _GreySkeleton(width: double.infinity, height: 300),
        ],
      ),
    );
  }

  Widget _buildNotFound(BuildContext context) {
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Text('Warehouse not found', style: TextStyle(fontSize: 18, color: Colors.grey)),
          const SizedBox(height: 12),
          OutlinedButton.icon(
            onPressed: () => Navigator.pushReplacementNamed(context, '/backoffice/warehouse-manager'),
            icon: const Icon(Icons.arrow_back),
            label: const Text('Back to Warehouses'),
          ),
        ],
      ),
    );
  }

  Widget _buildContent(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        // Header with back and title
        Row(
          children: [
            OutlinedButton(
              onPressed: () => Navigator.pushReplacementNamed(context, '/backoffice/warehouse-manager'),
              style: OutlinedButton.styleFrom(minimumSize: const Size(40, 40)),
              child: const Icon(Icons.arrow_back),
            ),
            const SizedBox(width: 12),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(_warehouse?.name ?? '', style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
                const SizedBox(height: 4),
                const Text('Details and inventory for this location', style: TextStyle(color: Colors.grey)),
              ],
            ),
          ],
        ),
        const SizedBox(height: 12),

        // Info card
        Card(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Wrap(
              spacing: 24,
              runSpacing: 12,
              children: [
                _infoRow(Icons.place, _warehouse?.address ?? ''),
                _infoRow(Icons.phone, _warehouse?.phone ?? ''),
                if (_managerName != null && _managerName!.isNotEmpty) _infoRow(Icons.person, _managerName!),
                if (_warehouse?.capacity != null) _infoRow(Icons.inventory_2, 'Capacity: ${_warehouse!.capacity}'),
              ],
            ),
          ),
        ),

        const SizedBox(height: 12),

        // Inventory table
        Expanded(
          child: Card(
            child: Padding(
              padding: const EdgeInsets.all(8.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  const Padding(
                    padding: EdgeInsets.symmetric(vertical: 8.0, horizontal: 4),
                    child: Text('Inventory at this location', style: TextStyle(fontWeight: FontWeight.w600)),
                  ),
                  const Divider(height: 1),
                  Expanded(
                    child: _stock.isEmpty
                        ? const Center(child: Text('No inventory records found for this warehouse.', style: TextStyle(color: Colors.grey)))
                        : Column(
                            children: [
                              Expanded(
                                child: Builder(builder: (context) {
                                  final total = _stock.length;
                                  final start = (_page * _rowsPerPage).clamp(0, total);
                                  final end = (start + _rowsPerPage).clamp(0, total);
                                  final rows = _stock.sublist(start, end);
                                  return ListView.builder(
                                    itemCount: rows.length,
                                    itemBuilder: (context, index) {
                                      final it = rows[index];
                              final qty = (it['ss_stock_quantity'] as int?) ?? 0;
                              final min = (it['ss_min_stock_level'] as int?) ?? 5;
                              final status = qty == 0
                                  ? ('Out of Stock', Colors.red)
                                  : (qty <= min ? ('Low Stock', Colors.orange) : ('In Stock', Colors.green));
                              return Container(
                                padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 8),
                                decoration: BoxDecoration(border: Border(bottom: BorderSide(color: Colors.grey.shade200))),
                                child: Row(
                                  children: [
                                    Expanded(flex: 3, child: Text(it['name'] ?? '', overflow: TextOverflow.ellipsis)),
                                    Expanded(flex: 2, child: Text(it['sku'] ?? '', style: const TextStyle(fontFamily: 'monospace'))),
                                    Expanded(flex: 1, child: Text('$qty')),
                                    Expanded(
                                      flex: 2,
                                      child: Align(
                                        alignment: Alignment.centerLeft,
                                        child: _badge(status.$1, status.$2),
                                      ),
                                    ),
                                  ],
                                ),
                              );
                                    },
                                  );
                                }),
                              ),
                              Container(
                                padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 8),
                                child: Row(
                                  children: [
                                    const Text('Rows per page:'),
                                    const SizedBox(width: 8),
                                    DropdownButton<int>(
                                      value: _rowsPerPage,
                                      items: const [10, 25, 50, 100]
                                          .map((v) => DropdownMenuItem(value: v, child: Text('$v')))
                                          .toList(),
                                      onChanged: (v) => setState(() { _rowsPerPage = v ?? 25; _page = 0; }),
                                    ),
                                    const Spacer(),
                                    Builder(builder: (context) {
                                      final total = _stock.length;
                                      final start = (_page * _rowsPerPage).clamp(0, total);
                                      final end = (start + _rowsPerPage).clamp(0, total);
                                      return Text('${start + 1}-$end of $total');
                                    }),
                                    IconButton(
                                      tooltip: 'Previous page',
                                      onPressed: _page > 0 ? () => setState(() => _page -= 1) : null,
                                      icon: const Icon(Icons.chevron_left),
                                    ),
                                    IconButton(
                                      tooltip: 'Next page',
                                      onPressed: ((_page + 1) * _rowsPerPage) < _stock.length ? () => setState(() => _page += 1) : null,
                                      icon: const Icon(Icons.chevron_right),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ],
    );
  }

  Widget _infoRow(IconData icon, String text) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Icon(icon, size: 18, color: Colors.grey.shade600),
        const SizedBox(width: 8),
        Text(text, style: const TextStyle(fontSize: 14)),
      ],
    );
  }

  Widget _badge(String label, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(color: color.withOpacity(0.1), borderRadius: BorderRadius.circular(12), border: Border.all(color: color.withOpacity(0.2))),
      child: Text(label, style: TextStyle(color: color, fontWeight: FontWeight.w600)),
    );
  }
}

class _GreySkeleton extends StatelessWidget {
  final double width; final double height;
  const _GreySkeleton({required this.width, required this.height});
  @override
  Widget build(BuildContext context) {
    return Container(width: width, height: height, decoration: BoxDecoration(color: Colors.grey.shade200, borderRadius: BorderRadius.circular(6)));
  }
}
