import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../../services/database_service.dart';
import '../../models/store.dart';
import '../../models/employee.dart';
import '../../widgets/back_office_layout.dart';
import '../../utils/responsive_utils.dart';

class SalesByPaymentScreen extends StatefulWidget {
  const SalesByPaymentScreen({super.key});

  @override
  State<SalesByPaymentScreen> createState() => _SalesByPaymentScreenState();
}

class _SalesByPaymentScreenState extends State<SalesByPaymentScreen> {
  List<Store> _stores = [];
  List<Employee> _employees = [];
  List<Map<String, dynamic>> _paymentData = [];
  bool _isLoading = false;

  // Filters
  DateTime _startDate = DateTime.now().subtract(const Duration(days: 7));
  DateTime _endDate = DateTime.now();
  int? _selectedStoreId;
  int? _selectedEmployeeId;
  String _period = 'Last 7 Days';

  // Column visibility controls
  final Set<String> _visibleColumns = {
    'payment_type',
    'payment_transactions',
    'payment_amount',
    'refund_transactions',
    'refund_amount',
    'net_amount',
  };

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  Future<void> _loadData() async {
    setState(() => _isLoading = true);
    
    try {
      final stores = await DatabaseService.getStores();
      final employees = await DatabaseService.getEmployees();
      
      setState(() {
        _stores = stores;
        _employees = employees;
      });
      
      await _loadPaymentData();
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error loading data: $e')),
        );
      }
    } finally {
      setState(() => _isLoading = false);
    }
  }

  Future<void> _loadPaymentData() async {
    try {
      final data = await DatabaseService.getSalesByPaymentType(
        startDate: _startDate,
        endDate: _endDate,
        storeId: _selectedStoreId,
        employeeId: _selectedEmployeeId,
      );
      
      setState(() {
        _paymentData = data;
      });
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error loading payment data: $e')),
        );
      }
    }
  }

  Future<void> _selectDateRange() async {
    final picked = await showDateRangePicker(
      context: context,
      firstDate: DateTime.now().subtract(const Duration(days: 365)),
      lastDate: DateTime.now(),
      initialDateRange: DateTimeRange(start: _startDate, end: _endDate),
    );
    
    if (picked != null) {
      setState(() {
        _startDate = picked.start;
        _endDate = picked.end;
        _period = 'Custom';
      });
      _loadPaymentData();
    }
  }

  void _applyDatePreset(String preset) {
    final now = DateTime.now();
    switch (preset) {
      case 'Today':
        _startDate = DateTime(now.year, now.month, now.day);
        _endDate = now;
        break;
      case 'Yesterday':
        final yesterday = now.subtract(const Duration(days: 1));
        _startDate = DateTime(yesterday.year, yesterday.month, yesterday.day);
        _endDate = DateTime(yesterday.year, yesterday.month, yesterday.day, 23, 59, 59);
        break;
      case 'Last 7 Days':
        _startDate = now.subtract(const Duration(days: 7));
        _endDate = now;
        break;
      case 'Last 30 Days':
        _startDate = now.subtract(const Duration(days: 30));
        _endDate = now;
        break;
      case 'This Month':
        _startDate = DateTime(now.year, now.month, 1);
        _endDate = now;
        break;
    }
    
    setState(() {
      _period = preset;
    });
    _loadPaymentData();
  }

  Map<String, dynamic> _calculateTotals() {
    if (_paymentData.isEmpty) {
      return {
        'payment_transactions': 0,
        'payment_amount': 0.0,
        'refund_transactions': 0,
        'refund_amount': 0.0,
        'net_amount': 0.0,
      };
    }

    return _paymentData.fold<Map<String, dynamic>>(
      {
        'payment_transactions': 0,
        'payment_amount': 0.0,
        'refund_transactions': 0,
        'refund_amount': 0.0,
        'net_amount': 0.0,
      },
      (totals, payment) => {
        'payment_transactions': totals['payment_transactions'] + (payment['payment_transactions'] ?? 0),
        'payment_amount': totals['payment_amount'] + (payment['payment_amount'] ?? 0.0),
        'refund_transactions': totals['refund_transactions'] + (payment['refund_transactions'] ?? 0),
        'refund_amount': totals['refund_amount'] + (payment['refund_amount'] ?? 0.0),
        'net_amount': totals['net_amount'] + (payment['net_amount'] ?? 0.0),
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final totals = _calculateTotals();

    return BackOfficeLayout(
      title: 'Sales by Payment Type',
      currentRoute: '/backoffice/sales-by-payment',
      child: Column(
        children: [
          // Header and Filters
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Payment Method Analysis',
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 16),
                  
                  // Filters
                  ResponsiveUtils.isMobile(context)
                    ? _buildMobileFilters()
                    : _buildDesktopFilters(),
                ],
              ),
            ),
          ),
          
          const SizedBox(height: 16),
          
          const SizedBox(height: 16),
          
          // Payment Types Table
          Expanded(
            child: Card(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Padding(
                    padding: const EdgeInsets.all(16.0),
                    child: Row(
                      children: [
                        const Text(
                          'Payment Methods Summary',
                          style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        const Spacer(),
                        PopupMenuButton<String>(
                          child: Container(
                            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                            decoration: BoxDecoration(
                              border: Border.all(color: Colors.grey.shade300),
                              borderRadius: BorderRadius.circular(8),
                            ),
                            child: const Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Icon(Icons.view_column, size: 16),
                                SizedBox(width: 4),
                                Text('Columns'),
                                Icon(Icons.arrow_drop_down, size: 16),
                              ],
                            ),
                          ),
                          itemBuilder: (context) => [
                            _buildColumnCheckbox('payment_type', 'Payment Type'),
                            _buildColumnCheckbox('payment_transactions', 'Payment Transactions'),
                            _buildColumnCheckbox('payment_amount', 'Payment Amount'),
                            _buildColumnCheckbox('refund_transactions', 'Refund Transactions'),
                            _buildColumnCheckbox('refund_amount', 'Refund Amount'),
                            _buildColumnCheckbox('net_amount', 'Net Amount'),
                          ],
                        ),
                      ],
                    ),
                  ),
                  Expanded(
                    child: _isLoading
                      ? const Center(child: CircularProgressIndicator())
                      : _paymentData.isEmpty
                        ? const Center(
                            child: Text(
                              'No payment data found for the selected period',
                              style: TextStyle(fontSize: 16, color: Colors.grey),
                            ),
                          )
                        : SingleChildScrollView(
                            scrollDirection: Axis.horizontal,
                            child: SingleChildScrollView(
                              child: Padding(
                                padding: const EdgeInsets.all(16.0),
                                child: _buildDataTable(totals),
                              ),
                            ),
                          ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildMobileFilters() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Date Period Selector
        DropdownButtonFormField<String>(
          value: _period,
          decoration: const InputDecoration(
            labelText: 'Period',
            border: OutlineInputBorder(),
          ),
          items: ['Today', 'Yesterday', 'Last 7 Days', 'Last 30 Days', 'This Month', 'Custom']
              .map((period) => DropdownMenuItem(value: period, child: Text(period)))
              .toList(),
          onChanged: (value) {
            if (value == 'Custom') {
              _selectDateRange();
            } else if (value != null) {
              _applyDatePreset(value);
            }
          },
        ),
        
        const SizedBox(height: 16),
        
        // Store Filter
        DropdownButtonFormField<int?>(
          value: _selectedStoreId,
          decoration: const InputDecoration(
            labelText: 'Store',
            border: OutlineInputBorder(),
          ),
          items: [
            const DropdownMenuItem<int?>(value: null, child: Text('All Stores')),
            ..._stores.map((store) => DropdownMenuItem<int?>(
              value: store.id,
              child: Text(store.name),
            )),
          ],
          onChanged: (value) {
            setState(() => _selectedStoreId = value);
            _loadPaymentData();
          },
        ),
        
        const SizedBox(height: 16),
        
        // Employee Filter
        DropdownButtonFormField<int?>(
          value: _selectedEmployeeId,
          decoration: const InputDecoration(
            labelText: 'Employee',
            border: OutlineInputBorder(),
          ),
          items: [
            const DropdownMenuItem<int?>(value: null, child: Text('All Employees')),
            ..._employees.map((employee) => DropdownMenuItem<int?>(
              value: employee.id,
              child: Text(employee.name),
            )),
          ],
          onChanged: (value) {
            setState(() => _selectedEmployeeId = value);
            _loadPaymentData();
          },
        ),
      ],
    );
  }

  Widget _buildDesktopFilters() {
    return Row(
      children: [
        // Date Period Selector
        Expanded(
          flex: 2,
          child: DropdownButtonFormField<String>(
            value: _period,
            decoration: const InputDecoration(
              labelText: 'Period',
              border: OutlineInputBorder(),
            ),
            items: ['Today', 'Yesterday', 'Last 7 Days', 'Last 30 Days', 'This Month', 'Custom']
                .map((period) => DropdownMenuItem(value: period, child: Text(period)))
                .toList(),
            onChanged: (value) {
              if (value == 'Custom') {
                _selectDateRange();
              } else if (value != null) {
                _applyDatePreset(value);
              }
            },
          ),
        ),
        
        const SizedBox(width: 16),
        
        // Store Filter
        Expanded(
          flex: 2,
          child: DropdownButtonFormField<int?>(
            value: _selectedStoreId,
            decoration: const InputDecoration(
              labelText: 'Store',
              border: OutlineInputBorder(),
            ),
            items: [
              const DropdownMenuItem<int?>(value: null, child: Text('All Stores')),
              ..._stores.map((store) => DropdownMenuItem<int?>(
                value: store.id,
                child: Text(store.name),
              )),
            ],
            onChanged: (value) {
              setState(() => _selectedStoreId = value);
              _loadPaymentData();
            },
          ),
        ),
        
        const SizedBox(width: 16),
        
        // Employee Filter
        Expanded(
          flex: 2,
          child: DropdownButtonFormField<int?>(
            value: _selectedEmployeeId,
            decoration: const InputDecoration(
              labelText: 'Employee',
              border: OutlineInputBorder(),
            ),
            items: [
              const DropdownMenuItem<int?>(value: null, child: Text('All Employees')),
              ..._employees.map((employee) => DropdownMenuItem<int?>(
                value: employee.id,
                child: Text(employee.name),
              )),
            ],
            onChanged: (value) {
              setState(() => _selectedEmployeeId = value);
              _loadPaymentData();
            },
          ),
        ),
        
        const SizedBox(width: 16),
        
        // Custom Date Range Button
        ElevatedButton.icon(
          onPressed: _selectDateRange,
          icon: const Icon(Icons.date_range),
          label: Text('${DateFormat('MMM d').format(_startDate)} - ${DateFormat('MMM d').format(_endDate)}'),
        ),
      ],
    );
  }

  PopupMenuItem<String> _buildColumnCheckbox(String key, String label) {
    return PopupMenuItem<String>(
      enabled: false,
      child: StatefulBuilder(
        builder: (context, setState) {
          return CheckboxListTile(
            title: Text(label),
            value: _visibleColumns.contains(key),
            onChanged: (value) {
              setState(() {
                if (value == true) {
                  _visibleColumns.add(key);
                } else {
                  _visibleColumns.remove(key);
                }
              });
              // Update the main widget state
              this.setState(() {});
            },
            dense: true,
            controlAffinity: ListTileControlAffinity.leading,
          );
        },
      ),
    );
  }

  Widget _buildDataTable(Map<String, dynamic> totals) {
    final columns = <DataColumn>[];
    final cellBuilders = <String, Widget Function(Map<String, dynamic>)>{};
    
    if (_visibleColumns.contains('payment_type')) {
      columns.add(const DataColumn(label: Text('Payment Type', style: TextStyle(fontWeight: FontWeight.bold))));
      cellBuilders['payment_type'] = (item) => Text(item['payment_type'] ?? 'Unknown', style: const TextStyle(fontWeight: FontWeight.w500));
    }
    
    if (_visibleColumns.contains('payment_transactions')) {
      columns.add(const DataColumn(label: Text('Payment Transactions', style: TextStyle(fontWeight: FontWeight.bold)), numeric: true));
      cellBuilders['payment_transactions'] = (item) => Text('${item['payment_transactions'] ?? 0}');
    }
    
    if (_visibleColumns.contains('payment_amount')) {
      columns.add(const DataColumn(label: Text('Payment Amount', style: TextStyle(fontWeight: FontWeight.bold)), numeric: true));
      cellBuilders['payment_amount'] = (item) => Text('\$${(item['payment_amount'] ?? 0.0).toStringAsFixed(2)}', style: const TextStyle(fontWeight: FontWeight.w500));
    }
    
    if (_visibleColumns.contains('refund_transactions')) {
      columns.add(const DataColumn(label: Text('Refund Transactions', style: TextStyle(fontWeight: FontWeight.bold)), numeric: true));
      cellBuilders['refund_transactions'] = (item) => Text('${item['refund_transactions'] ?? 0}', style: const TextStyle(color: Colors.red));
    }
    
    if (_visibleColumns.contains('refund_amount')) {
      columns.add(const DataColumn(label: Text('Refund Amount', style: TextStyle(fontWeight: FontWeight.bold)), numeric: true));
      cellBuilders['refund_amount'] = (item) => Text('\$${(item['refund_amount'] ?? 0.0).toStringAsFixed(2)}', style: const TextStyle(color: Colors.red));
    }
    
    if (_visibleColumns.contains('net_amount')) {
      columns.add(const DataColumn(label: Text('Net Amount', style: TextStyle(fontWeight: FontWeight.bold)), numeric: true));
      cellBuilders['net_amount'] = (item) => Text('\$${(item['net_amount'] ?? 0.0).toStringAsFixed(2)}', style: const TextStyle(fontWeight: FontWeight.bold, color: Colors.green));
    }

    return DataTable(
      columns: columns,
      rows: [
        ..._paymentData.map((payment) => DataRow(
          cells: _visibleColumns.map((key) => DataCell(cellBuilders[key]!(payment))).toList(),
        )),
        
        // Totals Row
        DataRow(
          color: MaterialStateProperty.all(Colors.grey.shade100),
          cells: _visibleColumns.map((key) {
            switch (key) {
              case 'payment_type':
                return const DataCell(Text('Total', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)));
              case 'payment_transactions':
                return DataCell(Text('${totals['payment_transactions']}', style: const TextStyle(fontWeight: FontWeight.bold)));
              case 'payment_amount':
                return DataCell(Text('\$${totals['payment_amount'].toStringAsFixed(2)}', style: const TextStyle(fontWeight: FontWeight.bold)));
              case 'refund_transactions':
                return DataCell(Text('${totals['refund_transactions']}', style: const TextStyle(fontWeight: FontWeight.bold, color: Colors.red)));
              case 'refund_amount':
                return DataCell(Text('\$${totals['refund_amount'].toStringAsFixed(2)}', style: const TextStyle(fontWeight: FontWeight.bold, color: Colors.red)));
              case 'net_amount':
                return DataCell(Text('\$${totals['net_amount'].toStringAsFixed(2)}', style: const TextStyle(fontWeight: FontWeight.bold, color: Colors.green)));
              default:
                return const DataCell(Text(''));
            }
          }).toList(),
        ),
      ],
    );
  }
}