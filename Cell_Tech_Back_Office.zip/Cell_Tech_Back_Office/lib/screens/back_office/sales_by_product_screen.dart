import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:fl_chart/fl_chart.dart';
import '../../services/database_service.dart';
import '../../models/store.dart';
import '../../models/employee.dart';
import '../../widgets/back_office_layout.dart';
import '../../utils/responsive_utils.dart';

class SalesByProductScreen extends StatefulWidget {
  const SalesByProductScreen({super.key});

  @override
  State<SalesByProductScreen> createState() => _SalesByProductScreenState();
}

class _SalesByProductScreenState extends State<SalesByProductScreen> {
  List<Store> _stores = [];
  List<Employee> _employees = [];
  List<Map<String, dynamic>> _productData = [];
  List<Map<String, dynamic>> _topProducts = [];
  bool _isLoading = false;

  // Filters
  DateTime _startDate = DateTime.now().subtract(const Duration(days: 7));
  DateTime _endDate = DateTime.now();
  int? _selectedStoreId;
  int? _selectedEmployeeId;
  String _period = 'Last 7 Days';

  // Chart controls
  String _chartType = 'pie';
  
  // Column visibility state
  Set<String> _visibleColumns = {
    'product_name',
    'category',
    'quantity_sold',
    'gross_sales',
    'net_sales',
    'cost_of_goods',
    'gross_profit',
    'profit_margin'
  };

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  Future<void> _loadData() async {
    setState(() => _isLoading = true);
    
    try {
      final stores = await DatabaseService.getStores();
      final employees = await DatabaseService.getEmployees();
      
      setState(() {
        _stores = stores;
        _employees = employees;
      });
      
      await _loadProductData();
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error loading data: $e')),
        );
      }
    } finally {
      setState(() => _isLoading = false);
    }
  }

  Future<void> _loadProductData() async {
    try {
      final data = await DatabaseService.getSalesByProduct(
        startDate: _startDate,
        endDate: _endDate,
        storeId: _selectedStoreId,
        employeeId: _selectedEmployeeId,
      );
      
      setState(() {
        _productData = data.map((item) {
          final netSales = item['net_sales'] ?? 0.0;
          final grossProfit = item['gross_profit'] ?? 0.0;
          final margin = netSales > 0 ? (grossProfit / netSales * 100) : 0.0;
          
          return {
            ...item,
            'margin': margin,
          };
        }).toList();
        
        // Get top 5 products for charts
        _topProducts = _productData.take(5).toList();
      });
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error loading product data: $e')),
        );
      }
    }
  }

  Future<void> _selectDateRange() async {
    final picked = await showDateRangePicker(
      context: context,
      firstDate: DateTime.now().subtract(const Duration(days: 365)),
      lastDate: DateTime.now(),
      initialDateRange: DateTimeRange(start: _startDate, end: _endDate),
    );
    
    if (picked != null) {
      setState(() {
        _startDate = picked.start;
        _endDate = picked.end;
        _period = 'Custom';
      });
      _loadProductData();
    }
  }

  void _applyDatePreset(String preset) {
    final now = DateTime.now();
    switch (preset) {
      case 'Today':
        _startDate = DateTime(now.year, now.month, now.day);
        _endDate = now;
        break;
      case 'Yesterday':
        final yesterday = now.subtract(const Duration(days: 1));
        _startDate = DateTime(yesterday.year, yesterday.month, yesterday.day);
        _endDate = DateTime(yesterday.year, yesterday.month, yesterday.day, 23, 59, 59);
        break;
      case 'Last 7 Days':
        _startDate = now.subtract(const Duration(days: 7));
        _endDate = now;
        break;
      case 'Last 30 Days':
        _startDate = now.subtract(const Duration(days: 30));
        _endDate = now;
        break;
      case 'This Month':
        _startDate = DateTime(now.year, now.month, 1);
        _endDate = now;
        break;
    }
    
    setState(() {
      _period = preset;
    });
    _loadProductData();
  }

  Map<String, dynamic> _calculateTotals() {
    if (_productData.isEmpty) {
      return {
        'products_sold': 0,
        'gross_sales': 0.0,
        'products_refunded': 0,
        'refunds': 0.0,
        'discounts': 0.0,
        'net_sales': 0.0,
        'cost_of_goods': 0.0,
        'gross_profit': 0.0,
      };
    }

    return _productData.fold<Map<String, dynamic>>(
      {
        'products_sold': 0,
        'gross_sales': 0.0,
        'products_refunded': 0,
        'refunds': 0.0,
        'discounts': 0.0,
        'net_sales': 0.0,
        'cost_of_goods': 0.0,
        'gross_profit': 0.0,
      },
      (totals, product) => {
        'products_sold': totals['products_sold'] + (product['products_sold'] ?? 0),
        'gross_sales': totals['gross_sales'] + (product['gross_sales'] ?? 0.0),
        'products_refunded': totals['products_refunded'] + (product['products_refunded'] ?? 0),
        'refunds': totals['refunds'] + (product['refunds'] ?? 0.0),
        'discounts': totals['discounts'] + (product['discounts'] ?? 0.0),
        'net_sales': totals['net_sales'] + (product['net_sales'] ?? 0.0),
        'cost_of_goods': totals['cost_of_goods'] + (product['cost_of_goods'] ?? 0.0),
        'gross_profit': totals['gross_profit'] + (product['gross_profit'] ?? 0.0),
      },
    );
  }

  double _calculateOverallMargin(Map<String, dynamic> totals) {
    if (totals['net_sales'] == 0.0) return 0.0;
    return totals['gross_profit'] / totals['net_sales'] * 100;
  }

  @override
  Widget build(BuildContext context) {
    final totals = _calculateTotals();
    final overallMargin = _calculateOverallMargin(totals);

    return BackOfficeLayout(
      title: 'Sales by Product',
      currentRoute: '/backoffice/sales-by-product',
      child: Column(
        children: [
          // Header and Filters
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Product Performance and Sales Analysis',
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 16),
                  
                  // Filters
                  ResponsiveUtils.isMobile(context)
                    ? _buildMobileFilters()
                    : _buildDesktopFilters(),
                ],
              ),
            ),
          ),
          
          const SizedBox(height: 16),
          
          // Top Products and Chart
          if (!ResponsiveUtils.isMobile(context))
            SizedBox(
              height: 400,
              child: Row(
                children: [
                  // Top 5 Products
                  Expanded(
                    child: Card(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Padding(
                            padding: EdgeInsets.all(16.0),
                            child: Row(
                              children: [
                                Icon(Icons.inventory_2, color: Colors.blue),
                                SizedBox(width: 8),
                                Text(
                                  'Top 5 Products by Net Sales',
                                  style: TextStyle(
                                    fontSize: 16,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Expanded(
                            child: _isLoading
                              ? const Center(child: CircularProgressIndicator())
                              : _topProducts.isEmpty
                                ? const Center(child: Text('No data available'))
                                : ListView.builder(
                                    padding: const EdgeInsets.symmetric(horizontal: 16.0),
                                    itemCount: _topProducts.length,
                                    itemBuilder: (context, index) {
                                      final product = _topProducts[index];
                                      return Card(
                                        margin: const EdgeInsets.only(bottom: 8.0),
                                        color: Colors.grey.shade50,
                                        child: ListTile(
                                          title: Text(
                                            product['product'] ?? 'Unknown',
                                            style: const TextStyle(fontWeight: FontWeight.w500),
                                          ),
                                          subtitle: Text(product['category'] ?? 'Uncategorized'),
                                          trailing: Column(
                                            mainAxisAlignment: MainAxisAlignment.center,
                                            crossAxisAlignment: CrossAxisAlignment.end,
                                            children: [
                                              Text(
                                                '\$${(product['net_sales'] ?? 0.0).toStringAsFixed(2)}',
                                                style: const TextStyle(
                                                  fontWeight: FontWeight.bold,
                                                  fontSize: 16,
                                                ),
                                              ),
                                              Text(
                                                '${product['products_sold'] ?? 0} units',
                                                style: TextStyle(
                                                  color: Colors.grey.shade600,
                                                  fontSize: 12,
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      );
                                    },
                                  ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  
                  const SizedBox(width: 16),
                  
                  // Chart
                  Expanded(
                    child: Card(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Padding(
                            padding: const EdgeInsets.all(16.0),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                const Row(
                                  children: [
                                    Icon(Icons.bar_chart, color: Colors.blue),
                                    SizedBox(width: 8),
                                    Text(
                                      'Sales by Product Chart',
                                      style: TextStyle(
                                        fontSize: 16,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                  ],
                                ),
                                DropdownButton<String>(
                                  value: _chartType,
                                  items: const [
                                    DropdownMenuItem(value: 'pie', child: Text('Pie')),
                                    DropdownMenuItem(value: 'bar', child: Text('Bar')),
                                  ],
                                  onChanged: (value) {
                                    if (value != null) {
                                      setState(() => _chartType = value);
                                    }
                                  },
                                ),
                              ],
                            ),
                          ),
                          Expanded(
                            child: Padding(
                              padding: const EdgeInsets.all(16.0),
                              child: _buildChart(),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          
          if (!ResponsiveUtils.isMobile(context)) const SizedBox(height: 16),
          
          // Column Visibility Controls
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Column Visibility',
                    style: TextStyle(fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 8),
                  Wrap(
                    spacing: 8,
                    children: [
                      _buildColumnToggle('product', 'Product'),
                      _buildColumnToggle('sku', 'SKU'),
                      _buildColumnToggle('category', 'Category'),
                      _buildColumnToggle('products_sold', 'Products Sold'),
                      _buildColumnToggle('gross_sales', 'Gross Sales'),
                      _buildColumnToggle('products_refunded', 'Products Refunded'),
                      _buildColumnToggle('refunds', 'Refunds'),
                      _buildColumnToggle('discounts', 'Discounts'),
                      _buildColumnToggle('net_sales', 'Net Sales'),
                      _buildColumnToggle('cost_of_goods', 'Cost of Goods'),
                      _buildColumnToggle('gross_profit', 'Gross Profit'),
                      _buildColumnToggle('margin', 'Margin'),
                    ],
                  ),
                ],
              ),
            ),
          ),
          
          const SizedBox(height: 16),
          
          // Products Performance Table
          Expanded(
            child: Card(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Padding(
                    padding: const EdgeInsets.all(16.0),
                    child: Row(
                      children: [
                        const Text(
                          'Products Performance',
                          style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        const Spacer(),
                        PopupMenuButton<String>(
                          child: Container(
                            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                            decoration: BoxDecoration(
                              border: Border.all(color: Colors.grey.shade300),
                              borderRadius: BorderRadius.circular(8),
                            ),
                            child: const Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Icon(Icons.view_column, size: 16),
                                SizedBox(width: 4),
                                Text('Columns'),
                                Icon(Icons.arrow_drop_down, size: 16),
                              ],
                            ),
                          ),
                          itemBuilder: (context) => [
                            _buildColumnCheckbox('product_name', 'Product Name'),
                            _buildColumnCheckbox('category', 'Category'),
                            _buildColumnCheckbox('quantity_sold', 'Quantity Sold'),
                            _buildColumnCheckbox('gross_sales', 'Gross Sales'),
                            _buildColumnCheckbox('net_sales', 'Net Sales'),
                            _buildColumnCheckbox('cost_of_goods', 'Cost of Goods'),
                            _buildColumnCheckbox('gross_profit', 'Gross Profit'),
                            _buildColumnCheckbox('profit_margin', 'Profit Margin'),
                          ],
                        ),
                      ],
                    ),
                  ),
                  Expanded(
                    child: _isLoading
                      ? const Center(child: CircularProgressIndicator())
                      : _productData.isEmpty
                        ? const Center(
                            child: Text(
                              'No product sales data found for the selected period',
                              style: TextStyle(fontSize: 16, color: Colors.grey),
                            ),
                          )
                        : SingleChildScrollView(
                            scrollDirection: Axis.horizontal,
                            child: SingleChildScrollView(
                              child: Padding(
                                padding: const EdgeInsets.all(16.0),
                                child: _buildDataTable(totals, overallMargin),
                              ),
                            ),
                          ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildChart() {
    if (_topProducts.isEmpty) {
      return const Center(child: Text('No data to display'));
    }

    if (_chartType == 'pie') {
      return PieChart(
        PieChartData(
          sections: _topProducts.asMap().entries.map((entry) {
            final index = entry.key;
            final product = entry.value;
            final colors = [
              Colors.blue,
              Colors.red,
              Colors.green,
              Colors.orange,
              Colors.purple,
            ];
            
            return PieChartSectionData(
              value: (product['net_sales'] ?? 0.0).toDouble(),
              title: '${product['product']}\n\$${(product['net_sales'] ?? 0.0).toStringAsFixed(0)}',
              color: colors[index % colors.length],
              radius: 100,
              titleStyle: const TextStyle(
                fontSize: 12,
                fontWeight: FontWeight.bold,
                color: Colors.white,
              ),
            );
          }).toList(),
          sectionsSpace: 2,
          centerSpaceRadius: 40,
        ),
      );
    } else {
      return BarChart(
        BarChartData(
          alignment: BarChartAlignment.spaceAround,
          maxY: _topProducts.isNotEmpty ? (_topProducts.first['net_sales'] ?? 0.0) * 1.2 : 100,
          barTouchData: BarTouchData(enabled: true),
          titlesData: FlTitlesData(
            show: true,
            rightTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
            topTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
            bottomTitles: AxisTitles(
              sideTitles: SideTitles(
                showTitles: true,
                getTitlesWidget: (value, meta) {
                  final index = value.toInt();
                  if (index >= 0 && index < _topProducts.length) {
                    final productName = _topProducts[index]['product'] ?? '';
                    return Padding(
                      padding: const EdgeInsets.only(top: 8.0),
                      child: Text(
                        productName.length > 10 ? '${productName.substring(0, 10)}...' : productName,
                        style: const TextStyle(fontSize: 12),
                      ),
                    );
                  }
                  return const Text('');
                },
              ),
            ),
            leftTitles: AxisTitles(
              sideTitles: SideTitles(
                showTitles: true,
                getTitlesWidget: (value, meta) {
                  return Text('\$${value.toInt()}', style: const TextStyle(fontSize: 12));
                },
              ),
            ),
          ),
          borderData: FlBorderData(show: false),
          barGroups: _topProducts.asMap().entries.map((entry) {
            final index = entry.key;
            final product = entry.value;
            
            return BarChartGroupData(
              x: index,
              barRods: [
                BarChartRodData(
                  toY: (product['net_sales'] ?? 0.0).toDouble(),
                  color: Colors.blue,
                  width: 20,
                  borderRadius: const BorderRadius.only(
                    topLeft: Radius.circular(4),
                    topRight: Radius.circular(4),
                  ),
                ),
              ],
            );
          }).toList(),
        ),
      );
    }
  }

  Widget _buildColumnToggle(String key, String label) {
    return FilterChip(
      label: Text(label),
      selected: _visibleColumns.contains(key),
      onSelected: (selected) {
        setState(() {
          if (selected) {
            _visibleColumns.add(key);
          } else {
            _visibleColumns.remove(key);
          }
        });
      },
    );
  }

  Widget _buildDataTable(Map<String, dynamic> totals, double overallMargin) {
    final columns = <DataColumn>[];
    final cellBuilders = <String, Widget Function(Map<String, dynamic>)>{};
    
    if (_visibleColumns.contains('product')) {
      columns.add(const DataColumn(label: Text('Product', style: TextStyle(fontWeight: FontWeight.bold))));
      cellBuilders['product'] = (item) => Text(item['product'] ?? 'Unknown');
    }
    
    if (_visibleColumns.contains('sku')) {
      columns.add(const DataColumn(label: Text('SKU', style: TextStyle(fontWeight: FontWeight.bold))));
      cellBuilders['sku'] = (item) => Text(item['sku'] ?? '', style: const TextStyle(fontFamily: 'monospace', fontSize: 12));
    }
    
    if (_visibleColumns.contains('category')) {
      columns.add(const DataColumn(label: Text('Category', style: TextStyle(fontWeight: FontWeight.bold))));
      cellBuilders['category'] = (item) => Text(item['category'] ?? 'Uncategorized');
    }
    
    if (_visibleColumns.contains('products_sold')) {
      columns.add(const DataColumn(label: Text('Products Sold', style: TextStyle(fontWeight: FontWeight.bold)), numeric: true));
      cellBuilders['products_sold'] = (item) => Text('${item['products_sold'] ?? 0}', style: const TextStyle(fontWeight: FontWeight.w500));
    }
    
    if (_visibleColumns.contains('gross_sales')) {
      columns.add(const DataColumn(label: Text('Gross Sales', style: TextStyle(fontWeight: FontWeight.bold)), numeric: true));
      cellBuilders['gross_sales'] = (item) => Text('\$${(item['gross_sales'] ?? 0.0).toStringAsFixed(2)}');
    }
    
    if (_visibleColumns.contains('products_refunded')) {
      columns.add(const DataColumn(label: Text('Products Refunded', style: TextStyle(fontWeight: FontWeight.bold)), numeric: true));
      cellBuilders['products_refunded'] = (item) => Text('${item['products_refunded'] ?? 0}');
    }
    
    if (_visibleColumns.contains('refunds')) {
      columns.add(const DataColumn(label: Text('Refunds', style: TextStyle(fontWeight: FontWeight.bold)), numeric: true));
      cellBuilders['refunds'] = (item) => Text('\$${(item['refunds'] ?? 0.0).toStringAsFixed(2)}', style: const TextStyle(color: Colors.red));
    }
    
    if (_visibleColumns.contains('discounts')) {
      columns.add(const DataColumn(label: Text('Discounts', style: TextStyle(fontWeight: FontWeight.bold)), numeric: true));
      cellBuilders['discounts'] = (item) => Text('\$${(item['discounts'] ?? 0.0).toStringAsFixed(2)}', style: const TextStyle(color: Colors.orange));
    }
    
    if (_visibleColumns.contains('net_sales')) {
      columns.add(const DataColumn(label: Text('Net Sales', style: TextStyle(fontWeight: FontWeight.bold)), numeric: true));
      cellBuilders['net_sales'] = (item) => Text('\$${(item['net_sales'] ?? 0.0).toStringAsFixed(2)}', style: const TextStyle(fontWeight: FontWeight.bold));
    }
    
    if (_visibleColumns.contains('cost_of_goods')) {
      columns.add(const DataColumn(label: Text('Cost of Goods', style: TextStyle(fontWeight: FontWeight.bold)), numeric: true));
      cellBuilders['cost_of_goods'] = (item) => Text('\$${(item['cost_of_goods'] ?? 0.0).toStringAsFixed(2)}');
    }
    
    if (_visibleColumns.contains('gross_profit')) {
      columns.add(const DataColumn(label: Text('Gross Profit', style: TextStyle(fontWeight: FontWeight.bold)), numeric: true));
      cellBuilders['gross_profit'] = (item) => Text('\$${(item['gross_profit'] ?? 0.0).toStringAsFixed(2)}', style: const TextStyle(fontWeight: FontWeight.w500, color: Colors.green));
    }
    
    if (_visibleColumns.contains('margin')) {
      columns.add(const DataColumn(label: Text('Margin', style: TextStyle(fontWeight: FontWeight.bold)), numeric: true));
      cellBuilders['margin'] = (item) => Text('${(item['margin'] ?? 0.0).toStringAsFixed(1)}%');
    }

    return DataTable(
      columns: columns,
      rows: [
        ..._productData.map((product) => DataRow(
          cells: _visibleColumns.map((key) => DataCell(cellBuilders[key]!(product))).toList(),
        )),
        
        // Totals Row
        DataRow(
          color: MaterialStateProperty.all(Colors.grey.shade100),
          cells: _visibleColumns.map((key) {
            switch (key) {
              case 'product':
                return const DataCell(Text('Total', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)));
              case 'sku':
                return const DataCell(Text(''));
              case 'category':
                return const DataCell(Text(''));
              case 'products_sold':
                return DataCell(Text('${totals['products_sold']}', style: const TextStyle(fontWeight: FontWeight.bold)));
              case 'gross_sales':
                return DataCell(Text('\$${totals['gross_sales'].toStringAsFixed(2)}', style: const TextStyle(fontWeight: FontWeight.bold)));
              case 'products_refunded':
                return DataCell(Text('${totals['products_refunded']}', style: const TextStyle(fontWeight: FontWeight.bold)));
              case 'refunds':
                return DataCell(Text('\$${totals['refunds'].toStringAsFixed(2)}', style: const TextStyle(fontWeight: FontWeight.bold, color: Colors.red)));
              case 'discounts':
                return DataCell(Text('\$${totals['discounts'].toStringAsFixed(2)}', style: const TextStyle(fontWeight: FontWeight.bold, color: Colors.orange)));
              case 'net_sales':
                return DataCell(Text('\$${totals['net_sales'].toStringAsFixed(2)}', style: const TextStyle(fontWeight: FontWeight.bold)));
              case 'cost_of_goods':
                return DataCell(Text('\$${totals['cost_of_goods'].toStringAsFixed(2)}', style: const TextStyle(fontWeight: FontWeight.bold)));
              case 'gross_profit':
                return DataCell(Text('\$${totals['gross_profit'].toStringAsFixed(2)}', style: const TextStyle(fontWeight: FontWeight.bold, color: Colors.green)));
              case 'margin':
                return DataCell(Text('${overallMargin.toStringAsFixed(1)}%', style: const TextStyle(fontWeight: FontWeight.bold)));
              default:
                return const DataCell(Text(''));
            }
          }).toList(),
        ),
      ],
    );
  }

  Widget _buildMobileFilters() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Date Period Selector
        DropdownButtonFormField<String>(
          value: _period,
          decoration: const InputDecoration(
            labelText: 'Period',
            border: OutlineInputBorder(),
          ),
          items: ['Today', 'Yesterday', 'Last 7 Days', 'Last 30 Days', 'This Month', 'Custom']
              .map((period) => DropdownMenuItem(value: period, child: Text(period)))
              .toList(),
          onChanged: (value) {
            if (value == 'Custom') {
              _selectDateRange();
            } else if (value != null) {
              _applyDatePreset(value);
            }
          },
        ),
        
        const SizedBox(height: 16),
        
        // Store Filter
        DropdownButtonFormField<int?>(
          value: _selectedStoreId,
          decoration: const InputDecoration(
            labelText: 'Store',
            border: OutlineInputBorder(),
          ),
          items: [
            const DropdownMenuItem<int?>(value: null, child: Text('All Stores')),
            ..._stores.map((store) => DropdownMenuItem<int?>(
              value: store.id,
              child: Text(store.name),
            )),
          ],
          onChanged: (value) {
            setState(() => _selectedStoreId = value);
            _loadProductData();
          },
        ),
        
        const SizedBox(height: 16),
        
        // Employee Filter
        DropdownButtonFormField<int?>(
          value: _selectedEmployeeId,
          decoration: const InputDecoration(
            labelText: 'Employee',
            border: OutlineInputBorder(),
          ),
          items: [
            const DropdownMenuItem<int?>(value: null, child: Text('All Employees')),
            ..._employees.map((employee) => DropdownMenuItem<int?>(
              value: employee.id,
              child: Text(employee.name),
            )),
          ],
          onChanged: (value) {
            setState(() => _selectedEmployeeId = value);
            _loadProductData();
          },
        ),
        
        const SizedBox(height: 16),
        
        // Column Visibility Controls
        PopupMenuButton<String>(
          child: const Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(Icons.view_column),
              SizedBox(width: 8),
              Text('Column Visibility'),
              Icon(Icons.arrow_drop_down),
            ],
          ),
          itemBuilder: (context) => [
            _buildColumnCheckbox('product_name', 'Product Name'),
            _buildColumnCheckbox('category', 'Category'),
            _buildColumnCheckbox('quantity_sold', 'Quantity Sold'),
            _buildColumnCheckbox('gross_sales', 'Gross Sales'),
            _buildColumnCheckbox('net_sales', 'Net Sales'),
            _buildColumnCheckbox('cost_of_goods', 'Cost of Goods'),
            _buildColumnCheckbox('gross_profit', 'Gross Profit'),
            _buildColumnCheckbox('profit_margin', 'Profit Margin'),
          ],
        ),
      ],
    );
  }

  Widget _buildDesktopFilters() {
    return Row(
      children: [
        // Date Period Selector
        Expanded(
          flex: 2,
          child: DropdownButtonFormField<String>(
            value: _period,
            decoration: const InputDecoration(
              labelText: 'Period',
              border: OutlineInputBorder(),
            ),
            items: ['Today', 'Yesterday', 'Last 7 Days', 'Last 30 Days', 'This Month', 'Custom']
                .map((period) => DropdownMenuItem(value: period, child: Text(period)))
                .toList(),
            onChanged: (value) {
              if (value == 'Custom') {
                _selectDateRange();
              } else if (value != null) {
                _applyDatePreset(value);
              }
            },
          ),
        ),
        
        const SizedBox(width: 16),
        
        // Store Filter
        Expanded(
          flex: 2,
          child: DropdownButtonFormField<int?>(
            value: _selectedStoreId,
            decoration: const InputDecoration(
              labelText: 'Store',
              border: OutlineInputBorder(),
            ),
            items: [
              const DropdownMenuItem<int?>(value: null, child: Text('All Stores')),
              ..._stores.map((store) => DropdownMenuItem<int?>(
                value: store.id,
                child: Text(store.name),
              )),
            ],
            onChanged: (value) {
              setState(() => _selectedStoreId = value);
              _loadProductData();
            },
          ),
        ),
        
        const SizedBox(width: 16),
        
        // Employee Filter
        Expanded(
          flex: 2,
          child: DropdownButtonFormField<int?>(
            value: _selectedEmployeeId,
            decoration: const InputDecoration(
              labelText: 'Employee',
              border: OutlineInputBorder(),
            ),
            items: [
              const DropdownMenuItem<int?>(value: null, child: Text('All Employees')),
              ..._employees.map((employee) => DropdownMenuItem<int?>(
                value: employee.id,
                child: Text(employee.name),
              )),
            ],
            onChanged: (value) {
              setState(() => _selectedEmployeeId = value);
              _loadProductData();
            },
          ),
        ),
        
        const SizedBox(width: 16),
        
        // Custom Date Range Button
        ElevatedButton.icon(
          onPressed: _selectDateRange,
          icon: const Icon(Icons.date_range),
          label: Text('${DateFormat('MMM d').format(_startDate)} - ${DateFormat('MMM d').format(_endDate)}'),
        ),
        
        const SizedBox(width: 16),
        
        // Column Visibility Controls
        PopupMenuButton<String>(
          child: const Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(Icons.view_column),
              SizedBox(width: 8),
              Text('Columns'),
              Icon(Icons.arrow_drop_down),
            ],
          ),
          itemBuilder: (context) => [
            _buildColumnCheckbox('product_name', 'Product Name'),
            _buildColumnCheckbox('category', 'Category'),
            _buildColumnCheckbox('quantity_sold', 'Quantity Sold'),
            _buildColumnCheckbox('gross_sales', 'Gross Sales'),
            _buildColumnCheckbox('net_sales', 'Net Sales'),
            _buildColumnCheckbox('cost_of_goods', 'Cost of Goods'),
            _buildColumnCheckbox('gross_profit', 'Gross Profit'),
            _buildColumnCheckbox('profit_margin', 'Profit Margin'),
          ],
        ),
      ],
    );
  }

  PopupMenuItem<String> _buildColumnCheckbox(String key, String label) {
    return PopupMenuItem<String>(
      enabled: false,
      child: StatefulBuilder(
        builder: (context, setState) {
          return CheckboxListTile(
            title: Text(label),
            value: _visibleColumns.contains(key),
            onChanged: (value) {
              setState(() {
                if (value == true) {
                  _visibleColumns.add(key);
                } else {
                  _visibleColumns.remove(key);
                }
              });
              // Update the main widget state
              this.setState(() {});
            },
            dense: true,
            controlAffinity: ListTileControlAffinity.leading,
          );
        },
      ),
    );
  }
}