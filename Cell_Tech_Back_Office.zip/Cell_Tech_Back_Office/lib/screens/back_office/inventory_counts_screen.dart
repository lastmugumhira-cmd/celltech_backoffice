import 'package:flutter/material.dart';
import '../../services/database_service.dart';
import '../../services/pdf_service.dart';
import '../../widgets/back_office_layout.dart';
import '../../widgets/components/inventory_count_form.dart';

class InventoryCountsScreen extends StatefulWidget {
  const InventoryCountsScreen({super.key});

  @override
  State<InventoryCountsScreen> createState() => _InventoryCountsScreenState();
}

class _InventoryCountsScreenState extends State<InventoryCountsScreen> {
  List<Map<String, dynamic>> _counts = [];
  bool _loading = true;
  String _search = '';
  int? _downloadingId;
  

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    try {
        final counts = await DatabaseService.getInventoryCounts();
        counts.sort((a, b) => DateTime.parse(b['started_at']).compareTo(DateTime.parse(a['started_at'])));
      setState(() {
        _counts = counts;
        _loading = false;
      });
    } catch (e) {
      setState(() => _loading = false);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error loading counts: $e')),
        );
      }
    }
  }

  List<Map<String, dynamic>> get _filteredCounts {
    final q = _search.trim().toLowerCase();
    if (q.isEmpty) return _counts;
    return _counts.where((c) {
      final num = (c['adjustment_number'] ?? '').toString().toLowerCase();
      final notes = (c['notes'] ?? '').toString().toLowerCase();
      final storeName = (c['store_name'] ?? '').toString().toLowerCase();
      return num.contains(q) || notes.contains(q) || storeName.contains(q);
    }).toList();
  }

  Color _statusColor(String s) {
    switch (s) {
      case 'pending':
        return Colors.grey;
      case 'in_progress':
        return Colors.blue;
      case 'completed':
        return Colors.green;
      case 'cancelled':
        return Colors.red;
      default:
        return Colors.grey;
    }
  }

  Future<void> _downloadPdf(Map<String, dynamic> count) async {
    setState(() => _downloadingId = count['id'] as int?);
     setState(() => _downloadingId = count['id'] as int?);
    try {
      final data = await PdfService.generateInventoryCountPdf(count);
      await PdfService.downloadPdf(data, 'inventory_count_${count['count_number']}.pdf');
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('PDF error: $e')),
        );
      }
    } finally {
      if (mounted) setState(() => _downloadingId = null);
    }
  }

  void _openForm({Map<String, dynamic>? existing}) async {
    final saved = await showDialog<bool>(
      context: context,
      barrierDismissible: false,
      builder: (_) => InventoryCountForm(
        existingCount: existing,
        onSuccess: () => Navigator.pop(context, true),
        onCancel: () => Navigator.pop(context, false),
      ),
    );
    if (saved == true) _load();
  }

  @override
  Widget build(BuildContext context) {
    return BackOfficeLayout(
      title: 'Inventory Counts',
      currentRoute: '/backoffice/inventory/counts',
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: _loading
            ? const Center(child: CircularProgressIndicator())
            : Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Row(
                    children: [
                      Expanded(
                        child: TextField(
                          decoration: const InputDecoration(
                            prefixIcon: Icon(Icons.search),
                            hintText: 'Search counts by number, notes, or store...',
                            border: OutlineInputBorder(),
                          ),
                          onChanged: (v) => setState(() => _search = v),
                        ),
                      ),
                      const SizedBox(width: 12),
                      ElevatedButton.icon(
                        onPressed: () => _openForm(),
                        icon: const Icon(Icons.playlist_add),
                        label: const Text('Start New Count'),
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),
                  Expanded(
                    child: _filteredCounts.isEmpty
                        ? _buildEmpty()
                        : _buildTable(_filteredCounts),
                  ),
                ],
              ),
      ),
    );
  }

  Widget _buildEmpty() {
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Icon(Icons.inventory_2, size: 48, color: Colors.grey),
          const SizedBox(height: 8),
          const Text('No inventory counts yet'),
          const SizedBox(height: 8),
          ElevatedButton.icon(
            onPressed: () => _openForm(),
            icon: const Icon(Icons.playlist_add),
            label: const Text('Start New Count'),
          ),
        ],
      ),
    );
  }

  Widget _buildTable(List<Map<String, dynamic>> rows) {
    return Card(
      child: Table(
        columnWidths: const {
          0: FixedColumnWidth(160),
          1: FixedColumnWidth(180),
          2: FlexColumnWidth(1),
          3: FixedColumnWidth(140),
          4: FlexColumnWidth(2),
          5: FixedColumnWidth(140),
        },
        children: [
          const TableRow(children: [
            _Header('Date'), _Header('Count #'), _Header('Location'), _Header('Status'), _Header('Notes'), _Header('Actions')
          ]),
          ...rows.map(_buildRow),
        ],
      ),
    );
  }

  TableRow _buildRow(Map<String, dynamic> row) {
    final status = (row['status'] ?? '').toString();
    final created = DateTime.tryParse(row['started_at']?.toString() ?? '');
    final dateStr = created != null ? '${created.year}-${created.month.toString().padLeft(2, '0')}-${created.day.toString().padLeft(2, '0')}' : '';
    return TableRow(children: [
      _Cell(Text(dateStr)),
      _Cell(Text(row['count_number']?.toString() ?? '')),
      _Cell(Text(row['store_name']?.toString() ?? '')),
      _Cell(Container(
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
        decoration: BoxDecoration(
          color: _statusColor(status).withOpacity(0.1),
          borderRadius: BorderRadius.circular(999),
        ),
        child: Text(status.replaceAll('_', ' '), style: TextStyle(color: _statusColor(status))),
      )),
      _Cell(Text(row['notes']?.toString() ?? '')),
      _Cell(LayoutBuilder(builder: (context, constraints) {
        return Row(
          mainAxisAlignment: MainAxisAlignment.end,
          children: [
            Flexible(
              child: TextButton(
                onPressed: () => _openForm(existing: row),
                child: Text(status == 'in_progress' ? 'Continue' : 'View', overflow: TextOverflow.ellipsis),
              ),
            ),
            const SizedBox(width: 4),
            IconButton(
              onPressed: _downloadingId == row['id'] ? null : () => _downloadPdf(row),
              icon: _downloadingId == row['id']
                  ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2))
                  : const Icon(Icons.download),
              tooltip: 'Download PDF',
            ),
          ],
        );
      })),
    ]);
  }
}

class _Header extends StatelessWidget {
  final String text;
  const _Header(this.text);
  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.all(12),
        color: const Color(0xFFF7F7F7),
        child: Text(text, style: const TextStyle(fontWeight: FontWeight.bold)),
      );
}

class _Cell extends StatelessWidget {
  final Widget child;
  const _Cell(this.child);
  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.all(12),
        child: child,
      );
}