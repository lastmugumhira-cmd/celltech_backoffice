import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../../models/store.dart';
import '../../services/database_service.dart';
import '../../widgets/back_office_layout.dart';
import '../../utils/responsive_utils.dart';

class POSDevice {
  final int? id;
  final String deviceName;
  final String deviceId;
  final int storeId;
  final String deviceType;
  final String? ipAddress;
  final bool isActive;
  final DateTime? lastSync;

  POSDevice({
    this.id,
    required this.deviceName,
    required this.deviceId,
    required this.storeId,
    required this.deviceType,
    this.ipAddress,
    this.isActive = true,
    this.lastSync,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'device_name': deviceName,
      'device_id': deviceId,
      'store_id': storeId,
      'device_type': deviceType,
      'ip_address': ipAddress,
      'is_active': isActive ? 1 : 0,
      'last_sync': lastSync?.toIso8601String(),
    };
  }

  factory POSDevice.fromMap(Map<String, dynamic> map) {
    return POSDevice(
      id: map['id'],
      deviceName: map['device_name'] ?? '',
      deviceId: map['device_id'] ?? '',
      storeId: map['store_id'] ?? 0,
      deviceType: map['device_type'] ?? 'tablet',
      ipAddress: map['ip_address'],
      isActive: (map['is_active'] ?? 1) == 1,
      lastSync: map['last_sync'] != null ? DateTime.parse(map['last_sync']) : null,
    );
  }
}

class PosDevicesScreen extends StatefulWidget {
  const PosDevicesScreen({super.key});

  @override
  State<PosDevicesScreen> createState() => _PosDevicesScreenState();
}

class _PosDevicesScreenState extends State<PosDevicesScreen> {
  List<POSDevice> _devices = [];
  List<Store> _stores = [];
  bool _isLoading = true;
  String _searchQuery = '';

  @override
  void initState() {
    super.initState();
    _loadData();
    _initializePOSDevicesTable();
  }

  Future<void> _initializePOSDevicesTable() async {
    final db = await DatabaseService.database;
    
    // Check if the table exists, if not create it
    await db.execute('''
      CREATE TABLE IF NOT EXISTS pos_devices (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        device_name TEXT NOT NULL,
        device_id TEXT UNIQUE NOT NULL,
        store_id INTEGER NOT NULL,
        device_type TEXT NOT NULL DEFAULT 'tablet',
        ip_address TEXT,
        is_active INTEGER DEFAULT 1,
        last_sync TEXT,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (store_id) REFERENCES stores (id)
      )
    ''');
  }

  Future<void> _loadData() async {
    setState(() => _isLoading = true);
    try {
      final stores = await DatabaseService.getStores();
      final devices = await _loadPOSDevices();
      
      setState(() {
        _stores = stores;
        _devices = devices;
        _isLoading = false;
      });
    } catch (e) {
      setState(() => _isLoading = false);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error loading data: $e')),
        );
      }
    }
  }

  Future<List<POSDevice>> _loadPOSDevices() async {
    final db = await DatabaseService.database;
    final List<Map<String, dynamic>> maps = await db.query(
      'pos_devices',
      orderBy: 'device_name ASC',
    );
    return List.generate(maps.length, (i) => POSDevice.fromMap(maps[i]));
  }

  Future<void> _addDevice(POSDevice device) async {
    final db = await DatabaseService.database;
    await db.insert('pos_devices', device.toMap());
    _loadData();
  }

  Future<void> _updateDevice(POSDevice device) async {
    final db = await DatabaseService.database;
    await db.update(
      'pos_devices',
      device.toMap(),
      where: 'id = ?',
      whereArgs: [device.id],
    );
    _loadData();
  }

  Future<void> _deleteDevice(int deviceId) async {
    final db = await DatabaseService.database;
    await db.delete('pos_devices', where: 'id = ?', whereArgs: [deviceId]);
    _loadData();
  }

  List<POSDevice> get _filteredDevices {
    if (_searchQuery.isEmpty) return _devices;
    return _devices.where((device) {
      return device.deviceName.toLowerCase().contains(_searchQuery.toLowerCase()) ||
             device.deviceId.toLowerCase().contains(_searchQuery.toLowerCase()) ||
             (device.ipAddress?.toLowerCase().contains(_searchQuery.toLowerCase()) ?? false);
    }).toList();
  }

  @override
  Widget build(BuildContext context) {
    return BackOfficeLayout(
      title: 'POS Devices',
      currentRoute: '/backoffice/pos-devices',
      child: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : SingleChildScrollView(
              padding: ResponsiveUtils.responsivePadding(context),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _buildHeader(),
                  const SizedBox(height: 24),
                  _buildSearchBar(),
                  const SizedBox(height: 24),
                  _buildDevicesTable(),
                ],
              ),
            ),
    );
  }

  Widget _buildHeader() {
    return ResponsiveRow(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            ResponsiveText(
              'POS Devices',
              baseFontSize: 28,
              style: const TextStyle(fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 4),
            ResponsiveText(
              'Manage your point of sale devices',
              baseFontSize: 16,
              style: TextStyle(color: Colors.grey.shade600),
            ),
          ],
        ),
        ElevatedButton.icon(
          onPressed: () => _showDeviceForm(),
          icon: const Icon(Icons.add),
          label: const Text('Add Device'),
          style: ElevatedButton.styleFrom(
            backgroundColor: const Color(0xFFFF5F1F),
            foregroundColor: Colors.white,
          ),
        ),
      ],
    );
  }

  Widget _buildSearchBar() {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: TextField(
          decoration: const InputDecoration(
            hintText: 'Search devices by name, ID, or IP address...',
            prefixIcon: Icon(Icons.search),
            border: OutlineInputBorder(),
            isDense: true,
          ),
          onChanged: (value) {
            setState(() => _searchQuery = value);
          },
        ),
      ),
    );
  }

  Widget _buildDevicesTable() {
    final filteredDevices = _filteredDevices;
    
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                const Icon(Icons.computer, color: Color(0xFFFF5F1F)),
                const SizedBox(width: 8),
                ResponsiveText(
                  'POS Devices (${filteredDevices.length})',
                  baseFontSize: 18,
                  style: const TextStyle(fontWeight: FontWeight.bold),
                ),
              ],
            ),
            const SizedBox(height: 16),
            if (filteredDevices.isEmpty)
              const Center(
                child: Padding(
                  padding: EdgeInsets.all(32),
                  child: Text(
                    'No POS devices found.',
                    style: TextStyle(color: Colors.grey),
                  ),
                ),
              )
            else
              SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: DataTable(
                  columns: const [
                    DataColumn(label: Text('Device Name')),
                    DataColumn(label: Text('Device ID')),
                    DataColumn(label: Text('Store')),
                    DataColumn(label: Text('Type')),
                    DataColumn(label: Text('IP Address')),
                    DataColumn(label: Text('Status')),
                    DataColumn(label: Text('Last Sync')),
                    DataColumn(label: Text('Actions')),
                  ],
                  rows: filteredDevices.map((device) {
                    final store = _stores.firstWhere(
                      (s) => s.id == device.storeId,
                      orElse: () => Store(id: 0, name: 'Unknown', address: '', phone: '', type: 'store'),
                    );
                    
                    return DataRow(
                      cells: [
                        DataCell(
                          Row(
                            children: [
                              const Icon(Icons.computer, size: 16, color: Colors.grey),
                              const SizedBox(width: 8),
                              Text(device.deviceName, style: const TextStyle(fontWeight: FontWeight.w500)),
                            ],
                          ),
                        ),
                        DataCell(Text(device.deviceId, style: const TextStyle(fontFamily: 'monospace'))),
                        DataCell(Text(store.name)),
                        DataCell(
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                            decoration: BoxDecoration(
                              color: Colors.grey.shade100,
                              borderRadius: BorderRadius.circular(4),
                            ),
                            child: Text(
                              device.deviceType.toUpperCase(),
                              style: const TextStyle(fontSize: 12),
                            ),
                          ),
                        ),
                        DataCell(Text(device.ipAddress ?? 'N/A', style: const TextStyle(fontFamily: 'monospace'))),
                        DataCell(
                          Row(
                            children: [
                              Container(
                                width: 8,
                                height: 8,
                                decoration: BoxDecoration(
                                  color: device.isActive ? Colors.green : Colors.red,
                                  shape: BoxShape.circle,
                                ),
                              ),
                              const SizedBox(width: 8),
                              Container(
                                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                                decoration: BoxDecoration(
                                  color: device.isActive ? Colors.green.shade100 : Colors.red.shade100,
                                  borderRadius: BorderRadius.circular(4),
                                ),
                                child: Text(
                                  device.isActive ? 'Active' : 'Inactive',
                                  style: TextStyle(
                                    fontSize: 12,
                                    color: device.isActive ? Colors.green.shade700 : Colors.red.shade700,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        DataCell(
                          Text(
                            device.lastSync != null
                                ? DateFormat('MMM dd, HH:mm').format(device.lastSync!)
                                : 'Never',
                            style: const TextStyle(fontSize: 12, color: Colors.grey),
                          ),
                        ),
                        DataCell(
                          Row(
                            children: [
                              IconButton(
                                icon: const Icon(Icons.edit, size: 16),
                                onPressed: () => _showDeviceForm(device: device),
                                tooltip: 'Edit Device',
                              ),
                              IconButton(
                                icon: const Icon(Icons.delete, size: 16, color: Colors.red),
                                onPressed: () => _confirmDelete(device),
                                tooltip: 'Delete Device',
                              ),
                            ],
                          ),
                        ),
                      ],
                    );
                  }).toList(),
                ),
              ),
          ],
        ),
      ),
    );
  }

  void _showDeviceForm({POSDevice? device}) {
    showDialog(
      context: context,
      builder: (context) => POSDeviceFormDialog(
        device: device,
        stores: _stores,
        onSubmit: (deviceData) async {
          if (device != null) {
            await _updateDevice(deviceData);
          } else {
            await _addDevice(deviceData);
          }
        },
      ),
    );
  }

  void _confirmDelete(POSDevice device) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Delete POS Device'),
        content: Text('Are you sure you want to delete "${device.deviceName}"? This action cannot be undone.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              _deleteDevice(device.id!);
            },
            style: TextButton.styleFrom(foregroundColor: Colors.red),
            child: const Text('Delete'),
          ),
        ],
      ),
    );
  }
}

class POSDeviceFormDialog extends StatefulWidget {
  final POSDevice? device;
  final List<Store> stores;
  final Function(POSDevice) onSubmit;

  const POSDeviceFormDialog({
    super.key,
    this.device,
    required this.stores,
    required this.onSubmit,
  });

  @override
  State<POSDeviceFormDialog> createState() => _POSDeviceFormDialogState();
}

class _POSDeviceFormDialogState extends State<POSDeviceFormDialog> {
  final _formKey = GlobalKey<FormState>();
  final _deviceNameController = TextEditingController();
  final _deviceIdController = TextEditingController();
  final _ipAddressController = TextEditingController();
  
  int? _selectedStoreId;
  String _deviceType = 'tablet';
  bool _isActive = true;

  @override
  void initState() {
    super.initState();
    if (widget.device != null) {
      _deviceNameController.text = widget.device!.deviceName;
      _deviceIdController.text = widget.device!.deviceId;
      _ipAddressController.text = widget.device!.ipAddress ?? '';
      _selectedStoreId = widget.device!.storeId;
      _deviceType = widget.device!.deviceType;
      _isActive = widget.device!.isActive;
    }
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text(widget.device == null ? 'Add POS Device' : 'Edit POS Device'),
      content: SizedBox(
        width: 400,
        child: Form(
          key: _formKey,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextFormField(
                controller: _deviceNameController,
                decoration: const InputDecoration(
                  labelText: 'Device Name',
                  border: OutlineInputBorder(),
                ),
                validator: (value) => value?.isEmpty == true ? 'Please enter device name' : null,
              ),
              const SizedBox(height: 16),
              TextFormField(
                controller: _deviceIdController,
                decoration: const InputDecoration(
                  labelText: 'Device ID',
                  border: OutlineInputBorder(),
                ),
                validator: (value) => value?.isEmpty == true ? 'Please enter device ID' : null,
              ),
              const SizedBox(height: 16),
              DropdownButtonFormField<int>(
                value: _selectedStoreId,
                decoration: const InputDecoration(
                  labelText: 'Store',
                  border: OutlineInputBorder(),
                ),
                items: widget.stores.map((store) {
                  return DropdownMenuItem<int>(
                    value: store.id,
                    child: Text(store.name),
                  );
                }).toList(),
                onChanged: (value) => setState(() => _selectedStoreId = value),
                validator: (value) => value == null ? 'Please select a store' : null,
              ),
              const SizedBox(height: 16),
              DropdownButtonFormField<String>(
                value: _deviceType,
                decoration: const InputDecoration(
                  labelText: 'Device Type',
                  border: OutlineInputBorder(),
                ),
                items: const [
                  DropdownMenuItem(value: 'tablet', child: Text('Tablet')),
                  DropdownMenuItem(value: 'desktop', child: Text('Desktop')),
                  DropdownMenuItem(value: 'mobile', child: Text('Mobile')),
                ],
                onChanged: (value) => setState(() => _deviceType = value!),
              ),
              const SizedBox(height: 16),
              TextFormField(
                controller: _ipAddressController,
                decoration: const InputDecoration(
                  labelText: 'IP Address (Optional)',
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 16),
              CheckboxListTile(
                title: const Text('Active'),
                value: _isActive,
                onChanged: (value) => setState(() => _isActive = value!),
                controlAffinity: ListTileControlAffinity.leading,
              ),
            ],
          ),
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: const Text('Cancel'),
        ),
        ElevatedButton(
          onPressed: _submit,
          style: ElevatedButton.styleFrom(
            backgroundColor: const Color(0xFFFF5F1F),
            foregroundColor: Colors.white,
          ),
          child: Text(widget.device == null ? 'Add' : 'Update'),
        ),
      ],
    );
  }

  void _submit() {
    if (_formKey.currentState!.validate()) {
      final device = POSDevice(
        id: widget.device?.id,
        deviceName: _deviceNameController.text.trim(),
        deviceId: _deviceIdController.text.trim(),
        storeId: _selectedStoreId!,
        deviceType: _deviceType,
        ipAddress: _ipAddressController.text.trim().isEmpty ? null : _ipAddressController.text.trim(),
        isActive: _isActive,
        lastSync: widget.device?.lastSync,
      );
      
      widget.onSubmit(device);
      Navigator.pop(context);
    }
  }

  @override
  void dispose() {
    _deviceNameController.dispose();
    _deviceIdController.dispose();
    _ipAddressController.dispose();
    super.dispose();
  }
}