import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../../services/database_service.dart';
import '../../models/store.dart';
import '../../models/employee.dart';

import '../../widgets/back_office_layout.dart';
import '../../widgets/components/shift_dialog.dart';
import 'dart:math' as math;

class ShiftsScreen extends StatefulWidget {
  const ShiftsScreen({super.key});

  @override
  State<ShiftsScreen> createState() => _ShiftsScreenState();
}

class _ShiftsScreenState extends State<ShiftsScreen> {
  List<Store> _stores = [];
  List<Employee> _employees = [];
  List<Map<String, dynamic>> _shifts = [];
  bool _isLoading = false;
  int? _filterStoreId;

  // Summary metrics
  int _openShifts = 0;
  int _closedToday = 0;
  double _cashOverShort = 0.0;
  double _totalCashToday = 0.0;

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  Future<void> _loadData() async {
    setState(() => _isLoading = true);
    
    try {
      // Load stores and employees
      final stores = await DatabaseService.getStores();
      final employees = await DatabaseService.getEmployees(); 
      
      setState(() {
        _stores = stores;
        _employees = employees;
      });
      
      await _loadShifts();
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error loading data: $e')),
        );
      }
    } finally {
      setState(() => _isLoading = false);
    }
  }

  Future<void> _loadShifts() async {
    try {
      // In a real implementation, this would fetch from database
      // For now, generating mock data
      _generateMockShiftData();
      _calculateSummaryMetrics();
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error loading shifts: $e')),
        );
      }
    }
  }

  void _generateMockShiftData() {
    final random = math.Random();
    final now = DateTime.now();
    final shifts = <Map<String, dynamic>>[];

    // Generate shifts for the last few days
    for (int i = 0; i < 15; i++) {
      final isOpen = random.nextBool() && i < 3; // Some recent shifts are still open
      final startTime = now.subtract(Duration(days: i, hours: random.nextInt(8) + 1));
      final endTime = isOpen ? null : startTime.add(Duration(hours: 6 + random.nextInt(6)));
      
      final startingCash = 200.0 + random.nextDouble() * 300; // $200-$500
      final endingCash = isOpen ? null : startingCash + (random.nextDouble() - 0.5) * 50; // ±$25 variance
      
      final storeIndex = random.nextInt(_stores.length);
      final employeeIndex = random.nextInt(_employees.length);
      
      shifts.add({
        'id': i + 1,
        'pos_device': 'POS-${100000 + random.nextInt(900000)}',
        'store_id': _stores.isNotEmpty ? _stores[storeIndex].id : 1,
        'store_name': _stores.isNotEmpty ? _stores[storeIndex].name : 'Store ${storeIndex + 1}',
        'employee_id': _employees.isNotEmpty ? _employees[employeeIndex].id : 1,
        'employee_name': _employees.isNotEmpty ? _employees[employeeIndex].name : 'Employee ${employeeIndex + 1}',
        'start_time': startTime,
        'end_time': endTime,
        'status': isOpen ? 'open' : 'closed',
        'starting_cash': startingCash,
        'ending_cash': endingCash,
        'cash_variance': endingCash != null ? endingCash - startingCash : null,
        'notes': random.nextBool() ? 'Regular shift' : null,
      });
    }

    setState(() {
      _shifts = shifts;
    });
  }

  void _calculateSummaryMetrics() {
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);
    
    final filteredShifts = _filterStoreId == null 
        ? _shifts 
        : _shifts.where((shift) => shift['store_id'] == _filterStoreId).toList();

    int openShifts = 0;
    int closedToday = 0;
    double cashOverShort = 0.0;
    double totalCashToday = 0.0;

    for (final shift in filteredShifts) {
      // Count open shifts
      if (shift['status'] == 'open') {
        openShifts++;
      }

      // Count closed today
      if (shift['status'] == 'closed' && shift['end_time'] != null) {
        final closingDate = DateTime(
          (shift['end_time'] as DateTime).year,
          (shift['end_time'] as DateTime).month,
          (shift['end_time'] as DateTime).day,
        );
        if (closingDate == today) {
          closedToday++;
        }
      }

      // Calculate cash over/short
      final startingCash = (shift['starting_cash'] as double?) ?? 0.0;
      final endingCash = (shift['ending_cash'] as double?) ?? 0.0;
      if (shift['status'] == 'closed' && shift['ending_cash'] != null) {
        cashOverShort += endingCash - startingCash;
      }

      // Calculate total cash today (from shifts opened today)
      if (shift['start_time'] != null) {
        final openingDate = DateTime(
          (shift['start_time'] as DateTime).year,
          (shift['start_time'] as DateTime).month,
          (shift['start_time'] as DateTime).day,
        );
        if (openingDate == today) {
          totalCashToday += endingCash > 0 ? endingCash : startingCash;
        }
      }
    }

    setState(() {
      _openShifts = openShifts;
      _closedToday = closedToday;
      _cashOverShort = cashOverShort;
      _totalCashToday = totalCashToday;
    });
  }

  void _showNewShiftDialog() {
    showDialog(
      context: context,
      builder: (context) => ShiftDialog(
        stores: _stores,
        employees: _employees,
        onSubmit: _createNewShift,
      ),
    );
  }

  Future<void> _createNewShift(Map<String, dynamic> shiftData) async {
    try {
      // In a real implementation, this would save to database
      // For now, add to local list
      final newShift = {
        'id': _shifts.length + 1,
        'pos_device': shiftData['pos_device'],
        'store_id': shiftData['store_id'],
        'store_name': _stores.firstWhere((s) => s.id == shiftData['store_id']).name,
        'employee_id': shiftData['employee_id'],
        'employee_name': _employees.firstWhere((e) => e.id == shiftData['employee_id']).name,
        'start_time': DateTime.now(),
        'end_time': null,
        'status': 'open',
        'starting_cash': shiftData['starting_cash'],
        'ending_cash': null,
        'cash_variance': null,
        'notes': shiftData['notes'],
      };

      setState(() {
        _shifts.insert(0, newShift);
      });

      _calculateSummaryMetrics();

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('New shift opened successfully')),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error creating shift: $e')),
        );
      }
    }
  }

  void _exportData() {
    // Mock export functionality
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Export functionality - would export shift data to CSV/Excel'),
        duration: Duration(seconds: 2),
      ),
    );
    print('Exporting shift data...');
  }

  String _formatDuration(DateTime? start, DateTime? end) {
    if (start == null) return '-';
    
    final endTime = end ?? DateTime.now();
    final duration = endTime.difference(start);
    final hours = duration.inHours;
    final minutes = (duration.inMinutes % 60);
    
    return '${hours}h ${minutes}m';
  }

  @override
  Widget build(BuildContext context) {
    return BackOfficeLayout(
      title: 'Shifts',
      currentRoute: '/backoffice/shifts',
      child: _isLoading 
        ? const Center(child: CircularProgressIndicator())
        : SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _buildHeader(),
                const SizedBox(height: 24),
                _buildSummaryCards(),
                const SizedBox(height: 24),
                _buildFilters(),
                const SizedBox(height: 24),
                _buildShiftsTable(),
              ],
            ),
          ),
    );
  }

  Widget _buildHeader() {
    return Row(
      children: [
        IconButton(
          onPressed: () => Navigator.of(context).pushReplacementNamed('/backoffice/dashboard'),
          icon: const Icon(Icons.arrow_back),
          tooltip: 'Back to Dashboard',
        ),
        const SizedBox(width: 8),
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Shifts',
              style: TextStyle(
                fontSize: 28,
                fontWeight: FontWeight.bold,
              ),
            ),
            Text(
              'Shift management and cash reconciliation',
              style: TextStyle(
                fontSize: 14,
                color: Colors.grey.shade600,
              ),
            ),
          ],
        ),
        const Spacer(),
        ElevatedButton.icon(
          onPressed: _showNewShiftDialog,
          icon: const Icon(Icons.add),
          label: const Text('Open New Shift'),
          style: ElevatedButton.styleFrom(
            backgroundColor: Colors.blue,
            foregroundColor: Colors.white,
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
          ),
        ),
      ],
    );
  }

  Widget _buildSummaryCards() {
    final currencyFormat = NumberFormat.currency(symbol: '\$');
    
    final cards = [
      {
        'title': 'Open Shifts',
        'value': _openShifts.toString(),
        'icon': Icons.schedule,
        'color': Colors.blue,
      },
      {
        'title': 'Closed Today',
        'value': _closedToday.toString(),
        'icon': Icons.check_circle,
        'color': Colors.green,
      },
      {
        'title': 'Cash Over/Short',
        'value': currencyFormat.format(_cashOverShort),
        'icon': Icons.account_balance_wallet,
        'color': _cashOverShort >= 0 ? Colors.green : Colors.red,
      },
      {
        'title': 'Total Cash Today',
        'value': currencyFormat.format(_totalCashToday),
        'icon': Icons.attach_money,
        'color': Colors.purple,
      },
    ];

    return LayoutBuilder(
      builder: (context, constraints) {
        final isSmallScreen = constraints.maxWidth < 600;
        final crossAxisCount = isSmallScreen ? 2 : 4;
        
        return GridView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: crossAxisCount,
            crossAxisSpacing: 16,
            mainAxisSpacing: 16,
            childAspectRatio: isSmallScreen ? 2.5 : 2.8,
          ),
          itemCount: cards.length,
          itemBuilder: (context, index) {
            final card = cards[index];
            
            return Container(
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: Colors.grey.shade200),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.05),
                    blurRadius: 8,
                    offset: const Offset(0, 2),
                  ),
                ],
              ),
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.all(8),
                        decoration: BoxDecoration(
                          color: (card['color'] as Color).withOpacity(0.1),
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: Icon(
                          card['icon'] as IconData,
                          color: card['color'] as Color,
                          size: 20,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  Text(
                    card['title'] as String,
                    style: TextStyle(
                      fontSize: 12,
                      color: Colors.grey.shade600,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    card['value'] as String,
                    style: const TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),
            );
          },
        );
      },
    );
  }

  Widget _buildFilters() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.grey.shade50,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.grey.shade200),
      ),
      child: Row(
        children: [
          const Text(
            'Filters:',
            style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: DropdownButtonFormField<int?>(
              initialValue: _filterStoreId,
              decoration: const InputDecoration(
                labelText: 'Store',
                border: OutlineInputBorder(),
                isDense: true,
              ),
              items: [
                const DropdownMenuItem(value: null, child: Text('All Stores')),
                ..._stores.map((store) => DropdownMenuItem(
                      value: store.id,
                      child: Text(store.name),
                    )),
              ],
              onChanged: (value) {
                setState(() => _filterStoreId = value);
                _calculateSummaryMetrics();
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildShiftsTable() {
    final filteredShifts = _filterStoreId == null 
        ? _shifts 
        : _shifts.where((shift) => shift['store_id'] == _filterStoreId).toList();

    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.grey.shade200),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Text(
                'Shifts',
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const Spacer(),
              ElevatedButton.icon(
                onPressed: _exportData,
                icon: const Icon(Icons.download),
                label: const Text('Export'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.green,
                  foregroundColor: Colors.white,
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          
          if (filteredShifts.isNotEmpty)
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: DataTable(
                columns: const [
                  DataColumn(label: Text('POS Device', style: TextStyle(fontWeight: FontWeight.bold))),
                  DataColumn(label: Text('Employee', style: TextStyle(fontWeight: FontWeight.bold))),
                  DataColumn(label: Text('Store', style: TextStyle(fontWeight: FontWeight.bold))),
                  DataColumn(label: Text('Opening Time', style: TextStyle(fontWeight: FontWeight.bold))),
                  DataColumn(label: Text('Closing Time', style: TextStyle(fontWeight: FontWeight.bold))),
                  DataColumn(label: Text('Duration', style: TextStyle(fontWeight: FontWeight.bold))),
                  DataColumn(label: Text('Status', style: TextStyle(fontWeight: FontWeight.bold))),
                  DataColumn(label: Text('Starting Cash', style: TextStyle(fontWeight: FontWeight.bold)), numeric: true),
                  DataColumn(label: Text('Ending Cash', style: TextStyle(fontWeight: FontWeight.bold)), numeric: true),
                  DataColumn(label: Text('Difference', style: TextStyle(fontWeight: FontWeight.bold)), numeric: true),
                ],
                rows: filteredShifts.map((shift) {
                  final currencyFormat = NumberFormat.currency(symbol: '\$');
                  final dateFormat = DateFormat('MMM dd, yyyy HH:mm');
                  
                  final startingCash = (shift['starting_cash'] as double?) ?? 0.0;
                  final endingCash = shift['ending_cash'] as double?;
                  final difference = endingCash != null ? endingCash - startingCash : 0.0;
                  
                  return DataRow(
                    cells: [
                      DataCell(Text(shift['pos_device'] ?? '-')),
                      DataCell(Text(shift['employee_name'] ?? '-')),
                      DataCell(Text(shift['store_name'] ?? '-')),
                      DataCell(Text(shift['start_time'] != null ? dateFormat.format(shift['start_time']) : '-')),
                      DataCell(Text(shift['end_time'] != null ? dateFormat.format(shift['end_time']) : 'Still Open')),
                      DataCell(Text(_formatDuration(shift['start_time'], shift['end_time']))),
                      DataCell(
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                          decoration: BoxDecoration(
                            color: shift['status'] == 'open' ? Colors.green.shade100 : Colors.grey.shade100,
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: Text(
                            shift['status'] == 'open' ? 'Open' : 'Closed',
                            style: TextStyle(
                              color: shift['status'] == 'open' ? Colors.green.shade700 : Colors.grey.shade700,
                              fontWeight: FontWeight.w500,
                              fontSize: 12,
                            ),
                          ),
                        ),
                      ),
                      DataCell(Text(currencyFormat.format(startingCash))),
                      DataCell(Text(endingCash != null ? currencyFormat.format(endingCash) : '-')),
                      DataCell(
                        Text(
                          endingCash != null ? currencyFormat.format(difference) : '-',
                          style: TextStyle(
                            color: endingCash != null 
                                ? (difference > 0 ? Colors.green.shade600 : difference < 0 ? Colors.red.shade600 : Colors.grey.shade600)
                                : Colors.grey.shade600,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ),
                    ],
                  );
                }).toList(),
              ),
            )
          else
            const SizedBox(
              height: 200,
              child: Center(
                child: Text('No shifts found for the selected criteria'),
              ),
            ),
        ],
      ),
    );
  }
}