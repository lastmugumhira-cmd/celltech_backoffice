import 'package:flutter/material.dart';
import '../../services/database_service.dart';
import '../../models/store.dart';
import '../../widgets/back_office_layout.dart';

class InventoryValuationScreen extends StatefulWidget {
  const InventoryValuationScreen({super.key});

  @override
  State<InventoryValuationScreen> createState() =>
      _InventoryValuationScreenState();
}

class _InventoryValuationScreenState extends State<InventoryValuationScreen> {
  List<Store> _stores = [];
  Map<String, dynamic>? _valuation;
  bool _isLoading = true;
  int? _selectedStoreId;
  String _searchQuery = '';

  // Pagination
  int _currentPage = 0;
  int _rowsPerPage = 25;
  final List<int> _availableRowsPerPage = [25, 50, 100];

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  Future<void> _loadData() async {
    setState(() => _isLoading = true);
    try {
      final stores = await DatabaseService.getStores();
      setState(() {
        _stores = stores;
        if (stores.isNotEmpty && _selectedStoreId == null) {
          _selectedStoreId = stores.first.id;
        }
      });
      await _loadValuation();
    } catch (e) {
      setState(() => _isLoading = false);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error loading data: $e')),
        );
      }
    }
  }

  Future<void> _loadValuation() async {
    if (_selectedStoreId == null) return;

    setState(() => _isLoading = true);
    try {
      final valuation = await DatabaseService.getInventoryValuation(
          storeId: _selectedStoreId!);
      setState(() {
        _valuation = valuation;
        _isLoading = false;
      });
    } catch (e) {
      setState(() => _isLoading = false);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error loading valuation: $e')),
        );
      }
    }
  }

  List<Map<String, dynamic>> get _filteredProducts {
    if (_valuation == null || _valuation!['items'] == null) return [];

    final products = List<Map<String, dynamic>>.from(_valuation!['items']);

    if (_searchQuery.isEmpty) return products;

    return products.where((product) {
      final name = product['name']?.toString().toLowerCase() ?? '';
      final sku = product['sku']?.toString().toLowerCase() ?? '';
      final query = _searchQuery.toLowerCase();
      return name.contains(query) || sku.contains(query);
    }).toList();
  }

  List<Map<String, dynamic>> get _paginatedProducts {
    final filtered = _filteredProducts;
    final startIndex = _currentPage * _rowsPerPage;
    final endIndex = (startIndex + _rowsPerPage).clamp(0, filtered.length);

    if (startIndex >= filtered.length) return [];
    return filtered.sublist(startIndex, endIndex);
  }

  @override
  Widget build(BuildContext context) {
    return BackOfficeLayout(
      title: 'Inventory Valuation',
      currentRoute: '/backoffice/inventory/valuation',
      child: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : _buildContent(),
    );
  }

  Widget _buildContent() {
    final totalProducts = _filteredProducts.length;
    final totalPages = (totalProducts / _rowsPerPage).ceil().clamp(1, 999999);
    final startIndex = _currentPage * _rowsPerPage;
    final endIndex = (startIndex + _rowsPerPage).clamp(0, totalProducts);

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Header
        Padding(
          padding: const EdgeInsets.all(24),
          child: Row(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'Inventory Valuation',
                      style:
                          TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      'View inventory value and costs by store',
                      style:
                          TextStyle(fontSize: 14, color: Colors.grey.shade600),
                    ),
                  ],
                ),
              ),
              SizedBox(
                width: 250,
                child: DropdownButtonFormField<int>(
                  initialValue: _selectedStoreId,
                  decoration: InputDecoration(
                    labelText: 'Select Store',
                    border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(8)),
                    contentPadding: const EdgeInsets.symmetric(
                        horizontal: 16, vertical: 12),
                  ),
                  items: _stores
                      .map((store) => DropdownMenuItem(
                            value: store.id,
                            child: Text(store.name),
                          ))
                      .toList(),
                  onChanged: (value) {
                    setState(() {
                      _selectedStoreId = value;
                      _currentPage = 0;
                    });
                    _loadValuation();
                  },
                ),
              ),
            ],
          ),
        ),

        // Summary Cards
        if (_valuation != null)
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 24),
            child: Row(
              children: [
                Expanded(
                  child: _buildSummaryCard(
                    'Total Units',
                    '${_valuation!['totalUnits'] ?? 0}',
                    Icons.inventory_2,
                    Colors.blue,
                  ),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: _buildSummaryCard(
                    'Total Cost',
                    '\$${(_valuation!['totalCost'] ?? 0).toStringAsFixed(2)}',
                    Icons.attach_money,
                    Colors.orange,
                  ),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: _buildSummaryCard(
                    'Total Retail',
                    '\$${(_valuation!['totalRetail'] ?? 0).toStringAsFixed(2)}',
                    Icons.point_of_sale,
                    Colors.green,
                  ),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: _buildSummaryCard(
                    'Gross Margin',
                    '${(_valuation!['grossMargin'] ?? 0).toStringAsFixed(1)}%',
                    Icons.trending_up,
                    Colors.purple,
                  ),
                ),
              ],
            ),
          ),

        const SizedBox(height: 24),

        // Search
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 24),
          child: SizedBox(
            width: 400,
            child: TextField(
              decoration: InputDecoration(
                hintText: 'Search products...',
                prefixIcon: const Icon(Icons.search),
                border:
                    OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
                contentPadding:
                    const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              ),
              onChanged: (value) => setState(() {
                _searchQuery = value;
                _currentPage = 0;
              }),
            ),
          ),
        ),

        const SizedBox(height: 16),

        // Products Table
        Expanded(
          child: Card(
            margin: const EdgeInsets.symmetric(horizontal: 24),
            child: Column(
              children: [
                Expanded(
                  child: SingleChildScrollView(
                    scrollDirection: Axis.horizontal,
                    child: SingleChildScrollView(
                      child: DataTable(
                        columns: const [
                          DataColumn(label: Text('Product')),
                          DataColumn(label: Text('SKU')),
                          DataColumn(label: Text('Quantity')),
                          DataColumn(label: Text('Cost/Unit')),
                          DataColumn(label: Text('Total Cost')),
                          DataColumn(label: Text('Price/Unit')),
                          DataColumn(label: Text('Total Retail')),
                          DataColumn(label: Text('Margin %')),
                        ],
                        rows: _paginatedProducts.map((product) {
                          final quantity = product['total_quantity'] ?? 0;
                          final cost = product['cost'] ?? 0.0;
                          final price = product['price'] ?? 0.0;
                          final totalCost = quantity * cost;
                          final totalRetail = quantity * price;
                          final margin =
                              price > 0 ? ((price - cost) / price * 100) : 0;

                          return DataRow(
                            cells: [
                              DataCell(
                                SizedBox(
                                  width: 200,
                                  child: Text(
                                    product['name'] ?? '',
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                ),
                              ),
                              DataCell(Text(product['sku'] ?? '')),
                              DataCell(Text('$quantity')),
                              DataCell(Text('\$${cost.toStringAsFixed(2)}')),
                              DataCell(
                                  Text('\$${totalCost.toStringAsFixed(2)}')),
                              DataCell(Text('\$${price.toStringAsFixed(2)}')),
                              DataCell(
                                  Text('\$${totalRetail.toStringAsFixed(2)}')),
                              DataCell(
                                Text(
                                  '${margin.toStringAsFixed(1)}%',
                                  style: TextStyle(
                                    color: margin >= 30
                                        ? Colors.green
                                        : margin >= 15
                                            ? Colors.orange
                                            : Colors.red,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ),
                            ],
                          );
                        }).toList(),
                      ),
                    ),
                  ),
                ),

                // Pagination
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: Colors.grey.shade50,
                    border:
                        Border(top: BorderSide(color: Colors.grey.shade300)),
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Row(
                        children: [
                          const Text('Rows per page:'),
                          const SizedBox(width: 8),
                          DropdownButton<int>(
                            value: _rowsPerPage,
                            items: _availableRowsPerPage.map((rows) {
                              return DropdownMenuItem<int>(
                                value: rows,
                                child: Text('$rows'),
                              );
                            }).toList(),
                            onChanged: (value) {
                              if (value != null) {
                                setState(() {
                                  _rowsPerPage = value;
                                  _currentPage = 0;
                                });
                              }
                            },
                          ),
                        ],
                      ),
                      Row(
                        children: [
                          Text(
                            'Showing ${startIndex + 1}-$endIndex of $totalProducts',
                            style: const TextStyle(fontSize: 14),
                          ),
                          const SizedBox(width: 16),
                          IconButton(
                            onPressed: _currentPage > 0
                                ? () => setState(() => _currentPage--)
                                : null,
                            icon: const Icon(Icons.chevron_left),
                            tooltip: 'Previous page',
                          ),
                          Text(
                            'Page ${_currentPage + 1} of $totalPages',
                            style: const TextStyle(fontSize: 14),
                          ),
                          IconButton(
                            onPressed: _currentPage < totalPages - 1
                                ? () => setState(() => _currentPage++)
                                : null,
                            icon: const Icon(Icons.chevron_right),
                            tooltip: 'Next page',
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),

        const SizedBox(height: 24),
      ],
    );
  }

  Widget _buildSummaryCard(
      String title, String value, IconData icon, Color color) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: color.withOpacity(0.1),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Icon(icon, color: color, size: 28),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: TextStyle(fontSize: 14, color: Colors.grey.shade600),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    value,
                    style: const TextStyle(
                        fontSize: 24, fontWeight: FontWeight.bold),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
