import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import '../../services/database_service.dart';
import '../../models/store.dart';
import '../../models/employee.dart';
import '../../widgets/back_office_layout.dart';

class SalesSummaryScreen extends StatefulWidget {
  const SalesSummaryScreen({super.key});

  @override
  State<SalesSummaryScreen> createState() => _SalesSummaryScreenState();
}

class _SalesSummaryScreenState extends State<SalesSummaryScreen> {
  List<Store> _stores = [];
  List<Employee> _employees = [];
  bool _isLoading = false;

  // Date filters
  DateTime _startDate = DateTime.now().subtract(const Duration(days: 7));
  DateTime _endDate = DateTime.now();
  int? _filterStoreId;
  int? _filterEmployeeId;
  String _datePreset = 'Last 7 Days';

  // Metrics
  double _grossSales = 0;
  double _refunds = 0;
  double _discounts = 0;
  double _netSales = 0;
  double _grossProfit = 0;

  // Chart controls
  String _selectedMetric = 'grossSales';
  String _chartType = 'Bar';
  String _timeFrame = 'Days';
  List<Map<String, dynamic>> _chartData = [];

  // Table controls
  final Set<String> _visibleColumns = {
    'date', 'gross_sales', 'refunds', 'discounts', 'net_sales', 'cost_of_goods', 'gross_profit', 'margin'
  };

  final Map<String, String> _metricLabels = {
    'grossSales': 'Gross Sales',
    'refunds': 'Refunds', 
    'discounts': 'Discounts',
    'netSales': 'Net Sales',
    'grossProfit': 'Gross Profit',
  };

  final Map<String, Color> _metricColors = {
    'grossSales': Colors.blue,
    'refunds': Colors.red,
    'discounts': Colors.orange,
    'netSales': Colors.green,
    'grossProfit': Colors.purple,
  };

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  Future<void> _loadData() async {
    setState(() => _isLoading = true);
    
    try {
      // Load stores and employees
      final stores = await DatabaseService.getStores();
      final employees = await DatabaseService.getEmployees();
      
      setState(() {
        _stores = stores;
        _employees = employees;
      });
      
      await _loadSalesData();
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error loading data: $e')),
        );
      }
    } finally {
      setState(() => _isLoading = false);
    }
  }

  Future<void> _loadSalesData() async {
    try {
      final sales = await DatabaseService.getSales(
        storeId: _filterStoreId,
        employeeId: _filterEmployeeId,
        startDate: _startDate,
        endDate: _endDate,
      );

      // Calculate metrics
      double grossSales = 0;
      double refunds = 0;
      double discounts = 0;
      double netSales = 0;

      for (var sale in sales) {
        final subtotal = (sale['subtotal'] as num?)?.toDouble() ?? 0;
        final totalAmount = (sale['total_amount'] as num?)?.toDouble() ?? 0;
        final discountAmount = (sale['discount_amount'] as num?)?.toDouble() ?? 0;
        final paymentStatus = sale['payment_status']?.toString() ?? '';

        grossSales += subtotal;
        discounts += discountAmount;
        
        if (paymentStatus == 'refunded') {
          refunds += totalAmount;
        } else {
          netSales += totalAmount;
        }
      }

      final grossProfit = netSales * 0.3; // 30% margin placeholder

      setState(() {
        _grossSales = grossSales;
        _refunds = refunds;
        _discounts = discounts;
        _netSales = netSales;
        _grossProfit = grossProfit;
      });

      await _generateChartData();
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error loading sales: $e')),
        );
      }
    }
  }

  Future<void> _generateChartData() async {
    try {
      final data = <Map<String, dynamic>>[];
      
      // Determine time frame based on date range
      final diffDays = _endDate.difference(_startDate).inDays;
      
      if (diffDays <= 7) {
        // Daily data for week view
        for (int i = 0; i <= diffDays; i++) {
          final date = _startDate.add(Duration(days: i));
          final dayStart = DateTime(date.year, date.month, date.day);
          final dayEnd = DateTime(date.year, date.month, date.day, 23, 59, 59);
          
          final daySales = await DatabaseService.getSales(
            storeId: _filterStoreId,
            employeeId: _filterEmployeeId,
            startDate: dayStart,
            endDate: dayEnd,
          );
          
          double grossSales = 0;
          double refunds = 0;
          double discounts = 0;
          double netSales = 0;
          
          for (var sale in daySales) {
            final subtotal = (sale['subtotal'] as num?)?.toDouble() ?? 0;
            final totalAmount = (sale['total_amount'] as num?)?.toDouble() ?? 0;
            final discountAmount = (sale['discount_amount'] as num?)?.toDouble() ?? 0;
            final paymentStatus = sale['payment_status']?.toString() ?? '';
            
            grossSales += subtotal;
            discounts += discountAmount;
            
            if (paymentStatus == 'refunded') {
              refunds += totalAmount;
            } else {
              netSales += totalAmount;
            }
          }
          
          final grossProfit = netSales * 0.3; // 30% margin placeholder
          
          data.add({
            'date': date,
            'grossSales': grossSales,
            'refunds': refunds,
            'discounts': discounts,
            'netSales': netSales,
            'grossProfit': grossProfit,
          });
        }
      } else if (diffDays <= 31) {
        // Weekly data for month view
        DateTime currentWeekStart = _startDate;
        while (currentWeekStart.isBefore(_endDate)) {
          final weekEnd = currentWeekStart.add(const Duration(days: 6));
          final actualWeekEnd = weekEnd.isAfter(_endDate) ? _endDate : weekEnd;
          
          final weekSales = await DatabaseService.getSales(
            storeId: _filterStoreId,
            employeeId: _filterEmployeeId,
            startDate: currentWeekStart,
            endDate: actualWeekEnd,
          );
          
          double grossSales = 0;
          double refunds = 0;
          double discounts = 0;
          double netSales = 0;
          
          for (var sale in weekSales) {
            final subtotal = (sale['subtotal'] as num?)?.toDouble() ?? 0;
            final totalAmount = (sale['total_amount'] as num?)?.toDouble() ?? 0;
            final discountAmount = (sale['discount_amount'] as num?)?.toDouble() ?? 0;
            final paymentStatus = sale['payment_status']?.toString() ?? '';
            
            grossSales += subtotal;
            discounts += discountAmount;
            
            if (paymentStatus == 'refunded') {
              refunds += totalAmount;
            } else {
              netSales += totalAmount;
            }
          }
          
          final grossProfit = netSales * 0.3;
          
          data.add({
            'date': currentWeekStart,
            'grossSales': grossSales,
            'refunds': refunds,
            'discounts': discounts,
            'netSales': netSales,
            'grossProfit': grossProfit,
          });
          
          currentWeekStart = currentWeekStart.add(const Duration(days: 7));
        }
      } else {
        // Monthly data for longer periods
        DateTime currentMonth = DateTime(_startDate.year, _startDate.month, 1);
        while (currentMonth.isBefore(_endDate)) {
          final monthEnd = DateTime(currentMonth.year, currentMonth.month + 1, 0, 23, 59, 59);
          final actualMonthEnd = monthEnd.isAfter(_endDate) ? _endDate : monthEnd;
          final actualMonthStart = currentMonth.isBefore(_startDate) ? _startDate : currentMonth;
          
          final monthSales = await DatabaseService.getSales(
            storeId: _filterStoreId,
            employeeId: _filterEmployeeId,
            startDate: actualMonthStart,
            endDate: actualMonthEnd,
          );
          
          double grossSales = 0;
          double refunds = 0;
          double discounts = 0;
          double netSales = 0;
          
          for (var sale in monthSales) {
            final subtotal = (sale['subtotal'] as num?)?.toDouble() ?? 0;
            final totalAmount = (sale['total_amount'] as num?)?.toDouble() ?? 0;
            final discountAmount = (sale['discount_amount'] as num?)?.toDouble() ?? 0;
            final paymentStatus = sale['payment_status']?.toString() ?? '';
            
            grossSales += subtotal;
            discounts += discountAmount;
            
            if (paymentStatus == 'refunded') {
              refunds += totalAmount;
            } else {
              netSales += totalAmount;
            }
          }
          
          final grossProfit = netSales * 0.3;
          
          data.add({
            'date': currentMonth,
            'grossSales': grossSales,
            'refunds': refunds,
            'discounts': discounts,
            'netSales': netSales,
            'grossProfit': grossProfit,
          });
          
          currentMonth = DateTime(currentMonth.year, currentMonth.month + 1, 1);
        }
      }
      
      setState(() {
        _chartData = data;
      });
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error generating chart data: $e')),
        );
      }
    }
  }

  Future<void> _setDatePreset(String preset) async {
    DateTime start;
    DateTime end = DateTime.now();
    
    switch (preset) {
      case 'Today':
        start = DateTime(end.year, end.month, end.day);
        break;
      case 'Yesterday':
        start = DateTime(end.year, end.month, end.day - 1);
        end = DateTime(end.year, end.month, end.day - 1, 23, 59, 59);
        break;
      case 'Last 7 Days':
        start = end.subtract(const Duration(days: 7));
        break;
      case 'Last 30 Days':
        start = end.subtract(const Duration(days: 30));
        break;
      case 'This Month':
        start = DateTime(end.year, end.month, 1);
        break;
      case 'Last Month':
        start = DateTime(end.year, end.month - 1, 1);
        end = DateTime(end.year, end.month, 0, 23, 59, 59);
        break;
      default:
        start = end.subtract(const Duration(days: 7));
    }
    
    setState(() {
      _datePreset = preset;
      _startDate = start;
      _endDate = end;
    });
    
    await _loadSalesData();
  }

  @override
  Widget build(BuildContext context) {
    return BackOfficeLayout(
      title: 'Sales Summary',
      currentRoute: '/backoffice/sales-summary',
      child: _isLoading 
        ? const Center(child: CircularProgressIndicator())
        : SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _buildHeader(),
                const SizedBox(height: 24),
                _buildFilters(),
                const SizedBox(height: 24),
                _buildSummaryCards(),
                const SizedBox(height: 24),
                _buildChart(),
                const SizedBox(height: 24),
                _buildDataTable(),
              ],
            ),
          ),
    );
  }

  Widget _buildHeader() {
    return Row(
      children: [
        IconButton(
          onPressed: () => Navigator.of(context).pushReplacementNamed('/backoffice/dashboard'),
          icon: const Icon(Icons.arrow_back),
          tooltip: 'Back to Dashboard',
        ),
        const SizedBox(width: 8),
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Sales Summary',
              style: TextStyle(
                fontSize: 28,
                fontWeight: FontWeight.bold,
              ),
            ),
            Text(
              'Comprehensive sales analytics and reporting',
              style: TextStyle(
                fontSize: 14,
                color: Colors.grey.shade600,
              ),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildFilters() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.grey.shade50,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.grey.shade200),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Filters',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 16),
          
          // Date presets
          Wrap(
            spacing: 8,
            children: [
              'Today', 'Yesterday', 'Last 7 Days', 'Last 30 Days', 'This Month', 'Last Month'
            ].map((preset) => 
              FilterChip(
                label: Text(preset),
                selected: _datePreset == preset,
                onSelected: (selected) => selected ? _setDatePreset(preset) : null,
                selectedColor: Colors.blue.shade100,
              )
            ).toList(),
          ),
          
          const SizedBox(height: 16),
          
          // Custom date range and dropdowns
          Row(
            children: [
              Expanded(
                flex: 2,
                child: _buildDatePicker('Start Date', _startDate, (date) {
                  setState(() {
                    _startDate = date;
                    _datePreset = 'Custom';
                  });
                  _loadSalesData();
                }),
              ),
              const SizedBox(width: 16),
              Expanded(
                flex: 2,
                child: _buildDatePicker('End Date', _endDate, (date) {
                  setState(() {
                    _endDate = date;
                    _datePreset = 'Custom';
                  });
                  _loadSalesData();
                }),
              ),
              const SizedBox(width: 16),
              Expanded(
                flex: 2,
                child: DropdownButtonFormField<int?>(
                  initialValue: _filterStoreId,
                  decoration: const InputDecoration(
                    labelText: 'Store',
                    border: OutlineInputBorder(),
                    isDense: true,
                  ),
                  items: [
                    const DropdownMenuItem(value: null, child: Text('All Stores')),
                    ..._stores.map((store) => DropdownMenuItem(
                          value: store.id,
                          child: Text(store.name),
                        )),
                  ],
                  onChanged: (value) {
                    setState(() => _filterStoreId = value);
                    _loadSalesData();
                  },
                ),
              ),
              const SizedBox(width: 16),
              Expanded(
                flex: 2,
                child: DropdownButtonFormField<int?>(
                  initialValue: _filterEmployeeId,
                  decoration: const InputDecoration(
                    labelText: 'Employee',
                    border: OutlineInputBorder(),
                    isDense: true,
                  ),
                  items: [
                    const DropdownMenuItem(value: null, child: Text('All Employees')),
                    ..._employees.map((emp) => DropdownMenuItem(
                          value: emp.id,
                          child: Text(emp.name),
                        )),
                  ],
                  onChanged: (value) {
                    setState(() => _filterEmployeeId = value);
                    _loadSalesData();
                  },
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildDatePicker(String label, DateTime date, Function(DateTime) onDateSelected) {
    return InkWell(
      onTap: () async {
        final picked = await showDatePicker(
          context: context,
          initialDate: date,
          firstDate: DateTime(2020),
          lastDate: DateTime.now(),
        );
        if (picked != null) {
          onDateSelected(picked);
        }
      },
      child: InputDecorator(
        decoration: InputDecoration(
          labelText: label,
          border: const OutlineInputBorder(),
          isDense: true,
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(DateFormat('yyyy-MM-dd').format(date)),
            const Icon(Icons.calendar_today, size: 18),
          ],
        ),
      ),
    );
  }

  Widget _buildSummaryCards() {
    final currencyFormat = NumberFormat.currency(symbol: '\$');
    final metrics = [
      {'key': 'grossSales', 'title': 'Gross Sales', 'value': _grossSales, 'icon': Icons.trending_up, 'color': Colors.blue},
      {'key': 'refunds', 'title': 'Refunds', 'value': _refunds, 'icon': Icons.undo, 'color': Colors.red},
      {'key': 'discounts', 'title': 'Discounts', 'value': _discounts, 'icon': Icons.local_offer, 'color': Colors.orange},
      {'key': 'netSales', 'title': 'Net Sales', 'value': _netSales, 'icon': Icons.attach_money, 'color': Colors.green},
      {'key': 'grossProfit', 'title': 'Gross Profit', 'value': _grossProfit, 'icon': Icons.account_balance, 'color': Colors.purple},
    ];

    return LayoutBuilder(
      builder: (context, constraints) {
        final isSmallScreen = constraints.maxWidth < 600;
        final crossAxisCount = isSmallScreen ? 1 : (constraints.maxWidth < 1000 ? 3 : 5);
        
        return GridView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: crossAxisCount,
            crossAxisSpacing: 16,
            mainAxisSpacing: 16,
            childAspectRatio: isSmallScreen ? 5 : 3.2,
          ),
          itemCount: metrics.length,
          itemBuilder: (context, index) {
            final metric = metrics[index];
            final isSelected = _selectedMetric == metric['key'];
            
            return GestureDetector(
              onTap: () => setState(() => _selectedMetric = metric['key'] as String),
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 200),
                decoration: BoxDecoration(
                  color: isSelected ? (metric['color'] as Color).withOpacity(0.1) : Colors.white,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(
                    color: isSelected ? (metric['color'] as Color) : Colors.grey.shade200,
                    width: isSelected ? 2 : 1,
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.05),
                      blurRadius: 8,
                      offset: const Offset(0, 2),
                    ),
                  ],
                ),
                padding: const EdgeInsets.all(12),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.all(6),
                          decoration: BoxDecoration(
                            color: (metric['color'] as Color).withOpacity(0.1),
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: Icon(
                            metric['icon'] as IconData,
                            color: metric['color'] as Color,
                            size: 18,
                          ),
                        ),
                        const Spacer(),
                        if (isSelected)
                          Icon(
                            Icons.check_circle,
                            color: metric['color'] as Color,
                            size: 16,
                          ),
                      ],
                    ),
                    const SizedBox(height: 8),
                    Flexible(
                      child: Text(
                        metric['title'] as String,
                        style: TextStyle(
                          fontSize: 11,
                          color: Colors.grey.shade600,
                          fontWeight: FontWeight.w500,
                        ),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Flexible(
                      child: Text(
                        currencyFormat.format(metric['value']),
                        style: const TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                        ),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        );
      },
    );
  }

  Widget _buildChart() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.grey.shade200),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Text(
                '${_metricLabels[_selectedMetric]} Trend',
                style: const TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const Spacer(),
              
              // Chart type selector
              DropdownButton<String>(
                value: _chartType,
                items: ['Bar', 'Area'].map((type) => 
                  DropdownMenuItem(value: type, child: Text(type))
                ).toList(),
                onChanged: (value) => setState(() => _chartType = value ?? 'Bar'),
              ),
              const SizedBox(width: 16),
              
              // Time frame selector
              DropdownButton<String>(
                value: _timeFrame,
                items: ['Hours', 'Days', 'Weeks', 'Months', 'Quarters', 'Years'].map((frame) => 
                  DropdownMenuItem(value: frame, child: Text(frame))
                ).toList(),
                onChanged: (value) => setState(() => _timeFrame = value ?? 'Days'),
              ),
            ],
          ),
          const SizedBox(height: 24),
          
          // Mock chart placeholder
          Container(
            height: 300,
            decoration: BoxDecoration(
              color: Colors.grey.shade50,
              borderRadius: BorderRadius.circular(8),
            ),
            child: Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(
                    _chartType == 'Bar' ? Icons.bar_chart : Icons.area_chart,
                    size: 48,
                    color: _metricColors[_selectedMetric],
                  ),
                  const SizedBox(height: 8),
                  Text(
                    '${_metricLabels[_selectedMetric]} $_chartType Chart',
                    style: TextStyle(
                      fontSize: 16,
                      color: Colors.grey.shade600,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    'Time frame: $_timeFrame',
                    style: TextStyle(
                      fontSize: 12,
                      color: Colors.grey.shade500,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDataTable() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.grey.shade200),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Text(
                'Daily Breakdown',
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const Spacer(),
              
              // Column visibility toggle
              PopupMenuButton<String>(
                icon: const Icon(Icons.view_column),
                tooltip: 'Show/Hide Columns',
                itemBuilder: (context) => [
                  'Date', 'Gross Sales', 'Refunds', 'Discounts', 'Net Sales', 
                  'Cost of Goods', 'Gross Profit', 'Margin %'
                ].map((column) {
                  final key = column.toLowerCase().replaceAll(' ', '_').replaceAll('%', '');
                  return PopupMenuItem<String>(
                    value: key,
                    child: Row(
                      children: [
                        Checkbox(
                          value: _visibleColumns.contains(key),
                          onChanged: null,
                        ),
                        Text(column),
                      ],
                    ),
                  );
                }).toList(),
                onSelected: (value) {
                  setState(() {
                    if (_visibleColumns.contains(value)) {
                      _visibleColumns.remove(value);
                    } else {
                      _visibleColumns.add(value);
                    }
                  });
                },
              ),
              const SizedBox(width: 8),
              
              // Export button
              ElevatedButton.icon(
                onPressed: _exportTableData,
                icon: const Icon(Icons.download),
                label: const Text('Export'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.green,
                  foregroundColor: Colors.white,
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          
          // Data table
          if (_chartData.isNotEmpty)
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: DataTable(
                columns: _buildTableColumns(),
                rows: _buildTableRows(),
              ),
            )
          else
            const SizedBox(
              height: 200,
              child: Center(
                child: Text('No data available for the selected period'),
              ),
            ),
        ],
      ),
    );
  }

  List<DataColumn> _buildTableColumns() {
    final columns = <DataColumn>[];
    
    final columnConfig = {
      'date': 'Date',
      'gross_sales': 'Gross Sales',
      'refunds': 'Refunds',
      'discounts': 'Discounts',
      'net_sales': 'Net Sales',
      'cost_of_goods': 'Cost of Goods',
      'gross_profit': 'Gross Profit',
      'margin': 'Margin %',
    };
    
    for (final entry in columnConfig.entries) {
      if (_visibleColumns.contains(entry.key)) {
        columns.add(DataColumn(
          label: Text(
            entry.value,
            style: const TextStyle(fontWeight: FontWeight.bold),
          ),
        ));
      }
    }
    
    return columns;
  }

  List<DataRow> _buildTableRows() {
    final currencyFormat = NumberFormat.currency(symbol: '\$');
    
    return _chartData.map((data) {
      final cells = <DataCell>[];
      final date = data['date'] as DateTime;
      final grossSales = data['grossSales'] as double;
      final refunds = data['refunds'] as double;
      final discounts = data['discounts'] as double;
      final netSales = data['netSales'] as double;
      final costOfGoods = netSales * 0.7; // 70% placeholder
      final grossProfit = data['grossProfit'] as double;
      final margin = netSales > 0 ? grossProfit / netSales : 0;
      
      final values = {
        'date': DateFormat('MMM dd').format(date),
        'gross_sales': currencyFormat.format(grossSales),
        'refunds': currencyFormat.format(refunds),
        'discounts': currencyFormat.format(discounts),
        'net_sales': currencyFormat.format(netSales),
        'cost_of_goods': currencyFormat.format(costOfGoods),
        'gross_profit': currencyFormat.format(grossProfit),
        'margin': '${(margin * 100).toStringAsFixed(1)}%',
      };
      
      for (final entry in values.entries) {
        if (_visibleColumns.contains(entry.key)) {
          cells.add(DataCell(Text(entry.value)));
        }
      }
      
      return DataRow(cells: cells);
    }).toList();
  }

  void _exportTableData() {
    // Mock export functionality
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Export functionality - would export table data to CSV'),
        duration: Duration(seconds: 2),
      ),
    );
    print('Exporting table data...');
  }
}