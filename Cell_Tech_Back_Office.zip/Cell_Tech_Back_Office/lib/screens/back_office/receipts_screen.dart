import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../../services/database_service.dart';
import '../../models/store.dart';
import '../../models/employee.dart';
import '../../models/customer.dart';
import '../../widgets/back_office_layout.dart';
import '../../widgets/components/receipt_details_dialog.dart';
import 'dart:math' as math;

class ReceiptsScreen extends StatefulWidget {
  const ReceiptsScreen({super.key});

  @override
  State<ReceiptsScreen> createState() => _ReceiptsScreenState();
}

class _ReceiptsScreenState extends State<ReceiptsScreen> {
  List<Map<String, dynamic>> _receipts = [];
  List<Store> _stores = [];
  List<Employee> _employees = [];
  List<Customer> _customers = [];
  bool _isLoading = false;
  String _activeFilter = 'all';
  String _searchValue = '';

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  Future<void> _loadData() async {
    setState(() => _isLoading = true);
    
    try {
      // Load stores, employees, and customers
      final stores = await DatabaseService.getStores();
      final employees = await DatabaseService.getEmployees();
      final customers = await DatabaseService.getCustomers();
      
      setState(() {
        _stores = stores;
        _employees = employees;
        _customers = customers;
      });
      
      _generateMockReceiptData();
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error loading data: $e')),
        );
      }
    } finally {
      setState(() => _isLoading = false);
    }
  }

  void _generateMockReceiptData() {
    final random = math.Random();
    final now = DateTime.now();
    final receipts = <Map<String, dynamic>>[];

    final paymentMethods = ['Cash', 'Credit Card', 'Debit Card', 'Mobile Pay'];

    // Generate receipts for the last 30 days
    for (int i = 0; i < 50; i++) {
      final isRefund = random.nextDouble() < 0.15; // 15% chance of refund
      final saleDate = now.subtract(Duration(days: random.nextInt(30), hours: random.nextInt(12) + 8));
      final subtotal = 10.0 + random.nextDouble() * 200; // $10-$210
      final discountAmount = random.nextDouble() < 0.3 ? subtotal * (0.05 + random.nextDouble() * 0.15) : 0.0; // 30% chance of discount
      final taxAmount = (subtotal - discountAmount) * 0.08; // 8% tax
      final totalAmount = subtotal - discountAmount + taxAmount;
      
      final storeIndex = random.nextInt(math.max(1, _stores.length));
      final employeeIndex = random.nextInt(math.max(1, _employees.length));
      final hasCustomer = random.nextDouble() < 0.4; // 40% chance of having a customer
      final customerIndex = hasCustomer && _customers.isNotEmpty ? random.nextInt(_customers.length) : null;
      
      receipts.add({
        'id': i + 1,
        'receipt_number': 'R${now.year}${(1000 + i).toString().padLeft(4, '0')}',
        'store_id': _stores.isNotEmpty ? _stores[storeIndex].id : 1,
        'store_name': _stores.isNotEmpty ? _stores[storeIndex].name : 'Store ${storeIndex + 1}',
        'employee_id': _employees.isNotEmpty ? _employees[employeeIndex].id : 1,
        'employee_name': _employees.isNotEmpty ? _employees[employeeIndex].name : 'Employee ${employeeIndex + 1}',
        'customer_id': customerIndex != null ? _customers[customerIndex].id : null,
        'customer_name': customerIndex != null ? _customers[customerIndex].name : 'Walk-in Customer',
        'sale_date': saleDate,
        'transaction_type': isRefund ? 'refund' : 'sale',
        'payment_status': isRefund ? 'refunded' : 'completed',
        'subtotal': subtotal,
        'tax_amount': taxAmount,
        'discount_amount': discountAmount,
        'total_amount': isRefund ? -totalAmount : totalAmount,
        'payment_method': paymentMethods[random.nextInt(paymentMethods.length)],
        'notes': random.nextDouble() < 0.2 ? 'Customer requested receipt copy' : null,
        'created_at': saleDate,
      });
    }

    // Sort by sale date (newest first)
    receipts.sort((a, b) => (b['sale_date'] as DateTime).compareTo(a['sale_date'] as DateTime));

    setState(() {
      _receipts = receipts;
    });
  }

  void _handleViewReceipt(Map<String, dynamic> receipt) {
    final store = _stores.where((s) => s.id == receipt['store_id']).firstOrNull;
    final employee = _employees.where((e) => e.id == receipt['employee_id']).firstOrNull;
    
    showDialog(
      context: context,
      builder: (context) => ReceiptDetailsDialog(
        receipt: receipt,
        store: store,
        employee: employee,
        customerName: receipt['customer_name'],
      ),
    );
  }

  List<Map<String, dynamic>> get _filteredReceipts {
    return _receipts.where((receipt) {
      // Filter by type
      final matchesFilter = _activeFilter == 'all' || 
                           (_activeFilter == 'sales' && receipt['transaction_type'] != 'refund' && receipt['payment_status'] != 'refunded') ||
                           (_activeFilter == 'refunds' && (receipt['transaction_type'] == 'refund' || receipt['payment_status'] == 'refunded'));
      
      // Filter by search
      final matchesSearch = _searchValue.isEmpty || 
                           (receipt['receipt_number'] as String).toLowerCase().contains(_searchValue.toLowerCase()) ||
                           (receipt['customer_name'] as String).toLowerCase().contains(_searchValue.toLowerCase());
      
      return matchesFilter && matchesSearch;
    }).toList();
  }

  Map<String, int> get _receiptCounts {
    return {
      'all': _receipts.length,
      'sales': _receipts.where((r) => r['transaction_type'] != 'refund' && r['payment_status'] != 'refunded').length,
      'refunds': _receipts.where((r) => r['transaction_type'] == 'refund' || r['payment_status'] == 'refunded').length,
    };
  }

  void _exportData() {
    // Mock export functionality
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Export functionality - would export receipt data to CSV/Excel'),
        duration: Duration(seconds: 2),
      ),
    );
    print('Exporting receipt data...');
  }

  @override
  Widget build(BuildContext context) {
    return BackOfficeLayout(
      title: 'Receipts',
      currentRoute: '/backoffice/receipts',
      child: _isLoading 
        ? const Center(child: CircularProgressIndicator())
        : SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _buildHeader(),
                const SizedBox(height: 24),
                _buildReceiptTypeCards(),
                const SizedBox(height: 24),
                _buildSearch(),
                const SizedBox(height: 24),
                _buildReceiptsTable(),
              ],
            ),
          ),
    );
  }

  Widget _buildHeader() {
    return Row(
      children: [
        IconButton(
          onPressed: () => Navigator.of(context).pushReplacementNamed('/backoffice/dashboard'),
          icon: const Icon(Icons.arrow_back),
          tooltip: 'Back to Dashboard',
        ),
        const SizedBox(width: 8),
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Receipts',
              style: TextStyle(
                fontSize: 28,
                fontWeight: FontWeight.bold,
              ),
            ),
            Text(
              'Receipt management and transaction history',
              style: TextStyle(
                fontSize: 14,
                color: Colors.grey.shade600,
              ),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildReceiptTypeCards() {
    final cards = [
      {'title': 'All Receipts', 'count': _receiptCounts['all']!, 'key': 'all', 'color': Colors.blue, 'icon': Icons.receipt},
      {'title': 'Sales', 'count': _receiptCounts['sales']!, 'key': 'sales', 'color': Colors.green, 'icon': Icons.receipt},
      {'title': 'Refunds', 'count': _receiptCounts['refunds']!, 'key': 'refunds', 'color': Colors.red, 'icon': Icons.undo},
    ];

    return LayoutBuilder(
      builder: (context, constraints) {
        final isSmallScreen = constraints.maxWidth < 600;
        final crossAxisCount = isSmallScreen ? 1 : 3;
        
        return GridView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: crossAxisCount,
            crossAxisSpacing: 16,
            mainAxisSpacing: 16,
            childAspectRatio: isSmallScreen ? 4 : 3.5,
          ),
          itemCount: cards.length,
          itemBuilder: (context, index) {
            final card = cards[index];
            final isSelected = _activeFilter == card['key'];
            
            return GestureDetector(
              onTap: () => setState(() => _activeFilter = card['key'] as String),
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 200),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(
                    color: isSelected ? (card['color'] as Color) : Colors.grey.shade200,
                    width: isSelected ? 2 : 1,
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.05),
                      blurRadius: 8,
                      offset: const Offset(0, 2),
                    ),
                  ],
                ),
                padding: const EdgeInsets.all(20),
                child: Row(
                  children: [
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text(
                            card['title'] as String,
                            style: TextStyle(
                              fontSize: 14,
                              color: Colors.grey.shade600,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                          const SizedBox(height: 8),
                          Text(
                            (card['count'] as int).toString(),
                            style: const TextStyle(
                              fontSize: 28,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: (card['color'] as Color).withOpacity(0.1),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Icon(
                        card['icon'] as IconData,
                        color: card['color'] as Color,
                        size: 24,
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        );
      },
    );
  }

  Widget _buildSearch() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.grey.shade200),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: TextField(
        onChanged: (value) => setState(() => _searchValue = value),
        decoration: InputDecoration(
          hintText: 'Search by Receipt No. or Customer...',
          prefixIcon: const Icon(Icons.search),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(8),
            borderSide: BorderSide(color: Colors.grey.shade300),
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(8),
            borderSide: BorderSide(color: Colors.grey.shade300),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(8),
            borderSide: BorderSide(color: Colors.blue.shade400),
          ),
        ),
      ),
    );
  }

  Widget _buildReceiptsTable() {
    final filteredReceipts = _filteredReceipts;
    final filterTitle = _activeFilter == 'all' ? 'All' : _activeFilter == 'sales' ? 'Sales' : 'Refund';

    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.grey.shade200),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Text(
                '$filterTitle Receipts',
                style: const TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const Spacer(),
              ElevatedButton.icon(
                onPressed: _exportData,
                icon: const Icon(Icons.download),
                label: const Text('Export'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.green,
                  foregroundColor: Colors.white,
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          
          if (filteredReceipts.isNotEmpty)
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: ConstrainedBox(
                constraints: BoxConstraints(
                  minWidth: MediaQuery.of(context).size.width - 88, // Account for padding
                ),
                child: DataTable(
                  columns: const [
                    DataColumn(label: Text('Receipt No.', style: TextStyle(fontWeight: FontWeight.bold))),
                    DataColumn(label: Text('Date', style: TextStyle(fontWeight: FontWeight.bold))),
                    DataColumn(label: Text('Store', style: TextStyle(fontWeight: FontWeight.bold))),
                    DataColumn(label: Text('Employee', style: TextStyle(fontWeight: FontWeight.bold))),
                    DataColumn(label: Text('Customer', style: TextStyle(fontWeight: FontWeight.bold))),
                    DataColumn(label: Text('Type', style: TextStyle(fontWeight: FontWeight.bold))),
                    DataColumn(label: Text('Total', style: TextStyle(fontWeight: FontWeight.bold)), numeric: true),
                    DataColumn(label: Text('Actions', style: TextStyle(fontWeight: FontWeight.bold))),
                  ],
                  rows: filteredReceipts.map((receipt) {
                    final dateFormat = DateFormat('MMM dd, yyyy HH:mm');
                    final currencyFormat = NumberFormat.currency(symbol: '\$');
                    final isRefund = receipt['transaction_type'] == 'refund' || receipt['payment_status'] == 'refunded';
                    
                    return DataRow(
                      cells: [
                        DataCell(
                          Text(
                            receipt['receipt_number'],
                            style: const TextStyle(fontWeight: FontWeight.w500),
                          ),
                        ),
                        DataCell(Text(dateFormat.format(receipt['sale_date']))),
                        DataCell(Text(receipt['store_name'])),
                        DataCell(Text(receipt['employee_name'])),
                        DataCell(
                          Text(
                            receipt['customer_name'],
                            style: TextStyle(
                              fontStyle: receipt['customer_name'] == 'Walk-in Customer' 
                                  ? FontStyle.italic 
                                  : FontStyle.normal,
                            ),
                          ),
                        ),
                        DataCell(
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                            decoration: BoxDecoration(
                              color: isRefund ? Colors.red.shade100 : Colors.green.shade100,
                              borderRadius: BorderRadius.circular(12),
                            ),
                            child: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Icon(
                                  isRefund ? Icons.undo : Icons.receipt,
                                  size: 14,
                                  color: isRefund ? Colors.red.shade700 : Colors.green.shade700,
                                ),
                                const SizedBox(width: 4),
                                Text(
                                  isRefund ? 'Refund' : 'Sale',
                                  style: TextStyle(
                                    fontSize: 12,
                                    fontWeight: FontWeight.w600,
                                    color: isRefund ? Colors.red.shade700 : Colors.green.shade700,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        DataCell(
                          Text(
                            '${isRefund ? '-' : ''}${currencyFormat.format((receipt['total_amount'] as double).abs())}',
                            style: TextStyle(
                              fontWeight: FontWeight.w600,
                              color: isRefund ? Colors.red.shade600 : Colors.green.shade600,
                            ),
                          ),
                        ),
                        DataCell(
                          IconButton(
                            onPressed: () => _handleViewReceipt(receipt),
                            icon: const Icon(Icons.visibility),
                            tooltip: 'View Receipt',
                            style: IconButton.styleFrom(
                              backgroundColor: Colors.blue.shade50,
                              foregroundColor: Colors.blue.shade600,
                            ),
                          ),
                        ),
                      ],
                    );
                  }).toList(),
                ),
              ),
            )
          else
            SizedBox(
              height: 200,
              child: Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(
                      Icons.receipt_long,
                      size: 48,
                      color: Colors.grey.shade400,
                    ),
                    const SizedBox(height: 16),
                    Text(
                      'No receipts found',
                      style: TextStyle(
                        fontSize: 16,
                        color: Colors.grey.shade600,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      _searchValue.isNotEmpty 
                          ? 'Try adjusting your search criteria'
                          : 'No receipts available for the selected filter',
                      style: TextStyle(
                        fontSize: 14,
                        color: Colors.grey.shade500,
                      ),
                    ),
                  ],
                ),
              ),
            ),
        ],
      ),
    );
  }
}