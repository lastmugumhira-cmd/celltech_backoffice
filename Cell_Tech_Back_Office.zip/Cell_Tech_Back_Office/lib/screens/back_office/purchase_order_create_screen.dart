import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../services/database_service.dart';
import '../../models/supplier.dart';
import '../../models/store.dart';
import '../../models/product.dart';
import '../../models/purchase_order.dart';
import '../../models/purchase_order_item.dart';
import '../../widgets/back_office_layout.dart';
import '../../main.dart';

class PurchaseOrderCreateScreen extends StatefulWidget {
  const PurchaseOrderCreateScreen({super.key});

  @override
  State<PurchaseOrderCreateScreen> createState() =>
      _PurchaseOrderCreateScreenState();
}

class _PurchaseOrderCreateScreenState extends State<PurchaseOrderCreateScreen> {
  final _formKey = GlobalKey<FormState>();
  List<Supplier> _suppliers = [];
  List<Store> _stores = [];
  List<Product> _products = [];
  bool _isLoading = true;

  int? _selectedSupplierId;
  final Set<int> _selectedStores = {};
  DateTime? _expectedDeliveryDate;
  final TextEditingController _notesController = TextEditingController();

  final List<Map<String, dynamic>> _items = [];
  String _searchQuery = '';

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  @override
  void dispose() {
    _notesController.dispose();
    super.dispose();
  }

  Future<void> _loadData() async {
    setState(() => _isLoading = true);
    try {
      final suppliers = await DatabaseService.getSuppliers(activeOnly: true);
      final stores = await DatabaseService.getStores();
      final products = await DatabaseService.getProducts();

      setState(() {
        _suppliers = suppliers;
        _stores = stores;
        _products = products;
        _isLoading = false;
      });
    } catch (e) {
      setState(() => _isLoading = false);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error loading data: $e')),
        );
      }
    }
  }

  void _addItem(Product product) {
    setState(() {
      _items.add({
        'product_id': product.id,
        'product_name': product.name,
        'sku': product.sku,
        'quantity': 1,
        'unit_cost': product.cost ?? 0.0,
      });
    });
  }

  void _removeItem(int index) {
    setState(() {
      _items.removeAt(index);
    });
  }

  void _updateItemQuantity(int index, int quantity) {
    setState(() {
      _items[index]['quantity'] = quantity;
    });
  }

  void _updateItemCost(int index, double cost) {
    setState(() {
      _items[index]['unit_cost'] = cost;
    });
  }

  double get _totalAmount {
    return _items.fold(
        0.0,
        (sum, item) =>
            sum + (item['quantity'] as int) * (item['unit_cost'] as double));
  }

  Future<void> _savePurchaseOrder(String status) async {
    if (!_formKey.currentState!.validate()) return;
    if (_items.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please add at least one item')),
      );
      return;
    }

    try {
      final appState = Provider.of<AppState>(context, listen: false);
      final now = DateTime.now();
      final poNumber =
          'PO-${now.year}${now.month.toString().padLeft(2, '0')}${now.day.toString().padLeft(2, '0')}-${now.millisecondsSinceEpoch % 10000}';

      final po = PurchaseOrder(
        poNumber: poNumber,
        supplierId: _selectedSupplierId,
        status: status,
        destinationStores: _selectedStores.toList(),
        expectedDeliveryDate: _expectedDeliveryDate,
        totalAmount: _totalAmount,
        notes: _notesController.text.isEmpty ? null : _notesController.text,
        createdBy: appState.currentEmployee?.id,
        createdAt: now,
      );

      final items = _items
          .map((item) => PurchaseOrderItem(
                purchaseOrderId: 0, // Will be set by database
                productId: item['product_id'],
                quantity: item['quantity'],
                unitCost: item['unit_cost'],
                totalCost: item['quantity'] * item['unit_cost'],
              ))
          .toList();

      await DatabaseService.insertPurchaseOrder(po, items);

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
              content: Text('Purchase order $poNumber created successfully')),
        );
        Navigator.pop(context);
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error creating purchase order: $e')),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return BackOfficeLayout(
      title: 'Create Purchase Order',
      currentRoute: '/backoffice/inventory/purchase-orders/create',
      child: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : _buildContent(),
    );
  }

  Widget _buildContent() {
    return Container(
      padding: const EdgeInsets.all(24),
      child: Form(
        key: _formKey,
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Expanded(
              flex: 2,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _buildPODetails(),
                  const SizedBox(height: 24),
                  Expanded(child: _buildItemsList()),
                  const SizedBox(height: 16),
                  _buildTotalSection(),
                ],
              ),
            ),
            const SizedBox(width: 24),
            Expanded(
              child: _buildProductSearch(),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildPODetails() {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Purchase Order Details',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 16),
            DropdownButtonFormField<int>(
              initialValue: _selectedSupplierId,
              decoration: const InputDecoration(
                labelText: 'Supplier',
                border: OutlineInputBorder(),
              ),
              items: _suppliers
                  .map((supplier) => DropdownMenuItem(
                        value: supplier.id,
                        child: Text(supplier.name),
                      ))
                  .toList(),
              onChanged: (value) => setState(() => _selectedSupplierId = value),
            ),
            const SizedBox(height: 16),
            const Text('Destination Stores:',
                style: TextStyle(fontWeight: FontWeight.w500)),
            const SizedBox(height: 8),
            Wrap(
              spacing: 8,
              children: _stores
                  .map((store) => FilterChip(
                        label: Text(store.name),
                        selected: _selectedStores.contains(store.id),
                        onSelected: (selected) {
                          setState(() {
                            if (selected) {
                              _selectedStores.add(store.id!);
                            } else {
                              _selectedStores.remove(store.id);
                            }
                          });
                        },
                      ))
                  .toList(),
            ),
            const SizedBox(height: 16),
            InkWell(
              onTap: () async {
                final date = await showDatePicker(
                  context: context,
                  initialDate: DateTime.now(),
                  firstDate: DateTime.now(),
                  lastDate: DateTime.now().add(const Duration(days: 365)),
                );
                if (date != null) {
                  setState(() => _expectedDeliveryDate = date);
                }
              },
              child: InputDecorator(
                decoration: const InputDecoration(
                  labelText: 'Expected Delivery Date',
                  border: OutlineInputBorder(),
                ),
                child: Text(
                  _expectedDeliveryDate != null
                      ? '${_expectedDeliveryDate!.day}/${_expectedDeliveryDate!.month}/${_expectedDeliveryDate!.year}'
                      : 'Select date',
                ),
              ),
            ),
            const SizedBox(height: 16),
            TextField(
              controller: _notesController,
              decoration: const InputDecoration(
                labelText: 'Notes',
                border: OutlineInputBorder(),
              ),
              maxLines: 3,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildItemsList() {
    return Card(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Padding(
            padding: EdgeInsets.all(20),
            child: Text(
              'Items',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
          const Divider(height: 1),
          Expanded(
            child: _items.isEmpty
                ? const Center(
                    child: Text(
                      'No items added yet. Search and add products from the right panel.',
                      style: TextStyle(color: Colors.grey),
                    ),
                  )
                : ListView.builder(
                    itemCount: _items.length,
                    itemBuilder: (context, index) {
                      final item = _items[index];
                      return ListTile(
                        title: Text(item['product_name']),
                        subtitle: Text('SKU: ${item['sku']}'),
                        trailing: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            SizedBox(
                              width: 80,
                              child: TextField(
                                decoration: const InputDecoration(
                                  labelText: 'Qty',
                                  border: OutlineInputBorder(),
                                  contentPadding: EdgeInsets.all(8),
                                ),
                                keyboardType: TextInputType.number,
                                controller: TextEditingController(
                                  text: item['quantity'].toString(),
                                ),
                                onChanged: (value) {
                                  final qty = int.tryParse(value) ?? 1;
                                  _updateItemQuantity(index, qty);
                                },
                              ),
                            ),
                            const SizedBox(width: 8),
                            SizedBox(
                              width: 100,
                              child: TextField(
                                decoration: const InputDecoration(
                                  labelText: 'Cost',
                                  border: OutlineInputBorder(),
                                  contentPadding: EdgeInsets.all(8),
                                  prefixText: '\$',
                                ),
                                keyboardType: TextInputType.number,
                                controller: TextEditingController(
                                  text: item['unit_cost'].toStringAsFixed(2),
                                ),
                                onChanged: (value) {
                                  final cost = double.tryParse(value) ?? 0.0;
                                  _updateItemCost(index, cost);
                                },
                              ),
                            ),
                            const SizedBox(width: 8),
                            Text(
                              '\$${(item['quantity'] * item['unit_cost']).toStringAsFixed(2)}',
                              style:
                                  const TextStyle(fontWeight: FontWeight.bold),
                            ),
                            IconButton(
                              onPressed: () => _removeItem(index),
                              icon: const Icon(Icons.delete, color: Colors.red),
                            ),
                          ],
                        ),
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }

  Widget _buildTotalSection() {
    return Card(
      color: Colors.grey[100],
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            const Text(
              'Total Amount:',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
            Text(
              '\$${_totalAmount.toStringAsFixed(2)}',
              style: const TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
                color: Color(0xFFFF8C00),
              ),
            ),
            Row(
              children: [
                OutlinedButton(
                  onPressed: () => _savePurchaseOrder('draft'),
                  child: const Text('Save as Draft'),
                ),
                const SizedBox(width: 8),
                ElevatedButton(
                  onPressed: () => _savePurchaseOrder('pending'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFFFF8C00),
                    foregroundColor: Colors.white,
                  ),
                  child: const Text('Create PO'),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildProductSearch() {
    final filteredProducts = _products
        .where((p) =>
            _searchQuery.isEmpty ||
            p.name.toLowerCase().contains(_searchQuery.toLowerCase()) ||
            p.sku.toLowerCase().contains(_searchQuery.toLowerCase()))
        .toList();

    return Card(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Padding(
            padding: EdgeInsets.all(20),
            child: Text(
              'Add Products',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: TextField(
              decoration: const InputDecoration(
                hintText: 'Search products...',
                prefixIcon: Icon(Icons.search),
                border: OutlineInputBorder(),
              ),
              onChanged: (value) => setState(() => _searchQuery = value),
            ),
          ),
          const SizedBox(height: 16),
          Expanded(
            child: ListView.builder(
              itemCount: filteredProducts.length,
              itemBuilder: (context, index) {
                final product = filteredProducts[index];
                final isAdded =
                    _items.any((item) => item['product_id'] == product.id);

                return ListTile(
                  title: Text(product.name),
                  subtitle: Text(
                      'SKU: ${product.sku} | Cost: \$${(product.cost ?? 0).toStringAsFixed(2)}'),
                  trailing: isAdded
                      ? const Icon(Icons.check, color: Colors.green)
                      : IconButton(
                          onPressed: () => _addItem(product),
                          icon: const Icon(Icons.add_circle,
                              color: Color(0xFFFF8C00)),
                        ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
