import 'package:flutter/material.dart';
import 'dart:convert';
import 'package:crypto/crypto.dart';
import '../../services/database_service.dart';
import '../../models/employee.dart';
import '../../models/store.dart';
import '../../widgets/back_office_layout.dart';

class EmployeesScreen extends StatefulWidget {
  const EmployeesScreen({super.key});

  @override
  State<EmployeesScreen> createState() => _EmployeesScreenState();
}

class _EmployeesScreenState extends State<EmployeesScreen> {
  List<Employee> _employees = [];
  List<Store> _stores = [];
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  Future<void> _loadData() async {
    setState(() => _isLoading = true);
    try {
      final employees = await DatabaseService.getEmployees();
      final stores = await DatabaseService.getStores();
      setState(() {
        _employees = employees;
        _stores = stores;
        _isLoading = false;
      });
    } catch (e) {
      setState(() => _isLoading = false);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error loading data: $e')),
        );
      }
    }
  }

  String _hashPassword(String password) {
    final bytes = utf8.encode(password);
    final digest = sha256.convert(bytes);
    return digest.toString();
  }

  @override
  Widget build(BuildContext context) {
    return BackOfficeLayout(
      title: 'Employees Management',
      currentRoute: '/backoffice/employees',
      child: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : _buildContent(),
    );
  }

  Widget _buildContent() {
    return Column(
      children: [
        _buildToolbar(),
        Expanded(child: _buildEmployeesTable()),
      ],
    );
  }

  Widget _buildToolbar() {
    return Container(
      padding: const EdgeInsets.all(16),
      color: Colors.grey.shade50,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          const Text(
            'Manage Employees',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          ElevatedButton.icon(
            onPressed: () => _showAddEditDialog(null),
            icon: const Icon(Icons.add),
            label: const Text('Add Employee'),
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.blue,
              foregroundColor: Colors.white,
              padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 24),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildEmployeesTable() {
    if (_employees.isEmpty) {
      return const Center(child: Text('No employees found'));
    }

    return SingleChildScrollView(
      child: SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        child: DataTable(
          columns: const [
            DataColumn(label: Text('Name', style: TextStyle(fontWeight: FontWeight.bold))),
            DataColumn(label: Text('Email', style: TextStyle(fontWeight: FontWeight.bold))),
            DataColumn(label: Text('Phone', style: TextStyle(fontWeight: FontWeight.bold))),
            DataColumn(label: Text('Username', style: TextStyle(fontWeight: FontWeight.bold))),
            DataColumn(label: Text('PIN', style: TextStyle(fontWeight: FontWeight.bold))),
            DataColumn(label: Text('Role', style: TextStyle(fontWeight: FontWeight.bold))),
            DataColumn(label: Text('Status', style: TextStyle(fontWeight: FontWeight.bold))),
            DataColumn(label: Text('Actions', style: TextStyle(fontWeight: FontWeight.bold))),
          ],
          rows: _employees.map((employee) {
            return DataRow(
              cells: [
                DataCell(Text(employee.name)),
                DataCell(Text(employee.email)),
                DataCell(Text(employee.phone)),
                DataCell(Text(employee.username)),
                DataCell(Text(employee.pin)),
                DataCell(
                  Chip(
                    label: Text(employee.role),
                    backgroundColor: _getRoleColor(employee.role),
                    labelStyle: const TextStyle(color: Colors.white),
                  ),
                ),
                DataCell(
                  Chip(
                    label: Text(employee.active ? 'Active' : 'Inactive'),
                    backgroundColor: employee.active ? Colors.green : Colors.grey,
                    labelStyle: const TextStyle(color: Colors.white),
                  ),
                ),
                DataCell(
                  Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      IconButton(
                        icon: const Icon(Icons.edit, color: Colors.blue),
                        onPressed: () => _showAddEditDialog(employee),
                        tooltip: 'Edit Employee',
                      ),
                      IconButton(
                        icon: const Icon(Icons.delete, color: Colors.red),
                        onPressed: () => _showDeleteConfirmDialog(employee),
                        tooltip: 'Delete Employee',
                      ),
                    ],
                  ),
                ),
              ],
            );
          }).toList(),
        ),
      ),
    );
  }

  Color _getRoleColor(String role) {
    switch (role) {
      case 'Administrator':
        return Colors.red;
      case 'Manager':
        return Colors.orange;
      case 'Cashier':
        return Colors.green;
      default:
        return Colors.grey;
    }
  }

  Future<void> _showAddEditDialog(Employee? employee) async {
    final isEdit = employee != null;
    final nameController = TextEditingController(text: employee?.name ?? '');
    final emailController = TextEditingController(text: employee?.email ?? '');
    final phoneController = TextEditingController(text: employee?.phone ?? '');
    final usernameController = TextEditingController(text: employee?.username ?? '');
    final passwordController = TextEditingController();
    final pinController = TextEditingController(text: employee?.pin ?? '');
    String selectedRole = employee?.role ?? 'Cashier';
    bool active = employee?.active ?? true;
    List<int> selectedStores = employee != null
        ? (jsonDecode(employee.assignedStoreIds) as List).cast<int>()
        : [];

    final result = await showDialog<bool>(
      context: context,
      builder: (context) => StatefulBuilder(
        builder: (context, setDialogState) => AlertDialog(
          title: Text(isEdit ? 'Edit Employee' : 'Add Employee'),
          content: SizedBox(
            width: 500,
            child: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  TextField(
                    controller: nameController,
                    decoration: const InputDecoration(
                      labelText: 'Full Name *',
                      border: OutlineInputBorder(),
                    ),
                  ),
                  const SizedBox(height: 16),
                  TextField(
                    controller: emailController,
                    decoration: const InputDecoration(
                      labelText: 'Email *',
                      border: OutlineInputBorder(),
                    ),
                  ),
                  const SizedBox(height: 16),
                  TextField(
                    controller: phoneController,
                    decoration: const InputDecoration(
                      labelText: 'Phone *',
                      border: OutlineInputBorder(),
                    ),
                  ),
                  const SizedBox(height: 16),
                  TextField(
                    controller: usernameController,
                    decoration: const InputDecoration(
                      labelText: 'Username *',
                      border: OutlineInputBorder(),
                    ),
                  ),
                  const SizedBox(height: 16),
                  TextField(
                    controller: passwordController,
                    obscureText: true,
                    decoration: InputDecoration(
                      labelText: isEdit ? 'Password (leave blank to keep current)' : 'Password *',
                      border: const OutlineInputBorder(),
                    ),
                  ),
                  const SizedBox(height: 16),
                  TextField(
                    controller: pinController,
                    decoration: const InputDecoration(
                      labelText: '4-Digit PIN *',
                      border: OutlineInputBorder(),
                    ),
                    maxLength: 4,
                    keyboardType: TextInputType.number,
                  ),
                  const SizedBox(height: 16),
                  DropdownButtonFormField<String>(
                    initialValue: selectedRole,
                    decoration: const InputDecoration(
                      labelText: 'Role *',
                      border: OutlineInputBorder(),
                    ),
                    items: const [
                      DropdownMenuItem(value: 'Administrator', child: Text('Administrator')),
                      DropdownMenuItem(value: 'Manager', child: Text('Manager')),
                      DropdownMenuItem(value: 'Cashier', child: Text('Cashier')),
                    ],
                    onChanged: (value) {
                      setDialogState(() => selectedRole = value!);
                    },
                  ),
                  const SizedBox(height: 16),
                  const Text('Assigned Stores:', style: TextStyle(fontWeight: FontWeight.bold)),
                  const SizedBox(height: 8),
                  ..._stores.map((store) {
                    final isSelected = selectedStores.contains(store.id);
                    return CheckboxListTile(
                      title: Text(store.name),
                      value: isSelected,
                      onChanged: (value) {
                        setDialogState(() {
                          if (value == true) {
                            selectedStores.add(store.id!);
                          } else {
                            selectedStores.remove(store.id);
                          }
                        });
                      },
                    );
                  }),
                  const SizedBox(height: 16),
                  SwitchListTile(
                    title: const Text('Active'),
                    value: active,
                    onChanged: (value) {
                      setDialogState(() => active = value);
                    },
                  ),
                ],
              ),
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context, false),
              child: const Text('Cancel'),
            ),
            ElevatedButton(
              onPressed: () async {
                if (nameController.text.isEmpty ||
                    emailController.text.isEmpty ||
                    phoneController.text.isEmpty ||
                    usernameController.text.isEmpty ||
                    (!isEdit && passwordController.text.isEmpty) ||
                    pinController.text.isEmpty ||
                    pinController.text.length != 4) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('Please fill all required fields')),
                  );
                  return;
                }

                final passwordHash = isEdit && passwordController.text.isEmpty
                    ? employee.passwordHash
                    : _hashPassword(passwordController.text);

                final newEmployee = Employee(
                  id: employee?.id,
                  name: nameController.text,
                  email: emailController.text,
                  phone: phoneController.text,
                  username: usernameController.text,
                  passwordHash: passwordHash,
                  pin: pinController.text,
                  role: selectedRole,
                  assignedStoreIds: jsonEncode(selectedStores),
                  active: active,
                );

                try {
                  if (isEdit) {
                    await DatabaseService.updateEmployee(newEmployee);
                  } else {
                    await DatabaseService.insertEmployee(newEmployee);
                  }
                  Navigator.pop(context, true);
                } catch (e) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text('Error: $e')),
                  );
                }
              },
              child: Text(isEdit ? 'Update' : 'Add'),
            ),
          ],
        ),
      ),
    );

    if (result == true) {
      _loadData();
    }
  }

  Future<void> _showDeleteConfirmDialog(Employee employee) async {
    final result = await showDialog<bool>(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        title: const Text('Delete Employee'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Are you sure you want to delete "${employee.name}"?'),
            const SizedBox(height: 16),
            const Text(
              'This action will also:',
              style: TextStyle(fontWeight: FontWeight.bold),
            ),
            const Text('• Remove this employee as manager from any stores'),
            const SizedBox(height: 8),
            const Text(
              'This action cannot be undone.',
              style: TextStyle(color: Colors.red, fontWeight: FontWeight.bold),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context, true),
            style: TextButton.styleFrom(foregroundColor: Colors.red),
            child: const Text('Delete'),
          ),
        ],
      ),
    );

    if (result == true && mounted) {
      try {
        await DatabaseService.deleteEmployee(employee.id!);
        _loadData(); // Refresh the employees list
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Employee "${employee.name}" deleted successfully')),
        );
      } catch (e) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error deleting employee: $e')),
        );
      }
    }
  }
}
