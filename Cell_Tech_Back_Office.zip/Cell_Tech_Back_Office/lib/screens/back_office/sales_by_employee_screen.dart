import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../../services/database_service.dart';
import '../../models/store.dart';
import '../../models/employee.dart';
import '../../widgets/back_office_layout.dart';
import '../../utils/responsive_utils.dart';

class SalesByEmployeeScreen extends StatefulWidget {
  const SalesByEmployeeScreen({super.key});

  @override
  State<SalesByEmployeeScreen> createState() => _SalesByEmployeeScreenState();
}

class _SalesByEmployeeScreenState extends State<SalesByEmployeeScreen> {
  List<Store> _stores = [];
  List<Employee> _employees = [];
  List<Map<String, dynamic>> _employeeData = [];
  bool _isLoading = false;

  // Filters
  DateTime _startDate = DateTime.now().subtract(const Duration(days: 7));
  DateTime _endDate = DateTime.now();
  int? _selectedStoreId;
  String _period = 'Last 7 Days';

  // Column visibility controls
  final Set<String> _visibleColumns = {
    'employee_name',
    'gross_sales',
    'net_sales',
    'receipts',
    'average_sale',
  };

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  Future<void> _loadData() async {
    setState(() => _isLoading = true);
    
    try {
      final stores = await DatabaseService.getStores();
      final employees = await DatabaseService.getEmployees();
      
      setState(() {
        _stores = stores;
        _employees = employees;
      });
      
      await _loadEmployeeData();
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error loading data: $e')),
        );
      }
    } finally {
      setState(() => _isLoading = false);
    }
  }

  Future<void> _loadEmployeeData() async {
    try {
      final data = await DatabaseService.getSalesByEmployee(
        startDate: _startDate,
        endDate: _endDate,
        storeId: _selectedStoreId,
      );
      
      setState(() {
        _employeeData = data;
      });
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error loading employee data: $e')),
        );
      }
    }
  }

  Future<void> _selectDateRange() async {
    final picked = await showDateRangePicker(
      context: context,
      firstDate: DateTime.now().subtract(const Duration(days: 365)),
      lastDate: DateTime.now(),
      initialDateRange: DateTimeRange(start: _startDate, end: _endDate),
    );
    
    if (picked != null) {
      setState(() {
        _startDate = picked.start;
        _endDate = picked.end;
        _period = 'Custom';
      });
      _loadEmployeeData();
    }
  }

  void _applyDatePreset(String preset) {
    final now = DateTime.now();
    switch (preset) {
      case 'Today':
        _startDate = DateTime(now.year, now.month, now.day);
        _endDate = now;
        break;
      case 'Yesterday':
        final yesterday = now.subtract(const Duration(days: 1));
        _startDate = DateTime(yesterday.year, yesterday.month, yesterday.day);
        _endDate = DateTime(yesterday.year, yesterday.month, yesterday.day, 23, 59, 59);
        break;
      case 'Last 7 Days':
        _startDate = now.subtract(const Duration(days: 7));
        _endDate = now;
        break;
      case 'Last 30 Days':
        _startDate = now.subtract(const Duration(days: 30));
        _endDate = now;
        break;
      case 'This Month':
        _startDate = DateTime(now.year, now.month, 1);
        _endDate = now;
        break;
    }
    
    setState(() {
      _period = preset;
    });
    _loadEmployeeData();
  }

  Map<String, dynamic> _calculateTotals() {
    if (_employeeData.isEmpty) {
      return {
        'gross_sales': 0.0,
        'refunds': 0.0,
        'discounts': 0.0,
        'net_sales': 0.0,
        'receipts': 0,
        'customers_signed_up': 0,
      };
    }

    return _employeeData.fold<Map<String, dynamic>>(
      {
        'gross_sales': 0.0,
        'refunds': 0.0,
        'discounts': 0.0,
        'net_sales': 0.0,
        'receipts': 0,
        'customers_signed_up': 0,
      },
      (totals, employee) => {
        'gross_sales': totals['gross_sales'] + (employee['gross_sales'] ?? 0.0),
        'refunds': totals['refunds'] + (employee['refunds'] ?? 0.0),
        'discounts': totals['discounts'] + (employee['discounts'] ?? 0.0),
        'net_sales': totals['net_sales'] + (employee['net_sales'] ?? 0.0),
        'receipts': totals['receipts'] + (employee['receipts'] ?? 0),
        'customers_signed_up': totals['customers_signed_up'] + (employee['customers_signed_up'] ?? 0),
      },
    );
  }

  double _calculateAverageFromTotals(Map<String, dynamic> totals) {
    if (totals['receipts'] == 0) return 0.0;
    return totals['net_sales'] / totals['receipts'];
  }

  @override
  Widget build(BuildContext context) {
    final totals = _calculateTotals();
    final overallAverage = _calculateAverageFromTotals(totals);

    return BackOfficeLayout(
      title: 'Sales by Employee',
      currentRoute: '/backoffice/sales-by-employee',
      child: Column(
        children: [
          // Header and Filters
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Employee Performance and Sales Tracking',
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 16),
                  
                  // Filters
                  ResponsiveUtils.isMobile(context)
                    ? _buildMobileFilters()
                    : _buildDesktopFilters(),
                ],
              ),
            ),
          ),
          
          const SizedBox(height: 16),
          
          const SizedBox(height: 16),
          
          // Employee Performance Table
          Expanded(
            child: Card(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Padding(
                    padding: const EdgeInsets.all(16.0),
                    child: Row(
                      children: [
                        const Text(
                          'Employee Performance',
                          style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        const Spacer(),
                        PopupMenuButton<String>(
                          child: Container(
                            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                            decoration: BoxDecoration(
                              border: Border.all(color: Colors.grey.shade300),
                              borderRadius: BorderRadius.circular(8),
                            ),
                            child: const Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Icon(Icons.view_column, size: 16),
                                SizedBox(width: 4),
                                Text('Columns'),
                                Icon(Icons.arrow_drop_down, size: 16),
                              ],
                            ),
                          ),
                          itemBuilder: (context) => [
                            _buildColumnCheckbox('employee_name', 'Employee Name'),
                            _buildColumnCheckbox('gross_sales', 'Gross Sales'),
                            _buildColumnCheckbox('refunds', 'Refunds'),
                            _buildColumnCheckbox('discounts', 'Discounts'),
                            _buildColumnCheckbox('net_sales', 'Net Sales'),
                            _buildColumnCheckbox('receipts', 'Receipts'),
                            _buildColumnCheckbox('average_sale', 'Average Sale'),
                            _buildColumnCheckbox('customers_signed_up', 'Customers Signed Up'),
                          ],
                        ),
                      ],
                    ),
                  ),
                  Expanded(
                    child: _isLoading
                      ? const Center(child: CircularProgressIndicator())
                      : _employeeData.isEmpty
                        ? const Center(
                            child: Text(
                              'No employee sales data found for the selected period',
                              style: TextStyle(fontSize: 16, color: Colors.grey),
                            ),
                          )
                        : SingleChildScrollView(
                            scrollDirection: Axis.horizontal,
                            child: SingleChildScrollView(
                              child: Padding(
                                padding: const EdgeInsets.all(16.0),
                                child: _buildDataTable(totals, overallAverage),
                              ),
                            ),
                          ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildMobileFilters() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Date Period Selector
        DropdownButtonFormField<String>(
          value: _period,
          decoration: const InputDecoration(
            labelText: 'Period',
            border: OutlineInputBorder(),
          ),
          items: ['Today', 'Yesterday', 'Last 7 Days', 'Last 30 Days', 'This Month', 'Custom']
              .map((period) => DropdownMenuItem(value: period, child: Text(period)))
              .toList(),
          onChanged: (value) {
            if (value == 'Custom') {
              _selectDateRange();
            } else if (value != null) {
              _applyDatePreset(value);
            }
          },
        ),
        
        const SizedBox(height: 16),
        
        // Store Filter
        DropdownButtonFormField<int?>(
          value: _selectedStoreId,
          decoration: const InputDecoration(
            labelText: 'Store',
            border: OutlineInputBorder(),
          ),
          items: [
            const DropdownMenuItem<int?>(value: null, child: Text('All Stores')),
            ..._stores.map((store) => DropdownMenuItem<int?>(
              value: store.id,
              child: Text(store.name),
            )),
          ],
          onChanged: (value) {
            setState(() => _selectedStoreId = value);
            _loadEmployeeData();
          },
        ),
      ],
    );
  }

  Widget _buildDesktopFilters() {
    return Row(
      children: [
        // Date Period Selector
        Expanded(
          flex: 2,
          child: DropdownButtonFormField<String>(
            value: _period,
            decoration: const InputDecoration(
              labelText: 'Period',
              border: OutlineInputBorder(),
            ),
            items: ['Today', 'Yesterday', 'Last 7 Days', 'Last 30 Days', 'This Month', 'Custom']
                .map((period) => DropdownMenuItem(value: period, child: Text(period)))
                .toList(),
            onChanged: (value) {
              if (value == 'Custom') {
                _selectDateRange();
              } else if (value != null) {
                _applyDatePreset(value);
              }
            },
          ),
        ),
        
        const SizedBox(width: 16),
        
        // Store Filter
        Expanded(
          flex: 2,
          child: DropdownButtonFormField<int?>(
            value: _selectedStoreId,
            decoration: const InputDecoration(
              labelText: 'Store',
              border: OutlineInputBorder(),
            ),
            items: [
              const DropdownMenuItem<int?>(value: null, child: Text('All Stores')),
              ..._stores.map((store) => DropdownMenuItem<int?>(
                value: store.id,
                child: Text(store.name),
              )),
            ],
            onChanged: (value) {
              setState(() => _selectedStoreId = value);
              _loadEmployeeData();
            },
          ),
        ),
        
        const SizedBox(width: 16),
        
        // Custom Date Range Button
        ElevatedButton.icon(
          onPressed: _selectDateRange,
          icon: const Icon(Icons.date_range),
          label: Text('${DateFormat('MMM d').format(_startDate)} - ${DateFormat('MMM d').format(_endDate)}'),
        ),
      ],
    );
  }

  PopupMenuItem<String> _buildColumnCheckbox(String key, String label) {
    return PopupMenuItem<String>(
      enabled: false,
      child: StatefulBuilder(
        builder: (context, setState) {
          return CheckboxListTile(
            title: Text(label),
            value: _visibleColumns.contains(key),
            onChanged: (value) {
              setState(() {
                if (value == true) {
                  _visibleColumns.add(key);
                } else {
                  _visibleColumns.remove(key);
                }
              });
              // Update the main widget state
              this.setState(() {});
            },
            dense: true,
            controlAffinity: ListTileControlAffinity.leading,
          );
        },
      ),
    );
  }

  Widget _buildDataTable(Map<String, dynamic> totals, double overallAverage) {
    final columns = <DataColumn>[];
    final cellBuilders = <String, Widget Function(Map<String, dynamic>)>{};
    
    if (_visibleColumns.contains('employee_name')) {
      columns.add(const DataColumn(label: Text('Employee Name', style: TextStyle(fontWeight: FontWeight.bold))));
      cellBuilders['employee_name'] = (item) => Text(item['employee_name'] ?? 'Unknown');
    }
    
    if (_visibleColumns.contains('gross_sales')) {
      columns.add(const DataColumn(label: Text('Gross Sales', style: TextStyle(fontWeight: FontWeight.bold)), numeric: true));
      cellBuilders['gross_sales'] = (item) => Text('\$${(item['gross_sales'] ?? 0.0).toStringAsFixed(2)}', style: const TextStyle(fontWeight: FontWeight.w500));
    }
    
    if (_visibleColumns.contains('refunds')) {
      columns.add(const DataColumn(label: Text('Refunds', style: TextStyle(fontWeight: FontWeight.bold)), numeric: true));
      cellBuilders['refunds'] = (item) => Text('\$${(item['refunds'] ?? 0.0).toStringAsFixed(2)}', style: const TextStyle(color: Colors.red));
    }
    
    if (_visibleColumns.contains('discounts')) {
      columns.add(const DataColumn(label: Text('Discounts', style: TextStyle(fontWeight: FontWeight.bold)), numeric: true));
      cellBuilders['discounts'] = (item) => Text('\$${(item['discounts'] ?? 0.0).toStringAsFixed(2)}', style: const TextStyle(color: Colors.orange));
    }
    
    if (_visibleColumns.contains('net_sales')) {
      columns.add(const DataColumn(label: Text('Net Sales', style: TextStyle(fontWeight: FontWeight.bold)), numeric: true));
      cellBuilders['net_sales'] = (item) => Text('\$${(item['net_sales'] ?? 0.0).toStringAsFixed(2)}', style: const TextStyle(fontWeight: FontWeight.bold));
    }
    
    if (_visibleColumns.contains('receipts')) {
      columns.add(const DataColumn(label: Text('Receipts', style: TextStyle(fontWeight: FontWeight.bold)), numeric: true));
      cellBuilders['receipts'] = (item) => Text('${item['receipts'] ?? 0}', style: const TextStyle(fontWeight: FontWeight.w500));
    }
    
    if (_visibleColumns.contains('average_sale')) {
      columns.add(const DataColumn(label: Text('Average Sale', style: TextStyle(fontWeight: FontWeight.bold)), numeric: true));
      cellBuilders['average_sale'] = (item) => Text('\$${(item['average_sale'] ?? 0.0).toStringAsFixed(2)}');
    }
    
    if (_visibleColumns.contains('customers_signed_up')) {
      columns.add(const DataColumn(label: Text('Customers Signed Up', style: TextStyle(fontWeight: FontWeight.bold)), numeric: true));
      cellBuilders['customers_signed_up'] = (item) => Text('${item['customers_signed_up'] ?? 0}');
    }

    return DataTable(
      columns: columns,
      rows: [
        ..._employeeData.map((employee) => DataRow(
          cells: _visibleColumns.map((key) => DataCell(cellBuilders[key]!(employee))).toList(),
        )),
        
        // Totals Row
        DataRow(
          color: MaterialStateProperty.all(Colors.grey.shade100),
          cells: _visibleColumns.map((key) {
            switch (key) {
              case 'employee_name':
                return const DataCell(Text('Total', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)));
              case 'gross_sales':
                return DataCell(Text('\$${totals['gross_sales'].toStringAsFixed(2)}', style: const TextStyle(fontWeight: FontWeight.bold)));
              case 'refunds':
                return DataCell(Text('\$${totals['refunds'].toStringAsFixed(2)}', style: const TextStyle(fontWeight: FontWeight.bold, color: Colors.red)));
              case 'discounts':
                return DataCell(Text('\$${totals['discounts'].toStringAsFixed(2)}', style: const TextStyle(fontWeight: FontWeight.bold, color: Colors.orange)));
              case 'net_sales':
                return DataCell(Text('\$${totals['net_sales'].toStringAsFixed(2)}', style: const TextStyle(fontWeight: FontWeight.bold)));
              case 'receipts':
                return DataCell(Text('${totals['receipts']}', style: const TextStyle(fontWeight: FontWeight.bold)));
              case 'average_sale':
                return DataCell(Text('\$${overallAverage.toStringAsFixed(2)}', style: const TextStyle(fontWeight: FontWeight.bold)));
              case 'customers_signed_up':
                return DataCell(Text('${totals['customers_signed_up']}', style: const TextStyle(fontWeight: FontWeight.bold)));
              default:
                return const DataCell(Text(''));
            }
          }).toList(),
        ),
      ],
    );
  }
}