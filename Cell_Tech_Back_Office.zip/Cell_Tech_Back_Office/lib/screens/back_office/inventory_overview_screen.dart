import 'package:flutter/material.dart';
import '../../widgets/back_office_layout.dart';

class InventoryOverviewScreen extends StatelessWidget {
  const InventoryOverviewScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return BackOfficeLayout(
      title: 'Inventory Management',
      currentRoute: '/backoffice/inventory/overview',
      child: _buildContent(context),
    );
  }

  Widget _buildContent(BuildContext context) {
    final menuItems = [
      {
        'title': 'Purchase Orders',
        'description': 'Create and manage purchase orders',
        'icon': Icons.shopping_cart,
        'color': const Color(0xFFFF8C00),
        'route': '/backoffice/inventory/purchase-orders/create',
      },
      {
        'title': 'Transfer Orders',
        'description': 'Transfer stock between locations',
        'icon': Icons.swap_horiz,
        'color': Colors.blue,
        'route': '/backoffice/inventory/transfers',
      },
      {
        'title': 'Stock Adjustments',
        'description': 'Adjust stock levels manually',
        'icon': Icons.edit_note,
        'color': Colors.purple,
        'route': '/backoffice/inventory/adjustments',
      },
      {
        'title': 'Inventory Counts',
        'description': 'Perform physical stock counts',
        'icon': Icons.inventory,
        'color': Colors.green,
        'route': '/backoffice/inventory/counts',
      },
      {
        'title': 'Productions',
        'description': 'Manage product bundles and kits',
        'icon': Icons.build_circle,
        'color': Colors.teal,
        'route': '/backoffice/inventory/productions',
      },
      {
        'title': 'Suppliers',
        'description': 'Manage supplier information',
        'icon': Icons.business,
        'color': Colors.indigo,
        'route': '/backoffice/inventory/suppliers',
      },
      {
        'title': 'Inventory History',
        'description': 'View all stock movements',
        'icon': Icons.history,
        'color': Colors.grey,
        'route': '/backoffice/inventory/history',
      },
      {
        'title': 'Inventory Valuation',
        'description': 'View inventory value and costs',
        'icon': Icons.attach_money,
        'color': Colors.amber,
        'route': '/backoffice/inventory/valuation',
      },
    ];

    return Container(
      padding: const EdgeInsets.all(24),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Inventory Management',
            style: TextStyle(
              fontSize: 24,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 8),
          const Text(
            'Manage your inventory, stock levels, and suppliers',
            style: TextStyle(
              fontSize: 14,
              color: Colors.grey,
            ),
          ),
          const SizedBox(height: 32),
          Expanded(
            child: GridView.builder(
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 4,
                crossAxisSpacing: 16,
                mainAxisSpacing: 16,
                childAspectRatio: 1.2,
              ),
              itemCount: menuItems.length,
              itemBuilder: (context, index) {
                final item = menuItems[index];
                return _buildMenuItem(
                  context,
                  title: item['title'] as String,
                  description: item['description'] as String,
                  icon: item['icon'] as IconData,
                  color: item['color'] as Color,
                  route: item['route'] as String,
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildMenuItem(
    BuildContext context, {
    required String title,
    required String description,
    required IconData icon,
    required Color color,
    required String route,
  }) {
    return Card(
      elevation: 2,
      child: InkWell(
        onTap: () => Navigator.pushNamed(context, route),
        borderRadius: BorderRadius.circular(8),
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: color.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Icon(icon, size: 32, color: color),
              ),
              const SizedBox(height: 16),
              Text(
                title,
                style: const TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w600,
                ),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 8),
              Text(
                description,
                style: const TextStyle(
                  fontSize: 12,
                  color: Colors.grey,
                ),
                textAlign: TextAlign.center,
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
