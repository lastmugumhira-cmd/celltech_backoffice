import 'dart:io';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:path_provider/path_provider.dart';
import '../../services/database_service.dart';
import '../../widgets/back_office_layout.dart';
import '../../models/product.dart';
import '../../models/sale.dart';
import '../../models/employee.dart';
import '../../models/store.dart';

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  // Data storage
  List<Product> _products = [];
  List<Sale> _sales = [];
  List<Employee> _employees = [];
  List<Store> _stores = [];
  Map<String, Map<String, dynamic>> _inventory = {};
  Map<String, dynamic> _dashboardStats = {};
  
  // Loading state
  bool _isLoading = true;
  
  // Filtering
  int? _selectedStoreId;
  
  // Computed values
  double _refundsToday = 0.0;
  List<Product> _lowStockProducts = [];
  List<Sale> _recentSales = [];
  List<Map<String, dynamic>> _topProducts = [];

  @override
  void initState() {
    super.initState();
    _loadDashboardData();
  }

  Future<void> _loadDashboardData() async {
    setState(() => _isLoading = true);
    
    try {
      // Clean up orphaned stock records first
      await DatabaseService.cleanupOrphanedStockRecords();
      
      // Load all data in parallel
      final results = await Future.wait([
        DatabaseService.getProducts(),
        DatabaseService.getSales(),
        DatabaseService.getEmployees(),
        DatabaseService.getStores(),
        DatabaseService.getDashboardStats(null),
      ]);
      
      // Load inventory data from store_stock table
      final db = await DatabaseService.database;
      final inventoryResults = await db.query('store_stock');
      _inventory = {};
      for (final row in inventoryResults) {
        final productId = row['product_id'].toString();
        final storeId = row['store_id'].toString();
        if (_inventory[productId] == null) {
          _inventory[productId] = {};
        }
        _inventory[productId]![storeId] = {
          'quantity': row['stock_quantity'],
          'min_level': row['min_stock_level'],
        };
      }
      
      _products = results[0] as List<Product>;
      
      // Convert sales data properly
      final salesData = results[1] as List<Map<String, dynamic>>;
      _sales = salesData.map((saleMap) => Sale.fromMap(saleMap)).toList();
      
      _employees = results[2] as List<Employee>;
      _stores = results[3] as List<Store>;
      _dashboardStats = results[4] as Map<String, dynamic>;
      
      _computeDashboardStats();
      
      setState(() => _isLoading = false);
    } catch (e) {
      print('Error loading dashboard data: $e');
      setState(() => _isLoading = false);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error loading dashboard data: $e')),
        );
      }
    }
  }
  
  void _computeDashboardStats() {
    final today = DateTime.now();
    final todayStart = DateTime(today.year, today.month, today.day);
    final todayEnd = todayStart.add(const Duration(days: 1));
    
    // Calculate real sales made today
    double todaysSalesTotal = 0.0;
    int todaysSalesCount = 0;
    _refundsToday = 0.0; // Will be calculated when refund tracking is implemented
    
    for (final sale in _sales) {
      final saleDate = sale.saleDate;
      if (saleDate.isAfter(todayStart) && saleDate.isBefore(todayEnd)) {
        todaysSalesTotal += sale.totalAmount;
        todaysSalesCount++;
      }
    }
    
    // Override dashboard stats with real calculated values
    _dashboardStats['todaySales'] = todaysSalesTotal;
    _dashboardStats['todaysSalesCount'] = todaysSalesCount;
    
    // Calculate low stock products using same logic as products screen
    _lowStockProducts = [];
    
    for (final product in _products) {
      if (_selectedStoreId != null) {
        // Store-specific filtering: check only the selected store
        final productInventory = _inventory[product.id!.toString()] ?? {};
        final storeStock = productInventory[_selectedStoreId.toString()] ?? {'quantity': 0};
        final storeQuantity = storeStock['quantity'] as int;
        
        if (storeQuantity <= 10 && storeQuantity >= 0) {
          _lowStockProducts.add(product);
        }
      } else {
        // All stores: check total stock across all stores
        final storeStocks = <int, int>{};
        for (final store in _stores) {
          final productInventory = _inventory[product.id!.toString()] ?? {};
          final storeStock = productInventory[store.id.toString()] ?? {'quantity': 0};
          storeStocks[store.id!] = storeStock['quantity'] as int;
        }
        
        // Calculate total stock across all stores
        final totalStock = storeStocks.values.fold(0, (sum, qty) => sum + qty);
        
        // Check if it's low stock (same criteria as products screen)
        if (totalStock <= 10 && totalStock >= 0) {
          _lowStockProducts.add(product);
        }
      }
    }
    
    // Update dashboard stats with calculated low stock count
    _dashboardStats['lowStockCount'] = _lowStockProducts.length;
    
    // Get recent sales (last 10) - sort by date descending
    _recentSales = _sales.toList()
      ..sort((a, b) => b.saleDate.compareTo(a.saleDate));
    _recentSales = _recentSales.take(10).toList();
    
    // Use real top products from database
    final topProductsData = _dashboardStats['topProducts'] as List? ?? [];
    _topProducts = topProductsData.map((item) => {
      'name': item['name'],
      'total_sold': item['total_sold'],
      'revenue': item['revenue'],
    }).toList();
  }

  @override
  Widget build(BuildContext context) {
    return BackOfficeLayout(
      title: '',
      currentRoute: '/backoffice/dashboard',
      child: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              Color(0xFFFF8C00), // Orange
              Color(0xFFE0E0E0), // Light gray
            ],
          ),
        ),
        child: _isLoading
            ? const Center(
                child: CircularProgressIndicator(
                  valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
                ),
              )
            : _buildModernDashboard(),
      ),
    );
  }

  Widget _buildModernDashboard() {
    final currencyFormat = NumberFormat.currency(symbol: '\$');

    return SingleChildScrollView(
      padding: const EdgeInsets.all(24),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header
          _buildHeader(),
          const SizedBox(height: 32),

          // At-a-glance stats (top strip)
          _buildStatsStrip(currencyFormat),
          const SizedBox(height: 32),

          // Sales Reports & Analytics menu grid
          _buildReportsGrid(),
          const SizedBox(height: 32),

          // Lower content area (two sections side-by-side)
          _buildLowerContent(),
        ],
      ),
    );
  }

  Widget _buildHeader() {
    return const Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Dashboard',
          style: TextStyle(
            fontSize: 36,
            fontWeight: FontWeight.bold,
            color: Colors.white,
          ),
        ),
        SizedBox(height: 8),
        Text(
          'Overview and reports for your retail operations.',
          style: TextStyle(
            fontSize: 16,
            color: Colors.black87,
          ),
        ),
      ],
    );
  }

  Widget _buildStatsStrip(NumberFormat currencyFormat) {
    return LayoutBuilder(
      builder: (context, constraints) {
        int columns = 5;
        double aspectRatio = 2.2;
        
        if (constraints.maxWidth < 1400) {
          columns = 3;
          aspectRatio = 2.0;
        }
        if (constraints.maxWidth < 1000) {
          columns = 2;
          aspectRatio = 1.8;
        }
        if (constraints.maxWidth < 700) {
          columns = 1;
          aspectRatio = 3.0;
        }

        return GridView.count(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          crossAxisCount: columns,
          crossAxisSpacing: 12,
          mainAxisSpacing: 12,
          childAspectRatio: aspectRatio,
          children: [
            _buildGradientStatCard(
              'Net Sales Today',
              currencyFormat.format((_dashboardStats['todaySales'] as num?)?.toDouble() ?? 0.0),
              Icons.bar_chart,
              [const Color(0xFFFF8C00), const Color(0xFFFF6B35)],
              '${(_dashboardStats['todaysSalesCount'] as int?) ?? 0} sales',
            ),
            _buildGradientStatCard(
              'Refunds Today',
              currencyFormat.format(_refundsToday),
              Icons.refresh,
              [const Color(0xFFFF5722), const Color(0xFFE53935)],
              null,
            ),
            _buildGradientStatCard(
              'Total Products',
              '${(_dashboardStats['inventoryCount'] as int?) ?? 0}',
              Icons.inventory_2,
              [const Color(0xFF2196F3), const Color(0xFF1976D2)],
              'Active items',
            ),
            _buildGradientStatCard(
              'Active Employees',
              '${_employees.length}',
              Icons.people,
              [const Color(0xFF009688), const Color(0xFF00796B)],
              '${(_dashboardStats['storesCount'] as int?) ?? 0} stores',
            ),
            _buildClickableGradientStatCard(
              'Low Stock Items',
              '${(_dashboardStats['lowStockCount'] as int?) ?? 0}',
              Icons.warning,
              [const Color(0xFFFF5722), const Color(0xFFE53935)],
              null,
              (_dashboardStats['lowStockCount'] as int? ?? 0) > 0 ? () => _showLowStockDialog() : null,
            ),
          ],
        );
      },
    );
  }

  Widget _buildGradientStatCard(
    String title,
    String value,
    IconData icon,
    List<Color> gradientColors,
    String? trendText,
  ) {
    return _buildClickableGradientStatCard(title, value, icon, gradientColors, trendText, null);
  }

  Widget _buildClickableGradientStatCard(
    String title,
    String value,
    IconData icon,
    List<Color> gradientColors,
    String? trendText,
    VoidCallback? onTap,
  ) {
    return Card(
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(12),
        child: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(colors: gradientColors),
            borderRadius: BorderRadius.circular(12),
          ),
          padding: const EdgeInsets.all(12),
          child: LayoutBuilder(
            builder: (context, constraints) {
              // Adjust text sizes based on available width
              double valueSize = constraints.maxWidth < 180 ? 18 : 
                                constraints.maxWidth < 220 ? 20 : 24;
              double titleSize = constraints.maxWidth < 180 ? 11 : 
                                constraints.maxWidth < 220 ? 12 : 14;
              double iconSize = constraints.maxWidth < 180 ? 20 : 24;
              
              return Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Container(
                        padding: const EdgeInsets.all(6),
                        decoration: BoxDecoration(
                          color: Colors.white.withOpacity(0.2),
                          borderRadius: BorderRadius.circular(6),
                        ),
                        child: Icon(icon, color: Colors.white, size: iconSize),
                      ),
                      if (trendText != null)
                        Flexible(
                          child: Container(
                            padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                            decoration: BoxDecoration(
                              color: Colors.white.withOpacity(0.2),
                              borderRadius: BorderRadius.circular(10),
                            ),
                            child: Text(
                              trendText,
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: constraints.maxWidth < 180 ? 9 : 10,
                                fontWeight: FontWeight.w500,
                              ),
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                        ),
                    ],
                  ),
                  const SizedBox(height: 6),
                  Flexible(
                    child: Text(
                      value,
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: valueSize,
                        fontWeight: FontWeight.bold,
                      ),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                  Flexible(
                    child: Text(
                      title,
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: titleSize,
                      ),
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                ],
              );
            },
          ),
        ),
      ),
    );
  }

  Widget _buildReportsGrid() {
    final reports = [
      {
        'title': 'Sales Summary',
        'description': 'Overall metrics and trends',
        'icon': Icons.trending_up,
        'colors': [const Color(0xFF2196F3), const Color(0xFF1976D2)],
        'route': '/backoffice/sales-summary',
      },
      {
        'title': 'Sales by Product',
        'description': 'Product performance',
        'icon': Icons.inventory_2,
        'colors': [const Color(0xFF4CAF50), const Color(0xFF388E3C)],
        'route': '/backoffice/sales-by-product',
      },
      {
        'title': 'Sales by Category',
        'description': 'Category performance',
        'icon': Icons.category,
        'colors': [const Color(0xFF9C27B0), const Color(0xFF7B1FA2)],
        'route': '/backoffice/sales-by-category',
      },
      {
        'title': 'Sales by Employee',
        'description': 'Employee performance',
        'icon': Icons.people,
        'colors': [const Color(0xFFFF8C00), const Color(0xFFFF6B35)],
        'route': '/backoffice/sales-by-employee',
      },
      {
        'title': 'Sales by Payment Type',
        'description': 'Payment method analysis',
        'icon': Icons.payment,
        'colors': [const Color(0xFF3F51B5), const Color(0xFF303F9F)],
        'route': '/backoffice/sales-by-payment',
      },
      {
        'title': 'Receipts',
        'description': 'Browse/search receipts',
        'icon': Icons.receipt_long,
        'colors': [const Color(0xFF009688), const Color(0xFF00796B)],
        'route': '/backoffice/receipts',
      },
      {
        'title': 'Discounts',
        'description': 'Discount usage and impact',
        'icon': Icons.discount,
        'colors': [const Color(0xFFE91E63), const Color(0xFFC2185B)],
        'route': '/backoffice/discounts',
      },
      {
        'title': 'Shifts',
        'description': 'Shift tracking & cash reconciliation',
        'icon': Icons.schedule,
        'colors': [const Color(0xFFFF5722), const Color(0xFFE53935)],
        'route': '/backoffice/shifts',
      },
    ];

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'Sales Reports & Analytics',
          style: TextStyle(
            fontSize: 24,
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 16),
        LayoutBuilder(
          builder: (context, constraints) {
            int columns = 4;
            double aspectRatio = 3.0;
            
            if (constraints.maxWidth < 1400) {
              columns = 3;
              aspectRatio = 2.8;
            }
            if (constraints.maxWidth < 1000) {
              columns = 2;
              aspectRatio = 3.2;
            }
            if (constraints.maxWidth < 650) {
              columns = 1;
              aspectRatio = 4.0;
            }

            return GridView.builder(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: columns,
                crossAxisSpacing: 12,
                mainAxisSpacing: 12,
                childAspectRatio: aspectRatio,
              ),
              itemCount: reports.length,
              itemBuilder: (context, index) {
                final report = reports[index];
                return _buildReportTile(
                  report['title'] as String,
                  report['description'] as String,
                  report['icon'] as IconData,
                  report['colors'] as List<Color>,
                  () => Navigator.pushNamed(context, report['route'] as String),
                );
              },
            );
          },
        ),
      ],
    );
  }

  Widget _buildReportTile(
    String title,
    String description,
    IconData icon,
    List<Color> colors,
    VoidCallback onTap,
  ) {
    return Card(
      elevation: 2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(12),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Row(
            children: [
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  gradient: LinearGradient(colors: colors),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Icon(icon, color: Colors.white, size: 24),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      title,
                      style: const TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      description,
                      style: const TextStyle(
                        fontSize: 12,
                        color: Colors.grey,
                      ),
                    ),
                  ],
                ),
              ),
              const Icon(
                Icons.chevron_right,
                color: Colors.grey,
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildLowerContent() {
    return LayoutBuilder(
      builder: (context, constraints) {
        if (constraints.maxWidth < 1000) {
          // Single column layout on smaller screens
          return Column(
            children: [
              _buildRecentSalesCard(),
              const SizedBox(height: 24),
              Row(
                children: [
                  Expanded(child: _buildTopProductsCard()),
                  const SizedBox(width: 16),
                  Expanded(child: _buildLowStockCard()),
                ],
              ),
            ],
          );
        } else {
          // Three column layout on larger screens
          return Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                flex: 2,
                child: _buildRecentSalesCard(),
              ),
              const SizedBox(width: 24),
              Expanded(
                flex: 1,
                child: Column(
                  children: [
                    _buildTopProductsCard(),
                    const SizedBox(height: 16),
                    _buildLowStockCard(),
                  ],
                ),
              ),
            ],
          );
        }
      },
    );
  }

  Widget _buildRecentSalesCard() {
    return Card(
      elevation: 2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Recent Sales',
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 16),
            if (_recentSales.isEmpty)
              const Center(
                child: Padding(
                  padding: EdgeInsets.all(32),
                  child: Text('No recent sales'),
                ),
              )
            else
              ListView.separated(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                itemCount: _recentSales.take(10).length,
                separatorBuilder: (context, index) => const Divider(),
                itemBuilder: (context, index) {
                  final sale = _recentSales[index];
                  return ListTile(
                    leading: CircleAvatar(
                      backgroundColor: Colors.orange.withOpacity(0.2),
                      child: Text(
                        sale.ticketNumber.split('-').last,
                        style: const TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                    title: Text(
                      'Ticket #${sale.ticketNumber}',
                      style: const TextStyle(fontWeight: FontWeight.w500),
                    ),
                    subtitle: Text(
                      DateFormat('MMM dd, yyyy HH:mm').format(sale.saleDate),
                    ),
                    trailing: Text(
                      NumberFormat.currency(symbol: '\$').format(sale.totalAmount),
                      style: const TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 16,
                      ),
                    ),
                  );
                },
              ),
          ],
        ),
      ),
    );
  }

  Widget _buildTopProductsCard() {
    return Card(
      elevation: 2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Top Products',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 16),
            if (_topProducts.isEmpty)
              const Center(
                child: Column(
                  children: [
                    Icon(
                      Icons.show_chart,
                      size: 48,
                      color: Colors.grey,
                    ),
                    SizedBox(height: 8),
                    Text(
                      'No sales data available',
                      style: TextStyle(
                        color: Colors.grey,
                        fontSize: 14,
                      ),
                    ),
                    Text(
                      'Start making sales to see top products',
                      style: TextStyle(
                        color: Colors.grey,
                        fontSize: 12,
                      ),
                    ),
                  ],
                ),
              )
            else
              ListView.separated(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                itemCount: _topProducts.length,
                separatorBuilder: (context, index) => const SizedBox(height: 8),
                itemBuilder: (context, index) {
                  final productData = _topProducts[index];
                  final productName = productData['name'] as String;
                  final totalSold = productData['total_sold'] as int? ?? 0;
                  
                  return Row(
                    children: [
                      CircleAvatar(
                        radius: 16,
                        backgroundColor: Colors.blue.withOpacity(0.2),
                        child: Text(
                          '${index + 1}',
                          style: const TextStyle(
                            fontSize: 12,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              productName,
                              style: const TextStyle(
                                fontWeight: FontWeight.w500,
                                fontSize: 14,
                              ),
                            ),
                            Text(
                              '$totalSold sold',
                              style: const TextStyle(
                                color: Colors.grey,
                                fontSize: 12,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  );
                },
              ),
          ],
        ),
      ),
    );
  }

  Widget _buildLowStockCard() {
    return Card(
      elevation: 2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: InkWell(
        onTap: (_dashboardStats['lowStockCount'] as int? ?? 0) > 0 ? () => _showLowStockDialog() : null,
        borderRadius: BorderRadius.circular(12),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  const Text(
                    'Low Stock Alert',
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const Spacer(),
                  if ((_dashboardStats['lowStockCount'] as int? ?? 0) > 0)
                    const Icon(
                      Icons.chevron_right,
                      color: Colors.grey,
                    ),
                ],
              ),
              const SizedBox(height: 16),
              if ((_dashboardStats['lowStockCount'] as int? ?? 0) == 0)
                const Row(
                  children: [
                    Icon(Icons.check_circle, color: Colors.green),
                    SizedBox(width: 8),
                    Text('All products well stocked'),
                  ],
                )
              else
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        const Icon(Icons.warning, color: Colors.red),
                        const SizedBox(width: 8),
                        Text(
                          '${(_dashboardStats['lowStockCount'] as int? ?? 0)} items need attention',
                          style: const TextStyle(
                            color: Colors.red,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 8),
                    const Text(
                      'Click to view details',
                      style: TextStyle(
                        color: Colors.grey,
                        fontSize: 12,
                      ),
                    ),
                  ],
                ),
            ],
          ),
        ),
      ),
    );
  }

  void _showLowStockDialog() {
    showDialog(
      context: context,
      builder: (context) => StatefulBuilder(
        builder: (context, setDialogState) => AlertDialog(
          title: Row(
            children: [
              const Expanded(child: Text('Low Stock Items')),
              // Store Filter Dropdown
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                decoration: BoxDecoration(
                  border: Border.all(color: Colors.grey.shade300),
                  borderRadius: BorderRadius.circular(4),
                ),
                child: DropdownButton<int?>(
                  value: _selectedStoreId,
                  hint: const Text('All Stores'),
                  underline: const SizedBox(),
                  items: [
                    const DropdownMenuItem<int?>(
                      value: null,
                      child: Text('All Stores'),
                    ),
                    ..._stores.map((store) => DropdownMenuItem<int?>(
                      value: store.id,
                      child: Text(store.name),
                    )),
                  ],
                  onChanged: (value) {
                    setDialogState(() {
                      _selectedStoreId = value;
                    });
                    _refreshDataForStore();
                  },
                ),
              ),
            ],
          ),
          content: SizedBox(
            width: double.maxFinite,
            height: 400,
            child: _lowStockProducts.isEmpty
                ? const Text('No low stock items found.')
                : ListView.builder(
                    itemCount: _lowStockProducts.length,
                    itemBuilder: (context, index) {
                      final product = _lowStockProducts[index];
                      final productInventory = _inventory[product.id.toString()] ?? {};
                      int totalStock = 0;
                      int minStock = 5;
                      
                      // Calculate total stock across all stores (or selected store)
                      if (_selectedStoreId != null) {
                        // Show stock for selected store only
                        final storeData = productInventory[_selectedStoreId.toString()];
                        if (storeData != null) {
                          totalStock = (storeData['quantity'] as int? ?? 0);
                          minStock = (storeData['min_level'] as int? ?? 5);
                        }
                      } else {
                        // Show total stock across all stores
                        for (final storeData in productInventory.values) {
                          totalStock += (storeData['quantity'] as int? ?? 0);
                          // Use the minimum of min_levels across stores
                          final storeMinLevel = (storeData['min_level'] as int? ?? 5);
                          if (minStock > storeMinLevel) {
                            minStock = storeMinLevel;
                          }
                        }
                      }
                      
                      return ListTile(
                        leading: const Icon(Icons.warning, color: Colors.red),
                        title: Text(product.name),
                        subtitle: Text('SKU: ${product.sku} | Min: $minStock'),
                        trailing: Text(
                          'Stock: $totalStock',
                          style: const TextStyle(
                            color: Colors.red,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      );
                    },
                  ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: const Text('Close'),
            ),
            ElevatedButton.icon(
              onPressed: _exportLowStockToPDF,
              icon: const Icon(Icons.picture_as_pdf, size: 18),
              label: const Text('Export PDF'),
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFFFF8C00),
                foregroundColor: Colors.white,
              ),
            ),
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
                Navigator.pushNamed(context, '/backoffice/products');
              },
              child: const Text('View Inventory'),
            ),
          ],
        ),
      ),
    );
  }

  void _refreshDataForStore() async {
    setState(() => _isLoading = true);
    
    try {
      // Reload dashboard stats for selected store
      _dashboardStats = await DatabaseService.getDashboardStats(_selectedStoreId);
      
      // Recalculate low stock products based on store filter
      _lowStockProducts = [];
      
      for (final product in _products) {
        if (_selectedStoreId != null) {
          // Store-specific filtering: check only the selected store
          final productInventory = _inventory[product.id!.toString()] ?? {};
          final storeStock = productInventory[_selectedStoreId.toString()] ?? {'quantity': 0};
          final storeQuantity = storeStock['quantity'] as int;
          
          if (storeQuantity <= 10 && storeQuantity >= 0) {
            _lowStockProducts.add(product);
          }
        } else {
          // All stores: check total stock across all stores (same as before)
          final storeStocks = <int, int>{};
          for (final store in _stores) {
            final productInventory = _inventory[product.id!.toString()] ?? {};
            final storeStock = productInventory[store.id.toString()] ?? {'quantity': 0};
            storeStocks[store.id!] = storeStock['quantity'] as int;
          }
          
          final totalStock = storeStocks.values.fold(0, (sum, qty) => sum + qty);
          if (totalStock <= 10 && totalStock >= 0) {
            _lowStockProducts.add(product);
          }
        }
      }
      
      // Update dashboard stats with calculated count
      _dashboardStats['lowStockCount'] = _lowStockProducts.length;
      
      _computeDashboardStats();
      setState(() => _isLoading = false);
    } catch (e) {
      print('Error refreshing data for store: $e');
      setState(() => _isLoading = false);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error refreshing data: $e')),
        );
      }
    }
  }

  Future<void> _exportLowStockToPDF() async {
    try {
      // Use the already loaded low stock products from dashboard
      final allLowStockProducts = _lowStockProducts;
      final pdf = pw.Document();
      
      const int itemsPerPage = 30; // Items per page (after header on first page)
      const int itemsFirstPage = 25; // Fewer items on first page due to header
      
      // First page with header and summary
      List<pw.Widget> firstPageItems = [];
      
      // Header
      firstPageItems.addAll([
        pw.Text(
          'Low Stock Items Report',
          style: pw.TextStyle(
            fontSize: 24,
            fontWeight: pw.FontWeight.bold,
          ),
        ),
        pw.SizedBox(height: 8),
        pw.Text(
          'Generated on: ${DateFormat('MMM dd, yyyy HH:mm').format(DateTime.now())}',
          style: const pw.TextStyle(fontSize: 12),
        ),
        if (_selectedStoreId != null)
          pw.Text(
            'Store: ${_stores.firstWhere((s) => s.id == _selectedStoreId).name}',
            style: const pw.TextStyle(fontSize: 12),
          ),
        pw.SizedBox(height: 20),
        // Summary
        pw.Text(
          'Summary',
          style: pw.TextStyle(
            fontSize: 18,
            fontWeight: pw.FontWeight.bold,
          ),
        ),
        pw.SizedBox(height: 10),
        pw.Text(
          'Total Low Stock Items: ${allLowStockProducts.length}',
          style: pw.TextStyle(fontSize: 14, fontWeight: pw.FontWeight.bold),
        ),
        pw.SizedBox(height: 20),
        pw.Text(
          'Low Stock Alert Items',
          style: pw.TextStyle(
            fontSize: 18,
            fontWeight: pw.FontWeight.bold,
          ),
        ),
        pw.SizedBox(height: 10),
      ]);
      
      if (allLowStockProducts.isNotEmpty) {
        // Table header
        firstPageItems.add(
          pw.Container(
            padding: const pw.EdgeInsets.all(6),
            decoration: pw.BoxDecoration(
              border: pw.Border.all(),
              color: PdfColor.fromHex('#f0f0f0'),
            ),
            child: pw.Row(
              children: [
                pw.Expanded(flex: 4, child: pw.Text('Product Name', style: pw.TextStyle(fontWeight: pw.FontWeight.bold, fontSize: 10))),
                pw.Expanded(flex: 3, child: pw.Text('SKU', style: pw.TextStyle(fontWeight: pw.FontWeight.bold, fontSize: 10))),
                pw.Expanded(flex: 1, child: pw.Text('Stock', style: pw.TextStyle(fontWeight: pw.FontWeight.bold, fontSize: 10))),
                pw.Expanded(flex: 1, child: pw.Text('Min', style: pw.TextStyle(fontWeight: pw.FontWeight.bold, fontSize: 10))),
              ],
            ),
          ),
        );
        
        // First page products
        final firstPageProducts = allLowStockProducts.take(itemsFirstPage).toList();
        for (final product in firstPageProducts) {
          final productName = product.name;
          final productSku = product.sku;
          
          // Calculate stock from inventory data
          final productInventory = _inventory[product.id.toString()] ?? {};
          int currentStock = 0;
          int minStock = 5;
          
          if (_selectedStoreId != null) {
            // Show stock for selected store only
            final storeData = productInventory[_selectedStoreId.toString()];
            if (storeData != null) {
              currentStock = (storeData['quantity'] as int? ?? 0);
              minStock = (storeData['min_level'] as int? ?? 5);
            }
          } else {
            // Show total stock across all stores
            for (final storeData in productInventory.values) {
              currentStock += (storeData['quantity'] as int? ?? 0);
              final storeMinLevel = (storeData['min_level'] as int? ?? 5);
              if (minStock > storeMinLevel) {
                minStock = storeMinLevel;
              }
            }
          }
          
          firstPageItems.add(
            pw.Container(
              padding: const pw.EdgeInsets.all(6),
              decoration: pw.BoxDecoration(
                border: pw.Border.all(),
              ),
              child: pw.Row(
                children: [
                  pw.Expanded(flex: 4, child: pw.Text(productName.length > 40 ? '${productName.substring(0, 40)}...' : productName, style: const pw.TextStyle(fontSize: 9))),
                  pw.Expanded(flex: 3, child: pw.Text(productSku, style: const pw.TextStyle(fontSize: 9))),
                  pw.Expanded(flex: 1, child: pw.Text('$currentStock', style: const pw.TextStyle(fontSize: 9))),
                  pw.Expanded(flex: 1, child: pw.Text('$minStock', style: const pw.TextStyle(fontSize: 9))),
                ],
              ),
            ),
          );
        }
      } else {
        firstPageItems.add(pw.Text('No low stock items found for the selected criteria.'));
      }
      
      // Add first page
      pdf.addPage(
        pw.Page(
          pageFormat: PdfPageFormat.a4,
          build: (pw.Context context) {
            return pw.Column(
              crossAxisAlignment: pw.CrossAxisAlignment.start,
              children: firstPageItems,
            );
          },
        ),
      );
      
      // Add additional pages for remaining products
      if (allLowStockProducts.length > itemsFirstPage) {
        final remainingProducts = allLowStockProducts.skip(itemsFirstPage).toList();
        
        for (int i = 0; i < remainingProducts.length; i += itemsPerPage) {
          final pageProducts = remainingProducts.skip(i).take(itemsPerPage).toList();
          final pageNumber = (i ~/ itemsPerPage) + 2; // Start from page 2
          
          List<pw.Widget> pageItems = [];
          
          // Page header
          pageItems.addAll([
            pw.Row(
              mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
              children: [
                pw.Text(
                  'Low Stock Items Report (continued)',
                  style: pw.TextStyle(fontSize: 16, fontWeight: pw.FontWeight.bold),
                ),
                pw.Text('Page $pageNumber', style: const pw.TextStyle(fontSize: 12)),
              ],
            ),
            pw.SizedBox(height: 20),
          ]);
          
          // Table header for continuation pages
          pageItems.add(
            pw.Container(
              padding: const pw.EdgeInsets.all(6),
              decoration: pw.BoxDecoration(
                border: pw.Border.all(),
                color: PdfColor.fromHex('#f0f0f0'),
              ),
              child: pw.Row(
                children: [
                  pw.Expanded(flex: 4, child: pw.Text('Product Name', style: pw.TextStyle(fontWeight: pw.FontWeight.bold, fontSize: 10))),
                  pw.Expanded(flex: 3, child: pw.Text('SKU', style: pw.TextStyle(fontWeight: pw.FontWeight.bold, fontSize: 10))),
                  pw.Expanded(flex: 1, child: pw.Text('Stock', style: pw.TextStyle(fontWeight: pw.FontWeight.bold, fontSize: 10))),
                  pw.Expanded(flex: 1, child: pw.Text('Min', style: pw.TextStyle(fontWeight: pw.FontWeight.bold, fontSize: 10))),
                ],
              ),
            ),
          );
          
          // Products for this page
          for (final product in pageProducts) {
            final productName = product.name;
            final productSku = product.sku;
            
            // Calculate stock from inventory data
            final productInventory = _inventory[product.id.toString()] ?? {};
            int currentStock = 0;
            int minStock = 5;
            
            if (_selectedStoreId != null) {
              // Show stock for selected store only
              final storeData = productInventory[_selectedStoreId.toString()];
              if (storeData != null) {
                currentStock = (storeData['quantity'] as int? ?? 0);
                minStock = (storeData['min_level'] as int? ?? 5);
              }
            } else {
              // Show total stock across all stores
              for (final storeData in productInventory.values) {
                currentStock += (storeData['quantity'] as int? ?? 0);
                final storeMinLevel = (storeData['min_level'] as int? ?? 5);
                if (minStock > storeMinLevel) {
                  minStock = storeMinLevel;
                }
              }
            }
            
            pageItems.add(
              pw.Container(
                padding: const pw.EdgeInsets.all(6),
                decoration: pw.BoxDecoration(
                  border: pw.Border.all(),
                ),
                child: pw.Row(
                  children: [
                    pw.Expanded(flex: 4, child: pw.Text(productName.length > 40 ? '${productName.substring(0, 40)}...' : productName, style: const pw.TextStyle(fontSize: 9))),
                    pw.Expanded(flex: 3, child: pw.Text(productSku, style: const pw.TextStyle(fontSize: 9))),
                    pw.Expanded(flex: 1, child: pw.Text('$currentStock', style: const pw.TextStyle(fontSize: 9))),
                    pw.Expanded(flex: 1, child: pw.Text('$minStock', style: const pw.TextStyle(fontSize: 9))),
                  ],
                ),
              ),
            );
          }
          
          // Add page
          pdf.addPage(
            pw.Page(
              pageFormat: PdfPageFormat.a4,
              build: (pw.Context context) {
                return pw.Column(
                  crossAxisAlignment: pw.CrossAxisAlignment.start,
                  children: pageItems,
                );
              },
            ),
          );
        }
      }

      // Save PDF file directly
      final bytes = await pdf.save();
      final directory = await getDownloadsDirectory();
      if (directory != null) {
        final timestamp = DateFormat('yyyy-MM-dd_HH-mm-ss').format(DateTime.now());
        final storeName = _selectedStoreId != null 
            ? _stores.firstWhere((s) => s.id == _selectedStoreId).name.replaceAll(' ', '_')
            : 'All_Stores';
        final fileName = 'Low_Stock_Report_${storeName}_$timestamp.pdf';
        final file = File('${directory.path}/$fileName');
        
        await file.writeAsBytes(bytes);
        
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text('PDF saved to Downloads: $fileName'),
              duration: const Duration(seconds: 4),
              action: SnackBarAction(
                label: 'Open Folder',
                onPressed: () async {
                  // Open the downloads folder on Windows
                  await Process.run('explorer', [directory.path]);
                },
              ),
            ),
          );
        }
      } else {
        throw Exception('Could not access Downloads folder');
      }
      
    } catch (e) {
      print('Error generating PDF: $e');
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error generating PDF: $e')),
        );
      }
    }
  }
}
