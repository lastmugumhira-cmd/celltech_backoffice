import 'package:flutter/material.dart';
import '../../widgets/back_office_layout.dart';
import '../../services/database_service.dart';
import '../../models/store.dart';
import '../../models/category.dart';
import 'warehouse_detail_screen.dart';
import '../../widgets/components/warehouse_import_dialog.dart';
import '../../widgets/components/receive_stock_dialog.dart';
import '../../widgets/components/transfer_stock_dialog.dart';

class WarehouseManagerScreen extends StatefulWidget {
  const WarehouseManagerScreen({super.key});

  @override
  State<WarehouseManagerScreen> createState() => _WarehouseManagerScreenState();
}

class _WarehouseManagerScreenState extends State<WarehouseManagerScreen> {
  bool _loading = true;
  String? _error;
  int? _warehouseId;
  List<Store> _stores = [];
  List<Store> _storeColumns = [];
  List<Category> _categories = [];
  List<Map<String, dynamic>> _rawStock = [];
  List<Map<String, dynamic>> _rows = [];

  // UI state
  final TextEditingController _searchCtrl = TextEditingController();
  String _categoryFilter = 'all';
  String _stockStatusFilter = 'all'; // all|low|out
  // Paging
  int _rowsPerPage = 25;
  int _page = 0;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() { _loading = true; _error = null; });
    try {
      final warehouse = await DatabaseService.getMainWarehouse();
      _warehouseId = warehouse?.id;
      _stores = await DatabaseService.getStores(active: true);
      _storeColumns = _stores.where((s) => s.type == 'store').toList();
      _categories = await DatabaseService.getCategories();
      _rawStock = await DatabaseService.getAllStoreStock();

      _rows = _buildInventoryRows();
      setState(() => _loading = false);
    } catch (e) {
      setState(() { _loading = false; _error = 'Failed to load data: $e'; });
    }
  }

  List<Map<String, dynamic>> _buildInventoryRows() {
    final Map<int, Map<String, dynamic>> rows = {};
    for (final r in _rawStock) {
      final pid = r['product_id'] as int;
      final storeId = r['store_id'] as int;
      final qty = (r['ss_stock_quantity'] as int?) ?? 0;
      rows.putIfAbsent(pid, () => {
            'product_id': pid,
            'name': r['name'],
            'sku': r['sku'],
            'category_id': r['category_id'],
            'category_name': r['category_name'],
            'total': 0,
            'warehouse': 0,
            'perStore': <int, int>{},
          });
      rows[pid]!['total'] = (rows[pid]!['total'] as int) + qty;
      if (_warehouseId != null && storeId == _warehouseId) {
        rows[pid]!['warehouse'] = qty;
      }
      (rows[pid]!['perStore'] as Map<int, int>)[storeId] = qty;
    }
    final list = rows.values.toList()
      ..sort((a, b) => (a['name'] as String).compareTo(b['name'] as String));
    return list;
  }

  @override
  Widget build(BuildContext context) {
    return BackOfficeLayout(
      title: 'Warehouse Manager',
      currentRoute: '/backoffice/warehouse-manager',
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          // Header with gradient title and action buttons
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                const Icon(Icons.warehouse, size: 32, color: Color(0xFFFF8C00)),
                const SizedBox(width: 8),
                _gradientTitle('Warehouse Manager'),
                const SizedBox(width: 16),
                if (_warehouseId != null) ...[
                  OutlinedButton.icon(
                    onPressed: () {
                      Navigator.of(context).push(
                        MaterialPageRoute(
                          builder: (_) => WarehouseDetailScreen(warehouseId: _warehouseId!),
                        ),
                      );
                    },
                    icon: const Icon(Icons.info_outline, size: 18, color: Color(0xFFFF8C00)),
                    label: const Text('Profile'),
                    style: OutlinedButton.styleFrom(foregroundColor: const Color(0xFFFF8C00)),
                  ),
                  const SizedBox(width: 8),
                ],
                OutlinedButton.icon(
                  onPressed: _openReceive,
                  icon: const Icon(Icons.download, size: 18, color: Color(0xFFFF8C00)),
                  label: const Text('Receive Stock'),
                  style: OutlinedButton.styleFrom(foregroundColor: const Color(0xFFFF8C00)),
                ),
                const SizedBox(width: 8),
                OutlinedButton.icon(
                  onPressed: _openTransfer,
                  icon: const Icon(Icons.sync_alt, size: 18, color: Color(0xFFFF8C00)),
                  label: const Text('Transfer Stock'),
                  style: OutlinedButton.styleFrom(foregroundColor: const Color(0xFFFF8C00)),
                ),
                const SizedBox(width: 8),
                ElevatedButton.icon(
                  onPressed: () async {
                    final stores = _stores.where((s) => s.type == 'store').toList();
                    await showDialog(
                      context: context,
                      builder: (_) => WarehouseImportDialog(stores: stores, onComplete: _load),
                    );
                  },
                  icon: const Icon(Icons.upload_file, size: 18),
                  label: const Text('Import'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFFFF8C00),
                    foregroundColor: Colors.white,
                    elevation: 2,
                  ),
                ),
                const SizedBox(width: 8),
                OutlinedButton.icon(
                  onPressed: () => Navigator.pushReplacementNamed(context, '/backoffice/warehouse-history'),
                  icon: const Icon(Icons.history, size: 18),
                  label: const Text('History'),
                ),
                const SizedBox(width: 16), // Extra padding at the end
              ],
            ),
          ),
          const SizedBox(height: 12),

          // Filters row
          Card(
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Wrap(
                spacing: 12,
                runSpacing: 12,
                crossAxisAlignment: WrapCrossAlignment.center,
                children: [
                  SizedBox(
                    width: 320,
                    child: TextField(
                      controller: _searchCtrl,
                      decoration: const InputDecoration(
                        prefixIcon: Icon(Icons.search),
                        labelText: 'Search by name or SKU…',
                        border: OutlineInputBorder(),
                      ),
                      onChanged: (_) => setState(() {}),
                    ),
                  ),
                  DropdownButtonHideUnderline(
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 12),
                      decoration: BoxDecoration(
                        border: Border.all(color: Colors.grey.shade300),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: DropdownButton<String>(
                        value: _categoryFilter,
                        items: [
                          const DropdownMenuItem(value: 'all', child: Text('All Categories')),
                          for (final c in _categories)
                            DropdownMenuItem(value: 'cat_${c.id}', child: Text(c.name)),
                        ],
                        onChanged: (v) => setState(() => _categoryFilter = v ?? 'all'),
                      ),
                    ),
                  ),
                  DropdownButtonHideUnderline(
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 12),
                      decoration: BoxDecoration(
                        border: Border.all(color: Colors.grey.shade300),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: DropdownButton<String>(
                        value: _stockStatusFilter,
                        items: const [
                          DropdownMenuItem(value: 'all', child: Text('All Stock')),
                          DropdownMenuItem(value: 'low', child: Text('Low Stock')),
                          DropdownMenuItem(value: 'out', child: Text('Out of Stock')),
                        ],
                        onChanged: (v) => setState(() => _stockStatusFilter = v ?? 'all'),
                      ),
                    ),
                  ),
                  IconButton(onPressed: _load, icon: const Icon(Icons.refresh)),
                ],
              ),
            ),
          ),

          const SizedBox(height: 12),

          // Table area
          Expanded(
            child: _loading
                ? _buildSkeletonTable()
                : _error != null
                    ? Center(child: Text(_error!, style: const TextStyle(color: Colors.red)))
                    : _buildInventoryTable(),
          ),
        ],
      ),
    );
  }

  // Removed unused _qtyChip method

  Future<void> _openReceive() async {
    if (_warehouseId == null) return;
    await showDialog(
      context: context,
      builder: (_) => ReceiveStockDialog(warehouseId: _warehouseId!, onDone: _load),
    );
  }

  Future<void> _openTransfer() async {
    if (_warehouseId == null) return;
    await showDialog(
      context: context,
      builder: (_) => TransferStockDialog(onDone: _load),
    );
  }

  Widget _gradientTitle(String text) {
    const gradient = LinearGradient(colors: [Color(0xFFFF8C00), Color(0xFFFF6B35)]);
    return ShaderMask(
      shaderCallback: (bounds) => gradient.createShader(Rect.fromLTWH(0, 0, bounds.width, bounds.height)),
      child: Text(text, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: Colors.white)),
    );
  }

  List<Map<String, dynamic>> get _filteredRows {
    final q = _searchCtrl.text.trim().toLowerCase();
    final catId = _categoryFilter.startsWith('cat_') ? int.tryParse(_categoryFilter.substring(4)) : null;
    return _rows.where((row) {
      final name = (row['name'] ?? '').toString().toLowerCase();
      final sku = (row['sku'] ?? '').toString().toLowerCase();
      final total = row['total'] as int? ?? 0;
      if (q.isNotEmpty && !(name.contains(q) || sku.contains(q))) return false;
      if (catId != null && (row['category_id'] as int?) != catId) return false;
      if (_stockStatusFilter == 'low' && !(total > 0 && total <= 10)) return false;
      if (_stockStatusFilter == 'out' && total != 0) return false;
      return true;
    }).toList();
  }

  Widget _buildInventoryTable() {
    final all = _filteredRows;
    final total = all.length;
    final start = (_page * _rowsPerPage).clamp(0, total);
    final end = (start + _rowsPerPage).clamp(0, total);
    final rows = all.sublist(start, end);
    
    if (rows.isEmpty) {
      return const Card(
        child: SizedBox(
          height: 300,
          child: Center(
            child: Text('No products found matching the current filters.', 
                      style: TextStyle(fontSize: 16, color: Colors.grey)),
          ),
        ),
      );
    }
    
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Column(
          children: [
            // Header
            Container(
              color: Colors.white,
              padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 8),
              child: SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: Row(
                  children: [
                    const SizedBox(width: 300, child: Text('Product', style: TextStyle(fontWeight: FontWeight.w600))),
                    const SizedBox(width: 140, child: Text('SKU', style: TextStyle(fontWeight: FontWeight.w600))),
                    const SizedBox(width: 100, child: Align(alignment: Alignment.centerRight, child: Text('Total Stock', style: TextStyle(fontWeight: FontWeight.w600)))),
                    const SizedBox(width: 140, child: Align(alignment: Alignment.centerRight, child: Text('Warehouse Stock', style: TextStyle(fontWeight: FontWeight.w600)))),
                    for (final s in _storeColumns)
                      SizedBox(width: 160, child: Align(alignment: Alignment.centerRight, child: Text(s.name, style: const TextStyle(fontWeight: FontWeight.w600), overflow: TextOverflow.ellipsis))),
                  ],
                ),
              ),
            ),
            const Divider(height: 1),
            // Body
            Expanded(
              child: SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: SizedBox(
                  width: 720 + (_storeColumns.length * 160),
                  child: ListView.builder(
                    itemCount: rows.length,
                    itemBuilder: (context, index) {
                      final r = rows[index];
                      final per = (r['perStore'] as Map<int, int>);
                      return Container(
                        padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 8),
                        decoration: BoxDecoration(
                          border: Border(bottom: BorderSide(color: Colors.grey.shade200)),
                        ),
                        child: Row(
                          children: [
                            SizedBox(width: 300, child: Text(r['name'] ?? '', overflow: TextOverflow.ellipsis)),
                            SizedBox(width: 140, child: Text(r['sku'] ?? '')),
                            SizedBox(width: 100, child: Align(alignment: Alignment.centerRight, child: Text('${r['total']}'))),
                            SizedBox(width: 140, child: Align(alignment: Alignment.centerRight, child: Text('${r['warehouse']}'))),
                            for (final s in _storeColumns)
                              SizedBox(width: 160, child: Align(alignment: Alignment.centerRight, child: Text('${per[s.id] ?? 0}'))),
                          ],
                        ),
                      );
                    },
                  ),
                ),
              ),
            ),
            // Pagination footer
            Container(
              padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 8),
              decoration: BoxDecoration(
                border: Border(top: BorderSide(color: Colors.grey.shade200)),
              ),
              child: Row(
                children: [
                  const Text('Rows per page:'),
                  const SizedBox(width: 8),
                  DropdownButton<int>(
                    value: _rowsPerPage,
                    items: const [25, 50, 100]
                        .map((v) => DropdownMenuItem(value: v, child: Text('$v')))
                        .toList(),
                    onChanged: (v) => setState(() { _rowsPerPage = v ?? 25; _page = 0; }),
                  ),
                  const Spacer(),
                  Text('${start + 1}-$end of $total'),
                  IconButton(
                    tooltip: 'Previous page',
                    onPressed: _page > 0 ? () => setState(() => _page -= 1) : null,
                    icon: const Icon(Icons.chevron_left),
                  ),
                  IconButton(
                    tooltip: 'Next page',
                    onPressed: end < total ? () => setState(() => _page += 1) : null,
                    icon: const Icon(Icons.chevron_right),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSkeletonTable() {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Column(
          children: [
            Container(
              padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 8),
              child: const Row(
                children: [
                  SizedBox(width: 300, child: _GreyBox(w: 160)),
                  SizedBox(width: 140, child: _GreyBox(w: 80)),
                  SizedBox(width: 100, child: Align(alignment: Alignment.centerRight, child: _GreyBox(w: 60))),
                  SizedBox(width: 140, child: Align(alignment: Alignment.centerRight, child: _GreyBox(w: 80))),
                ],
              ),
            ),
            const Divider(height: 1),
            Expanded(
              child: ListView.builder(
                itemCount: 10,
                itemBuilder: (context, index) => Container(
                  padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 8),
                  decoration: BoxDecoration(
                    border: Border(bottom: BorderSide(color: Colors.grey.shade200)),
                  ),
                  child: const Row(
                    children: [
                      SizedBox(width: 300, child: _GreyBox(w: 180)),
                      SizedBox(width: 140, child: _GreyBox(w: 100)),
                      SizedBox(width: 100, child: Align(alignment: Alignment.centerRight, child: _GreyBox(w: 50))),
                      SizedBox(width: 140, child: Align(alignment: Alignment.centerRight, child: _GreyBox(w: 70))),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _GreyBox extends StatelessWidget {
  final double w;
  const _GreyBox({required this.w});
  @override
  Widget build(BuildContext context) {
    return Container(width: w, height: 14, decoration: BoxDecoration(color: Colors.grey.shade200, borderRadius: BorderRadius.circular(4)));
  }
}

// Replaced old inline _ReceiveDialog with reusable ReceiveStockDialog widget.

// Replaced old inline _TransferDialog with reusable TransferStockDialog widget.