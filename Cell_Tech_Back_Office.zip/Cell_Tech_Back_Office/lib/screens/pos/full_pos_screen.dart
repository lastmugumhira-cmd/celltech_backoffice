import 'package:flutter/material.dart';

import 'dart:async';
import 'dart:math';
import '../../models/product.dart';
import '../../models/store.dart';
import '../../models/employee.dart';
import '../../models/category.dart';
import '../../models/shift.dart';
import '../../models/customer.dart';

import '../../services/database_service.dart';
import '../../widgets/components/customer_selector_dialog.dart';
import '../../widgets/components/receipts_panel.dart';
import '../../widgets/components/shifts_panel.dart';

class FullPOSScreen extends StatefulWidget {
  const FullPOSScreen({super.key});

  @override
  State<FullPOSScreen> createState() => _FullPOSScreenState();
}

class _FullPOSScreenState extends State<FullPOSScreen> {
  // Core state
  Store? selectedStore;
  Employee? currentEmployee;
  Shift? activeShift;
  Customer? selectedCustomer;
  bool isOnline = true;
  bool isLoading = false;
  bool isProcessingPayment = false;

  // Data
  List<Product> allProducts = [];
  List<Product> storeProducts = [];
  List<Product> filteredProducts = [];
  List<Store> stores = [];
  List<Category> categories = [];
  Map<String, String> appSettings = {};

  // Ticket
  List<TicketItem> ticketItems = [];
  double totalAmount = 0.0;
  double discountAmount = 0.0;
  String selectedPaymentMethod = 'Cash';

  // UI Controllers
  final TextEditingController _searchController = TextEditingController();
  final TextEditingController _discountController = TextEditingController();
  Timer? _inactivityTimer;
  final ScrollController _ticketScrollController = ScrollController();

  // Constants
  static const Duration inactivityDuration = Duration(minutes: 5);
  static const List<String> paymentMethods = ['Cash', 'Card', 'Mobile Pay'];

  @override
  void initState() {
    super.initState();
    _initializePOS();
  }

  @override
  void dispose() {
    _inactivityTimer?.cancel();
    _searchController.dispose();
    _discountController.dispose();
    _ticketScrollController.dispose();
    super.dispose();
  }

  // Initialization
  Future<void> _initializePOS() async {
    setState(() => isLoading = true);
    
    try {
      // Check if we have stored session data
      final storedStoreId = await _getStoredStoreId();
      final storedEmployeeId = await _getStoredEmployeeId();
      
      if (storedStoreId != null && storedEmployeeId != null) {
        await _loadSessionData(storedStoreId, storedEmployeeId);
      } else {
        await _showStoreSelection();
      }
    } catch (e) {
      _showError('Failed to initialize POS: $e');
    } finally {
      setState(() => isLoading = false);
    }
  }

  Future<void> _loadSessionData(int storeId, int employeeId) async {
    final stores = await DatabaseService.getStores();
    final employees = await DatabaseService.getEmployees();
    
    selectedStore = stores.firstWhere((s) => s.id == storeId);
    currentEmployee = employees.firstWhere((e) => e.id == employeeId);
    
    await _loadPOSData();
    _startInactivityTimer();
  }

  // Store Selection
  Future<void> _showStoreSelection() async {
    final stores = await DatabaseService.getStores();
    
    if (!mounted) return;
    
    final Store? store = await showDialog<Store>(
      context: context,
      barrierDismissible: false,
      builder: (context) => StoreSelectionDialog(stores: stores),
    );
    
    if (store != null) {
      selectedStore = store;
      await _storeStoreId(store.id!);
      await _showPINLogin();
    }
  }

  // PIN Login
  Future<void> _showPINLogin() async {
    if (!mounted) return;
    
    final Employee? employee = await showDialog<Employee>(
      context: context,
      barrierDismissible: false,
      builder: (context) => PINLoginDialog(store: selectedStore!),
    );
    
    if (employee != null) {
      currentEmployee = employee;
      await _storeEmployeeId(employee.id!);
      await _loadPOSData();
      _startInactivityTimer();
    }
  }

  // Data Loading
  Future<void> _loadPOSData() async {
    if (!isOnline) return;
    
    setState(() => isLoading = true);
    
    try {
      // Load all data
      final results = await Future.wait([
        DatabaseService.getProducts(),
        DatabaseService.getStores(),
        DatabaseService.getCategories(),
        _loadAppSettings(),
        _loadActiveShift(),
      ]);
      
      allProducts = results[0] as List<Product>;
      stores = results[1] as List<Store>;
      categories = results[2] as List<Category>;
      appSettings = results[3] as Map<String, String>;
      activeShift = results[4] as Shift?;
      
      _buildStoreProductList();
      _filterProducts();
      
    } catch (e) {
      _showError('Failed to load POS data: $e');
    } finally {
      setState(() => isLoading = false);
    }
  }

  void _buildStoreProductList() {
    storeProducts = allProducts.map((product) {
      // Adjust price and stock for current store
      final storePrice = _getStorePrice(product);
      final storeStock = _getStoreStock(product);

      
      return product.copyWith(
        price: storePrice,
        stock: storeStock,
        // Add category name for display
      );
    }).toList();
  }

  double _getStorePrice(Product product) {
    // Store-specific pricing logic
    return product.price; // Base implementation
  }

  int _getStoreStock(Product product) {
    // Store-specific stock logic
    return product.stock; // Base implementation
  }

  String _getCategoryName(int? categoryId) {
    if (categoryId == null) return 'Uncategorized';
    final category = categories.firstWhere(
      (c) => c.id == categoryId,
      orElse: () => Category(id: 0, name: 'Unknown', color: '#CCCCCC', description: ''),
    );
    return category.name;
  }

  Future<Map<String, String>> _loadAppSettings() async {
    // Load app settings from database/storage
    return {'allowNegativeStock': 'true'}; // Mock implementation
  }

  Future<Shift?> _loadActiveShift() async {
    final shifts = await _getMockShifts();
    return shifts.firstWhere(
      (s) => s.storeId == selectedStore?.id && 
             s.employeeId == currentEmployee?.id &&
             s.status == 'Open',
      orElse: () => shifts.first,
    );
  }

  // Search and Filtering
  void _filterProducts() {
    final query = _searchController.text.toLowerCase();
    setState(() {
      filteredProducts = storeProducts.where((product) {
        return product.name.toLowerCase().contains(query) ||
               (product.barcode?.contains(query) ?? false);
      }).toList();
    });
  }

  // Ticket Management
  void _addProductToTicket(Product product) {
    _resetInactivityTimer();
    
    final existingIndex = ticketItems.indexWhere((item) => item.product.id == product.id);
    
    setState(() {
      if (existingIndex >= 0) {
        ticketItems[existingIndex].quantity++;
      } else {
        ticketItems.add(TicketItem(product: product, quantity: 1));
      }
      _calculateTotal();
    });
    
    // Auto-scroll to payment on mobile when first item added
    if (ticketItems.length == 1 && MediaQuery.of(context).size.width < 768) {
      Future.delayed(const Duration(milliseconds: 300), () {
        _ticketScrollController.animateTo(
          _ticketScrollController.position.maxScrollExtent,
          duration: const Duration(milliseconds: 500),
          curve: Curves.easeOut,
        );
      });
    }
  }

  void _updateTicketItemQuantity(int index, int newQuantity) {
    _resetInactivityTimer();
    
    setState(() {
      if (newQuantity <= 0) {
        ticketItems.removeAt(index);
      } else {
        ticketItems[index].quantity = newQuantity;
      }
      _calculateTotal();
    });
  }

  void _clearTicket() {
    setState(() {
      ticketItems.clear();
      selectedCustomer = null;
      discountAmount = 0.0;
      _discountController.clear();
      _calculateTotal();
    });
  }

  void _calculateTotal() {
    double subtotal = ticketItems.fold(0.0, (sum, item) => 
        sum + (item.product.price * item.quantity));
    totalAmount = subtotal - discountAmount;
  }

  // Payment Processing
  Future<void> _processPayment() async {
    if (!_validatePayment()) return;
    
    setState(() => isProcessingPayment = true);
    
    try {
      final saleData = await _buildSaleData();
      final allowNegativeStock = appSettings['allowNegativeStock'] == 'true';
      
      final result = await _processSale(saleData, allowNegativeStock);
      
      if (result['success']) {
        // Update shift if returned
        if (result['shift'] != null) {
          activeShift = result['shift'];
        }
        
        // Update inventory immediately
        if (result['inventoryUpdates'] != null) {
          _applyInventoryUpdates(result['inventoryUpdates']);
        }
        
        _showSuccessMessage('Sale completed successfully!');
        _clearTicket();
        
      } else {
        _showError(result['error'] ?? 'Payment failed');
      }
      
    } catch (e) {
      _showError('Payment processing failed: $e');
    } finally {
      setState(() => isProcessingPayment = false);
    }
  }

  bool _validatePayment() {
    if (ticketItems.isEmpty) {
      _showError('No items in ticket');
      return false;
    }
    
    if (currentEmployee == null) {
      _showError('Not logged in');
      return false;
    }
    
    if (activeShift == null || activeShift!.status != 'Open') {
      _showError('No active shift. Please start a shift first.');
      _showShiftsPanel();
      return false;
    }
    
    if (!isOnline) {
      _showError('Payment requires internet connection');
      return false;
    }
    
    return true;
  }

  Future<Map<String, dynamic>> _buildSaleData() async {
    return {
      'ticketNumber': _generateTicketNumber(),
      'items': ticketItems.map((item) => {
        'productId': item.product.id,
        'quantity': item.quantity,
        'price': item.product.price,
        'total': item.product.price * item.quantity,
      }).toList(),
      'subtotal': ticketItems.fold(0.0, (sum, item) => 
          sum + (item.product.price * item.quantity)),
      'discount': discountAmount,
      'total': totalAmount,
      'paymentMethod': selectedPaymentMethod,
      'customerId': selectedCustomer?.id,
      'employeeId': currentEmployee!.id,
      'storeId': selectedStore!.id,
      'shiftId': activeShift!.id,
      'deviceId': await _getDeviceId(),
      'deviceName': await _getDeviceName(),
      'timestamp': DateTime.now().toIso8601String(),
    };
  }

  String _generateTicketNumber() {
    final now = DateTime.now();
    final random = Random();
    return '${now.year}${now.month.toString().padLeft(2, '0')}${now.day.toString().padLeft(2, '0')}-${random.nextInt(9999).toString().padLeft(4, '0')}';
  }

  Future<Map<String, dynamic>> _processSale(Map<String, dynamic> saleData, bool allowNegativeStock) async {
    // Simulate server call
    await Future.delayed(const Duration(seconds: 2));
    
    // Mock successful response
    return {
      'success': true,
      'shift': activeShift, // Updated shift
      'inventoryUpdates': ticketItems.map((item) => {
        'productId': item.product.id,
        'newStock': item.product.stock - item.quantity,
      }).toList(),
    };
  }

  void _applyInventoryUpdates(List<dynamic> updates) {
    for (final update in updates) {
      final productId = update['productId'];
      final newStock = update['newStock'];
      
      // Update filtered products
      final filteredIndex = filteredProducts.indexWhere((p) => p.id == productId);
      if (filteredIndex >= 0) {
        setState(() {
          filteredProducts[filteredIndex] = filteredProducts[filteredIndex].copyWith(stock: newStock);
        });
      }
      
      // Update store products
      final storeIndex = storeProducts.indexWhere((p) => p.id == productId);
      if (storeIndex >= 0) {
        storeProducts[storeIndex] = storeProducts[storeIndex].copyWith(stock: newStock);
      }
    }
  }

  // Inactivity Timer
  void _startInactivityTimer() {
    _inactivityTimer = Timer(inactivityDuration, _autoLogout);
  }

  void _resetInactivityTimer() {
    _inactivityTimer?.cancel();
    _startInactivityTimer();
  }

  void _autoLogout() {
    _logout(isAutoLogout: true);
  }

  // Authentication
  void _logout({bool isAutoLogout = false}) async {
    _inactivityTimer?.cancel();
    
    // Clear session data
    await _clearStoredSession();
    
    setState(() {
      selectedStore = null;
      currentEmployee = null;
      activeShift = null;
      selectedCustomer = null;
      ticketItems.clear();
      totalAmount = 0.0;
      discountAmount = 0.0;
    });
    
    if (isAutoLogout) {
      _showInfo('Logged out due to inactivity');
    }
    
    await _showStoreSelection();
  }

  // Panel Management
  void _showReceiptsPanel() {
    _resetInactivityTimer();
    _showPanel(ReceiptsPanel(shift: activeShift));
  }

  void _showShiftsPanel() {
    _resetInactivityTimer();
    _showPanel(ShiftsPanel(
      employee: currentEmployee!,
      store: selectedStore!,
      onShiftChanged: (shift) => setState(() => activeShift = shift),
    ));
  }

  void _showBackOffice() {
    _resetInactivityTimer();
    if (currentEmployee?.role == 'Admin') {
      Navigator.pushNamed(context, '/backoffice');
    } else {
      _showError('Admin access required');
    }
  }

  void _showCustomerSelector() async {
    _resetInactivityTimer();
    final Customer? customer = await showDialog<Customer>(
      context: context,
      builder: (context) => const CustomerSelectorDialog(),
    );
    
    if (customer != null) {
      setState(() => selectedCustomer = customer);
    }
  }

  void _showPanel(Widget panel) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (context) => DraggableScrollableSheet(
        initialChildSize: 0.7,
        maxChildSize: 0.9,
        minChildSize: 0.3,
        builder: (context, scrollController) => panel,
      ),
    );
  }

  // UI Helpers
  void _showError(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: Colors.red,
        duration: const Duration(seconds: 4),
      ),
    );
  }

  void _showSuccessMessage(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: Colors.green,
        duration: const Duration(seconds: 3),
      ),
    );
  }

  void _showInfo(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: Colors.blue,
        duration: const Duration(seconds: 3),
      ),
    );
  }

  // Storage helpers
  Future<int?> _getStoredStoreId() async {
    // Mock implementation - replace with actual storage
    return null;
  }

  Future<int?> _getStoredEmployeeId() async {
    // Mock implementation - replace with actual storage
    return null;
  }

  Future<void> _storeStoreId(int storeId) async {
    // Mock implementation - replace with actual storage
  }

  Future<void> _storeEmployeeId(int employeeId) async {
    // Mock implementation - replace with actual storage
  }

  Future<void> _clearStoredSession() async {
    // Mock implementation - replace with actual storage
  }

  Future<String> _getDeviceId() async {
    return 'device_${Random().nextInt(99999)}';
  }

  Future<String> _getDeviceName() async {
    return 'POS Terminal 1';
  }

  // Mock data
  Future<List<Shift>> _getMockShifts() async {
    return [
      Shift(
        id: 1,
        employeeId: currentEmployee?.id ?? 1,
        storeId: selectedStore?.id ?? 1,
        startTime: DateTime.now().subtract(const Duration(hours: 2)),
        status: 'Open',
      ),
    ];
  }

  @override
  Widget build(BuildContext context) {
    if (isLoading) {
      return const Scaffold(
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              CircularProgressIndicator(),
              SizedBox(height: 16),
              Text('Loading POS...'),
            ],
          ),
        ),
      );
    }

    if (!isOnline) {
      return Scaffold(
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Icon(Icons.wifi_off, size: 64, color: Colors.red),
              const SizedBox(height: 16),
              const Text(
                'Offline',
                style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 8),
              const Text('POS requires internet connection'),
              const SizedBox(height: 16),
              ElevatedButton(
                onPressed: () {
                  setState(() => isOnline = true);
                  _loadPOSData();
                },
                child: const Text('Retry'),
              ),
            ],
          ),
        ),
      );
    }

    if (selectedStore == null || currentEmployee == null) {
      return const Scaffold(
        body: Center(child: CircularProgressIndicator()),
      );
    }

    return Scaffold(
      body: GestureDetector(
        onTap: _resetInactivityTimer,
        onPanDown: (_) => _resetInactivityTimer(),
        child: Column(
          children: [
            _buildHeader(),
            Expanded(
              child: Row(
                children: [
                  Expanded(flex: 2, child: _buildProductArea()),
                  Container(
                    width: 1,
                    color: Colors.grey[300],
                  ),
                  Expanded(flex: 1, child: _buildTicketArea()),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildHeader() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Theme.of(context).primaryColor,
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.1),
            blurRadius: 4,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Row(
        children: [
          // Store info
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Text(
                      selectedStore!.name,
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(width: 8),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                      decoration: BoxDecoration(
                        color: isOnline ? Colors.green : Colors.red,
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Text(
                        isOnline ? 'Online' : 'Offline',
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 12,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ],
                ),
                Text(
                  'Cashier: ${currentEmployee!.name}',
                  style: const TextStyle(color: Colors.white70),
                ),
              ],
            ),
          ),
          
          // Action buttons
          Row(
            children: [
              _buildHeaderButton(
                icon: Icons.receipt_long,
                label: 'Receipts',
                onPressed: _showReceiptsPanel,
              ),
              const SizedBox(width: 8),
              _buildHeaderButton(
                icon: Icons.access_time,
                label: 'Shifts',
                onPressed: _showShiftsPanel,
              ),
              const SizedBox(width: 8),
              if (currentEmployee!.role == 'Admin')
                _buildHeaderButton(
                  icon: Icons.dashboard,
                  label: 'Back Office',
                  onPressed: _showBackOffice,
                ),
              const SizedBox(width: 8),
              _buildHeaderButton(
                icon: Icons.person,
                label: selectedCustomer?.name ?? 'Customer',
                onPressed: _showCustomerSelector,
                isSelected: selectedCustomer != null,
              ),
              const SizedBox(width: 8),
              _buildHeaderButton(
                icon: Icons.logout,
                label: 'Logout',
                onPressed: () => _logout(),
                color: Colors.red[700],
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildHeaderButton({
    required IconData icon,
    required String label,
    required VoidCallback onPressed,
    bool isSelected = false,
    Color? color,
  }) {
    return ElevatedButton.icon(
      onPressed: onPressed,
      icon: Icon(icon, size: 18),
      label: Text(label, style: const TextStyle(fontSize: 12)),
      style: ElevatedButton.styleFrom(
        backgroundColor: isSelected 
            ? Colors.orange 
            : color ?? Colors.white.withOpacity(0.2),
        foregroundColor: Colors.white,
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        minimumSize: const Size(0, 36),
      ),
    );
  }

  Widget _buildProductArea() {
    return Column(
      children: [
        // Search bar
        Padding(
          padding: const EdgeInsets.all(16),
          child: TextField(
            controller: _searchController,
            onChanged: (_) => _filterProducts(),
            onTap: _resetInactivityTimer,
            decoration: InputDecoration(
              hintText: 'Search products...',
              prefixIcon: const Icon(Icons.search),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(8),
              ),
              suffixIcon: _searchController.text.isNotEmpty
                  ? IconButton(
                      icon: const Icon(Icons.clear),
                      onPressed: () {
                        _searchController.clear();
                        _filterProducts();
                      },
                    )
                  : null,
            ),
          ),
        ),
        
        // Product grid
        Expanded(
          child: GridView.builder(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 3,
              crossAxisSpacing: 12,
              mainAxisSpacing: 12,
              childAspectRatio: 0.85,
            ),
            itemCount: filteredProducts.length,
            itemBuilder: (context, index) {
              final product = filteredProducts[index];
              return _buildProductCard(product);
            },
          ),
        ),
      ],
    );
  }

  Widget _buildProductCard(Product product) {
    final categoryName = _getCategoryName(product.categoryId);
    final isLowStock = product.stock <= 5;
    final isOutOfStock = product.stock <= 0;
    
    return Card(
      child: InkWell(
        onTap: isOutOfStock && appSettings['allowNegativeStock'] != 'true'
            ? null
            : () => _addProductToTicket(product),
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Product name
              Expanded(
                child: Text(
                  product.name,
                  style: const TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 14,
                  ),
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                ),
              ),
              
              const SizedBox(height: 8),
              
              // Category
              Text(
                categoryName,
                style: TextStyle(
                  color: Colors.grey[600],
                  fontSize: 12,
                ),
              ),
              
              const SizedBox(height: 8),
              
              // Price and stock
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    '\$${product.price.toStringAsFixed(2)}',
                    style: const TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 16,
                      color: Colors.green,
                    ),
                  ),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                    decoration: BoxDecoration(
                      color: isOutOfStock
                          ? Colors.red
                          : isLowStock
                              ? Colors.orange
                              : Colors.green,
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Text(
                      '${product.stock}',
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 12,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildTicketArea() {
    return Container(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          // Ticket header
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text(
                'Current Ticket',
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                ),
              ),
              if (ticketItems.isNotEmpty)
                TextButton(
                  onPressed: _clearTicket,
                  child: const Text('Clear All'),
                ),
            ],
          ),
          
          const SizedBox(height: 16),
          
          // Ticket items
          Expanded(
            child: ticketItems.isEmpty
                ? const Center(
                    child: Text(
                      'No items in ticket\nScan or select products to add',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        color: Colors.grey,
                        fontSize: 16,
                      ),
                    ),
                  )
                : ListView.builder(
                    controller: _ticketScrollController,
                    itemCount: ticketItems.length,
                    itemBuilder: (context, index) {
                      return _buildTicketItem(ticketItems[index], index);
                    },
                  ),
          ),
          
          if (ticketItems.isNotEmpty) ...[
            const Divider(),
            _buildTicketSummary(),
            const SizedBox(height: 16),
            _buildPaymentSection(),
          ],
        ],
      ),
    );
  }

  Widget _buildTicketItem(TicketItem item, int index) {
    return Card(
      margin: const EdgeInsets.only(bottom: 8),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Row(
          children: [
            // Item details
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    item.product.name,
                    style: const TextStyle(fontWeight: FontWeight.bold),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                  Text(
                    '\$${item.product.price.toStringAsFixed(2)} each',
                    style: TextStyle(color: Colors.grey[600]),
                  ),
                ],
              ),
            ),
            
            // Quantity controls
            Row(
              children: [
                IconButton(
                  onPressed: () => _updateTicketItemQuantity(index, item.quantity - 1),
                  icon: const Icon(Icons.remove),
                  iconSize: 18,
                ),
                Container(
                  width: 40,
                  alignment: Alignment.center,
                  child: Text(
                    '${item.quantity}',
                    style: const TextStyle(fontWeight: FontWeight.bold),
                  ),
                ),
                IconButton(
                  onPressed: () => _updateTicketItemQuantity(index, item.quantity + 1),
                  icon: const Icon(Icons.add),
                  iconSize: 18,
                ),
              ],
            ),
            
            // Total
            SizedBox(
              width: 60,
              child: Text(
                '\$${(item.product.price * item.quantity).toStringAsFixed(2)}',
                style: const TextStyle(fontWeight: FontWeight.bold),
                textAlign: TextAlign.right,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTicketSummary() {
    final subtotal = ticketItems.fold(0.0, (sum, item) => 
        sum + (item.product.price * item.quantity));
    
    return Column(
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            const Text('Subtotal:'),
            Text('\$${subtotal.toStringAsFixed(2)}'),
          ],
        ),
        if (discountAmount > 0) ...[
          const SizedBox(height: 4),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text('Discount:'),
              Text('-\$${discountAmount.toStringAsFixed(2)}'),
            ],
          ),
        ],
        const SizedBox(height: 8),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            const Text(
              'Total:',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
            Text(
              '\$${totalAmount.toStringAsFixed(2)}',
              style: const TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: Colors.green,
              ),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildPaymentSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        // Payment method
        DropdownButtonFormField<String>(
          initialValue: selectedPaymentMethod,
          decoration: const InputDecoration(
            labelText: 'Payment Method',
            border: OutlineInputBorder(),
          ),
          items: paymentMethods.map((method) => DropdownMenuItem(
            value: method,
            child: Text(method),
          )).toList(),
          onChanged: (value) {
            if (value != null) {
              setState(() => selectedPaymentMethod = value);
            }
          },
        ),
        
        const SizedBox(height: 12),
        
        // Discount
        TextField(
          controller: _discountController,
          keyboardType: TextInputType.number,
          onTap: _resetInactivityTimer,
          decoration: const InputDecoration(
            labelText: 'Discount Amount',
            prefixText: '\$',
            border: OutlineInputBorder(),
          ),
          onChanged: (value) {
            final discount = double.tryParse(value) ?? 0.0;
            setState(() {
              discountAmount = discount;
              _calculateTotal();
            });
          },
        ),
        
        const SizedBox(height: 16),
        
        // Pay button
        ElevatedButton(
          onPressed: isProcessingPayment ? null : _processPayment,
          style: ElevatedButton.styleFrom(
            backgroundColor: Colors.green,
            foregroundColor: Colors.white,
            padding: const EdgeInsets.symmetric(vertical: 16),
            textStyle: const TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
            ),
          ),
          child: isProcessingPayment
              ? const Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    SizedBox(
                      width: 20,
                      height: 20,
                      child: CircularProgressIndicator(color: Colors.white),
                    ),
                    SizedBox(width: 8),
                    Text('Processing...'),
                  ],
                )
              : Text('Pay \$${totalAmount.toStringAsFixed(2)}'),
        ),
      ],
    );
  }
}

// Support classes
class TicketItem {
  final Product product;
  int quantity;

  TicketItem({required this.product, required this.quantity});
}

// Store Selection Dialog
class StoreSelectionDialog extends StatelessWidget {
  final List<Store> stores;

  const StoreSelectionDialog({super.key, required this.stores});

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Text('Select Store'),
      content: SizedBox(
        width: double.maxFinite,
        child: ListView.builder(
          shrinkWrap: true,
          itemCount: stores.length,
          itemBuilder: (context, index) {
            final store = stores[index];
            return ListTile(
              title: Text(store.name),
              subtitle: Text(store.address),
              onTap: () => Navigator.of(context).pop(store),
            );
          },
        ),
      ),
    );
  }
}

// PIN Login Dialog
class PINLoginDialog extends StatefulWidget {
  final Store store;

  const PINLoginDialog({super.key, required this.store});

  @override
  State<PINLoginDialog> createState() => _PINLoginDialogState();
}

class _PINLoginDialogState extends State<PINLoginDialog> {
  final TextEditingController _pinController = TextEditingController();
  bool isLoading = false;

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text('Login to ${widget.store.name}'),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Text('Enter your PIN to continue'),
          const SizedBox(height: 16),
          TextField(
            controller: _pinController,
            obscureText: true,
            keyboardType: TextInputType.number,
            maxLength: 4,
            decoration: const InputDecoration(
              labelText: 'PIN',
              border: OutlineInputBorder(),
            ),
            onSubmitted: (_) => _login(),
          ),
        ],
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.of(context).pop(),
          child: const Text('Cancel'),
        ),
        ElevatedButton(
          onPressed: isLoading ? null : _login,
          child: isLoading
              ? const SizedBox(
                  width: 20,
                  height: 20,
                  child: CircularProgressIndicator(),
                )
              : const Text('Login'),
        ),
      ],
    );
  }

  Future<void> _login() async {
    final pin = _pinController.text;
    if (pin.length != 4) return;

    setState(() => isLoading = true);

    try {
      final employees = await DatabaseService.getEmployees();
      final employee = employees.firstWhere(
        (e) => e.pin == pin,
        orElse: () => throw Exception('Invalid PIN'),
      );

      // Check store access for non-admins
      if (employee.role != 'Admin' && !employee.assignedStoreIds.contains(widget.store.id.toString())) {
        throw Exception('Not authorized for this store');
      }

      if (!mounted) return;
      Navigator.of(context).pop(employee);

    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(e.toString()),
          backgroundColor: Colors.red,
        ),
      );
    } finally {
      setState(() => isLoading = false);
    }
  }
}