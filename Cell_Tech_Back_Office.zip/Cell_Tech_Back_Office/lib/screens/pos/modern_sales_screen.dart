import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../../models/product.dart';
import '../../models/customer.dart';
import '../../models/employee.dart';
import '../../models/store.dart';
import '../../models/shift.dart';
import '../../models/sale.dart';
import '../../services/database_service.dart';
import '../../widgets/components/customer_selector_dialog.dart';
import '../back_office/dashboard_screen.dart';

// Payment Method data class
class PaymentMethod {
  final String type;
  final String currency;
  final double amount;

  PaymentMethod({
    required this.type,
    required this.currency,
    required this.amount,
  });
}

// Payment Dialog Widget
class PaymentDialog extends StatefulWidget {
  final double totalAmount;
  final Function(List<PaymentMethod>) onPaymentConfirmed;

  const PaymentDialog({
    super.key,
    required this.totalAmount,
    required this.onPaymentConfirmed,
  });

  @override
  State<PaymentDialog> createState() => _PaymentDialogState();
}

class _PaymentDialogState extends State<PaymentDialog> {
  static const Color _brandColor = Color(0xFFFF5F1F);
  
  final List<PaymentMethod> _payments = [];
  double _remainingAmount = 0.0;
  String _selectedType = 'Cash';
  String _selectedCurrency = 'USD';
  final TextEditingController _amountController = TextEditingController();

  final Map<String, List<String>> _paymentOptions = {
    'Cash': ['USD', 'ZIG', 'BWP', 'ZAR'],
    'Ecocash': ['USD', 'ZIG'],
  };

  final Map<String, String> _currencyFullNames = {
    'USD': 'US Dollar',
    'ZIG': 'Zimbabwe Gold',
    'BWP': 'Botswana Pula',
    'ZAR': 'South African Rand',
  };

  final Map<String, Color> _paymentColors = {
    'Cash': Colors.green,
    'Ecocash': Colors.orange,
  };

  @override
  void initState() {
    super.initState();
    _remainingAmount = widget.totalAmount;
    _amountController.text = widget.totalAmount.toStringAsFixed(2);
  }

  @override
  void dispose() {
    _amountController.dispose();
    super.dispose();
  }

  void _addPayment() {
    final amount = double.tryParse(_amountController.text) ?? 0.0;
    if (amount <= 0) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please enter a valid amount')),
      );
      return;
    }

    if (amount > _remainingAmount) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Amount cannot exceed remaining balance')),
      );
      return;
    }

    setState(() {
      _payments.add(PaymentMethod(
        type: _selectedType,
        currency: _selectedCurrency,
        amount: amount,
      ));
      _remainingAmount -= amount;
      _amountController.text = _remainingAmount.toStringAsFixed(2);
    });
  }

  void _removePayment(int index) {
    setState(() {
      _remainingAmount += _payments[index].amount;
      _payments.removeAt(index);
      _amountController.text = _remainingAmount.toStringAsFixed(2);
    });
  }

  void _confirmPayment() {
    if (_remainingAmount > 0.01) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please complete the payment allocation')),
      );
      return;
    }

    Navigator.of(context).pop();
    widget.onPaymentConfirmed(_payments);
  }

  @override
  Widget build(BuildContext context) {
    return Dialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: Container(
        width: 600,
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(Icons.payment, color: _brandColor, size: 24),
                const SizedBox(width: 12),
                const Text(
                  'Payment Method',
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                ),
                const Spacer(),
                IconButton(
                  onPressed: () => Navigator.of(context).pop(),
                  icon: const Icon(Icons.close),
                ),
              ],
            ),
            const SizedBox(height: 24),
            
            // Total and Remaining Amount
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.grey.shade100,
                borderRadius: BorderRadius.circular(12),
              ),
              child: Row(
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text('Total Amount', style: TextStyle(fontSize: 14, color: Colors.grey)),
                        Text('\$${widget.totalAmount.toStringAsFixed(2)}', 
                             style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                      ],
                    ),
                  ),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text('Remaining', style: TextStyle(fontSize: 14, color: Colors.grey)),
                        Text('\$${_remainingAmount.toStringAsFixed(2)}', 
                             style: TextStyle(
                               fontSize: 18, 
                               fontWeight: FontWeight.bold,
                               color: _remainingAmount > 0.01 ? Colors.red : Colors.green,
                             )),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 24),
            
            // Payment Type Selection
            const Text('Payment Method', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
            const SizedBox(height: 8),
            Row(
              children: _paymentOptions.keys.map((type) {
                final isSelected = _selectedType == type;
                return Expanded(
                  child: Padding(
                    padding: const EdgeInsets.only(right: 8),
                    child: GestureDetector(
                      onTap: () {
                        setState(() {
                          _selectedType = type;
                          _selectedCurrency = _paymentOptions[type]!.first;
                        });
                      },
                      child: Container(
                        padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 16),
                        decoration: BoxDecoration(
                          color: isSelected ? _paymentColors[type] : Colors.grey.shade200,
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(
                              type == 'Cash' ? Icons.payments : Icons.phone_android,
                              color: isSelected ? Colors.white : Colors.grey.shade600,
                              size: 20,
                            ),
                            const SizedBox(width: 8),
                            Text(
                              type,
                              style: TextStyle(
                                color: isSelected ? Colors.white : Colors.grey.shade600,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                );
              }).toList(),
            ),
            const SizedBox(height: 16),
            
            // Currency Selection
            const Text('Currency', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
            const SizedBox(height: 8),
            DropdownButtonFormField<String>(
              value: _selectedCurrency,
              decoration: InputDecoration(
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
                contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
              ),
              items: _paymentOptions[_selectedType]!.map((currency) {
                return DropdownMenuItem(
                  value: currency,
                  child: Text('$currency - ${_currencyFullNames[currency]}'),
                );
              }).toList(),
              onChanged: (value) {
                if (value != null) {
                  setState(() => _selectedCurrency = value);
                }
              },
            ),
            const SizedBox(height: 16),
            
            // Amount Input
            Row(
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text('Amount', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
                      const SizedBox(height: 8),
                      TextFormField(
                        controller: _amountController,
                        keyboardType: const TextInputType.numberWithOptions(decimal: true),
                        decoration: InputDecoration(
                          border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
                          prefixText: '\$',
                          contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 12),
                Padding(
                  padding: const EdgeInsets.only(top: 24),
                  child: ElevatedButton(
                    onPressed: _remainingAmount > 0.01 ? _addPayment : null,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: _brandColor,
                      foregroundColor: Colors.white,
                      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                    ),
                    child: const Text('Add'),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 24),
            
            // Payment List
            if (_payments.isNotEmpty) ...[
              const Text('Payment Breakdown', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
              const SizedBox(height: 8),
              Container(
                constraints: const BoxConstraints(maxHeight: 200),
                child: ListView.builder(
                  shrinkWrap: true,
                  itemCount: _payments.length,
                  itemBuilder: (context, index) {
                    final payment = _payments[index];
                    return Card(
                      margin: const EdgeInsets.only(bottom: 8),
                      child: ListTile(
                        leading: Icon(
                          payment.type == 'Cash' ? Icons.payments : Icons.phone_android,
                          color: _paymentColors[payment.type],
                        ),
                        title: Text('${payment.type} (${payment.currency})'),
                        subtitle: Text(_currencyFullNames[payment.currency] ?? payment.currency),
                        trailing: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Text('\$${payment.amount.toStringAsFixed(2)}', 
                                 style: const TextStyle(fontWeight: FontWeight.bold)),
                            IconButton(
                              onPressed: () => _removePayment(index),
                              icon: const Icon(Icons.delete, color: Colors.red),
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                ),
              ),
              const SizedBox(height: 24),
            ],
            
            // Action Buttons
            Row(
              children: [
                Expanded(
                  child: OutlinedButton(
                    onPressed: () => Navigator.of(context).pop(),
                    style: OutlinedButton.styleFrom(
                      padding: const EdgeInsets.symmetric(vertical: 12),
                    ),
                    child: const Text('Cancel'),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: ElevatedButton(
                    onPressed: _remainingAmount <= 0.01 ? _confirmPayment : null,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: _brandColor,
                      foregroundColor: Colors.white,
                      padding: const EdgeInsets.symmetric(vertical: 12),
                    ),
                    child: const Text('Confirm Payment'),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class ModernSalesScreen extends StatefulWidget {
  final Employee employee;
  final Store store;

  const ModernSalesScreen({
    super.key,
    required this.employee,
    required this.store,
  });

  @override
  State<ModernSalesScreen> createState() => _ModernSalesScreenState();
}

class _ModernSalesScreenState extends State<ModernSalesScreen>
    with TickerProviderStateMixin {

  // Brand color constant
  static const Color _brandColor = Color(0xFFFF5F1F);
  
  // State variables
  List<Product> _products = [];
  List<Product> _filteredProducts = [];
  final List<TicketItem> _currentTicket = [];
  String _searchTerm = '';
  Customer? _selectedCustomer;
  Shift? _currentShift;
  bool _isLoading = true;
  bool _isProcessing = false;
  bool _isOnline = true;
  
  // New state variables
  bool _isGridView = false; // Default to list view
  List<Map<String, dynamic>> _categories = [];
  List<Customer> _customers = [];
  int? _selectedCategoryId;
  double _discountAmount = 0.0;
  
  // Controllers
  final TextEditingController _searchController = TextEditingController();
  Timer? _inactivityTimer;
  
  // Animation controllers
  late AnimationController _fadeAnimationController;
  late AnimationController _slideAnimationController;
  late Animation<double> _fadeAnimation;
  late Animation<Offset> _slideAnimation;

  @override
  void initState() {
    super.initState();
    _initializeAnimations();
    _initializeData();
    _setupInactivityTimer();
    _startConnectivityCheck();
  }

  void _initializeAnimations() {
    _fadeAnimationController = AnimationController(
      duration: const Duration(milliseconds: 600),
      vsync: this,
    );
    _slideAnimationController = AnimationController(
      duration: const Duration(milliseconds: 800),
      vsync: this,
    );
    
    _fadeAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _fadeAnimationController, curve: Curves.easeOut),
    );
    
    _slideAnimation = Tween<Offset>(
      begin: const Offset(0, 0.1),
      end: Offset.zero,
    ).animate(CurvedAnimation(
      parent: _slideAnimationController, 
      curve: Curves.easeOutCubic
    ));

    _fadeAnimationController.forward();
    _slideAnimationController.forward();
  }

  Future<void> _initializeData() async {
    try {
      setState(() => _isLoading = true);
      
      // Load store stock for current store only
      final storeStock = await DatabaseService.getStoreStock(widget.store.id!);
      
      // Convert store stock to Product objects
      final products = storeStock.map((stockItem) => Product(
        id: stockItem['id'] as int?,
        name: stockItem['name'] as String,
        description: stockItem['description'] as String?,
        sku: stockItem['sku'] as String,
        categoryId: stockItem['category_id'] as int,
        price: (stockItem['price'] as num).toDouble(),
        cost: stockItem['cost'] != null ? (stockItem['cost'] as num).toDouble() : null,
        stock: stockItem['stock_quantity'] as int? ?? 0,
        trackStock: (stockItem['track_stock'] as int? ?? 1) == 1,
        active: (stockItem['active'] as int? ?? 1) == 1,
        createdAt: DateTime.tryParse(stockItem['created_at'] as String? ?? '') ?? DateTime.now(),
      )).where((p) => p.active).toList();
      
      // Load categories
      final categories = await DatabaseService.getCategories();
      
      // Load customers
      final customers = await DatabaseService.getCustomers();
      
      // Load active shift for today only - persistent across app restarts
      final activeShift = await DatabaseService.getActiveShift(
        employeeId: widget.employee.id!,
        storeId: widget.store.id!,
      );
      
      // Create category list for dropdown
      final categoryList = [
        {'id': null, 'name': 'All Categories'},
        ...categories.map((cat) => {'id': cat.id, 'name': cat.name}),
      ];
      
      setState(() {
        _products = products;
        _filteredProducts = products;
        _categories = categoryList;
        _customers = customers;
        _currentShift = activeShift;
        _isLoading = false;
      });
      
      _filterProducts();
    } catch (e) {
      setState(() => _isLoading = false);
      _showErrorSnackBar('Failed to load data: $e');
    }
  }

  void _setupInactivityTimer() {
    _resetInactivityTimer();
  }

  void _resetInactivityTimer() {
    _inactivityTimer?.cancel();
    
    _inactivityTimer = Timer(const Duration(minutes: 5), () {
      _showAutoLogoutDialog();
    });
  }

  void _showAutoLogoutDialog() {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        title: const Row(
          children: [
            Icon(Icons.warning_amber_rounded, color: Colors.orange),
            SizedBox(width: 8),
            Text('Auto Logout'),
          ],
        ),
        content: const Text(
          'You have been automatically logged out due to inactivity.',
        ),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.of(context).pop();
              _handleLogout();
            },
            child: const Text('OK'),
          ),
        ],
      ),
    );
  }

  void _startConnectivityCheck() {
    // Check connectivity every 30 seconds
    Timer.periodic(const Duration(seconds: 30), (timer) {
      _checkConnectivity();
    });
    // Initial check
    _checkConnectivity();
  }

  void _checkConnectivity() async {
    try {
      // Try to access the database as a connectivity test
      await DatabaseService.database;
      if (!_isOnline) {
        setState(() => _isOnline = true);
      }
    } catch (e) {
      if (_isOnline) {
        setState(() => _isOnline = false);
      }
    }
  }

  Future<List<Map<String, dynamic>>> _loadShiftSalesWithRetry(int shiftId, {int maxRetries = 3}) async {
    for (int attempt = 0; attempt < maxRetries; attempt++) {
      try {
        final sales = await DatabaseService.getShiftSales(shiftId);
        return sales;
      } catch (e) {
        print('Attempt ${attempt + 1} failed: $e');
        if (attempt == maxRetries - 1) {
          // On final attempt, return empty list instead of throwing
          return [];
        }
        // Wait a bit before retrying
        await Future.delayed(Duration(milliseconds: 500 * (attempt + 1)));
      }
    }
    return [];
  }

  void _filterProducts() {
    setState(() {
      _filteredProducts = _products.where((product) {
        // Search filter
        final matchesSearch = product.name.toLowerCase().contains(_searchTerm.toLowerCase()) ||
                             product.sku.toLowerCase().contains(_searchTerm.toLowerCase());
        
        // Category filter
        final matchesCategory = _selectedCategoryId == null || product.categoryId == _selectedCategoryId;
        
        return matchesSearch && matchesCategory;
      }).toList();
    });
  }

  void _addToTicket(Product product) {
    setState(() {
      final existingIndex = _currentTicket.indexWhere(
        (item) => item.productId == product.id,
      );
      
      if (existingIndex >= 0) {
        _currentTicket[existingIndex] = _currentTicket[existingIndex].copyWith(
          quantity: _currentTicket[existingIndex].quantity + 1,
        );
      } else {
        _currentTicket.add(TicketItem(
          productId: product.id!,
          productName: product.name,
          quantity: 1,
          price: product.price,
        ));
      }
    });
    
    _resetInactivityTimer();
    HapticFeedback.lightImpact();
  }

  void _updateQuantity(int productId, int change) {
    setState(() {
      final index = _currentTicket.indexWhere((item) => item.productId == productId);
      if (index >= 0) {
        final newQuantity = _currentTicket[index].quantity + change;
        if (newQuantity <= 0) {
          _currentTicket.removeAt(index);
        } else {
          _currentTicket[index] = _currentTicket[index].copyWith(quantity: newQuantity);
        }
      }
    });
    _resetInactivityTimer();
  }

  void _clearTicket() {
    setState(() {
      _currentTicket.clear();
      _selectedCustomer = null;
      _discountAmount = 0.0; // Reset discount when clearing ticket
    });
    HapticFeedback.mediumImpact();
  }

  void _showPaymentDialog() {
    if (_currentTicket.isEmpty) {
      _showErrorSnackBar('Cannot process payment with empty ticket');
      return;
    }

    if (_currentShift == null) {
      _showErrorSnackBar('No active shift found. Please start a shift first.');
      return;
    }

    final subtotal = _currentTicket.fold<double>(
      0.0, (sum, item) => sum + item.total,
    );
    final finalTotal = subtotal - _discountAmount;

    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => PaymentDialog(
        totalAmount: finalTotal,
        onPaymentConfirmed: (List<PaymentMethod> payments) async {
          await _processMultiplePayments(payments);
        },
      ),
    );
  }

  Future<void> _processMultiplePayments(List<PaymentMethod> payments) async {
    setState(() => _isProcessing = true);

    try {
      final subtotal = _currentTicket.fold<double>(
        0.0, (sum, item) => sum + item.total,
      );
      final finalTotal = subtotal - _discountAmount;

      // Combine payment methods into a single string
      final paymentMethodString = payments.map((p) => '${p.type} ${p.currency} (\$${p.amount.toStringAsFixed(2)})').join(', ');

      // Create sale record
      final sale = Sale(
        ticketNumber: 'TKT-${DateTime.now().millisecondsSinceEpoch}',
        storeId: widget.store.id!,
        employeeId: widget.employee.id!,
        customerId: _selectedCustomer?.id,
        shiftId: _currentShift?.id,
        saleDate: DateTime.now(),
        subtotal: subtotal,
        taxAmount: 0.0,
        discountAmount: _discountAmount,
        totalAmount: finalTotal,
        paymentMethod: paymentMethodString,
        status: 'completed',
        createdAt: DateTime.now(),
      );

      // Create sale items
      final saleItems = _currentTicket.map((item) => SaleItem(
        saleId: 0, // Will be updated after sale is inserted
        productId: item.productId,
        quantity: item.quantity,
        unitPrice: item.price,
        lineTotal: item.total,
      )).toList();

      // Save sale to database
      await DatabaseService.insertSale(sale, saleItems);

      // Update shift totals in database
      if (_currentShift?.id != null) {
        await DatabaseService.updateShiftSales(_currentShift!.id!, finalTotal);
        
        // Refresh shift data from database
        final updatedShift = await DatabaseService.getShiftById(_currentShift!.id!);
        setState(() => _currentShift = updatedShift);
      }

      // Show success and clear ticket
      _showSuccessSnackBar(
        'Sale completed! Ticket #${sale.ticketNumber} - Total: \$${finalTotal.toStringAsFixed(2)}',
      );
      
      _clearTicket();
      await _initializeData(); // Refresh data

    } catch (e) {
      _showErrorSnackBar('Failed to process payment: $e');
    } finally {
      setState(() => _isProcessing = false);
    }
  }

  void _handleLogout() {
    _showLogoutConfirmationDialog();
  }

  void _showLogoutConfirmationDialog() {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext context) {
        return AlertDialog(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
          ),
          title: Row(
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: Colors.red.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: const Icon(
                  Icons.logout,
                  color: Colors.red,
                  size: 24,
                ),
              ),
              const SizedBox(width: 12),
              const Text(
                'Confirm Logout',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                  color: Color(0xFF111827),
                ),
              ),
            ],
          ),
          content: const Text(
            'Are you sure you want to logout? Any unsaved work will be lost.',
            style: TextStyle(
              fontSize: 16,
              color: Color(0xFF6B7280),
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              style: TextButton.styleFrom(
                padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8),
                ),
              ),
              child: const Text(
                'Cancel',
                style: TextStyle(
                  color: Color(0xFF6B7280),
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
            Container(
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  colors: [Color(0xFFDC2626), Color(0xFFB91C1C)],
                ),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Material(
                color: Colors.transparent,
                child: InkWell(
                  onTap: () {
                    Navigator.of(context).pop();
                    Navigator.of(context).pushNamedAndRemoveUntil(
                      '/login',
                      (route) => false,
                    );
                  },
                  borderRadius: BorderRadius.circular(8),
                  child: const Padding(
                    padding: EdgeInsets.symmetric(horizontal: 20, vertical: 12),
                    child: Text(
                      'Logout',
                      style: TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ],
        );
      },
    );
  }

  void _showErrorSnackBar(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            const Icon(Icons.error_outline, color: Colors.white),
            const SizedBox(width: 8),
            Expanded(child: Text(message)),
          ],
        ),
        backgroundColor: Colors.red[600],
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  void _showSuccessSnackBar(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            const Icon(Icons.check_circle_outline, color: Colors.white),
            const SizedBox(width: 8),
            Expanded(child: Text(message)),
          ],
        ),
        backgroundColor: Colors.green[600],
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  @override
  void dispose() {
    _inactivityTimer?.cancel();
    _searchController.dispose();
    _fadeAnimationController.dispose();
    _slideAnimationController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              Color(0xFFFFF7ED), // orange-50
              Color(0xFFFED7AA), // orange-200
              Color(0xFFFEECE2), // orange-100
              Color(0xFFFFF7ED), // orange-50
            ],
            stops: [0.0, 0.3, 0.7, 1.0],
          ),
        ),
        child: _isLoading ? _buildLoadingScreen() : _buildMainContent(),
      ),
    );
  }

  Widget _buildLoadingScreen() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            width: 64,
            height: 64,
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [Color(0xFFEA580C), Color(0xFFDC2626), Color(0xFFD97706)],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(20),
              boxShadow: [
                BoxShadow(
                  color: Colors.orange.withOpacity(0.4),
                  blurRadius: 12,
                  offset: const Offset(0, 6),
                ),
              ],
            ),
            child: const Center(
              child: SizedBox(
                width: 32,
                height: 32,
                child: CircularProgressIndicator(
                  strokeWidth: 4,
                  valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
                ),
              ),
            ),
          ),
          const SizedBox(height: 16),
          const Text(
            'CellTech PoS',
            style: TextStyle(
              fontSize: 28,
              fontWeight: FontWeight.bold,
              color: Color(0xFFEA580C),
              letterSpacing: 1.2,
            ),
          ),
          const SizedBox(height: 8),
          const Text(
            'Loading products...',
            style: TextStyle(
              fontSize: 16,
              color: Color(0xFFF97316),
              fontWeight: FontWeight.w500,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildMainContent() {
    return FadeTransition(
      opacity: _fadeAnimation,
      child: SlideTransition(
        position: _slideAnimation,
        child: Row(
          children: [
            // Product List Panel
            Expanded(
              flex: 2,
              child: _buildProductPanel(),
            ),
            // Ticket Panel
            Container(
              width: 400,
              decoration: const BoxDecoration(
                color: Colors.white,
                border: Border(
                  left: BorderSide(color: Color(0xFFE5E7EB)),
                ),
              ),
              child: _buildTicketPanel(),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildProductPanel() {
    return Column(
      children: [
        _buildHeader(),
        _buildSearchBar(),
        Expanded(child: _isGridView ? _buildProductGrid() : _buildProductList()),
      ],
    );
  }

  Widget _buildHeader() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            Color(0xFFFFFBF2), // orange-25 (very light)
            Color(0xFFFFF7ED), // orange-50
          ],
        ),
        border: const Border(
          bottom: BorderSide(color: Color(0xFFD97706), width: 2), // orange-600 border
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.orange.withOpacity(0.1),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        children: [
          Row(
            children: [
              Expanded(
                child: Row(
                  children: [
                    Text(
                      widget.store.name,
                      style: const TextStyle(
                        fontSize: 22,
                        fontWeight: FontWeight.bold,
                        color: Color(0xFFEA580C), // orange-600
                        letterSpacing: 0.5,
                      ),
                    ),
                    const SizedBox(width: 12),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          colors: _isOnline 
                            ? [const Color(0xFF059669), const Color(0xFF047857)]
                            : [const Color(0xFFDC2626), const Color(0xFFB91C1C)],
                        ),
                        borderRadius: BorderRadius.circular(16),
                        boxShadow: [
                          BoxShadow(
                            color: (_isOnline ? Colors.green : Colors.red).withOpacity(0.3),
                            blurRadius: 4,
                            offset: const Offset(0, 2),
                          ),
                        ],
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(
                            _isOnline ? Icons.wifi : Icons.wifi_off, 
                            size: 14, 
                            color: Colors.white
                          ),
                          const SizedBox(width: 6),
                          Text(
                            _isOnline ? 'Online' : 'Offline',
                            style: const TextStyle(
                              fontSize: 12,
                              color: Colors.white,
                              fontWeight: FontWeight.w600,
                              letterSpacing: 0.3,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              Row(
                children: [
                  _buildHeaderButton(
                    icon: Icons.receipt_long,
                    label: 'Receipts',
                    onPressed: () => _showReceiptsPanel(),
                  ),
                  const SizedBox(width: 12),
                  _buildHeaderButton(
                    icon: Icons.schedule,
                    label: 'Shifts',
                    onPressed: () => _showShiftsPanel(),
                  ),
                  const SizedBox(width: 12),
                  if (widget.employee.role == 'admin')
                    _buildHeaderButton(
                      icon: Icons.dashboard_customize,
                      label: 'Back Office',
                      onPressed: () => Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => const DashboardScreen(),
                        ),
                      ),
                    ),
                ],
              ),
            ],
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                child: Row(
                  children: [
                    _buildHeaderButton(
                      icon: _selectedCustomer != null ? Icons.person : Icons.person_add,
                      label: _selectedCustomer?.name ?? 'Add Customer',
                      onPressed: () => _showCustomerDialog(),
                    ),
                    const SizedBox(width: 12),
                    _buildHeaderButton(
                      icon: Icons.exit_to_app,
                      label: 'Logout',
                      onPressed: _handleLogout,
                      isDestructive: true,
                    ),
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildHeaderButton({
    required IconData icon,
    required String label,
    required VoidCallback onPressed,
    bool isDestructive = false,
  }) {
    return AnimatedContainer(
      duration: const Duration(milliseconds: 200),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: isDestructive
              ? [
                  const Color(0xFFDC2626), // red-600
                  const Color(0xFFB91C1C), // red-700
                  const Color(0xFF991B1B), // red-800
                ]
              : [
                  const Color(0xFFEA580C), // orange-600
                  const Color(0xFFDC2626), // orange-700 mixed with red
                  const Color(0xFFD97706), // orange-600 darker
                ],
        ),
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: (isDestructive ? Colors.red : Colors.orange).withOpacity(0.4),
            blurRadius: 8,
            offset: const Offset(0, 4),
          ),
          BoxShadow(
            color: (isDestructive ? Colors.red : Colors.orange).withOpacity(0.1),
            blurRadius: 16,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: onPressed,
          borderRadius: BorderRadius.circular(12),
          hoverColor: Colors.white.withOpacity(0.2),
          splashColor: Colors.white.withOpacity(0.3),
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 200),
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(
                  icon,
                  size: 18,
                  color: Colors.white,
                ),
                const SizedBox(width: 8),
                Text(
                  label,
                  style: const TextStyle(
                    fontSize: 13,
                    fontWeight: FontWeight.w600,
                    color: Colors.white,
                    letterSpacing: 0.3,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildSearchBar() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: const BoxDecoration(
        color: Colors.white,
        border: Border(
          bottom: BorderSide(color: Color(0xFFE5E7EB)),
        ),
      ),
      child: Row(
        children: [
          // Search field
          Expanded(
            flex: 2,
            child: TextField(
              controller: _searchController,
              onChanged: (value) {
                setState(() => _searchTerm = value);
                _filterProducts();
                _resetInactivityTimer();
              },
              decoration: InputDecoration(
                hintText: 'Search products...',
                prefixIcon: const Icon(Icons.search, color: _brandColor),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: const BorderSide(color: Colors.orange),
                ),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: const BorderSide(color: Colors.orange),
                ),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: const BorderSide(color: Colors.orange, width: 2),
                ),
                filled: true,
                fillColor: const Color(0xFFFFF7ED),
                contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              ),
            ),
          ),
          const SizedBox(width: 12),
          
          // Category dropdown
          Expanded(
            child: Container(
              decoration: BoxDecoration(
                border: Border.all(color: _brandColor),
                borderRadius: BorderRadius.circular(12),
                color: const Color(0xFFFFF7ED),
              ),
              child: DropdownButtonHideUnderline(
                child: DropdownButton<int?>(
                  value: _selectedCategoryId,
                  hint: const Text('Category', style: TextStyle(color: Colors.orange)),
                  isExpanded: true,
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                  dropdownColor: const Color(0xFFFFF7ED),
                  onChanged: (value) {
                    setState(() => _selectedCategoryId = value);
                    _filterProducts();
                    _resetInactivityTimer();
                  },
                  items: _categories.map((category) {
                    return DropdownMenuItem<int?>(
                      value: category['id'],
                      child: Text(
                        category['name'],
                        style: const TextStyle(color: Colors.black87),
                        overflow: TextOverflow.ellipsis,
                      ),
                    );
                  }).toList(),
                ),
              ),
            ),
          ),
          const SizedBox(width: 12),
          
          // View toggle buttons
          Container(
            decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [Colors.orange.shade50, Colors.orange.shade100],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
              borderRadius: BorderRadius.circular(12),
                border: Border.all(color: Colors.orange, width: 1.5),
                boxShadow: [
                  BoxShadow(
                    color: Colors.orange.withOpacity(0.1),
                    blurRadius: 4,
                    offset: const Offset(0, 2),
                  ),
                ],
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                  Container(
                    decoration: BoxDecoration(
                      color: !_isGridView ? Colors.orange : Colors.transparent,
                      borderRadius: const BorderRadius.only(
                        topLeft: Radius.circular(10),
                        bottomLeft: Radius.circular(10),
                      ),
                  ),
                    child: Material(
                      color: Colors.transparent,
                      child: InkWell(
                        borderRadius: const BorderRadius.only(
                          topLeft: Radius.circular(10),
                          bottomLeft: Radius.circular(10),
                        ),
                        onTap: () {
                          setState(() => _isGridView = false);
                          _resetInactivityTimer();
                          HapticFeedback.lightImpact();
                        },
                        child: Padding(
                          padding: const EdgeInsets.all(12),
                          child: Icon(
                            Icons.view_list_rounded,
                            color: !_isGridView ? Colors.white : Colors.orange.shade600,
                            size: 20,
                          ),
                        ),
                      ),
                    ),
                  ),
                  Container(
                    width: 1,
                    height: 44,
                    decoration: BoxDecoration(
                      color: Colors.orange.withOpacity(0.3),
                    ),
                  ),
                  Container(
                    decoration: BoxDecoration(
                      color: _isGridView ? Colors.orange : Colors.transparent,
                      borderRadius: const BorderRadius.only(
                        topRight: Radius.circular(10),
                        bottomRight: Radius.circular(10),
                      ),
                  ),
                    child: Material(
                      color: Colors.transparent,
                      child: InkWell(
                        borderRadius: const BorderRadius.only(
                          topRight: Radius.circular(10),
                          bottomRight: Radius.circular(10),
                        ),
                        onTap: () {
                          setState(() => _isGridView = true);
                          _resetInactivityTimer();
                          HapticFeedback.lightImpact();
                        },
                        child: Padding(
                          padding: const EdgeInsets.all(12),
                          child: Icon(
                            Icons.grid_view_rounded,
                            color: _isGridView ? Colors.white : Colors.orange.shade600,
                            size: 20,
                          ),
                        ),
                      ),
                    ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildProductList() {
    if (_filteredProducts.isEmpty) {
      return _buildEmptyState();
    }

    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: _filteredProducts.length,
      itemBuilder: (context, index) {
        final product = _filteredProducts[index];
        return _buildProductListTile(product);
      },
    );
  }

  Widget _buildProductGrid() {
    if (_filteredProducts.isEmpty) {
      return _buildEmptyState();
    }

    return GridView.builder(
      padding: const EdgeInsets.all(16),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 4,
        childAspectRatio: 0.8,
        crossAxisSpacing: 12,
        mainAxisSpacing: 12,
      ),
      itemCount: _filteredProducts.length,
      itemBuilder: (context, index) {
        final product = _filteredProducts[index];
        return _buildProductCard(product);
      },
    );
  }

  Widget _buildEmptyState() {
    return const Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            Icons.inventory_2_outlined,
            size: 64,
            color: Colors.orange,
          ),
          SizedBox(height: 16),
          Text(
            'No products found',
            style: TextStyle(
              fontSize: 18,
              color: Colors.orange,
              fontWeight: FontWeight.w500,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildProductListTile(Product product) {
    final isLowStock = product.stock <= 5;
    final isOutOfStock = product.stock <= 0;

    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      child: Card(
        elevation: 2,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        child: ListTile(
          onTap: () => _addToTicket(product),
          leading: Container(
            width: 50,
            height: 50,
            decoration: BoxDecoration(
              color: Colors.orange[50],
              borderRadius: BorderRadius.circular(8),
            ),
            child: const Icon(Icons.inventory_2_outlined, color: Colors.orange),
          ),
          title: Text(
            product.name,
            style: const TextStyle(fontWeight: FontWeight.w600),
          ),
          subtitle: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('SKU: ${product.sku}'),
              const SizedBox(height: 4),
              _buildStoreStockInfo(product),
            ],
          ),
          trailing: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Text(
                    '\$${product.price.toStringAsFixed(2)}',
                    style: const TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                      color: Colors.orange,
                    ),
                  ),
                  const SizedBox(height: 4),
                  if (isOutOfStock)
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                      decoration: BoxDecoration(
                        color: Colors.red[100],
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Text(
                        'Out of Stock',
                        style: TextStyle(
                          fontSize: 10,
                          color: Colors.red[700],
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    )
                  else if (isLowStock)
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                      decoration: BoxDecoration(
                        color: Colors.orange[100],
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Text(
                        'Low Stock',
                        style: TextStyle(
                          fontSize: 10,
                          color: Colors.orange[700],
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                ],
              ),
              const SizedBox(width: 12),
              Container(
                width: 36,
                height: 36,
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: isOutOfStock 
                        ? [Colors.grey.shade400, Colors.grey.shade500]
                        : [Colors.green.shade400, Colors.green.shade600],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  borderRadius: BorderRadius.circular(8),
                  boxShadow: [
                    BoxShadow(
                      color: (isOutOfStock ? Colors.grey : Colors.green).withOpacity(0.3),
                      blurRadius: 4,
                      offset: const Offset(0, 2),
                    ),
                  ],
                ),
                child: Material(
                  color: Colors.transparent,
                  child: InkWell(
                    borderRadius: BorderRadius.circular(8),
                    onTap: isOutOfStock ? null : () => _addToTicket(product),
                    child: const Center(
                      child: Icon(
                        Icons.add,
                        color: Colors.white,
                        size: 20,
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildProductCard(Product product) {
    final isLowStock = product.stock <= 5;
    final isOutOfStock = product.stock <= 0;

    return GestureDetector(
      onTap: () => _addToTicket(product),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: isOutOfStock ? Colors.red[300]! : Colors.orange[200]!,
          ),
          boxShadow: [
            BoxShadow(
              color: Colors.orange.withOpacity(0.1),
              blurRadius: 4,
              offset: const Offset(0, 2),
            ),
          ],
        ),
        child: Column(
          children: [
            Expanded(
              child: Container(
                width: double.infinity,
                decoration: BoxDecoration(
                  color: Colors.orange[50],
                  borderRadius: const BorderRadius.vertical(top: Radius.circular(12)),
                ),
                child: const Icon(
                  Icons.inventory_2_outlined,
                  size: 40,
                  color: Colors.orange,
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    product.name,
                    style: const TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.w600,
                      color: Color(0xFF111827),
                    ),
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                  ),
                  const SizedBox(height: 4),
                  Text(
                    '\$${product.price.toStringAsFixed(2)}',
                    style: const TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                      color: Colors.orange,
                    ),
                  ),
                  const SizedBox(height: 4),
                  _buildStoreStockInfo(product),
                  const SizedBox(height: 4),
                  if (isOutOfStock)
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                      decoration: BoxDecoration(
                        color: Colors.red[100],
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Text(
                        'Out of Stock',
                        style: TextStyle(
                          fontSize: 10,
                          color: Colors.red[700],
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    )
                  else if (isLowStock)
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                      decoration: BoxDecoration(
                        color: Colors.orange[100],
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Text(
                        'Low Stock',
                        style: TextStyle(
                          fontSize: 10,
                          color: Colors.orange[700],
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildStoreStockInfo(Product product) {
    // Mock store stock data - in real app, this would come from database
    final storeStocks = [
      {'name': 'Cell Tech', 'stock': product.stock},
      {'name': 'Cell Tech 6th Ave', 'stock': (product.stock * 0.7).round()},
    ];

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: storeStocks.map((store) {
        return Padding(
          padding: const EdgeInsets.only(bottom: 2),
          child: Text(
            '${store['name']}: ${store['stock']}',
            style: TextStyle(
              fontSize: 11,
              color: store['stock'] == 0 ? Colors.red[600] : Colors.grey[600],
              fontWeight: FontWeight.w500,
            ),
          ),
        );
      }).toList(),
    );
  }

  Widget _buildTicketPanel() {
    final subtotal = _currentTicket.fold<double>(0.0, (sum, item) => sum + item.total);
    
    return Column(
      children: [
          // Customer Selection
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [Colors.orange.shade50, Colors.orange.shade100],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              border: const Border(
                bottom: BorderSide(color: Colors.orange, width: 2),
              ),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Icon(Icons.person_outline, color: Colors.orange.shade700, size: 20),
                    const SizedBox(width: 8),
                    const Text(
                      'Customer',
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w600,
                        color: Colors.black87,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                Container(
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: Colors.orange, width: 1.5),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.orange.withOpacity(0.1),
                        blurRadius: 4,
                        offset: const Offset(0, 2),
                      ),
                    ],
                  ),
                  child: DropdownButtonFormField<Customer?>(
                    value: _selectedCustomer,
                    decoration: const InputDecoration(
                      contentPadding: EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                      border: InputBorder.none,
                      hintText: 'Select customer (optional)',
                      hintStyle: TextStyle(color: Colors.grey),
                    ),
                    icon: Icon(Icons.keyboard_arrow_down, color: Colors.orange.shade600),
                    items: [
                      const DropdownMenuItem<Customer?>(
                        value: null,
                        child: Text(
                          'Walk-in Customer',
                          style: TextStyle(fontStyle: FontStyle.italic, color: Colors.grey),
                        ),
                      ),
                      ..._customers.map((customer) => DropdownMenuItem<Customer?>(
                        value: customer,
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            CircleAvatar(
                              radius: 12,
                              backgroundColor: Colors.orange.shade100,
                              child: Text(
                                customer.name.isNotEmpty ? customer.name[0].toUpperCase() : 'C',
                                style: TextStyle(
                                  fontSize: 12,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.orange.shade700,
                                ),
                              ),
                            ),
                            const SizedBox(width: 10),
                            Text(
                              customer.name,
                              style: const TextStyle(
                                fontWeight: FontWeight.w500,
                                fontSize: 14,
                              ),
                              overflow: TextOverflow.ellipsis,
                            ),
                          ],
                        ),
                      )).toList(),
                    ],
                    onChanged: (customer) {
                      setState(() => _selectedCustomer = customer);
                      HapticFeedback.lightImpact();
                    },
                  ),
                ),
              ],
            ),
          ),
        
          // Ticket Header
        Container(
          padding: const EdgeInsets.all(16),
          decoration: const BoxDecoration(
            color: Color(0xFFF8FAFC),
            border: Border(
              bottom: BorderSide(color: Color(0xFFE5E7EB)),
            ),
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text(
                'Current Ticket',
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  color: Color(0xFF111827),
                ),
              ),
              if (_currentTicket.isNotEmpty)
                  Container(
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(8),
                      gradient: LinearGradient(
                        colors: [Colors.red.shade400, Colors.red.shade500],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.red.withOpacity(0.2),
                          blurRadius: 4,
                          offset: const Offset(0, 2),
                        ),
                      ],
                    ),
                    child: Material(
                      color: Colors.transparent,
                      child: InkWell(
                        borderRadius: BorderRadius.circular(8),
                        onTap: _clearTicket,
                        child: const Padding(
                          padding: EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Icon(Icons.clear_all, size: 16, color: Colors.white),
                              SizedBox(width: 4),
                              Text(
                                'Clear',
                                style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 12,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                ),
            ],
          ),
        ),
        
        // Ticket Items
        Expanded(
          child: _currentTicket.isEmpty
              ? const Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(
                        Icons.shopping_cart_outlined,
                        size: 64,
                        color: Color(0xFF9CA3AF),
                      ),
                      SizedBox(height: 16),
                      Text(
                        'Ticket is empty',
                        style: TextStyle(
                          fontSize: 16,
                          color: Color(0xFF6B7280),
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                      SizedBox(height: 8),
                      Text(
                        'Add products to start',
                        style: TextStyle(
                          fontSize: 14,
                          color: Color(0xFF9CA3AF),
                        ),
                      ),
                    ],
                  ),
                )
              : ListView.separated(
                  padding: const EdgeInsets.all(16),
                  itemCount: _currentTicket.length,
                  separatorBuilder: (context, index) => const Divider(),
                  itemBuilder: (context, index) {
                    final item = _currentTicket[index];
                    return _buildTicketItem(item);
                  },
                ),
        ),
        
        // Payment Section
        if (_currentTicket.isNotEmpty) _buildPaymentSection(subtotal),
      ],
    );
  }

  Widget _buildTicketItem(TicketItem item) {
    return Row(
      children: [
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                item.productName,
                style: const TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w600,
                  color: Color(0xFF111827),
                ),
              ),
              const SizedBox(height: 4),
              Text(
                '\$${item.price.toStringAsFixed(2)} each',
                style: const TextStyle(
                  fontSize: 12,
                  color: Color(0xFF6B7280),
                ),
              ),
            ],
          ),
        ),
        Row(
          children: [
            IconButton(
              onPressed: () => _updateQuantity(item.productId, -1),
              icon: const Icon(Icons.remove_circle_outline),
              color: Colors.red[600],
              iconSize: 20,
            ),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
              decoration: BoxDecoration(
                color: const Color(0xFFF3F4F6),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Text(
                '${item.quantity}',
                style: const TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w600,
                  color: Color(0xFF111827),
                ),
              ),
            ),
            IconButton(
              onPressed: () => _updateQuantity(item.productId, 1),
              icon: const Icon(Icons.add_circle_outline),
              color: Colors.green[600],
              iconSize: 20,
            ),
          ],
        ),
        SizedBox(
          width: 80,
          child: Text(
            '\$${item.total.toStringAsFixed(2)}',
            style: const TextStyle(
              fontSize: 14,
              fontWeight: FontWeight.bold,
              color: Color(0xFFEA580C),
            ),
            textAlign: TextAlign.right,
          ),
        ),
      ],
    );
  }

  Widget _buildPaymentSection(double subtotal) {
    final total = subtotal - _discountAmount;
    
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.orange[50],
        border: const Border(
          top: BorderSide(color: Colors.orange),
        ),
      ),
      child: Column(
        children: [
          // Subtotal
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text(
                'Subtotal',
                style: TextStyle(
                  fontSize: 16,
                  color: Colors.black87,
                ),
              ),
              Text(
                '\$${subtotal.toStringAsFixed(2)}',
                style: const TextStyle(
                  fontSize: 16,
                  color: Colors.black87,
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          
          // Discount Input
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text(
                'Discount',
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w600,
                  color: Colors.black87,
                ),
              ),
              SizedBox(
                width: 120,
                child: TextFormField(
                  initialValue: _discountAmount.toStringAsFixed(2),
                  keyboardType: const TextInputType.numberWithOptions(decimal: true),
                  textAlign: TextAlign.right,
                  style: const TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                    color: Colors.orange,
                  ),
                  decoration: InputDecoration(
                    prefixText: '-\$',
                    prefixStyle: const TextStyle(
                      color: Colors.orange,
                      fontWeight: FontWeight.w600,
                    ),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8),
                      borderSide: const BorderSide(color: Colors.orange, width: 1.5),
                    ),
                    enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8),
                      borderSide: const BorderSide(color: Colors.orange, width: 1.5),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8),
                      borderSide: const BorderSide(color: Colors.orange, width: 2),
                    ),
                    contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                    filled: true,
                    fillColor: Colors.orange.withOpacity(0.05),
                  ),
                  onChanged: (value) {
                    final discount = double.tryParse(value) ?? 0.0;
                    setState(() => _discountAmount = discount);
                  },
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          const Divider(color: Colors.orange),
          const SizedBox(height: 8),
          
          // Total
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text(
                'Total',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                  color: Colors.black87,
                ),
              ),
              Text(
                '\$${total.toStringAsFixed(2)}',
                style: const TextStyle(
                  fontSize: 22,
                  fontWeight: FontWeight.bold,
                  color: Colors.orange,
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          
          // Payment Button
          Container(
            width: double.infinity,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(12),
              gradient: LinearGradient(
                colors: _isProcessing ? [Colors.grey.shade400, Colors.grey.shade500] : [_brandColor, _brandColor.withOpacity(0.8)],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              boxShadow: [
                BoxShadow(
                  color: (_isProcessing ? Colors.grey : _brandColor).withOpacity(0.3),
                  blurRadius: 8,
                  offset: const Offset(0, 4),
                ),
              ],
            ),
            child: Material(
              color: Colors.transparent,
              child: InkWell(
                borderRadius: BorderRadius.circular(12),
                onTap: _isProcessing ? null : _showPaymentDialog,
                child: Container(
                  padding: const EdgeInsets.symmetric(vertical: 16),
                  child: _isProcessing
                    ? const SizedBox(
                        width: 16,
                        height: 16,
                        child: CircularProgressIndicator(
                          strokeWidth: 2,
                          valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
                        ),
                      )
                    : const Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(Icons.payment, color: Colors.white, size: 20),
                          SizedBox(width: 8),
                          Text(
                            'Make Payment',
                            style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                              color: Colors.white,
                            ),
                          ),
                        ],
                      ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }



  void _showCustomerDialog() {
    showDialog(
      context: context,
      builder: (context) => const CustomerSelectorDialog(),
    ).then((customer) {
      if (customer != null) {
        setState(() => _selectedCustomer = customer);
      }
    });
  }

  void _showReceiptsPanel() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => DraggableScrollableSheet(
        initialChildSize: 0.8,
        minChildSize: 0.6,
        maxChildSize: 0.95,
        builder: (context, scrollController) => Container(
          decoration: const BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
          ),
          child: _buildModernReceiptsPanel(scrollController),
        ),
      ),
    );
  }

  void _showShiftsPanel() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => DraggableScrollableSheet(
        initialChildSize: 0.8,
        minChildSize: 0.6,
        maxChildSize: 0.95,
        builder: (context, scrollController) => Container(
          decoration: const BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
          ),
          child: _buildModernShiftsPanel(scrollController),
        ),
      ),
    );
  }

  Widget _buildModernShiftsPanel(ScrollController scrollController) {
    return Column(
      children: [
        // Handle bar
        Container(
          margin: const EdgeInsets.only(top: 8),
          width: 40,
          height: 4,
          decoration: BoxDecoration(
            color: Colors.grey[300],
            borderRadius: BorderRadius.circular(2),
          ),
        ),
        // Header
        Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [
                Colors.orange.shade50,
                Colors.orange.shade100,
              ],
            ),
          ),
          child: Row(
            children: [
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    colors: [Color(0xFFEA580C), Color(0xFFDC2626)],
                  ),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: const Icon(
                  Icons.schedule,
                  color: Colors.white,
                  size: 24,
                ),
              ),
              const SizedBox(width: 16),
              const Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Shift Management',
                      style: TextStyle(
                        fontSize: 22,
                        fontWeight: FontWeight.bold,
                        color: Color(0xFFEA580C),
                      ),
                    ),
                    Text(
                      'Manage your current shift',
                      style: TextStyle(
                        fontSize: 14,
                        color: Color(0xFF6B7280),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
        // Content
        Expanded(
          child: _currentShift == null 
            ? _buildStartShiftContent(scrollController)
            : _buildCurrentShiftContent(scrollController),
        ),
      ],
    );
  }

  Widget _buildStartShiftContent(ScrollController scrollController) {
    final TextEditingController floatController = TextEditingController();
    
    return SingleChildScrollView(
      controller: scrollController,
      padding: const EdgeInsets.all(20),
      child: Column(
        children: [
          Container(
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [
                  Colors.orange.shade50,
                  Colors.white,
                ],
              ),
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: Colors.orange.shade200),
            ),
            child: Column(
              children: [
                Icon(
                  Icons.play_circle_outline,
                  size: 64,
                  color: Colors.orange.shade600,
                ),
                const SizedBox(height: 16),
                const Text(
                  'No Active Shift',
                  style: TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                    color: Color(0xFF111827),
                  ),
                ),
                const SizedBox(height: 8),
                const Text(
                  'Start your shift to begin processing sales',
                  style: TextStyle(
                    fontSize: 16,
                    color: Color(0xFF6B7280),
                  ),
                  textAlign: TextAlign.center,
                ),
              ],
            ),
          ),
          const SizedBox(height: 24),
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: Colors.grey.shade200),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'Opening Balance',
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: Color(0xFF111827),
                  ),
                ),
                const SizedBox(height: 8),
                const Text(
                  'Enter the starting cash amount in your register',
                  style: TextStyle(
                    fontSize: 14,
                    color: Color(0xFF6B7280),
                  ),
                ),
                const SizedBox(height: 16),
                TextField(
                  controller: floatController,
                  keyboardType: const TextInputType.numberWithOptions(decimal: true),
                  decoration: InputDecoration(
                    labelText: 'Float Balance (\$)',
                    hintText: '0.00',
                    prefixIcon: const Icon(Icons.attach_money, color: Colors.orange),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8),
                      borderSide: const BorderSide(color: Colors.orange),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8),
                      borderSide: const BorderSide(color: Colors.orange, width: 2),
                    ),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 24),
          Container(
            width: double.infinity,
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [Color(0xFFEA580C), Color(0xFFDC2626)],
              ),
              borderRadius: BorderRadius.circular(12),
              boxShadow: [
                BoxShadow(
                  color: Colors.orange.withOpacity(0.3),
                  blurRadius: 8,
                  offset: const Offset(0, 4),
                ),
              ],
            ),
            child: Material(
              color: Colors.transparent,
              child: InkWell(
                onTap: () => _startShift(floatController.text),
                borderRadius: BorderRadius.circular(12),
                child: const Padding(
                  padding: EdgeInsets.symmetric(vertical: 16),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.play_arrow, color: Colors.white, size: 24),
                      SizedBox(width: 8),
                      Text(
                        'Start Shift',
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                          color: Colors.white,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildCurrentShiftContent(ScrollController scrollController) {
    if (_currentShift == null) return const SizedBox();
    
    return SingleChildScrollView(
      controller: scrollController,
      padding: const EdgeInsets.all(20),
      child: Column(
        children: [
          // Current Shift Info
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [
                  Colors.green.shade50,
                  Colors.white,
                ],
              ),
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: Colors.green.shade200),
            ),
            child: Column(
              children: [
                Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(
                        color: Colors.green,
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: const Icon(Icons.access_time, color: Colors.white),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text(
                            'Current Shift Active',
                            style: TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                              color: Color(0xFF111827),
                            ),
                          ),
                          Text(
                            'Started: ${_formatDateTime(_currentShift!.startTime)}',
                            style: const TextStyle(
                              fontSize: 14,
                              color: Color(0xFF6B7280),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(height: 20),
          // Daily Sales Summary
          _buildDailySalesSummary(),
          const SizedBox(height: 20),
          // Cash Management
          _buildCashManagement(),
        ],
      ),
    );
  }

  Widget _buildDailySalesSummary() {
    final totalSales = _currentShift?.totalSales ?? 0.0;
    final totalTransactions = _currentShift?.totalTransactions ?? 0;
    
    // In a real implementation, you'd query the database for these breakdown values
    // For now, we'll estimate based on common patterns
    final totalDiscounts = totalSales * 0.05; // Estimate 5% discount average
    final cashPayments = totalSales * 0.4; // Estimate 40% cash payments
    final cardPayments = totalSales - cashPayments;
    
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.grey.shade200),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.1),
            blurRadius: 4,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Daily Sales Summary',
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
              color: Color(0xFF111827),
            ),
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              Expanded(
                child: _buildSummaryCard(
                  'Total Sales',
                  '\$${totalSales.toStringAsFixed(2)}',
                  Icons.trending_up,
                  Colors.green,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: _buildSummaryCard(
                  'Transactions',
                  '$totalTransactions',
                  Icons.receipt,
                  Colors.blue,
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                child: _buildSummaryCard(
                  'Discounts',
                  '\$${totalDiscounts.toStringAsFixed(2)}',
                  Icons.discount,
                  Colors.orange,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: _buildSummaryCard(
                  'Cash Payments',
                  '\$${cashPayments.toStringAsFixed(2)}',
                  Icons.money,
                  Colors.purple,
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          _buildSummaryCard(
            'Card Payments',
            '\$${cardPayments.toStringAsFixed(2)}',
            Icons.credit_card,
            Colors.indigo,
            fullWidth: true,
          ),
        ],
      ),
    );
  }

  Widget _buildSummaryCard(
    String title, 
    String value, 
    IconData icon, 
    Color color,
    {bool fullWidth = false}
  ) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: color.withOpacity(0.1),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: color.withOpacity(0.3)),
      ),
      child: Row(
        children: [
          Icon(icon, color: color, size: 20),
          const SizedBox(width: 8),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: TextStyle(
                    fontSize: 12,
                    color: color,
                    fontWeight: FontWeight.w500,
                  ),
                ),
                Text(
                  value,
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                    color: color,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildCashManagement() {
    final totalSales = _currentShift?.totalSales ?? 0.0;
    final expectedCash = (totalSales * 0.4) + (_currentShift?.startingCash ?? 0.0); // 40% cash + opening balance
    final TextEditingController actualCashController = TextEditingController();
    
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.grey.shade200),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.1),
            blurRadius: 4,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Cash Management',
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
              color: Color(0xFF111827),
            ),
          ),
          const SizedBox(height: 16),
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Colors.blue.shade50,
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: Colors.blue.shade200),
            ),
            child: Row(
              children: [
                Icon(Icons.info_outline, color: Colors.blue.shade600),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        'Expected Cash',
                        style: TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.w500,
                          color: Color(0xFF111827),
                        ),
                      ),
                      Text(
                        '\$${expectedCash.toStringAsFixed(2)}',
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                          color: Colors.blue.shade700,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),
          TextField(
            controller: actualCashController,
            keyboardType: const TextInputType.numberWithOptions(decimal: true),
            decoration: InputDecoration(
              labelText: 'Actual Cash on Hand (\$)',
              hintText: '0.00',
              prefixIcon: const Icon(Icons.attach_money, color: Colors.orange),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(8),
                borderSide: const BorderSide(color: Colors.orange),
              ),
              focusedBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(8),
                borderSide: const BorderSide(color: Colors.orange, width: 2),
              ),
            ),
          ),
          const SizedBox(height: 16),
          Container(
            width: double.infinity,
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [Color(0xFFDC2626), Color(0xFFB91C1C)],
              ),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Material(
              color: Colors.transparent,
              child: InkWell(
                onTap: () => _endShift(actualCashController.text, expectedCash),
                borderRadius: BorderRadius.circular(8),
                child: const Padding(
                  padding: EdgeInsets.symmetric(vertical: 12),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.stop, color: Colors.white),
                      SizedBox(width: 8),
                      Text(
                        'End Shift',
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                          color: Colors.white,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  void _startShift(String floatAmount) async {
    final float = double.tryParse(floatAmount);
    if (float == null || float < 0) {
      _showErrorSnackBar('Please enter a valid opening balance');
      return;
    }

    try {
      // Create new shift and save to database
      final newShift = Shift(
        employeeId: widget.employee.id ?? 0,
        storeId: widget.store.id ?? 0,
        startTime: DateTime.now(),
        startingCash: float,
        status: 'open',
        totalSales: 0.0,
        totalTransactions: 0,
      );

      final shiftId = await DatabaseService.insertShift(newShift);
      final savedShift = newShift.copyWith(id: shiftId);

      setState(() => _currentShift = savedShift);
      Navigator.of(context).pop();
      _showSuccessSnackBar('Shift started successfully and saved');
    } catch (e) {
      _showErrorSnackBar('Failed to start shift: $e');
    }
  }

  void _endShift(String actualCashText, double expectedCash) async {
    final actualCash = double.tryParse(actualCashText);
    if (actualCash == null) {
      _showErrorSnackBar('Please enter the actual cash amount');
      return;
    }

    if (actualCash < expectedCash) {
      _showErrorDialog(
        'Cash Shortage',
        'Actual cash (\$${actualCash.toStringAsFixed(2)}) is less than expected (\$${expectedCash.toStringAsFixed(2)}). Please recount and verify.',
      );
      return;
    }

    try {
      // Close shift in database
      if (_currentShift?.id != null) {
        await DatabaseService.closeShift(_currentShift!.id!, endingCash: actualCash);
        setState(() => _currentShift = null);
        
        Navigator.of(context).pop();
        _showSuccessSnackBar('Shift ended successfully and saved');
      } else {
        _showErrorSnackBar('Cannot end shift: Invalid shift data');
      }
    } catch (e) {
      _showErrorSnackBar('Failed to end shift: $e');
    }
  }

  void _showErrorDialog(String title, String message) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        title: Row(
          children: [
            const Icon(Icons.error_outline, color: Colors.red),
            const SizedBox(width: 8),
            Text(title),
          ],
        ),
        content: Text(message),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('OK'),
          ),
        ],
      ),
    );
  }

  String _formatDateTime(DateTime dateTime) {
    return '${dateTime.day}/${dateTime.month}/${dateTime.year} ${dateTime.hour}:${dateTime.minute.toString().padLeft(2, '0')}';
  }

  Widget _buildModernReceiptsPanel(ScrollController scrollController) {
    return Column(
      children: [
        // Handle bar
        Container(
          margin: const EdgeInsets.only(top: 8),
          width: 40,
          height: 4,
          decoration: BoxDecoration(
            color: Colors.grey[300],
            borderRadius: BorderRadius.circular(2),
          ),
        ),
        // Header
        Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [
                Colors.orange.shade50,
                Colors.orange.shade100,
              ],
            ),
          ),
          child: Row(
            children: [
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    colors: [Color(0xFFEA580C), Color(0xFFDC2626)],
                  ),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: const Icon(
                  Icons.receipt_long,
                  color: Colors.white,
                  size: 24,
                ),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'Today\'s Receipts',
                      style: TextStyle(
                        fontSize: 22,
                        fontWeight: FontWeight.bold,
                        color: Color(0xFFEA580C),
                      ),
                    ),
                    Text(
                      _currentShift != null 
                        ? 'Current shift receipts'
                        : 'No active shift',
                      style: const TextStyle(
                        fontSize: 14,
                        color: Color(0xFF6B7280),
                      ),
                    ),
                  ],
                ),
              ),
              FutureBuilder<List<Map<String, dynamic>>>(
                future: _currentShift?.id != null 
                  ? DatabaseService.getShiftSales(_currentShift!.id!)
                  : Future.value(<Map<String, dynamic>>[]),
                builder: (context, snapshot) {
                  final receiptsCount = snapshot.data?.length ?? 0;
                  return Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                    decoration: BoxDecoration(
                      color: Colors.orange.shade100,
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Text(
                      '$receiptsCount receipts',
                      style: TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.w600,
                        color: Colors.orange.shade700,
                      ),
                    ),
                  );
                },
              ),
            ],
          ),
        ),
        // Content
        Expanded(
          child: _currentShift == null 
            ? _buildNoShiftMessage()
            : FutureBuilder<List<Map<String, dynamic>>>(
                key: ValueKey('receipts_${_currentShift!.id}'),
                future: _loadShiftSalesWithRetry(_currentShift!.id!),
                builder: (context, snapshot) {
                  if (snapshot.connectionState == ConnectionState.waiting) {
                    return const Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          CircularProgressIndicator(),
                          SizedBox(height: 16),
                          Text(
                            'Loading receipts...',
                            style: TextStyle(color: Color(0xFF6B7280)),
                          ),
                        ],
                      ),
                    );
                  }
                  
                  if (snapshot.hasError) {
                    return Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(Icons.receipt_long, size: 48, color: Colors.grey.shade400),
                          const SizedBox(height: 16),
                          Text(
                            'Database Temporarily Unavailable',
                            style: TextStyle(fontSize: 18, color: Colors.grey.shade600),
                          ),
                          const SizedBox(height: 8),
                          Text(
                            'Please try again in a moment',
                            style: TextStyle(color: Color(0xFF6B7280)),
                          ),
                          const SizedBox(height: 16),
                          ElevatedButton.icon(
                            onPressed: () => setState(() {}),
                            icon: const Icon(Icons.refresh),
                            label: const Text('Retry'),
                            style: ElevatedButton.styleFrom(
                              backgroundColor: _brandColor,
                              foregroundColor: Colors.white,
                            ),
                          ),
                        ],
                      ),
                    );
                  }
                  
                  final sales = snapshot.data ?? [];
                  return _buildRealReceiptsList(sales, scrollController);
                },
              ),
        ),
      ],
    );
  }

  Widget _buildNoShiftMessage() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            Icons.receipt_outlined,
            size: 64,
            color: Colors.grey.shade400,
          ),
          const SizedBox(height: 16),
          const Text(
            'No Active Shift',
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
              color: Color(0xFF6B7280),
            ),
          ),
          const SizedBox(height: 8),
          const Text(
            'Start a shift to view receipts',
            style: TextStyle(
              fontSize: 16,
              color: Color(0xFF9CA3AF),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildRealReceiptsList(List<Map<String, dynamic>> sales, ScrollController scrollController) {
    if (sales.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.receipt_outlined,
              size: 64,
              color: Colors.grey.shade400,
            ),
            const SizedBox(height: 16),
            const Text(
              'No Receipts Yet',
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
                color: Color(0xFF6B7280),
              ),
            ),
            const SizedBox(height: 8),
            const Text(
              'Receipts will appear here as sales are made',
              style: TextStyle(
                fontSize: 16,
                color: Color(0xFF9CA3AF),
              ),
            ),
          ],
        ),
      );
    }

    return ListView.builder(
      controller: scrollController,
      padding: const EdgeInsets.all(16),
      itemCount: sales.length,
      itemBuilder: (context, index) {
        final sale = sales[index];
        return _buildRealReceiptCard(sale);
      },
    );
  }

  Widget _buildRealReceiptCard(Map<String, dynamic> sale) {
    final saleDate = DateTime.tryParse(sale['created_at'] as String? ?? '') ?? DateTime.now();
    final isRefund = sale['status'] == 'refunded';
    final totalAmount = (sale['total_amount'] as num?)?.toDouble() ?? 0.0;
    final customerName = sale['customer_name'] as String?;
    
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.grey.shade200),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.1),
            blurRadius: 4,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(16),
            child: Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: isRefund 
                      ? Colors.red.shade50 
                      : Colors.green.shade50,
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Icon(
                    isRefund ? Icons.undo : Icons.shopping_cart,
                    color: isRefund 
                      ? Colors.red.shade600 
                      : Colors.green.shade600,
                    size: 20,
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Text(
                            sale['ticket_number'] as String? ?? 'N/A',
                            style: const TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                              color: Color(0xFF111827),
                            ),
                          ),
                          const SizedBox(width: 8),
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                            decoration: BoxDecoration(
                              color: isRefund 
                                ? Colors.red.shade100 
                                : Colors.green.shade100,
                              borderRadius: BorderRadius.circular(12),
                            ),
                            child: Text(
                              isRefund ? 'Refunded' : 'Sale',
                              style: TextStyle(
                                fontSize: 10,
                                fontWeight: FontWeight.w600,
                                color: isRefund 
                                  ? Colors.red.shade700 
                                  : Colors.green.shade700,
                              ),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 4),
                      Row(
                        children: [
                          Text(
                            _formatDateTime(saleDate),
                            style: const TextStyle(
                              fontSize: 12,
                              color: Color(0xFF6B7280),
                            ),
                          ),
                          if (customerName != null) ...[
                            const SizedBox(width: 8),
                            Icon(Icons.person, size: 12, color: Colors.grey.shade500),
                            const SizedBox(width: 4),
                            Text(
                              customerName,
                              style: const TextStyle(
                                fontSize: 12,
                                color: Color(0xFF6B7280),
                              ),
                            ),
                          ],
                        ],
                      ),
                    ],
                  ),
                ),
                Text(
                  '\$${totalAmount.toStringAsFixed(2)}',
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: isRefund 
                      ? Colors.red.shade600 
                      : Colors.green.shade600,
                  ),
                ),
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: Colors.grey.shade50,
              borderRadius: const BorderRadius.only(
                bottomLeft: Radius.circular(12),
                bottomRight: Radius.circular(12),
              ),
            ),
            child: Row(
              children: [
                Expanded(
                  child: _buildActionButton(
                    'View Items',
                    Icons.visibility,
                    Colors.blue,
                    () => _showRealReceiptDetails(sale),
                  ),
                ),
                const SizedBox(width: 8),
                if (!isRefund)
                  Expanded(
                    child: _buildActionButton(
                      'Refund',
                      Icons.undo,
                      Colors.red,
                      () => _showRealRefundDialog(sale),
                    ),
                  ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildActionButton(
    String label,
    IconData icon,
    Color color,
    VoidCallback onPressed,
  ) {
    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [color, color.withOpacity(0.8)],
        ),
        borderRadius: BorderRadius.circular(8),
        boxShadow: [
          BoxShadow(
            color: color.withOpacity(0.3),
            blurRadius: 4,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: onPressed,
          borderRadius: BorderRadius.circular(8),
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 8),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(icon, color: Colors.white, size: 16),
                const SizedBox(width: 4),
                Text(
                  label,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 12,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  void _showRealReceiptDetails(Map<String, dynamic> sale) {
    final saleItems = sale['items'] as List<dynamic>? ?? [];
    final totalAmount = (sale['total_amount'] as num?)?.toDouble() ?? 0.0;
    final saleDate = DateTime.tryParse(sale['created_at'] as String? ?? '') ?? DateTime.now();
    final customerName = sale['customer_name'] as String?;
    final paymentMethod = sale['payment_method'] as String? ?? 'Cash';
    
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: Colors.orange.shade50,
                borderRadius: BorderRadius.circular(8),
              ),
              child: Icon(
                Icons.receipt_long,
                color: Colors.orange.shade600,
                size: 24,
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    sale['ticket_number'] as String? ?? 'Receipt',
                    style: const TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  Text(
                    _formatDateTime(saleDate),
                    style: TextStyle(
                      fontSize: 12,
                      color: Colors.grey.shade600,
                      fontWeight: FontWeight.normal,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
        content: SizedBox(
          width: double.maxFinite,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              if (customerName != null) ...[
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: Colors.grey.shade50,
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Row(
                    children: [
                      Icon(Icons.person, size: 16, color: Colors.grey.shade600),
                      const SizedBox(width: 8),
                      Text(
                        'Customer: $customerName',
                        style: const TextStyle(fontWeight: FontWeight.w500),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 16),
              ],
              const Text(
                'Items:',
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 16,
                ),
              ),
              const SizedBox(height: 8),
              Container(
                constraints: const BoxConstraints(maxHeight: 300),
                child: SingleChildScrollView(
                  child: Column(
                    children: saleItems.map<Widget>((item) {
                      final productName = item['product_name'] as String? ?? 'Unknown Product';
                      final quantity = (item['quantity'] as num?)?.toInt() ?? 0;
                      final unitPrice = (item['unit_price'] as num?)?.toDouble() ?? 0.0;
                      final totalPrice = (item['total_price'] as num?)?.toDouble() ?? 0.0;
                      
                      return Container(
                        margin: const EdgeInsets.only(bottom: 8),
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          border: Border.all(color: Colors.grey.shade200),
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: Row(
                          children: [
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    productName,
                                    style: const TextStyle(
                                      fontWeight: FontWeight.w500,
                                    ),
                                  ),
                                  Text(
                                    'Qty: $quantity × \$${unitPrice.toStringAsFixed(2)}',
                                    style: TextStyle(
                                      fontSize: 12,
                                      color: Colors.grey.shade600,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            Text(
                              '\$${totalPrice.toStringAsFixed(2)}',
                              style: const TextStyle(
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ],
                        ),
                      );
                    }).toList(),
                  ),
                ),
              ),
              const SizedBox(height: 16),
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Colors.orange.shade50,
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: Colors.orange.shade200),
                ),
                child: Column(
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          'Payment Method:',
                          style: TextStyle(
                            color: Colors.grey.shade700,
                          ),
                        ),
                        Text(
                          paymentMethod,
                          style: const TextStyle(
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 8),
                    const Divider(),
                    const SizedBox(height: 8),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Text(
                          'Total:',
                          style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        Text(
                          '\$${totalAmount.toStringAsFixed(2)}',
                          style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                            color: Colors.orange.shade700,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text(
              'Close',
              style: TextStyle(color: Colors.orange.shade600),
            ),
          ),
        ],
      ),
    );
  }

  void _showRealRefundDialog(Map<String, dynamic> sale) {
    final TextEditingController reasonController = TextEditingController();
    final totalAmount = (sale['total_amount'] as num?)?.toDouble() ?? 0.0;
    final ticketNumber = sale['ticket_number'] as String? ?? 'N/A';
    
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: Colors.red.shade50,
                borderRadius: BorderRadius.circular(8),
              ),
              child: Icon(Icons.undo, color: Colors.red.shade600),
            ),
            const SizedBox(width: 12),
            const Text('Refund Sale'),
          ],
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Refunding $ticketNumber',
              style: const TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w600,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              'Total: \$${totalAmount.toStringAsFixed(2)}',
              style: TextStyle(
                fontSize: 14,
                color: Colors.red.shade600,
              ),
            ),
            const SizedBox(height: 16),
            TextField(
              controller: reasonController,
              maxLines: 3,
              decoration: InputDecoration(
                labelText: 'Refund Reason *',
                hintText: 'Enter reason for refund...',
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8),
                ),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8),
                  borderSide: const BorderSide(color: Colors.red, width: 2),
                ),
              ),
            ),
            const SizedBox(height: 12),
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: Colors.red.shade50,
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: Colors.red.shade200),
              ),
              child: Row(
                children: [
                  Icon(Icons.warning_amber, color: Colors.red.shade600),
                  const SizedBox(width: 8),
                  const Expanded(
                    child: Text(
                      'This action cannot be undone',
                      style: TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('Cancel'),
          ),
          Container(
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [Color(0xFFDC2626), Color(0xFFB91C1C)],
              ),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Material(
              color: Colors.transparent,
              child: InkWell(
                onTap: () async {
                  if (reasonController.text.trim().isEmpty) {
                    _showErrorSnackBar('Please enter a refund reason');
                    return;
                  }
                  Navigator.of(context).pop();
                  await _processRealRefund(sale, reasonController.text.trim());
                },
                borderRadius: BorderRadius.circular(8),
                child: const Padding(
                  padding: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                  child: Text(
                    'Process Refund',
                    style: TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Future<void> _processRealRefund(Map<String, dynamic> sale, String reason) async {
    try {
      final saleId = sale['id'] as int;
      final totalAmount = (sale['total_amount'] as num?)?.toDouble() ?? 0.0;
      final ticketNumber = sale['ticket_number'] as String? ?? 'N/A';
      
      // Update the sale status to refunded in the database
      await DatabaseService.safeUpdateSales(
        'UPDATE sales SET status = ?, refund_reason = ?, refunded_at = ? WHERE id = ?',
        ['refunded', reason, DateTime.now().toIso8601String(), saleId],
      );
      
      // Update shift totals (subtract refund from totals)
      if (_currentShift != null) {
        await DatabaseService.updateShiftSales(
          _currentShift!.id!,
          -totalAmount, // Negative amount for refund
        );
      }
      
      _showSuccessSnackBar(
        'Refund processed for $ticketNumber - \$${totalAmount.toStringAsFixed(2)}'
      );
      
      // Refresh the receipts panel
      setState(() {});
      
    } catch (e) {
      print('Error processing refund: $e');
      _showErrorSnackBar('Failed to process refund: $e');
    }
  }

}

class TicketItem {
  final int productId;
  final String productName;
  final int quantity;
  final double price;

  TicketItem({
    required this.productId,
    required this.productName,
    required this.quantity,
    required this.price,
  });

  double get total => quantity * price;

  TicketItem copyWith({
    int? productId,
    String? productName,
    int? quantity,
    double? price,
  }) {
    return TicketItem(
      productId: productId ?? this.productId,
      productName: productName ?? this.productName,
      quantity: quantity ?? this.quantity,
      price: price ?? this.price,
    );
  }
}