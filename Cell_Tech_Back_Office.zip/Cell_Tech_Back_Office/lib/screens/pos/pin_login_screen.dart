import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../main.dart';
import '../../services/database_service.dart';

class PinLoginScreen extends StatefulWidget {
  const PinLoginScreen({super.key});

  @override
  State<PinLoginScreen> createState() => _PinLoginScreenState();
}

class _PinLoginScreenState extends State<PinLoginScreen> {
  String _pin = '';
  bool _isLoading = false;

  void _onNumberPressed(String number) {
    if (_pin.length < 4) {
      setState(() {
        _pin += number;
      });

      if (_pin.length == 4) {
        _authenticate();
      }
    }
  }

  void _onClear() {
    setState(() {
      _pin = '';
    });
  }

  Future<void> _authenticate() async {
    final store = Provider.of<AppState>(context, listen: false).currentStore;
    if (store == null) return;

    setState(() => _isLoading = true);

    try {
      final employee = await DatabaseService.authenticateByPin(_pin, store.id!);

      if (employee != null) {
        if (mounted) {
          Provider.of<AppState>(context, listen: false).setEmployee(employee);
          Navigator.pushReplacementNamed(
            context, 
            '/pos/modern',
            arguments: {
              'employee': employee,
              'store': store,
            },
          );
        }
      } else {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text('Invalid PIN or not assigned to this store'),
              backgroundColor: Colors.red,
            ),
          );
          setState(() {
            _pin = '';
            _isLoading = false;
          });
        }
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error: $e')),
        );
        setState(() {
          _pin = '';
          _isLoading = false;
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final store = Provider.of<AppState>(context).currentStore;

    return Scaffold(
      appBar: AppBar(
        title: Text('POS Login - ${store?.name ?? 'Store'}'),
        backgroundColor: const Color(0xFFFF8C00),
        foregroundColor: Colors.white,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => Navigator.pushReplacementNamed(context, '/pos/store-selection'),
        ),
      ),
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              Color(0xFFFF8C00), // Orange theme
              Color(0xFFFF6B35),
            ],
          ),
        ),
        child: Center(
          child: SingleChildScrollView(
            child: Card(
              elevation: 8,
              margin: const EdgeInsets.all(32),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(16),
              ),
              child: Container(
                constraints: const BoxConstraints(
                  maxWidth: 400,
                ),
                padding: const EdgeInsets.all(24),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Container(
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        gradient: const LinearGradient(
                          colors: [Color(0xFFFF5F1F), Color(0xFFFF6B35)],
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                        ),
                        borderRadius: BorderRadius.circular(50),
                      ),
                      child: const Icon(
                        Icons.lock, 
                        size: 32, 
                        color: Colors.white,
                      ),
                    ),
                    const SizedBox(height: 16),
                    const Text(
                      'Enter Your PIN',
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 24),
                    _buildPinDisplay(),
                    const SizedBox(height: 24),
                    _buildNumPad(),
                    if (_isLoading) ...[
                      const SizedBox(height: 16),
                      const CircularProgressIndicator(color: Color(0xFFFF5F1F)),
                    ],
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildPinDisplay() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: List.generate(4, (index) {
        return Container(
          margin: const EdgeInsets.symmetric(horizontal: 8),
          width: 20,
          height: 20,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            gradient: index < _pin.length
                ? const LinearGradient(
                    colors: [Color(0xFFFF5F1F), Color(0xFFFF6B35)],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  )
                : null,
            color: index < _pin.length ? null : Colors.grey.shade300,
          ),
          child: Center(
            child: index < _pin.length
                ? const Icon(
                    Icons.circle, 
                    color: Colors.white, 
                    size: 8,
                  )
                : null,
          ),
        );
      }),
    );
  }

  Widget _buildNumPad() {
    final numbers = ['1', '2', '3', '4', '5', '6', '7', '8', '9', 'C', '0', '←'];

    return GridView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 3,
        crossAxisSpacing: 12,
        mainAxisSpacing: 12,
        childAspectRatio: 1.5,
      ),
      itemCount: numbers.length,
      itemBuilder: (context, index) {
        final number = numbers[index];
        return _buildNumButton(number);
      },
    );
  }

  Widget _buildNumButton(String value) {
    final isSpecial = value == 'C' || value == '←';

    return ElevatedButton(
      onPressed: _isLoading
          ? null
          : () {
              if (value == 'C') {
                _onClear();
              } else if (value == '←') {
                if (_pin.isNotEmpty) {
                  setState(() {
                    _pin = _pin.substring(0, _pin.length - 1);
                  });
                }
              } else {
                _onNumberPressed(value);
              }
            },
      style: ElevatedButton.styleFrom(
        backgroundColor: isSpecial ? Colors.grey.shade600 : const Color(0xFFFF5F1F),
        foregroundColor: Colors.white,
        textStyle: const TextStyle(
          fontSize: 20, 
          fontWeight: FontWeight.bold,
        ),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
        ),
        elevation: 4,
      ),
      child: Text(value),
    );
  }
}