import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:intl/intl.dart';
import 'dart:math' as math;
import '../../main.dart';
import '../../services/database_service.dart';
import '../../models/shift.dart';
import '../../models/sale.dart';
import '../../utils/responsive_utils.dart';

class MainPosScreen extends StatefulWidget {
  const MainPosScreen({super.key});

  @override
  State<MainPosScreen> createState() => _MainPosScreenState();
}

class _MainPosScreenState extends State<MainPosScreen> {
  List<Map<String, dynamic>> _products = [];
  List<Map<String, dynamic>> _categories = [];
  final List<TicketItem> _ticketItems = [];
  bool _isLoading = true;
  String _searchQuery = '';
  int? _filterCategoryId;
  double _taxRate = 15.0;
  bool _allowNegativeStock = false;

  @override
  void initState() {
    super.initState();
    _loadData();
    _checkShift();
  }

  Future<void> _loadData() async {
    setState(() => _isLoading = true);
    try {
      final store = Provider.of<AppState>(context, listen: false).currentStore;
      if (store == null) return;

      final products = await DatabaseService.getStoreStock(store.id!);
      final categories = await DatabaseService.getCategories();
      final taxRateStr = await DatabaseService.getSetting('tax_rate') ?? '15';
      final allowNegStr = await DatabaseService.getSetting('allow_negative_stock') ?? 'false';

      setState(() {
        _products = products;
        _categories = categories.map((c) => c.toMap()).toList();
        _taxRate = double.tryParse(taxRateStr) ?? 15.0;
        _allowNegativeStock = allowNegStr == 'true';
        _isLoading = false;
      });
    } catch (e) {
      setState(() => _isLoading = false);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error loading data: $e')),
        );
      }
    }
  }

  Future<void> _checkShift() async {
    final employee = Provider.of<AppState>(context, listen: false).currentEmployee;
    final store = Provider.of<AppState>(context, listen: false).currentStore;
    
    if (employee == null || store == null) return;

    final shift = await DatabaseService.getOpenShift(employee.id!, store.id!);
    
    if (shift == null) {
      // No open shift, prompt to start one
      if (mounted) {
        _showStartShiftDialog();
      }
    } else {
      // Use existing shift
      Provider.of<AppState>(context, listen: false).setShiftId(shift.id);
    }
  }

  Future<void> _showStartShiftDialog() async {
    final startingCashController = TextEditingController(text: '100.00');
    
    await showDialog<bool>(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        title: const Text('Start Shift'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text('Please enter the starting cash amount in the register:'),
            const SizedBox(height: 16),
            TextField(
              controller: startingCashController,
              decoration: const InputDecoration(
                labelText: 'Starting Cash',
                prefixText: '\$ ',
                border: OutlineInputBorder(),
              ),
              keyboardType: TextInputType.number,
            ),
          ],
        ),
        actions: [
          ElevatedButton(
            onPressed: () async {
              final startingCash = double.tryParse(startingCashController.text);
              if (startingCash == null) {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Please enter a valid amount')),
                );
                return;
              }

              final employee = Provider.of<AppState>(context, listen: false).currentEmployee;
              final store = Provider.of<AppState>(context, listen: false).currentStore;

              final shift = Shift(
                storeId: store!.id!,
                employeeId: employee!.id!,
                startingCash: startingCash,
              );

              final shiftId = await DatabaseService.startShift(shift);
              Provider.of<AppState>(context, listen: false).setShiftId(shiftId);
              
              Navigator.pop(context, true);
            },
            child: const Text('Start Shift'),
          ),
        ],
      ),
    );
  }

  List<Map<String, dynamic>> get _filteredProducts {
    return _products.where((product) {
      final name = product['name'] as String;
      final sku = product['sku'] as String;
      final matchesSearch = name.toLowerCase().contains(_searchQuery.toLowerCase()) ||
          sku.toLowerCase().contains(_searchQuery.toLowerCase());
      final matchesCategory = _filterCategoryId == null || product['category_id'] == _filterCategoryId;
      return matchesSearch && matchesCategory;
    }).toList();
  }

  void _addProductToTicket(Map<String, dynamic> product) {
    final stockQty = product['stock_quantity'] as int;
    
    if (!_allowNegativeStock && stockQty <= 0) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Product is out of stock')),
      );
      return;
    }

    setState(() {
      final existingIndex = _ticketItems.indexWhere((item) => item.productId == product['id']);
      
      if (existingIndex >= 0) {
        _ticketItems[existingIndex].quantity++;
      } else {
        _ticketItems.add(TicketItem(
          productId: product['id'] as int,
          productName: product['name'] as String,
          unitPrice: (product['price'] as num).toDouble(),
          quantity: 1,
        ));
      }
    });
  }

  void _updateQuantity(int index, int newQuantity) {
    if (newQuantity <= 0) {
      _removeItem(index);
    } else {
      setState(() {
        _ticketItems[index].quantity = newQuantity;
      });
    }
  }

  void _removeItem(int index) {
    setState(() {
      _ticketItems.removeAt(index);
    });
  }

  void _clearTicket() {
    setState(() {
      _ticketItems.clear();
    });
  }

  double get _subtotal {
    return _ticketItems.fold(0, (sum, item) => sum + item.lineTotal);
  }

  double get _taxAmount {
    return _subtotal * (_taxRate / 100);
  }

  double get _total {
    return _subtotal + _taxAmount;
  }

  @override
  Widget build(BuildContext context) {
    final employee = Provider.of<AppState>(context).currentEmployee;
    final store = Provider.of<AppState>(context).currentStore;

    return Scaffold(
      appBar: AppBar(
        title: Text('POS - ${store?.name ?? 'Store'}'),
        backgroundColor: const Color(0xFFFF5F1F),
        foregroundColor: Colors.white,
        actions: [
          ResponsiveBuilder(
            builder: (context, isMobile, isTablet, isDesktop) {
              return Padding(
                padding: EdgeInsets.symmetric(horizontal: isMobile ? 8 : 16),
                child: ResponsiveRow(
                  children: [
                    if (!isMobile) ...[
                      const Icon(Icons.person),
                      const SizedBox(width: 8),
                      Text(
                        employee?.name ?? 'Employee',
                        style: TextStyle(
                          fontSize: isMobile ? 12 : 14,
                        ),
                      ),
                      const SizedBox(width: 16),
                    ],
                    IconButton(
                      icon: const Icon(Icons.receipt),
                      onPressed: _showReceiptsDialog,
                      tooltip: 'Receipts History',
                      iconSize: isMobile ? 20 : 24,
                    ),
                    IconButton(
                      icon: const Icon(Icons.access_time),
                      onPressed: _showEndShiftDialog,
                      tooltip: 'End Shift',
                      iconSize: isMobile ? 20 : 24,
                    ),
                    IconButton(
                      icon: const Icon(Icons.logout),
                      onPressed: () {
                        Provider.of<AppState>(context, listen: false).logout();
                        Navigator.pushReplacementNamed(context, '/');
                      },
                      tooltip: 'Logout',
                      iconSize: isMobile ? 20 : 24,
                    ),
                  ],
                ),
              );
            },
          ),
        ],
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : ResponsiveBuilder(
              builder: (context, isMobile, isTablet, isDesktop) {
                if (isMobile) {
                  // Stack layout for mobile with tabs
                  return DefaultTabController(
                    length: 2,
                    child: Column(
                      children: [
                        TabBar(
                          tabs: const [
                            Tab(text: 'Products'),
                            Tab(text: 'Cart'),
                          ],
                          labelColor: const Color(0xFFFF5F1F),
                          unselectedLabelColor: Colors.grey,
                        ),
                        Expanded(
                          child: TabBarView(
                            children: [
                              _buildProductGrid(),
                              _buildTicketPanel(),
                            ],
                          ),
                        ),
                      ],
                    ),
                  );
                } else {
                  // Side-by-side layout for tablet/desktop
                  return Row(
                    children: [
                      Expanded(
                        flex: isTablet ? 2 : 3,
                        child: _buildProductGrid(),
                      ),
                      Container(width: 1, color: Colors.grey.shade300),
                      Expanded(
                        flex: isTablet ? 1 : 2,
                        child: _buildTicketPanel(),
                      ),
                    ],
                  );
                }
              },
            ),
    );
  }

  Widget _buildProductGrid() {
    return Column(
      children: [
        ResponsiveContainer(
          mobilePadding: const EdgeInsets.all(12),
          tabletPadding: const EdgeInsets.all(16),
          desktopPadding: const EdgeInsets.all(16),
          child: Container(
            decoration: BoxDecoration(
              color: Colors.grey.shade100,
              borderRadius: BorderRadius.circular(8),
            ),
            padding: ResponsiveUtils.responsivePadding(context),
            child: Column(
              children: [
                TextField(
                  decoration: InputDecoration(
                    hintText: 'Search products...',
                    prefixIcon: const Icon(Icons.search),
                    border: const OutlineInputBorder(),
                    isDense: true,
                    contentPadding: EdgeInsets.symmetric(
                      horizontal: ResponsiveUtils.wp(context, 3),
                      vertical: ResponsiveUtils.hp(context, 1.5),
                    ),
                  ),
                  onChanged: (value) {
                    setState(() => _searchQuery = value);
                  },
                ),
                SizedBox(height: ResponsiveUtils.hp(context, 1)),
                SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: ResponsiveRow(
                    wrapOnSmallScreen: false,
                    children: [
                      ChoiceChip(
                        label: const Text('All'),
                        selected: _filterCategoryId == null,
                        onSelected: (selected) {
                          setState(() => _filterCategoryId = null);
                        },
                      ),
                      SizedBox(width: ResponsiveUtils.wp(context, 2)),
                      ..._categories.map((category) {
                        return Padding(
                          padding: EdgeInsets.only(right: ResponsiveUtils.wp(context, 2)),
                          child: ChoiceChip(
                            label: Text(category['name'] as String),
                            selected: _filterCategoryId == category['id'],
                            onSelected: (selected) {
                              setState(() => _filterCategoryId = selected ? category['id'] as int : null);
                            },
                          ),
                        );
                      }),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
        Expanded(
          child: _buildProductGridView(),
        ),
      ],
    );
  }

  Widget _buildProductGridView() {
    final products = _filteredProducts;

    if (products.isEmpty) {
      return const Center(child: Text('No products found'));
    }

    return ResponsiveBuilder(
      builder: (context, isMobile, isTablet, isDesktop) {
        final crossAxisCount = isMobile ? 2 : (isTablet ? 3 : 4);
        final childAspectRatio = isMobile ? 1.1 : (isTablet ? 1.0 : 0.9);
        
        return GridView.builder(
          padding: ResponsiveUtils.responsivePadding(context),
          gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: crossAxisCount,
            crossAxisSpacing: ResponsiveUtils.wp(context, 2),
            mainAxisSpacing: ResponsiveUtils.wp(context, 2),
            childAspectRatio: childAspectRatio,
          ),
          itemCount: products.length,
          itemBuilder: (context, index) {
            final product = products[index];
            return _buildProductTile(product);
          },
        );
      },
    );
  }

  Widget _buildProductTile(Map<String, dynamic> product) {
    final stockQty = product['stock_quantity'] as int;
    final minLevel = product['min_stock_level'] as int;
    final isOutOfStock = stockQty <= 0;
    final isLowStock = stockQty <= minLevel && stockQty > 0;
    final color = _parseColor(product['category_color'] as String);

    return Card(
      elevation: 2,
      child: InkWell(
        onTap: isOutOfStock && !_allowNegativeStock
            ? null
            : () => _addProductToTicket(product),
        child: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: isOutOfStock && !_allowNegativeStock
                  ? [Colors.grey.shade400, Colors.grey.shade600]
                  : [color.withOpacity(0.8), color],
            ),
            borderRadius: BorderRadius.circular(4),
          ),
          child: Padding(
            padding: const EdgeInsets.all(12),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Expanded(
                  child: Center(
                    child: ResponsiveText(
                      product['name'] as String,
                      baseFontSize: 16,
                      style: const TextStyle(
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                      ),
                      textAlign: TextAlign.center,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                ),
                const SizedBox(height: 8),
                
                // Category Badge
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.2),
                    borderRadius: BorderRadius.circular(4),
                  ),
                  child: Text(
                    product['category_name'] ?? 'General',
                    style: const TextStyle(
                      fontSize: 9,
                      color: Colors.white,
                      fontWeight: FontWeight.w500,
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
                
                const SizedBox(height: 4),
                
                Text(
                  NumberFormat.currency(symbol: '\$').format(product['price']),
                  style: const TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                  ),
                ),
                const SizedBox(height: 4),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                  decoration: BoxDecoration(
                    color: isOutOfStock
                        ? Colors.red
                        : isLowStock
                            ? Colors.orange
                            : Colors.green,
                    borderRadius: BorderRadius.circular(4),
                  ),
                  child: Text(
                    'Qty: $stockQty',
                    style: const TextStyle(
                      fontSize: 10,
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Color _parseColor(String colorString) {
    try {
      return Color(int.parse(colorString.replaceFirst('#', '0xFF')));
    } catch (e) {
      return Colors.blue;
    }
  }

  Widget _buildTicketPanel() {
    return Container(
      color: Colors.grey.shade50,
      child: Column(
        children: [
          Container(
            padding: ResponsiveUtils.responsivePadding(context),
            color: const Color(0xFFFF5F1F),
            child: ResponsiveRow(
              children: [
                ResponsiveText(
                  'Current Ticket',
                  baseFontSize: 20,
                  style: const TextStyle(
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                  ),
                ),
                const Spacer(),
                ResponsiveText(
                  'Items: ${_ticketItems.length}',
                  baseFontSize: 14,
                  style: const TextStyle(color: Colors.white),
                ),
              ],
            ),
          ),
          Expanded(
            child: _ticketItems.isEmpty
                ? const Center(child: Text('No items in ticket'))
                : ListView.builder(
                    itemCount: _ticketItems.length,
                    itemBuilder: (context, index) {
                      return _buildTicketItemTile(index);
                    },
                  ),
          ),
          _buildTicketSummary(),
          _buildPaymentButtons(),
        ],
      ),
    );
  }

  Widget _buildTicketItemTile(int index) {
    final item = _ticketItems[index];

    return Card(
      margin: EdgeInsets.symmetric(
        horizontal: ResponsiveUtils.wp(context, 2),
        vertical: ResponsiveUtils.hp(context, 0.5),
      ),
      child: ResponsiveContainer(
        mobilePadding: const EdgeInsets.all(8),
        tabletPadding: const EdgeInsets.all(12),
        desktopPadding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            ResponsiveRow(
              children: [
                Expanded(
                  child: ResponsiveText(
                    item.productName,
                    baseFontSize: 14,
                    style: const TextStyle(fontWeight: FontWeight.bold),
                  ),
                ),
                IconButton(
                  icon: Icon(
                    Icons.delete,
                    color: Colors.red,
                    size: ResponsiveUtils.adaptiveIconSize(context, 20),
                  ),
                  onPressed: () => _removeItem(index),
                ),
              ],
            ),
            const SizedBox(height: 8),
            Row(
              children: [
                IconButton(
                  icon: const Icon(Icons.remove_circle_outline),
                  onPressed: () => _updateQuantity(index, item.quantity - 1),
                ),
                Text(
                  '${item.quantity}',
                  style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                ),
                IconButton(
                  icon: const Icon(Icons.add_circle_outline),
                  onPressed: () => _updateQuantity(index, item.quantity + 1),
                ),
                const Spacer(),
                Text(
                  '${NumberFormat.currency(symbol: '\$').format(item.unitPrice)} × ${item.quantity}',
                  style: const TextStyle(fontSize: 12),
                ),
              ],
            ),
            const Divider(),
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                const Text('Line Total: ', style: TextStyle(fontSize: 12)),
                Text(
                  NumberFormat.currency(symbol: '\$').format(item.lineTotal),
                  style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTicketSummary() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        border: Border(top: BorderSide(color: Colors.grey.shade300)),
      ),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text('Subtotal:'),
              Text(NumberFormat.currency(symbol: '\$').format(_subtotal)),
            ],
          ),
          const SizedBox(height: 8),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text('Tax ($_taxRate%):'),
              Text(NumberFormat.currency(symbol: '\$').format(_taxAmount)),
            ],
          ),
          const Divider(height: 24),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text(
                'Total:',
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
              ),
              Text(
                NumberFormat.currency(symbol: '\$').format(_total),
                style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: Colors.green),
              ),
            ],
          ),
          const SizedBox(height: 16),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              onPressed: _ticketItems.isEmpty ? null : _clearTicket,
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.red,
                foregroundColor: Colors.white,
              ),
              child: const Text('Clear Ticket'),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPaymentButtons() {
    return Container(
      padding: const EdgeInsets.all(16),
      child: Column(
        children: [
          Row(
            children: [
              Expanded(
                child: ElevatedButton.icon(
                  onPressed: _ticketItems.isEmpty ? null : () => _processPayment('Cash'),
                  icon: const Icon(Icons.attach_money),
                  label: const Text('Pay Cash'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.green,
                    foregroundColor: Colors.white,
                    padding: const EdgeInsets.symmetric(vertical: 16),
                  ),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: ElevatedButton.icon(
                  onPressed: _ticketItems.isEmpty ? null : () => _processPayment('Card'),
                  icon: const Icon(Icons.credit_card),
                  label: const Text('Pay Card'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.blue,
                    foregroundColor: Colors.white,
                    padding: const EdgeInsets.symmetric(vertical: 16),
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Row(
            children: [
              Expanded(
                child: ElevatedButton.icon(
                  onPressed: _ticketItems.isEmpty ? null : () => _processPayment('EcoCash USD'),
                  icon: const Icon(Icons.phone_android),
                  label: const Text('EcoCash USD'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.orange,
                    foregroundColor: Colors.white,
                    padding: const EdgeInsets.symmetric(vertical: 16),
                  ),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: ElevatedButton.icon(
                  onPressed: _ticketItems.isEmpty ? null : () => _processPayment('EcoCash ZIG'),
                  icon: const Icon(Icons.phone_android),
                  label: const Text('EcoCash ZIG'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.purple,
                    foregroundColor: Colors.white,
                    padding: const EdgeInsets.symmetric(vertical: 16),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Future<void> _processPayment(String paymentMethod) async {
    if (paymentMethod == 'Cash') {
      await _showCashPaymentDialog();
    } else {
      await _confirmPayment(paymentMethod);
    }
  }

  Future<void> _showCashPaymentDialog() async {
    final tenderedController = TextEditingController(text: _total.toStringAsFixed(2));
    
    await showDialog(
      context: context,
      builder: (context) => StatefulBuilder(
        builder: (context, setDialogState) {
          final tendered = double.tryParse(tenderedController.text) ?? 0;
          final change = tendered - _total;
          
          return AlertDialog(
            title: const Text('Cash Payment'),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  'Total: ${NumberFormat.currency(symbol: '\$').format(_total)}',
                  style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 16),
                TextField(
                  controller: tenderedController,
                  decoration: const InputDecoration(
                    labelText: 'Tendered Amount',
                    prefixText: '\$ ',
                    border: OutlineInputBorder(),
                  ),
                  keyboardType: TextInputType.number,
                  onChanged: (_) => setDialogState(() {}),
                ),
                const SizedBox(height: 16),
                if (change >= 0)
                  Text(
                    'Change: ${NumberFormat.currency(symbol: '\$').format(change)}',
                    style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                      color: change >= 0 ? Colors.green : Colors.red,
                    ),
                  ),
              ],
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context),
                child: const Text('Cancel'),
              ),
              ElevatedButton(
                onPressed: change < 0
                    ? null
                    : () {
                        Navigator.pop(context);
                        _confirmPayment('Cash');
                      },
                child: const Text('Complete Payment'),
              ),
            ],
          );
        },
      ),
    );
  }

  Future<void> _confirmPayment(String paymentMethod) async {
    try {
      final employee = Provider.of<AppState>(context, listen: false).currentEmployee;
      final store = Provider.of<AppState>(context, listen: false).currentStore;
      final shiftId = Provider.of<AppState>(context, listen: false).currentShiftId;

      if (employee == null || store == null) return;

      final ticketNumber = 'TKT${DateTime.now().millisecondsSinceEpoch}';

      final sale = Sale(
        ticketNumber: ticketNumber,
        storeId: store.id!,
        employeeId: employee.id!,
        shiftId: shiftId,
        subtotal: _subtotal,
        taxAmount: _taxAmount,
        discountAmount: 0,
        totalAmount: _total,
        paymentMethod: paymentMethod,
      );

      final saleItems = _ticketItems.map((item) => SaleItem(
        saleId: 0, // Will be set by database
        productId: item.productId,
        quantity: item.quantity,
        unitPrice: item.unitPrice,
        lineTotal: item.lineTotal,
      )).toList();

      await DatabaseService.insertSale(sale, saleItems);

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Sale completed successfully'),
            backgroundColor: Colors.green,
          ),
        );
        
        _clearTicket();
        _loadData(); // Refresh stock levels
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error processing payment: $e')),
        );
      }
    }
  }

  Future<void> _showReceiptsDialog() async {
    final shiftId = Provider.of<AppState>(context, listen: false).currentShiftId;
    if (shiftId == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('No active shift')),
      );
      return;
    }

    final sales = await DatabaseService.getSales();
    
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Receipts History'),
        content: SizedBox(
          width: 600,
          height: 400,
          child: sales.isEmpty
              ? const Center(child: Text('No sales found'))
              : ListView.builder(
                  itemCount: sales.length,
                  itemBuilder: (context, index) {
                    final sale = sales[index];
                    return ListTile(
                      title: Text('Ticket: ${sale['ticket_number']}'),
                      subtitle: Text('${sale['payment_method']} - ${NumberFormat.currency(symbol: '\$').format(sale['total_amount'])}'),
                      trailing: Text(DateFormat('HH:mm').format(DateTime.parse(sale['sale_date']))),
                    );
                  },
                ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Close'),
          ),
        ],
      ),
    );
  }

  Future<void> _showEndShiftDialog() async {
    final shiftId = Provider.of<AppState>(context, listen: false).currentShiftId;
    if (shiftId == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('No active shift to end')),
      );
      return;
    }

    final endingCashController = TextEditingController();
    
    await showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('End Shift'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text('Please count and enter the cash in the register:'),
            const SizedBox(height: 16),
            TextField(
              controller: endingCashController,
              decoration: const InputDecoration(
                labelText: 'Ending Cash',
                prefixText: '\$ ',
                border: OutlineInputBorder(),
              ),
              keyboardType: TextInputType.number,
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () async {
              final endingCash = double.tryParse(endingCashController.text);
              if (endingCash == null) {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Please enter a valid amount')),
                );
                return;
              }

              await DatabaseService.endShift(shiftId, endingCash);
              Provider.of<AppState>(context, listen: false).setShiftId(null);
              
              Navigator.pop(context);
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('Shift ended successfully')),
              );
            },
            child: const Text('End Shift'),
          ),
        ],
      ),
    );
  }
}

class TicketItem {
  final int productId;
  final String productName;
  final double unitPrice;
  int quantity;

  TicketItem({
    required this.productId,
    required this.productName,
    required this.unitPrice,
    required this.quantity,
  });

  double get lineTotal => unitPrice * quantity;
}
