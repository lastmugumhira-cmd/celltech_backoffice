import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../main.dart';
import '../models/employee.dart';

class BackOfficeLayout extends StatefulWidget {
  final String title;
  final Widget child;
  final String currentRoute;

  const BackOfficeLayout({
    super.key,
    required this.title,
    required this.child,
    required this.currentRoute,
  });

  @override
  State<BackOfficeLayout> createState() => _BackOfficeLayoutState();
}

class _BackOfficeLayoutState extends State<BackOfficeLayout> {
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();

  // Define navigation items with groups - exactly as described
  final List<NavigationItem> navigationItems = [
    // Dashboard group
    NavigationItem(
        'Dashboard', Icons.dashboard, '/backoffice/dashboard', 'main'),

    // Product Management group
    NavigationItem(
        'Products & Stock', Icons.inventory_2, '/backoffice/products', 'products'),
    NavigationItem(
        'Categories', Icons.category, '/backoffice/categories', 'products'),

    // Inventory Management group
    NavigationItem('Inventory Overview', Icons.warehouse,
        '/backoffice/inventory/overview', 'inventory'),
    NavigationItem('Stock Adjustments', Icons.tune,
        '/backoffice/inventory/adjustments', 'inventory'),
    NavigationItem('Inventory Counts', Icons.format_list_numbered,
        '/backoffice/inventory/counts', 'inventory'),
    NavigationItem('Stock History', Icons.history,
        '/backoffice/inventory/history', 'inventory'),
    NavigationItem('Valuation', Icons.attach_money,
        '/backoffice/inventory/valuation', 'inventory'),
    NavigationItem('Productions', Icons.precision_manufacturing,
        '/backoffice/inventory/productions', 'inventory'),

    // Warehouse group
    NavigationItem('Warehouse Manager', Icons.warehouse,
        '/backoffice/warehouse-manager', 'warehouse'),

    // Store Management group
    NavigationItem('Stores', Icons.store, '/backoffice/stores', 'store'),
    NavigationItem('Employees', Icons.people, '/backoffice/employees', 'store'),
    NavigationItem('Customers', Icons.person, '/backoffice/customers', 'store'),
    NavigationItem(
        'POS Devices', Icons.point_of_sale, '/backoffice/pos-devices', 'store'),

    // System group
    NavigationItem('Sales Reports', Icons.bar_chart,
        '/backoffice/sales-reports', 'system'),
    NavigationItem('Discounts', Icons.local_offer,
        '/backoffice/discounts', 'system'),
    NavigationItem('Shifts', Icons.schedule,
        '/backoffice/shifts', 'system'),
    NavigationItem('Receipts', Icons.receipt_long,
        '/backoffice/receipts', 'system'),
    NavigationItem(
        'Settings', Icons.settings, '/backoffice/settings', 'system'),
  ];

  // Groups map for section headers
  final Map<String, String> groups = {
    'main': 'Dashboard',
    'products': 'Products & Stock Management',
    'inventory': 'Inventory Management',
    'warehouse': 'Warehouse',
    'store': 'Store Management',
    'system': 'System',
  };

  @override
  Widget build(BuildContext context) {
    final employee = Provider.of<AppState>(context).currentEmployee;
    final isDesktop = MediaQuery.of(context).size.width > 768;

    return Scaffold(
      key: _scaffoldKey,
      backgroundColor: Colors.grey.shade50,
      drawer: isDesktop ? null : _buildSidebar(context, false),
      body: Row(
        children: [
          if (isDesktop) _buildSidebar(context, true),
          Expanded(
            child: Column(
              children: [
                // Mobile header
                if (!isDesktop) _buildMobileHeader(context, employee),
                // Main content
                Expanded(
                  child: Container(
                    padding: const EdgeInsets.all(24),
                    child: widget.child,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildMobileHeader(BuildContext context, Employee? employee) {
    return Container(
      height: 60,
      decoration: BoxDecoration(
        color: Colors.white,
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.1),
            blurRadius: 4,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Row(
        children: [
          IconButton(
            icon: const Icon(Icons.menu),
            onPressed: () => _scaffoldKey.currentState?.openDrawer(),
          ),
          const SizedBox(width: 8),
          // Logo
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [Color(0xFFFF8C00), Color(0xFFFF6B35)],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(8),
            ),
            child: const Text(
              'CellTech',
              style: TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.bold,
                fontSize: 16,
              ),
            ),
          ),
          const Spacer(),
          // User info
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Row(
              children: [
                const Icon(Icons.person, color: Color(0xFFFF8C00)),
                const SizedBox(width: 8),
                Text(
                  employee?.name ?? 'User',
                  style: const TextStyle(fontWeight: FontWeight.w500),
                ),
                const SizedBox(width: 16),
                IconButton(
                  icon: const Icon(Icons.logout, color: Color(0xFFFF8C00)),
                  onPressed: () {
                    Provider.of<AppState>(context, listen: false).logout();
                    Navigator.pushReplacementNamed(context, '/');
                  },
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSidebar(BuildContext context, bool isDesktop) {
    final employee = Provider.of<AppState>(context).currentEmployee;

    return Container(
      width: isDesktop ? 280 : 280,
      decoration: BoxDecoration(
        color: Colors.white,
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.1),
            blurRadius: 8,
            offset: const Offset(2, 0),
          ),
        ],
      ),
      child: Column(
        children: [
          // Header
          _buildSidebarHeader(),
          // Navigation
          Expanded(
            child: ListView(
              padding: const EdgeInsets.symmetric(vertical: 16),
              children: _buildNavigationItems(),
            ),
          ),
          // Footer
          _buildSidebarFooter(employee),
        ],
      ),
    );
  }

  Widget _buildSidebarHeader() {
    return Container(
      padding: const EdgeInsets.all(24),
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          colors: [Color(0xFFFF8C00), Color(0xFFFF6B35)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.2),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: const Icon(
                  Icons.business,
                  color: Colors.white,
                  size: 32,
                ),
              ),
              const SizedBox(width: 12),
              const Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'CellTech POS',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    Text(
                      'Back Office System',
                      style: TextStyle(
                        color: Colors.white70,
                        fontSize: 12,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  List<Widget> _buildNavigationItems() {
    List<Widget> items = [];

    // Group items by their group key
    Map<String, List<NavigationItem>> groupedItems = {};
    for (var item in navigationItems) {
      if (!groupedItems.containsKey(item.group)) {
        groupedItems[item.group] = [];
      }
      groupedItems[item.group]!.add(item);
    }

    // Build navigation sections
    groups.forEach((groupKey, groupName) {
      if (groupedItems.containsKey(groupKey)) {
        // Add group header
        items.add(
          Padding(
            padding: const EdgeInsets.fromLTRB(24, 16, 24, 8),
            child: Text(
              groupName,
              style: TextStyle(
                fontSize: 12,
                fontWeight: FontWeight.w600,
                color: Colors.grey.shade600,
                letterSpacing: 0.5,
              ),
            ),
          ),
        );

        // Add group items
        for (var item in groupedItems[groupKey]!) {
          items.add(_buildNavigationItem(item));
        }

        // Add spacing between groups
        items.add(const SizedBox(height: 8));
      }
    });

    return items;
  }

  Widget _buildNavigationItem(NavigationItem item) {
    final isSelected = widget.currentRoute == item.route;

    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 2),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: BorderRadius.circular(12),
          onTap: () {
            // Only navigate if route exists and is different
            if (item.route != widget.currentRoute && _routeExists(item.route)) {
              Navigator.pushReplacementNamed(context, item.route);
            }
            // Close drawer on mobile
            if (MediaQuery.of(context).size.width <= 768) {
              Navigator.of(context).pop();
            }
          },
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            decoration: BoxDecoration(
              gradient: isSelected
                  ? const LinearGradient(
                      colors: [Color(0xFFFF8C00), Color(0xFFFF6B35)],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    )
                  : null,
              borderRadius: BorderRadius.circular(12),
              boxShadow: isSelected
                  ? [
                      BoxShadow(
                        color: const Color(0xFFFF8C00).withOpacity(0.3),
                        blurRadius: 8,
                        offset: const Offset(0, 2),
                      ),
                    ]
                  : null,
            ),
            child: Row(
              children: [
                Icon(
                  item.icon,
                  color: isSelected ? Colors.white : Colors.grey.shade600,
                  size: 20,
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Text(
                    item.title,
                    style: TextStyle(
                      color: isSelected ? Colors.white : Colors.grey.shade800,
                      fontWeight:
                          isSelected ? FontWeight.w600 : FontWeight.w500,
                      fontSize: 14,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  bool _routeExists(String route) {
    // Check if route exists in our defined routes
    final existingRoutes = [
      '/backoffice/dashboard',
      '/backoffice/products',
      '/backoffice/categories',
      '/backoffice/inventory/overview',
  '/backoffice/inventory/adjustments',
      '/backoffice/inventory/counts',
      '/backoffice/inventory/history',
      '/backoffice/inventory/valuation',
      '/backoffice/inventory/productions',
      '/backoffice/warehouse-manager',
  '/backoffice/warehouse-history',
      '/backoffice/employees',
      '/backoffice/customers',
      '/backoffice/pos-devices',
      '/backoffice/sales-reports',
      '/backoffice/discounts',
      '/backoffice/shifts',
      '/backoffice/receipts',
      '/backoffice/stores',
      '/backoffice/settings',
    ];
    return existingRoutes.contains(route);
  }

  Widget _buildSidebarFooter(Employee? employee) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            const Color(0xFFFF8C00).withOpacity(0.1),
            const Color(0xFFFF6B35).withOpacity(0.1),
          ],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
      ),
      child: Row(
        children: [
          CircleAvatar(
            radius: 20,
            backgroundColor: const Color(0xFFFF8C00),
            child: Text(
              employee?.name.substring(0, 1).toUpperCase() ?? 'A',
              style: const TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  employee?.name ?? 'Admin User',
                  style: const TextStyle(
                    fontWeight: FontWeight.w600,
                    fontSize: 14,
                  ),
                ),
                Text(
                  'System Administrator',
                  style: TextStyle(
                    color: Colors.grey.shade600,
                    fontSize: 12,
                  ),
                ),
              ],
            ),
          ),
          IconButton(
            icon: const Icon(Icons.logout, color: Color(0xFFFF8C00)),
            onPressed: () {
              Provider.of<AppState>(context, listen: false).logout();
              Navigator.pushReplacementNamed(context, '/');
            },
          ),
        ],
      ),
    );
  }
}

class NavigationItem {
  final String title;
  final IconData icon;
  final String route;
  final String group;

  NavigationItem(this.title, this.icon, this.route, this.group);
}
