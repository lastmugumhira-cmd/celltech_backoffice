import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:file_picker/file_picker.dart';
import 'dart:convert';
import 'dart:io';
import '../../models/product.dart';
import '../../models/category.dart';
import '../../models/store.dart';
import '../../services/database_service.dart';

class ProductForm extends StatefulWidget {
  final Product? product;
  final List<Category> categories;
  final List<Store> stores;
  final Function(Product, Map<int, Map<String, dynamic>>) onSubmit;
  final VoidCallback onCancel;

  const ProductForm({
    super.key,
    this.product,
    required this.categories,
    required this.stores,
    required this.onSubmit,
    required this.onCancel,
  });

  @override
  State<ProductForm> createState() => _ProductFormState();
}

class _ProductFormState extends State<ProductForm>
    with TickerProviderStateMixin {
  final _formKey = GlobalKey<FormState>();
  late TabController _tabController;

  // Basic Info Controllers
  final _nameController = TextEditingController();
  final _descriptionController = TextEditingController();
  final _skuController = TextEditingController();
  final _barcodeController = TextEditingController();
  final _priceController = TextEditingController();
  final _costController = TextEditingController();
  final _supplierController = TextEditingController();

  // Form State
  int? _selectedCategoryId;
  bool _trackStock = true;
  bool _active = true;
  bool _soldByWeight = false;
  bool _useProduction = false;
  bool _isLoading = false;
  String? _imageUrl;
  String? _selectedImageName;

  // Multi-store settings
  String _storeAvailability = 'all_stores'; // 'all_stores' or 'specific_stores'
  bool _availableAllStores = true; // UI toggle that mirrors _storeAvailability
  Set<int> _selectedStores = {};
  final Map<int, Map<String, dynamic>> _storeSettings = {};
  final Map<int, TextEditingController> _inStockControllers = {};

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
    _initializeForm();
  }

  void _initializeForm() {
    if (widget.product != null) {
      final product = widget.product!;
      _nameController.text = product.name;
      _descriptionController.text = product.description ?? '';
      _skuController.text = product.sku;
      _barcodeController.text = product.barcode ?? '';
      _priceController.text = product.price.toString();
      _costController.text = product.cost?.toString() ?? '';
      _selectedCategoryId = product.categoryId;
      _trackStock = product.trackStock;
      _active = product.active;
      _soldByWeight = product.soldByWeight ?? false;
      _imageUrl = product.imageUrl;

      // Initialize store availability and settings from product if present
      _storeAvailability = product.storeAvailability ?? 'all_stores';
      _availableAllStores = _storeAvailability == 'all_stores';

      // Seed selected stores based on product.availableStores or default to all
      if (product.availableStores != null && product.availableStores!.isNotEmpty) {
        _selectedStores = product.availableStores!.toSet();
      } else {
        _selectedStores = widget.stores.where((s) => s.id != null).map((s) => s.id!).toSet();
      }

      // Build initial _storeSettings from product.storeSettings if present
      // Keys in product.storeSettings are expected to be stringified store IDs
      for (final store in widget.stores) {
        final sid = store.id;
        if (sid == null) continue;
        final settingsFromProduct = product.storeSettings != null
            ? product.storeSettings![sid.toString()] as Map<String, dynamic>?
            : null;
        _storeSettings[sid] = {
          'available_for_sale': settingsFromProduct?['available_for_sale'] ?? true,
          'price': (settingsFromProduct?['price'] as num?)?.toDouble() ?? product.price,
          'in_stock': settingsFromProduct?['in_stock'] ?? 0,
          'low_stock': settingsFromProduct?['low_stock'] ?? 5,
          'optimal_stock': settingsFromProduct?['optimal_stock'] ?? 20,
        };
        // Prime a controller for in_stock to allow async refresh
        _inStockControllers[sid] = TextEditingController(text: (_storeSettings[sid]!['in_stock'] ?? 0).toString());
      }

      // After base init, load authoritative stock quantities from DB for accuracy
      // and update the controllers/state so the edit form always shows correct Available QTY
      if (product.id != null) {
        _loadExistingStockQuantities(product.id!);
      }
    } else {
      // Default values for new product
      // Set default category to first available category
      if (widget.categories.isNotEmpty) {
        _selectedCategoryId = widget.categories.first.id;
      }
      
      _availableAllStores = true;
      _storeAvailability = 'all_stores';
      _selectedStores = widget.stores.where((s) => s.id != null).map((s) => s.id!).toSet();
      for (final store in widget.stores) {
        if (store.id != null) {
          _storeSettings[store.id!] = {
            'available_for_sale': true,
            'price': 0.0,
            'in_stock': 0,
            'low_stock': 5,
            'optimal_stock': 20,
          };
          _inStockControllers[store.id!] = TextEditingController(text: '0');
        }
      }
    }
  }

  Future<void> _loadExistingStockQuantities(int productId) async {
    try {
      for (final store in widget.stores) {
        final sid = store.id;
        if (sid == null) continue;
        final qty = await DatabaseService.getProductStock(productId, sid);
        // Update internal settings and controller
        _storeSettings[sid] = {
          ..._storeSettings[sid] ?? {},
          'in_stock': qty,
        };
        if (_inStockControllers.containsKey(sid)) {
          _inStockControllers[sid]!.text = qty.toString();
        } else {
          _inStockControllers[sid] = TextEditingController(text: qty.toString());
        }
      }
      if (mounted) setState(() {});
    } catch (e) {
      // Non-fatal; keep existing values
    }
  }

  @override
  void dispose() {
    _tabController.dispose();
    _nameController.dispose();
    _descriptionController.dispose();
    _skuController.dispose();
    _barcodeController.dispose();
    _priceController.dispose();
    _costController.dispose();
    _supplierController.dispose();
    for (final c in _inStockControllers.values) {
      c.dispose();
    }
    super.dispose();
  }

  Future<void> _pickImage() async {
    try {
      FilePickerResult? result = await FilePicker.platform.pickFiles(
        type: FileType.image,
        allowMultiple: false,
      );

      if (result != null && result.files.isNotEmpty) {
        final file = result.files.first;
        setState(() {
          _selectedImageName = file.name;
          if (file.bytes != null && file.bytes!.isNotEmpty) {
            // Keep as data URI for immediate preview; persisted on save
            _imageUrl = 'data:image/${file.extension};base64,${base64Encode(file.bytes!)}';
          } else if (file.path != null && file.path!.isNotEmpty) {
            // Desktop platforms often provide only a path; preview directly from file path
            _imageUrl = file.path!;
          }
        });
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error picking image: $e')),
        );
      }
    }
  }

  void _removeImage() {
    setState(() {
      _selectedImageName = null;
      _imageUrl = null;
    });
  }

  int get _totalAvailableQty {
    int total = 0;
    final Iterable<int> ids = _availableAllStores
        ? _storeSettings.keys
        : _selectedStores;
    for (final id in ids) {
      final v = _storeSettings[id]?['in_stock'];
      if (v is int) {
        total += v;
      } else if (v is num) {
        total += v.toInt();
      } else if (v != null) {
        total += int.tryParse(v.toString()) ?? 0;
      }
    }
    return total;
  }

  String _generateSku() {
    final name = _nameController.text.trim();
    if (name.isEmpty) return '';

    final prefix = name.replaceAll(RegExp(r'[^a-zA-Z0-9]'), '').toUpperCase();
    final timestamp = DateTime.now().millisecondsSinceEpoch.toString();
    final suffix = timestamp.substring(timestamp.length - 6);

    return '${prefix.length > 3 ? prefix.substring(0, 3) : prefix}$suffix';
  }

  void _handleSubmit() async {
    print('ProductForm: _handleSubmit called');
    
    if (_formKey.currentState == null) {
      print('ProductForm: Form state is null');
      return;
    }
    
    if (!_formKey.currentState!.validate()) {
      print('ProductForm: Form validation failed');
      return;
    }
    
    print('ProductForm: Starting form submission');
    setState(() => _isLoading = true);

    try {
      // Auto-generate SKU if empty for new products
      String sku = _skuController.text.trim();
      if (sku.isEmpty && widget.product == null) {
        sku = _generateSku();
      }

      // Build store settings based on availability choice
      Map<String, dynamic> storeSettings = {};
      List<int> availableStores = [];

      if (_storeAvailability == 'all_stores') {
        // Auto-fill all stores with default price
        final defaultPrice = double.tryParse(_priceController.text) ?? 0.0;
        for (final store in widget.stores) {
          if (store.id != null) {
            storeSettings[store.id.toString()] = {
              'available_for_sale': true,
              'price': defaultPrice,
              'in_stock': _storeSettings[store.id!]?['in_stock'] ?? 0,
              'low_stock': _storeSettings[store.id!]?['low_stock'] ?? 5,
              'optimal_stock': _storeSettings[store.id!]?['optimal_stock'] ?? 20,
            };
            availableStores.add(store.id!);
          }
        }
      } else {
        // Use specific store settings
        for (final storeId in _selectedStores) {
          storeSettings[storeId.toString()] = _storeSettings[storeId] ??
              {
                'available_for_sale': true,
                'price': double.tryParse(_priceController.text) ?? 0.0,
                'in_stock': 0,
                'low_stock': 5,
                'optimal_stock': 20,
              };
          availableStores.add(storeId);
        }
      }

      // Validate required fields
      if (_selectedCategoryId == null) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Please select a category'),
            backgroundColor: Colors.red,
          ),
        );
        setState(() => _isLoading = false);
        return;
      }

      final product = Product(
        id: widget.product?.id,
        name: _nameController.text.trim(),
        description: _descriptionController.text.trim().isEmpty
            ? null
            : _descriptionController.text.trim(),
        sku: sku,
        barcode: _barcodeController.text.trim().isEmpty
            ? null
            : _barcodeController.text.trim(),
        categoryId: _selectedCategoryId!,
        price: double.parse(_priceController.text),
        cost: _costController.text.trim().isEmpty
            ? null
            : double.tryParse(_costController.text.trim()),
        trackStock: _trackStock,
        active: _active,
        soldByWeight: _soldByWeight,
        imageUrl: _imageUrl,
        createdAt: widget.product?.createdAt ?? DateTime.now(),
        // Additional fields for multi-store support
        storeAvailability: _storeAvailability,
        availableStores: availableStores,
        storeSettings: storeSettings,
      );

      print('ProductForm: About to submit with _storeSettings: $_storeSettings');
      widget.onSubmit(product, _storeSettings);
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error: $e')),
        );
      }
    } finally {
      if (mounted) {
        setState(() => _isLoading = false);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final screenSize = MediaQuery.of(context).size;
    return Dialog(
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
      ),
      child: Container(
        width: screenSize.width * 0.8,
        height: screenSize.height * 0.8,
        constraints: const BoxConstraints(
          maxWidth: 800,
          maxHeight: 700,
          minWidth: 600,
          minHeight: 500,
        ),
        padding: const EdgeInsets.all(24),
        child: Column(
          children: [
            _buildHeader(),
            const SizedBox(height: 16),
            _buildTabBar(),
            Expanded(
              child: Form(
                key: _formKey,
                child: TabBarView(
                  controller: _tabController,
                  children: [
                    _buildBasicInfoTab(),
                    _buildPricingTab(),
                    _buildStoresTab(),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 16),
            _buildActionButtons(),
          ],
        ),
      ),
    );
  }

  Widget _buildHeader() {
    return Row(
      children: [
        Container(
          padding: const EdgeInsets.all(8),
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              colors: [Color(0xFFFF8C00), Color(0xFFFF6B35)],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            borderRadius: BorderRadius.circular(8),
          ),
          child: const Icon(
            Icons.inventory_2,
            color: Colors.white,
            size: 20,
          ),
        ),
        const SizedBox(width: 12),
        Text(
          widget.product == null ? 'Add Product' : 'Edit Product',
          style: const TextStyle(
            fontSize: 20,
            fontWeight: FontWeight.bold,
          ),
        ),
        const Spacer(),
        IconButton(
          onPressed: widget.onCancel,
          icon: const Icon(Icons.close),
        ),
      ],
    );
  }

  Widget _buildTabBar() {
    return TabBar(
      controller: _tabController,
      labelColor: const Color(0xFFFF8C00),
      unselectedLabelColor: Colors.grey,
      indicatorColor: const Color(0xFFFF8C00),
      tabs: const [
        Tab(text: 'Basic Info'),
        Tab(text: 'Pricing & Cost'),
        Tab(text: 'Store Availability'),
      ],
    );
  }

  Widget _buildBasicInfoTab() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
          children: [
            // Product Name
            TextFormField(
              controller: _nameController,
              decoration: const InputDecoration(
                labelText: 'Product Name *',
                border: OutlineInputBorder(),
                prefixIcon: Icon(Icons.label, color: Color(0xFFFF8C00)),
              ),
              validator: (value) {
                if (value == null || value.trim().isEmpty) {
                  return 'Please enter a product name';
                }
                return null;
              },
            ),
            const SizedBox(height: 16),

            // SKU
            TextFormField(
              controller: _skuController,
              decoration: InputDecoration(
                labelText: 'SKU',
                border: const OutlineInputBorder(),
                prefixIcon: const Icon(Icons.qr_code, color: Color(0xFFFF8C00)),
                helperText: widget.product == null
                    ? 'Leave empty to auto-generate'
                    : null,
              ),
            ),
            const SizedBox(height: 16),

            // Category
            DropdownButtonFormField<int>(
              initialValue: _selectedCategoryId,
              decoration: const InputDecoration(
                labelText: 'Category *',
                border: OutlineInputBorder(),
                prefixIcon: Icon(Icons.category, color: Color(0xFFFF8C00)),
              ),
              items: widget.categories
                  .map((category) => DropdownMenuItem(
                        value: category.id,
                        child: Text(category.name),
                      ))
                  .toList(),
              onChanged: (value) {
                setState(() => _selectedCategoryId = value);
              },
              validator: (value) {
                if (value == null) {
                  return 'Please select a category';
                }
                return null;
              },
            ),
            const SizedBox(height: 16),

            // Description
            TextFormField(
              controller: _descriptionController,
              decoration: const InputDecoration(
                labelText: 'Description',
                border: OutlineInputBorder(),
                prefixIcon: Icon(Icons.description, color: Color(0xFFFF8C00)),
              ),
              maxLines: 3,
            ),
            const SizedBox(height: 16),

            // Barcode
            TextFormField(
              controller: _barcodeController,
              decoration: const InputDecoration(
                labelText: 'Barcode',
                border: OutlineInputBorder(),
                prefixIcon:
                    Icon(Icons.barcode_reader, color: Color(0xFFFF8C00)),
              ),
            ),
            const SizedBox(height: 16),

            // Product Image
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        const Icon(Icons.image, color: Color(0xFFFF8C00)),
                        const SizedBox(width: 8),
                        const Text(
                          'Product Image',
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                        const Spacer(),
                        if (_imageUrl != null)
                          TextButton.icon(
                            onPressed: _removeImage,
                            icon: const Icon(Icons.delete, size: 16),
                            label: const Text('Remove'),
                            style: TextButton.styleFrom(
                              foregroundColor: Colors.red,
                            ),
                          ),
                      ],
                    ),
                    const SizedBox(height: 12),
                    if (_imageUrl != null) ...[
                      Container(
                        width: 120,
                        height: 120,
                        decoration: BoxDecoration(
                          border: Border.all(color: Colors.grey.shade300),
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: _buildImagePreview(_imageUrl),
                      ),
                      const SizedBox(height: 8),
                      if (_selectedImageName != null)
                        Text(
                          _selectedImageName!,
                          style: TextStyle(
                            color: Colors.grey.shade600,
                            fontSize: 12,
                          ),
                        ),
                    ] else ...[
                      Container(
                        width: double.infinity,
                        height: 120,
                        decoration: BoxDecoration(
                          border: Border.all(
                            color: Colors.grey.shade300,
                            width: 2,
                          ),
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: InkWell(
                          onTap: _pickImage,
                          borderRadius: BorderRadius.circular(8),
                          child: const Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(
                                Icons.cloud_upload,
                                size: 32,
                                color: Colors.grey,
                              ),
                              SizedBox(height: 8),
                              Text(
                                'Click to upload image',
                                style: TextStyle(
                                  color: Colors.grey,
                                  fontSize: 14,
                                ),
                              ),
                              Text(
                                'PNG, JPG, GIF up to 10MB',
                                style: TextStyle(
                                  color: Colors.grey,
                                  fontSize: 12,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                    if (_imageUrl == null) ...[
                      const SizedBox(height: 12),
                      Center(
                        child: ElevatedButton.icon(
                          onPressed: _pickImage,
                          icon: const Icon(Icons.upload),
                          label: const Text('Upload Image'),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: const Color(0xFFFF8C00),
                            foregroundColor: Colors.white,
                          ),
                        ),
                      ),
                    ],
                  ],
                ),
              ),
            ),
            const SizedBox(height: 16),

            // Switches
            _buildSwitchRow('Track Stock', _trackStock, (value) {
              setState(() => _trackStock = value);
            }),
            _buildSwitchRow('Active', _active, (value) {
              setState(() => _active = value);
            }),
            _buildSwitchRow('Sold by Weight', _soldByWeight, (value) {
              setState(() => _soldByWeight = value);
            }),
            _buildSwitchRow('Use Production', _useProduction, (value) {
              setState(() => _useProduction = value);
            }),
          ],
        ),
      );
  }

  Widget _buildImagePreview(String? imageUrl) {
    if (imageUrl == null || imageUrl.isEmpty) return const Icon(Icons.broken_image);
    if (imageUrl.startsWith('data:image')) {
      try {
        final bytes = base64Decode(imageUrl.split(',').last);
        return Image.memory(bytes, fit: BoxFit.cover);
      } catch (_) {
        return const Icon(Icons.broken_image);
      }
    }
    // Local file path
    if (imageUrl.startsWith('C:') || imageUrl.startsWith('D:') || imageUrl.startsWith('E:') || imageUrl.startsWith('\\') || imageUrl.startsWith('/')) {
      return Image.file(
        File(imageUrl),
        fit: BoxFit.cover,
        errorBuilder: (context, error, stackTrace) => const Icon(Icons.broken_image),
      );
    }
    // Network
    return Image.network(
      imageUrl,
      fit: BoxFit.cover,
      errorBuilder: (context, error, stackTrace) => const Icon(Icons.broken_image),
    );
  }

  Widget _buildPricingTab() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        children: [
          // Default Price
          TextFormField(
            controller: _priceController,
            decoration: const InputDecoration(
              labelText: 'Default Price *',
              border: OutlineInputBorder(),
              prefixIcon: Icon(Icons.attach_money, color: Color(0xFFFF8C00)),
              prefixText: '\$',
            ),
            keyboardType: TextInputType.number,
            inputFormatters: [
              FilteringTextInputFormatter.allow(RegExp(r'^\d*\.?\d{0,2}')),
            ],
            validator: (value) {
              if (value == null || value.trim().isEmpty) {
                return 'Please enter a price';
              }
              if (double.tryParse(value) == null) {
                return 'Please enter a valid price';
              }
              return null;
            },
          ),
          const SizedBox(height: 16),

          // Cost
          TextFormField(
            controller: _costController,
            decoration: const InputDecoration(
              labelText: 'Cost',
              border: OutlineInputBorder(),
              prefixIcon: Icon(Icons.money_off, color: Color(0xFFFF8C00)),
              prefixText: '\$',
            ),
            keyboardType: TextInputType.number,
            inputFormatters: [
              FilteringTextInputFormatter.allow(RegExp(r'^\d*\.?\d{0,2}')),
            ],
          ),
          const SizedBox(height: 16),

          // Supplier
          TextFormField(
            controller: _supplierController,
            decoration: const InputDecoration(
              labelText: 'Supplier',
              border: OutlineInputBorder(),
              prefixIcon: Icon(Icons.local_shipping, color: Color(0xFFFF8C00)),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStoresTab() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Store Availability',
            style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 16),

          // Quick summary row with total available quantity
          Row(
            children: [
              const Icon(Icons.inventory_2, color: Color(0xFFFF8C00)),
              const SizedBox(width: 8),
              const Text('Available QTY: '),
              Text(
                _totalAvailableQty.toString(),
                style: const TextStyle(fontWeight: FontWeight.bold),
              ),
              const Spacer(),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                decoration: BoxDecoration(
                  color: Colors.orange.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Text(
                  _availableAllStores ? 'All Stores' : 'Specific Stores',
                  style: const TextStyle(color: Color(0xFFFF8C00)),
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),

          // Availability Toggle
          SwitchListTile(
            title: const Text('Available in all stores'),
            subtitle: const Text('Use default price and settings for all stores'),
            value: _availableAllStores,
            activeThumbColor: const Color(0xFFFF8C00),
            onChanged: (value) {
              setState(() {
                _availableAllStores = value;
                _storeAvailability = value ? 'all_stores' : 'specific_stores';
                if (value) {
                  // Select all stores when toggled on
                  _selectedStores = widget.stores.where((s) => s.id != null).map((s) => s.id!).toSet();
                }
              });
            },
          ),
          const SizedBox(height: 16),

          if (_storeAvailability == 'specific_stores') ...[
            const Text(
              'Select Stores and Configure Settings',
              style: TextStyle(fontSize: 14, fontWeight: FontWeight.w500),
            ),
            const SizedBox(height: 12),
            ...widget.stores.map((store) => _buildStoreSettings(store)),
          ],
        ],
      ),
    );
  }

  Widget _buildStoreSettings(Store store) {
    if (store.id == null) return const SizedBox.shrink();
    
    final isSelected = _selectedStores.contains(store.id);
    final settings = _storeSettings[store.id!] ?? {};

    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            // Store Selection
            CheckboxListTile(
              title: Text(store.name),
              subtitle: Text(store.address),
              value: isSelected,
              activeColor: const Color(0xFFFF8C00),
              onChanged: (value) {
                setState(() {
                  if (value == true && store.id != null) {
                    _selectedStores.add(store.id!);
                  } else if (store.id != null) {
                    _selectedStores.remove(store.id!);
                  }
                });
              },
            ),

            if (isSelected) ...[
              const Divider(),
              Row(
                children: [
                  Expanded(
                    child: TextFormField(
                      initialValue: settings['price']?.toString() ??
                          _priceController.text,
                      decoration: const InputDecoration(
                        labelText: 'Price',
                        prefixText: '\$',
                        border: OutlineInputBorder(),
                        isDense: true,
                      ),
                      keyboardType: TextInputType.number,
                      onChanged: (value) {
                        if (store.id != null) {
                          _storeSettings[store.id!] = {
                            ..._storeSettings[store.id!] ?? {},
                            'price': double.tryParse(value) ?? 0.0,
                          };
                        }
                      },
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: TextFormField(
                      controller: store.id != null
                          ? (_inStockControllers[store.id!] ??
                              (_inStockControllers[store.id!] = TextEditingController(
                                text: (settings['in_stock'] ?? 0).toString(),
                              )))
                          : null,
                      decoration: const InputDecoration(
                        labelText: 'In Stock',
                        border: OutlineInputBorder(),
                        isDense: true,
                      ),
                      keyboardType: TextInputType.number,
                      onChanged: (value) {
                        if (store.id != null) {
                          _storeSettings[store.id!] = {
                            ..._storeSettings[store.id!] ?? {},
                            'in_stock': int.tryParse(value) ?? 0,
                          };
                          setState(() {}); // Update total available qty
                        }
                      },
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              Row(
                children: [
                  Expanded(
                    child: TextFormField(
                      initialValue: settings['low_stock']?.toString() ?? '5',
                      decoration: const InputDecoration(
                        labelText: 'Low Stock Level',
                        border: OutlineInputBorder(),
                        isDense: true,
                      ),
                      keyboardType: TextInputType.number,
                      onChanged: (value) {
                        if (store.id != null) {
                          _storeSettings[store.id!] = {
                            ..._storeSettings[store.id!] ?? {},
                            'low_stock': int.tryParse(value) ?? 5,
                          };
                        }
                      },
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: TextFormField(
                      initialValue:
                          settings['optimal_stock']?.toString() ?? '20',
                      decoration: const InputDecoration(
                        labelText: 'Optimal Stock',
                        border: OutlineInputBorder(),
                        isDense: true,
                      ),
                      keyboardType: TextInputType.number,
                      onChanged: (value) {
                        if (store.id != null) {
                          _storeSettings[store.id!] = {
                            ..._storeSettings[store.id!] ?? {},
                            'optimal_stock': int.tryParse(value) ?? 20,
                          };
                        }
                      },
                    ),
                  ),
                ],
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _buildSwitchRow(String title, bool value, Function(bool) onChanged) {
    return Row(
      children: [
        Icon(
          value ? Icons.toggle_on : Icons.toggle_off,
          color: value ? const Color(0xFFFF8C00) : Colors.grey,
        ),
        const SizedBox(width: 8),
        Text(title),
        const Spacer(),
        Switch(
          value: value,
          onChanged: onChanged,
          activeThumbColor: const Color(0xFFFF8C00),
        ),
      ],
    );
  }

  Widget _buildActionButtons() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.end,
      children: [
        TextButton(
          onPressed: _isLoading ? null : widget.onCancel,
          child: const Text('Cancel'),
        ),
        const SizedBox(width: 12),
        ElevatedButton(
          onPressed: _isLoading ? null : _handleSubmit,
          style: ElevatedButton.styleFrom(
            backgroundColor: const Color(0xFFFF8C00),
            foregroundColor: Colors.white,
            padding: const EdgeInsets.symmetric(
              horizontal: 24,
              vertical: 12,
            ),
          ),
          child: _isLoading
              ? const SizedBox(
                  width: 16,
                  height: 16,
                  child: CircularProgressIndicator(
                    strokeWidth: 2,
                    color: Colors.white,
                  ),
                )
              : Text(
                  widget.product == null ? 'Create Product' : 'Update Product'),
        ),
      ],
    );
  }
}
