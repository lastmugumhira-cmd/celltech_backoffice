import 'package:flutter/material.dart';
import '../../services/database_service.dart';
import '../../services/pdf_service.dart';
import '../../models/store.dart';

class TransferStockDialog extends StatefulWidget {
  final VoidCallback onDone;
  const TransferStockDialog({super.key, required this.onDone});

  @override
  State<TransferStockDialog> createState() => _TransferStockDialogState();
}

class _TransferStockDialogState extends State<TransferStockDialog> {
  final TextEditingController _search = TextEditingController();
  final TextEditingController _notes = TextEditingController();
  bool _loading = false;
  bool _searching = false;
  String? _error;

  Store? _warehouse;
  List<Store> _stores = [];
  int? _fromId;
  int? _toId;

  final List<Map<String, dynamic>> _items = [];
  final List<Map<String, dynamic>> _searchResults = [];
  final Map<int, int> _destStock = {}; // productId -> qty at destination
  
  // PDF state
  bool _showPdfPrompt = false;
  Map<String, dynamic>? _lastTransferDetails;

  @override
  void initState() {
    super.initState();
    _search.addListener(_onSearchChanged);
    _loadLocations();
  }

  Future<void> _generateTransferPdf() async {
    if (_lastTransferDetails == null) return;
    
    try {
      final details = _lastTransferDetails!;
      await PdfService.generateTransferPdf(
        fromLocation: details['fromLocation'],
        toLocation: details['toLocation'],
        items: details['items'],
        notes: details['notes'],
        date: details['date'],
      );
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Failed to generate PDF: $e'), backgroundColor: Colors.red),
        );
      }
    }
  }

  void _closeDialog() {
    widget.onDone();
    Navigator.pop(context);
  }

  @override
  void dispose() {
    _search.removeListener(_onSearchChanged);
    _search.dispose();
    _notes.dispose();
    super.dispose();
  }

  void _onSearchChanged() {
    if (_search.text.trim().isNotEmpty && _fromId != null) {
      _performLiveSearch();
    } else {
      setState(() => _searchResults.clear());
    }
  }

  Future<void> _performLiveSearch() async {
    final q = _search.text.trim();
    final from = _fromId;
    if (q.isEmpty || from == null) return;
    
    setState(() => _searching = true);
    try {
      final results = await DatabaseService.searchProductsInStore(storeId: from, query: q, limit: 20);
      if (mounted && _search.text.trim() == q) { // Only update if search hasn't changed
        setState(() => _searchResults..clear()..addAll(results.where((r) => ((r['ss_stock_quantity'] as int?) ?? 0) > 0)));
      }
    } catch (e) {
      if (mounted) setState(() => _error = 'Search failed: $e');
    } finally {
      if (mounted) setState(() => _searching = false);
    }
  }

  Future<void> _loadLocations() async {
    setState(() => _loading = true);
    try {
      final wh = await DatabaseService.getMainWarehouse();
      final stores = (await DatabaseService.getStores(active: true)).where((s) => s.type == 'store').toList();
      setState(() {
        _warehouse = wh;
        _stores = stores;
        _fromId = wh?.id; // default from warehouse
      });
    } catch (e) {
      setState(() => _error = 'Failed to load locations: $e');
    } finally {
      setState(() => _loading = false);
    }
  }

  void _addProductToItems(Map<String, dynamic> product) {
    final productId = product['product_id'] as int;
    final available = (product['ss_stock_quantity'] as int?) ?? 0;
    if (available <= 0) return;
    
    if (!_items.any((e) => e['product_id'] == productId)) {
      setState(() {
        _items.add({
          'product_id': productId,
          'name': product['name'],
          'sku': product['sku'],
          'available': available,
          'quantity': 1
        });
      });
      _refreshDestStockForItems();
    }
  }

  Future<void> _refreshDestStockForItems() async {
    final to = _toId;
    if (to == null) return;
    for (final it in _items) {
      final pid = it['product_id'] as int;
      final qty = await DatabaseService.getProductStock(pid, to);
      _destStock[pid] = qty;
    }
    if (mounted) setState(() {});
  }

  Future<void> _onChangeTo(int? storeId) async {
    setState(() => _toId = storeId);
    await _refreshDestStockForItems();
  }

  Future<void> _onChangeFrom(int? storeId) async {
    setState(() {
      _fromId = storeId;
      _items.clear();
      _searchResults.clear();
    });
    if (_search.text.trim().isNotEmpty) {
      _performLiveSearch();
    }
    await _refreshDestStockForItems();
  }

  Future<void> _submit() async {
    if (_fromId == null || _toId == null) {
      setState(() => _error = 'Please select both a source and destination.');
      return;
    }
    if (_fromId == _toId) {
      setState(() => _error = 'Cannot transfer to the same location.');
      return;
    }
    final payload = _items
        .where((e) => (e['quantity'] as int) > 0)
        .map((e) => {'product_id': e['product_id'], 'quantity': e['quantity']})
        .toList();
    if (payload.isEmpty) {
      setState(() => _error = 'Please add items with a quantity greater than zero.');
      return;
    }
    setState(() { _loading = true; _error = null; });
    try {
      await DatabaseService.transferStock(
        fromStoreId: _fromId!,
        toStoreId: _toId!,
        items: payload,
        notes: _notes.text.trim().isEmpty ? null : _notes.text.trim(),
      );
      
      // Prepare transfer details for PDF
      final fromStore = _warehouse?.id == _fromId ? _warehouse : _stores.firstWhere((s) => s.id == _fromId);
      final toStore = _stores.firstWhere((s) => s.id == _toId);
      
      _lastTransferDetails = {
        'fromLocation': fromStore?.name ?? 'Unknown',
        'toLocation': toStore.name,
        'items': _items.where((e) => (e['quantity'] as int) > 0).toList(),
        'notes': _notes.text.trim(),
        'date': DateTime.now(),
      };
      
      setState(() => _showPdfPrompt = true);
    } catch (e) {
      setState(() => _error = 'Failed to transfer stock: $e');
    } finally {
      setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Dialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: Container(
        width: 900,
        constraints: const BoxConstraints(maxHeight: 700),
        padding: const EdgeInsets.all(16),
        child: _showPdfPrompt ? _buildPdfPrompt() : _buildTransferForm(),
      ),
    );
  }

  Widget _buildPdfPrompt() {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        const Icon(Icons.check_circle, color: Colors.green, size: 64),
        const SizedBox(height: 16),
        const Text('Transfer Completed Successfully!', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
        const SizedBox(height: 16),
        const Text('Would you like to download a PDF report of this transfer?', style: TextStyle(fontSize: 16)),
        const SizedBox(height: 24),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            OutlinedButton(
              onPressed: _closeDialog,
              child: const Text('No, Close'),
            ),
            const SizedBox(width: 16),
            ElevatedButton.icon(
              onPressed: () async {
                await _generateTransferPdf();
                _closeDialog();
              },
              icon: const Icon(Icons.download),
              label: const Text('Download PDF'),
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFFFF8C00),
                foregroundColor: Colors.white,
              ),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildTransferForm() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            const Text('Transfer Stock Between Locations', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
            IconButton(onPressed: () => Navigator.pop(context), icon: const Icon(Icons.close)),
          ],
        ),
            const SizedBox(height: 12),
            Row(children: [
              // From
              Expanded(
                child: InputDecorator(
                  decoration: const InputDecoration(labelText: 'From Location', border: OutlineInputBorder()),
                  child: DropdownButtonHideUnderline(
                    child: DropdownButton<int>(
                      isExpanded: true,
                      value: _fromId,
                      items: [
                        if (_warehouse != null)
                          DropdownMenuItem(value: _warehouse!.id, child: Text(_warehouse!.name)),
                        ..._stores.map((s) => DropdownMenuItem(value: s.id, child: Text(s.name))),
                      ],
                      onChanged: _onChangeFrom,
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 12),
              // To
              Expanded(
                child: InputDecorator(
                  decoration: const InputDecoration(labelText: 'To Location', border: OutlineInputBorder()),
                  child: DropdownButtonHideUnderline(
                    child: DropdownButton<int>(
                      isExpanded: true,
                      value: _toId,
                      items: _stores
                          .where((s) => s.id != _fromId) // avoid same location
                          .map((s) => DropdownMenuItem(value: s.id, child: Text(s.name)))
                          .toList(),
                      onChanged: (v) => _onChangeTo(v),
                    ),
                  ),
                ),
              ),
            ]),
            const SizedBox(height: 12),
            TextField(
              controller: _search,
              decoration: InputDecoration(
                prefixIcon: const Icon(Icons.search),
                suffixIcon: _searching ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2)) : null,
                labelText: 'Search products available in source location',
                helperText: 'Type to search and click on results to add',
              ),
            ),
            const SizedBox(height: 12),
            // Search results
            if (_searchResults.isNotEmpty) ...[
              Container(
                height: 120,
                decoration: BoxDecoration(
                  border: Border.all(color: Colors.grey.shade300),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: ListView.builder(
                  itemCount: _searchResults.length,
                  itemBuilder: (context, index) {
                    final product = _searchResults[index];
                    final available = (product['ss_stock_quantity'] as int?) ?? 0;
                    final isAdded = _items.any((e) => e['product_id'] == product['product_id']);
                    return ListTile(
                      dense: true,
                      title: Text(product['name'] ?? '', style: const TextStyle(fontSize: 14)),
                      subtitle: Text('SKU: ${product['sku'] ?? ''} | Available: $available', style: const TextStyle(fontSize: 12)),
                      trailing: isAdded 
                        ? const Icon(Icons.check, color: Colors.green) 
                        : const Icon(Icons.add, color: Colors.blue),
                      onTap: isAdded ? null : () => _addProductToItems(product),
                    );
                  },
                ),
              ),
              const SizedBox(height: 12),
            ],
            // Selected items
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Selected Items (${_items.length})', style: const TextStyle(fontWeight: FontWeight.w600)),
                  const SizedBox(height: 8),
                  Expanded(
                    child: _items.isEmpty
                        ? const Center(child: Text('No items selected\nSearch and click on products to add them'))
                  : ListView.builder(
                      itemCount: _items.length,
                      itemBuilder: (context, index) {
                        final it = _items[index];
                        final pid = it['product_id'] as int;
                        final available = it['available'] as int? ?? 0;
                        final destQty = _destStock[pid] ?? 0;
                        return Card(
                          child: Padding(
                            padding: const EdgeInsets.all(12.0),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Row(
                                  children: [
                                    Expanded(
                                      child: Column(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          Text(it['name'] ?? '', style: const TextStyle(fontWeight: FontWeight.w500, fontSize: 14)),
                                          Text('SKU: ${it['sku']}', style: TextStyle(fontSize: 12, color: Colors.grey.shade600)),
                                        ],
                                      ),
                                    ),
                                    IconButton(
                                      onPressed: () => setState(() => _items.removeAt(index)),
                                      icon: const Icon(Icons.close, color: Colors.redAccent, size: 20),
                                    ),
                                  ],
                                ),
                                const SizedBox(height: 8),
                                Row(
                                  children: [
                                    Expanded(
                                      child: Text('Available: $available  •  At destination: $destQty', style: TextStyle(fontSize: 12, color: Colors.grey.shade600)),
                                    ),
                                    SizedBox(
                                      width: 40,
                                      child: IconButton(
                                        onPressed: () => setState(() {
                                          final q = (it['quantity'] as int) - 1; it['quantity'] = q < 0 ? 0 : q;
                                        }),
                                        icon: const Icon(Icons.remove_circle_outline, size: 20),
                                      ),
                                    ),
                                    SizedBox(
                                      width: 60,
                                      child: TextFormField(
                                        initialValue: (it['quantity'] ?? 0).toString(),
                                        keyboardType: TextInputType.number,
                                        textAlign: TextAlign.center,
                                        style: const TextStyle(fontSize: 14),
                                        decoration: const InputDecoration(
                                          contentPadding: EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                                          border: OutlineInputBorder(),
                                        ),
                                        onChanged: (v) {
                                          final val = int.tryParse(v) ?? 0;
                                          it['quantity'] = val > available ? available : val;
                                        },
                                      ),
                                    ),
                                    SizedBox(
                                      width: 40,
                                      child: IconButton(
                                        onPressed: () => setState(() {
                                          final q = (it['quantity'] as int) + 1; it['quantity'] = q > available ? available : q;
                                        }),
                                        icon: const Icon(Icons.add_circle_outline, size: 20),
                                      ),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                        );
                      },
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 8),
            if (_items.isNotEmpty)
              TextField(
                controller: _notes,
                decoration: const InputDecoration(labelText: 'Transfer Notes (Optional)', border: OutlineInputBorder()),
                minLines: 2,
                maxLines: 4,
              ),
            if (_error != null) ...[
              const SizedBox(height: 8),
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(color: Colors.red.shade50, borderRadius: BorderRadius.circular(8), border: Border.all(color: Colors.red.shade200)),
                child: Row(children: [Icon(Icons.error_outline, color: Colors.red.shade600), const SizedBox(width: 8), Expanded(child: Text(_error!, style: TextStyle(color: Colors.red.shade700)))]),
              ),
            ],
            const SizedBox(height: 8),
            Row(
              children: [
                TextButton(onPressed: _loading ? null : () => Navigator.pop(context), child: const Text('Cancel')),
                const Spacer(),
                ElevatedButton.icon(
                  onPressed: _loading || _items.isEmpty || _fromId == null || _toId == null ? null : _submit,
                  icon: _loading ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white)) : const Icon(Icons.move_up),
                  label: Text('Transfer ${_items.length} Items'),
                ),
              ],
            ),
          ],
        );
      }
}
