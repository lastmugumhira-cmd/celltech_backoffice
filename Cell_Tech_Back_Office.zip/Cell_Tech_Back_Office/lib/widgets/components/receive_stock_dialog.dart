import 'package:flutter/material.dart';
import '../../services/database_service.dart';
import '../../models/product.dart';
import '../../services/pdf_service.dart';
import '../../models/category.dart';

class ReceiveStockDialog extends StatefulWidget {
  final int warehouseId;
  final VoidCallback onDone;
  const ReceiveStockDialog({super.key, required this.warehouseId, required this.onDone});

  @override
  State<ReceiveStockDialog> createState() => _ReceiveStockDialogState();
}

class _ReceiveStockDialogState extends State<ReceiveStockDialog> with SingleTickerProviderStateMixin {
  late TabController _tabController;
  final TextEditingController _search = TextEditingController();
  final TextEditingController _notes = TextEditingController();
  final List<Map<String, dynamic>> _items = [];
  final List<Map<String, dynamic>> _searchResults = [];
  bool _loading = false;
  bool _searching = false;
  String? _error;
  int? _defaultCategoryId;

  // New product form
  final TextEditingController _npName = TextEditingController();
  final TextEditingController _npSku = TextEditingController();
  final TextEditingController _npBarcode = TextEditingController();
  final TextEditingController _npDesc = TextEditingController();
  final TextEditingController _npCost = TextEditingController(text: '0');
  final TextEditingController _npPrice = TextEditingController(text: '0');
  final TextEditingController _npQty = TextEditingController(text: '1');

  // PDF state
  bool _showPdfPrompt = false;
  Map<String, dynamic>? _lastAdjustmentDetails;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
    _search.addListener(_onSearchChanged);
    _ensureDefaultCategory();
    _generateNextSku();
  }
  
  Future<void> _generateNextSku() async {
    try {
      final nextSku = await DatabaseService.generateNextSku();
      setState(() => _npSku.text = nextSku);
    } catch (e) {
      // If generation fails, leave it empty for manual entry
      print('Failed to generate SKU: $e');
    }
  }

  void _onSearchChanged() {
    if (_search.text.trim().isNotEmpty) {
      _performLiveSearch();
    } else {
      setState(() => _searchResults.clear());
    }
  }

  Future<void> _performLiveSearch() async {
    final q = _search.text.trim();
    if (q.isEmpty) return;
    
    setState(() => _searching = true);
    try {
      final results = await DatabaseService.searchProductsInStore(storeId: widget.warehouseId, query: q, limit: 20);
      if (mounted && _search.text.trim() == q) { // Only update if search hasn't changed
        setState(() => _searchResults..clear()..addAll(results));
      }
    } catch (e) {
      if (mounted) setState(() => _error = 'Search failed: $e');
    } finally {
      if (mounted) setState(() => _searching = false);
    }
  }

  Future<void> _ensureDefaultCategory() async {
    try {
      final cats = await DatabaseService.getCategories();
      if (cats.isEmpty) {
        final uncategorized = Category(name: 'Uncategorized', color: '#FF9800');
        final id = await DatabaseService.insertCategory(uncategorized);
        setState(() => _defaultCategoryId = id);
      } else {
        setState(() => _defaultCategoryId = cats.first.id);
      }
    } catch (_) {
      // Fallback: null will cause insert to fail; better set temp 1
      setState(() => _defaultCategoryId = catsSafeFirstId);
    }
  }

  int? get catsSafeFirstId => _defaultCategoryId;

  @override
  void dispose() {
    _tabController.dispose();
    _search.removeListener(_onSearchChanged);
    _search.dispose();
    _notes.dispose();
    _npName.dispose();
    _npSku.dispose();
    _npBarcode.dispose();
    _npDesc.dispose();
    _npCost.dispose();
    _npPrice.dispose();
    _npQty.dispose();
    super.dispose();
  }

  void _addProductToItems(Map<String, dynamic> product) {
    final productId = product['product_id'];
    if (!_items.any((e) => e['product_id'] == productId)) {
      setState(() {
        _items.add({
          'product_id': productId,
          'name': product['name'],
          'sku': product['sku'],
          'quantity': 1
        });
      });
    }
  }

  Future<void> _createNewProductAndAdd() async {
    final name = _npName.text.trim();
    final sku = _npSku.text.trim();
    if (name.isEmpty) {
      setState(() => _error = 'Product name is required.');
      return;
    }
    if (sku.isEmpty) {
      setState(() => _error = 'Failed to generate SKU. Please try again.');
      return;
    }
    final qty = int.tryParse(_npQty.text) ?? 1;
    final price = double.tryParse(_npPrice.text) ?? 0;
    final cost = double.tryParse(_npCost.text) ?? 0;
    setState(() { _loading = true; _error = null; });
    try {
      final product = Product(
        name: name,
        sku: sku,
        categoryId: _defaultCategoryId ?? 1,
        description: _npDesc.text.trim().isEmpty ? null : _npDesc.text.trim(),
        price: price,
        cost: cost,
        barcode: _npBarcode.text.trim().isEmpty ? null : _npBarcode.text.trim(),
        trackStock: true,
        active: true,
      );
      final id = await DatabaseService.insertProduct(product);
      setState(() {
        _items.add({'product_id': id, 'name': name, 'sku': sku, 'quantity': qty});
        _tabController.index = 0;
        _npName.clear(); _npBarcode.clear(); _npDesc.clear(); _npCost.text = '0'; _npPrice.text = '0'; _npQty.text = '1';
        _generateNextSku(); // Generate new SKU for next product
      });
    } catch (e) {
      setState(() => _error = 'Failed to create product: $e');
    } finally {
      setState(() => _loading = false);
    }
  }

  Future<void> _submitReceive() async {
    if (_items.isEmpty) {
      setState(() => _error = 'Please add items with quantity > 0.');
      return;
    }
    final payload = _items
        .where((e) => (e['quantity'] as int) > 0)
        .map((e) => {'product_id': e['product_id'], 'quantity': e['quantity']})
        .toList();
    if (payload.isEmpty) {
      setState(() => _error = 'Please add items with quantity > 0.');
      return;
    }
    setState(() { _loading = true; _error = null; });
    try {
      final adjId = await DatabaseService.receiveStock(storeId: widget.warehouseId, items: payload, notes: _notes.text.trim().isEmpty ? null : _notes.text.trim());
      final details = await DatabaseService.getStockAdjustment(adjId);
      setState(() {
        _lastAdjustmentDetails = details;
        _showPdfPrompt = true;
      });
      widget.onDone();
    } catch (e) {
      setState(() => _error = 'Failed to receive stock: $e');
    } finally {
      setState(() => _loading = false);
    }
  }

  Future<void> _downloadPdf() async {
    final details = _lastAdjustmentDetails;
    if (details == null) return;
    final data = await PdfService.generateStockAdjustmentPdf(details);
    await PdfService.downloadPdf(data, 'receipt-${details['adjustment_number']}.pdf');
    if (mounted) Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    if (_showPdfPrompt) {
      return AlertDialog(
        title: const Text('Stock Received Successfully!'),
        content: const Text('Would you like to download a PDF receipt for this transaction?'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Skip PDF')),
          ElevatedButton.icon(onPressed: _downloadPdf, icon: const Icon(Icons.download), label: const Text('Download PDF')),
        ],
      );
    }

    return Dialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: Container(
        width: 900,
        constraints: const BoxConstraints(maxHeight: 700),
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text('Receive Stock into Warehouse', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
                IconButton(onPressed: () => Navigator.pop(context), icon: const Icon(Icons.close)),
              ],
            ),
            const SizedBox(height: 12),
            TabBar(
              controller: _tabController,
              tabs: const [Tab(text: 'Existing Products'), Tab(text: 'Create New Product')],
            ),
            const SizedBox(height: 12),
            Expanded(
              child: TabBarView(
                controller: _tabController,
                children: [
                  // Existing products tab
                  Column(
                    children: [
                      TextField(
                        controller: _search,
                        decoration: InputDecoration(
                          prefixIcon: const Icon(Icons.search),
                          suffixIcon: _searching ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2)) : null,
                          labelText: 'Search by name or SKU...',
                          helperText: 'Type to search and click on results to add',
                        ),
                      ),
                      const SizedBox(height: 12),
                      // Search results
                      if (_searchResults.isNotEmpty) ...[
                        Container(
                          height: 120,
                          decoration: BoxDecoration(
                            border: Border.all(color: Colors.grey.shade300),
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: ListView.builder(
                            itemCount: _searchResults.length,
                            itemBuilder: (context, index) {
                              final product = _searchResults[index];
                              final isAdded = _items.any((e) => e['product_id'] == product['product_id']);
                              return ListTile(
                                dense: true,
                                title: Text(product['name'] ?? '', style: const TextStyle(fontSize: 14)),
                                subtitle: Text('SKU: ${product['sku'] ?? ''} | Stock: ${product['ss_stock_quantity'] ?? 0}', style: const TextStyle(fontSize: 12)),
                                trailing: isAdded 
                                  ? const Icon(Icons.check, color: Colors.green) 
                                  : const Icon(Icons.add, color: Colors.blue),
                                onTap: isAdded ? null : () => _addProductToItems(product),
                              );
                            },
                          ),
                        ),
                        const SizedBox(height: 12),
                      ],
                      // Selected items
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text('Selected Items (${_items.length})', style: const TextStyle(fontWeight: FontWeight.w600)),
                            const SizedBox(height: 8),
                            Expanded(
                              child: _items.isEmpty
                                  ? const Center(child: Text('No items added yet\nSearch and click on products to add them'))
                                  : ListView.builder(
                                      itemCount: _items.length,
                                      itemBuilder: (context, index) {
                                        final it = _items[index];
                                        return Card(
                                          child: Padding(
                                            padding: const EdgeInsets.all(8.0),
                                            child: Row(
                                              children: [
                                                Expanded(
                                                  flex: 3,
                                                  child: Column(
                                                    crossAxisAlignment: CrossAxisAlignment.start,
                                                    children: [
                                                      Text(it['name'] ?? '', style: const TextStyle(fontWeight: FontWeight.w500)),
                                                      Text('SKU: ${it['sku'] ?? ''}', style: TextStyle(fontSize: 12, color: Colors.grey.shade600)),
                                                    ],
                                                  ),
                                                ),
                                                const SizedBox(width: 8),
                                                SizedBox(
                                                  width: 40,
                                                  child: IconButton(
                                                    onPressed: () => setState(() {
                                                      final q = (it['quantity'] as int) - 1; it['quantity'] = q < 0 ? 0 : q;
                                                    }),
                                                    icon: const Icon(Icons.remove_circle_outline, size: 20),
                                                  ),
                                                ),
                                                SizedBox(
                                                  width: 60,
                                                  child: TextFormField(
                                                    initialValue: (it['quantity'] ?? 0).toString(),
                                                    keyboardType: TextInputType.number,
                                                    textAlign: TextAlign.center,
                                                    style: const TextStyle(fontSize: 14),
                                                    decoration: const InputDecoration(
                                                      contentPadding: EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                                                      border: OutlineInputBorder(),
                                                    ),
                                                    onChanged: (v) => it['quantity'] = int.tryParse(v) ?? 0,
                                                  ),
                                                ),
                                                SizedBox(
                                                  width: 40,
                                                  child: IconButton(
                                                    onPressed: () => setState(() => it['quantity'] = (it['quantity'] as int) + 1),
                                                    icon: const Icon(Icons.add_circle_outline, size: 20),
                                                  ),
                                                ),
                                                SizedBox(
                                                  width: 40,
                                                  child: IconButton(
                                                    onPressed: () => setState(() => _items.removeAt(index)),
                                                    icon: const Icon(Icons.delete_outline, size: 20, color: Colors.red),
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                        );
                                      },
                                    ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                  // Create new product tab
                  SingleChildScrollView(
                    child: Column(
                      children: [
                        Row(children: [
                          Expanded(child: _tf(_npName, 'Product Name *')),
                          const SizedBox(width: 8),
                          Expanded(child: _tf(_npSku, 'SKU (Auto-generated)', readOnly: true)),
                        ]),
                        const SizedBox(height: 8),
                        Row(children: [
                          Expanded(child: _tf(_npBarcode, 'Barcode')),
                          const SizedBox(width: 8),
                          Expanded(child: _tf(_npCost, 'Cost (0.00)', number: true)),
                        ]),
                        const SizedBox(height: 8),
                        Row(children: [
                          Expanded(child: _tf(_npPrice, 'Price (0.00)', number: true)),
                          const SizedBox(width: 8),
                          Expanded(child: _tf(_npQty, 'Initial Quantity', number: true)),
                        ]),
                        const SizedBox(height: 8),
                        _ta(_npDesc, 'Description'),
                        const SizedBox(height: 12),
                        SizedBox(
                          width: double.infinity,
                          child: ElevatedButton.icon(
                            onPressed: _loading ? null : _createNewProductAndAdd,
                            icon: const Icon(Icons.add),
                            label: const Text('Create Product & Add to Receive List'),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 8),
            _items.isNotEmpty ? _ta(_notes, 'Notes (Optional)', minLines: 2) : const SizedBox.shrink(),
            if (_error != null) ...[
              const SizedBox(height: 8),
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(color: Colors.red.shade50, borderRadius: BorderRadius.circular(8), border: Border.all(color: Colors.red.shade200)),
                child: Row(children: [Icon(Icons.error_outline, color: Colors.red.shade600), const SizedBox(width: 8), Expanded(child: Text(_error!, style: TextStyle(color: Colors.red.shade700)))]),
              ),
            ],
            const SizedBox(height: 8),
            Row(
              children: [
                TextButton(onPressed: _loading ? null : () => Navigator.pop(context), child: const Text('Cancel')),
                const Spacer(),
                ElevatedButton.icon(
                  onPressed: _loading || _items.isEmpty ? null : _submitReceive,
                  icon: _loading ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white)) : const Icon(Icons.move_down),
                  label: Text('Receive ${_items.length} Items'),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _tf(TextEditingController c, String label, {bool number = false, bool readOnly = false}) {
    return TextField(
      controller: c,
      readOnly: readOnly,
      decoration: InputDecoration(
        labelText: label, 
        border: const OutlineInputBorder(),
        filled: readOnly,
        fillColor: readOnly ? Colors.grey.shade100 : null,
        suffixIcon: readOnly ? const Icon(Icons.lock_outline, size: 16, color: Colors.grey) : null,
      ),
      keyboardType: number ? const TextInputType.numberWithOptions(decimal: true) : TextInputType.text,
    );
  }

  Widget _ta(TextEditingController c, String label, {int minLines = 3}) {
    return TextField(
      controller: c,
      decoration: InputDecoration(labelText: label, border: const OutlineInputBorder()),
      minLines: minLines,
      maxLines: 6,
    );
  }
}
