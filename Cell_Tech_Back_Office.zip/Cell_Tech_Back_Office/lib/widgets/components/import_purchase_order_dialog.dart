import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';
import 'dart:typed_data';
import 'dart:convert';
import 'package:csv/csv.dart';

class ImportPurchaseOrderDialog extends StatefulWidget {
  final Function(Uint8List fileData, String fileName) onImport;
  final VoidCallback? onCancel;

  const ImportPurchaseOrderDialog({
    super.key,
    required this.onImport,
    this.onCancel,
  });

  @override
  State<ImportPurchaseOrderDialog> createState() => _ImportPurchaseOrderDialogState();
}

class _ImportPurchaseOrderDialogState extends State<ImportPurchaseOrderDialog> {
  Uint8List? _selectedFileData;
  String? _selectedFileName;
  bool _isProcessing = false;
  List<List<dynamic>>? _previewData;
  String? _errorMessage;

  // CSV Template for download
  final List<List<dynamic>> _csvTemplate = [
    ['Product Name', 'SKU', 'Quantity', 'Unit Cost', 'Notes'],
    ['Example Product 1', 'EX001', '10', '25.99', 'Optional notes'],
    ['Example Product 2', 'EX002', '5', '49.99', ''],
  ];

  Future<void> _pickFile() async {
    try {
      setState(() {
        _isProcessing = true;
        _errorMessage = null;
      });

      FilePickerResult? result = await FilePicker.platform.pickFiles(
        type: FileType.custom,
        allowedExtensions: ['csv', 'xlsx', 'xls'],
        allowMultiple: false,
      );

      if (result != null && result.files.isNotEmpty) {
        final file = result.files.first;
        
        setState(() {
          _selectedFileData = file.bytes;
          _selectedFileName = file.name;
        });

        // Preview the file if it's CSV
        if (file.extension?.toLowerCase() == 'csv' && file.bytes != null) {
          await _previewCsvFile(file.bytes!);
        }
      }
    } catch (e) {
      setState(() {
        _errorMessage = 'Error selecting file: $e';
      });
    } finally {
      setState(() => _isProcessing = false);
    }
  }

  Future<void> _previewCsvFile(Uint8List data) async {
    try {
      final csvString = utf8.decode(data);
      final csvData = const CsvToListConverter().convert(csvString);
      
      setState(() {
        _previewData = csvData.take(5).toList(); // Preview first 5 rows
        _errorMessage = null;
      });
    } catch (e) {
      setState(() {
        _previewData = null;
        _errorMessage = 'Error reading CSV file: $e';
      });
    }
  }

  void _downloadTemplate() {
    final csvString = const ListToCsvConverter().convert(_csvTemplate);
    
    // Since we can't directly download in Flutter web without additional packages,
    // we'll show the template content in a dialog
    _showTemplateDialog(csvString);
  }

  void _showTemplateDialog(String csvContent) {
    showDialog(
      context: context,
      builder: (context) => Dialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        child: Container(
          width: 600,
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  const Icon(Icons.download, color: Color(0xFFFF8C00)),
                  const SizedBox(width: 12),
                  const Expanded(
                    child: Text(
                      'CSV Template',
                      style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                    ),
                  ),
                  IconButton(
                    onPressed: () => Navigator.of(context).pop(),
                    icon: const Icon(Icons.close),
                  ),
                ],
              ),
              const SizedBox(height: 16),
              const Text(
                'Copy the template below and save it as a .csv file:',
                style: TextStyle(fontWeight: FontWeight.w500),
              ),
              const SizedBox(height: 12),
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: Colors.grey.shade100,
                  border: Border.all(color: Colors.grey.shade300),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: SelectableText(
                  csvContent,
                  style: const TextStyle(
                    fontFamily: 'monospace',
                    fontSize: 12,
                  ),
                ),
              ),
              const SizedBox(height: 16),
              Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  ElevatedButton(
                    onPressed: () => Navigator.of(context).pop(),
                    child: const Text('Close'),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _handleImport() {
    if (_selectedFileData != null && _selectedFileName != null) {
      widget.onImport(_selectedFileData!, _selectedFileName!);
    }
  }

  void _clearSelection() {
    setState(() {
      _selectedFileData = null;
      _selectedFileName = null;
      _previewData = null;
      _errorMessage = null;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Dialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: Container(
        width: 700,
        constraints: const BoxConstraints(maxHeight: 600),
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildHeader(),
            const SizedBox(height: 24),
            _buildTemplateSection(),
            const SizedBox(height: 24),
            _buildFileUploadSection(),
            if (_previewData != null) ...[
              const SizedBox(height: 24),
              _buildPreviewSection(),
            ],
            if (_errorMessage != null) ...[
              const SizedBox(height: 16),
              _buildErrorSection(),
            ],
            const SizedBox(height: 24),
            _buildActions(),
          ],
        ),
      ),
    );
  }

  Widget _buildHeader() {
    return Row(
      children: [
        Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: const Color(0xFFFF8C00).withOpacity(0.1),
            borderRadius: BorderRadius.circular(12),
          ),
          child: const Icon(
            Icons.upload_file,
            color: Color(0xFFFF8C00),
            size: 24,
          ),
        ),
        const SizedBox(width: 16),
        const Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Import Purchase Order Items',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Text(
                'Upload CSV or Excel file to bulk add items',
                style: TextStyle(
                  color: Colors.grey,
                  fontSize: 14,
                ),
              ),
            ],
          ),
        ),
        IconButton(
          onPressed: widget.onCancel ?? () => Navigator.of(context).pop(),
          icon: const Icon(Icons.close),
        ),
      ],
    );
  }

  Widget _buildTemplateSection() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.blue.shade50,
        border: Border.all(color: Colors.blue.shade200),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Icon(Icons.info_outline, color: Colors.blue),
              const SizedBox(width: 8),
              const Expanded(
                child: Text(
                  'Download Template',
                  style: TextStyle(
                    fontWeight: FontWeight.w600,
                    fontSize: 16,
                  ),
                ),
              ),
              TextButton.icon(
                onPressed: _downloadTemplate,
                icon: const Icon(Icons.download),
                label: const Text('Get Template'),
                style: TextButton.styleFrom(
                  foregroundColor: Colors.blue,
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          const Text(
            'Use our CSV template to ensure your data is formatted correctly. The template includes required columns: Product Name, SKU, Quantity, Unit Cost, and Notes.',
            style: TextStyle(color: Colors.grey),
          ),
        ],
      ),
    );
  }

  Widget _buildFileUploadSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'Upload File',
          style: TextStyle(fontWeight: FontWeight.w600, fontSize: 16),
        ),
        const SizedBox(height: 12),
        Container(
          width: double.infinity,
          padding: const EdgeInsets.all(24),
          decoration: BoxDecoration(
            border: Border.all(
              color: _selectedFileData != null ? Colors.green : Colors.grey.shade300,
              width: 2,
              style: BorderStyle.solid,
            ),
            borderRadius: BorderRadius.circular(12),
            color: _selectedFileData != null ? Colors.green.shade50 : Colors.grey.shade50,
          ),
          child: Column(
            children: [
              Icon(
                _selectedFileData != null ? Icons.check_circle : Icons.cloud_upload,
                size: 48,
                color: _selectedFileData != null ? Colors.green : Colors.grey,
              ),
              const SizedBox(height: 16),
              if (_selectedFileData != null) ...[
                Text(
                  'File Selected: $_selectedFileName',
                  style: const TextStyle(
                    fontWeight: FontWeight.w600,
                    color: Colors.green,
                  ),
                ),
                const SizedBox(height: 8),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    TextButton(
                      onPressed: _clearSelection,
                      child: const Text('Remove'),
                    ),
                    const SizedBox(width: 16),
                    ElevatedButton(
                      onPressed: _pickFile,
                      child: const Text('Choose Different File'),
                    ),
                  ],
                ),
              ] else ...[
                const Text(
                  'Drag and drop your file here, or click to browse',
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w500,
                  ),
                ),
                const SizedBox(height: 8),
                const Text(
                  'Supports CSV, XLS, and XLSX files',
                  style: TextStyle(
                    color: Colors.grey,
                    fontSize: 14,
                  ),
                ),
                const SizedBox(height: 16),
                ElevatedButton.icon(
                  onPressed: _isProcessing ? null : _pickFile,
                  icon: _isProcessing
                      ? const SizedBox(
                          width: 16,
                          height: 16,
                          child: CircularProgressIndicator(strokeWidth: 2),
                        )
                      : const Icon(Icons.file_upload),
                  label: Text(_isProcessing ? 'Processing...' : 'Choose File'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFFFF8C00),
                    foregroundColor: Colors.white,
                  ),
                ),
              ],
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildPreviewSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'File Preview',
          style: TextStyle(fontWeight: FontWeight.w600, fontSize: 16),
        ),
        const SizedBox(height: 12),
        Container(
          width: double.infinity,
          decoration: BoxDecoration(
            border: Border.all(color: Colors.grey.shade300),
            borderRadius: BorderRadius.circular(8),
          ),
          child: SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: DataTable(
              columns: _previewData!.isNotEmpty
                  ? _previewData!.first.asMap().entries.map((entry) {
                      return DataColumn(
                        label: Text(
                          entry.value?.toString() ?? 'Column ${entry.key + 1}',
                          style: const TextStyle(fontWeight: FontWeight.bold),
                        ),
                      );
                    }).toList()
                  : [const DataColumn(label: Text('No Data'))],
              rows: _previewData!.skip(1).map((row) {
                return DataRow(
                  cells: row.asMap().entries.map((entry) {
                    return DataCell(
                      Text(entry.value?.toString() ?? ''),
                    );
                  }).toList(),
                );
              }).toList(),
            ),
          ),
        ),
        const SizedBox(height: 8),
        Text(
          'Showing first ${_previewData!.length - 1} rows',
          style: TextStyle(color: Colors.grey.shade600, fontSize: 12),
        ),
      ],
    );
  }

  Widget _buildErrorSection() {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.red.shade50,
        border: Border.all(color: Colors.red.shade200),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Row(
        children: [
          const Icon(Icons.error_outline, color: Colors.red),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              _errorMessage!,
              style: const TextStyle(color: Colors.red),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildActions() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.end,
      children: [
        TextButton(
          onPressed: widget.onCancel ?? () => Navigator.of(context).pop(),
          child: const Text('Cancel'),
        ),
        const SizedBox(width: 12),
        ElevatedButton(
          onPressed: _selectedFileData != null ? _handleImport : null,
          style: ElevatedButton.styleFrom(
            backgroundColor: const Color(0xFFFF8C00),
            foregroundColor: Colors.white,
            padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
          ),
          child: const Text('Import Items'),
        ),
      ],
    );
  }
}