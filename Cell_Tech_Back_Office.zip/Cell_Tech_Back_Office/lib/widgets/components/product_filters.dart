import 'package:flutter/material.dart';
import '../../models/category.dart';

class ProductFilters extends StatelessWidget {
  final Map<String, dynamic> filters;
  final List<Category> categories;
  final Function(Map<String, dynamic>) onFiltersChange;
  final int rowsPerPage;
  final Function(int) onRowsPerPageChange;

  const ProductFilters({
    super.key,
    required this.filters,
    required this.categories,
    required this.onFiltersChange,
    required this.rowsPerPage,
    required this.onRowsPerPageChange,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        const Icon(
          Icons.filter_list,
          color: Colors.grey,
          size: 16,
        ),
        const SizedBox(width: 12),
        // Category Filter
        _buildCategoryFilter(),
        const SizedBox(width: 16),
        // Status Filter  
        _buildStatusFilter(),
        const SizedBox(width: 16),
        // Stock Level Filter
        _buildStockLevelFilter(),
        const SizedBox(width: 16),
        // Rows Per Page Filter
        _buildRowsPerPageFilter(),
      ],
    );
  }

  Widget _buildCategoryFilter() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      decoration: BoxDecoration(
        border: Border.all(color: Colors.grey.shade300),
        borderRadius: BorderRadius.circular(6),
      ),
      child: DropdownButton<String>(
        value: filters['category'] ?? 'all',
        underline: const SizedBox(),
        isDense: true,
        items: [
          const DropdownMenuItem(
            value: 'all',
            child: Text('All Categories'),
          ),
          ...categories.map((category) => DropdownMenuItem(
                value: category.id.toString(),
                child: Text(category.name),
              )),
        ],
        onChanged: (value) {
          final newFilters = Map<String, dynamic>.from(filters);
          newFilters['category'] = value;
          onFiltersChange(newFilters);
        },
      ),
    );
  }

  Widget _buildStatusFilter() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      decoration: BoxDecoration(
        border: Border.all(color: Colors.grey.shade300),
        borderRadius: BorderRadius.circular(6),
      ),
      child: DropdownButton<String>(
        value: filters['status'] ?? 'all',
        underline: const SizedBox(),
        isDense: true,
        items: const [
          DropdownMenuItem(value: 'all', child: Text('All')),
          DropdownMenuItem(value: 'active', child: Text('Active')),
          DropdownMenuItem(value: 'inactive', child: Text('Inactive')),
        ],
        onChanged: (value) {
          final newFilters = Map<String, dynamic>.from(filters);
          newFilters['status'] = value;
          onFiltersChange(newFilters);
        },
      ),
    );
  }

  Widget _buildStockLevelFilter() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      decoration: BoxDecoration(
        border: Border.all(color: Colors.grey.shade300),
        borderRadius: BorderRadius.circular(6),
      ),
      child: DropdownButton<String>(
        value: filters['stockLevel'] ?? 'all',
        underline: const SizedBox(),
        isDense: true,
        items: const [
          DropdownMenuItem(value: 'all', child: Text('All Stock')),
          DropdownMenuItem(value: 'normal', child: Text('In Stock')),
          DropdownMenuItem(value: 'low', child: Text('Low Stock')),
          DropdownMenuItem(value: 'out', child: Text('Out of Stock')),
        ],
        onChanged: (value) {
          final newFilters = Map<String, dynamic>.from(filters);
          newFilters['stockLevel'] = value;
          onFiltersChange(newFilters);
        },
      ),
    );
  }

  Widget _buildRowsPerPageFilter() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      decoration: BoxDecoration(
        border: Border.all(color: Colors.grey.shade300),
        borderRadius: BorderRadius.circular(6),
      ),
      child: DropdownButton<int>(
        value: rowsPerPage,
        underline: const SizedBox(),
        isDense: true,
        items: const [
          DropdownMenuItem(value: 25, child: Text('25 rows')),
          DropdownMenuItem(value: 50, child: Text('50 rows')),
          DropdownMenuItem(value: 100, child: Text('100 rows')),
        ],
        onChanged: (value) {
          if (value != null) {
            onRowsPerPageChange(value);
          }
        },
      ),
    );
  }
}
