import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../main.dart';
import '../../models/product.dart';
import '../../models/store.dart';
import '../../models/stock_adjustment.dart';
import '../../models/stock_adjustment_item.dart';
import '../../services/database_service.dart';
import '../../services/pdf_service.dart';

class AdvancedStockAdjustmentDialog extends StatefulWidget {
  const AdvancedStockAdjustmentDialog({super.key});

  @override
  State<AdvancedStockAdjustmentDialog> createState() => _AdvancedStockAdjustmentDialogState();
}

class _AdvancedStockAdjustmentDialogState extends State<AdvancedStockAdjustmentDialog> {
  final _formKey = GlobalKey<FormState>();
  final _searchController = TextEditingController();
  final _notesController = TextEditingController();

  bool _loading = true;
  bool _saving = false;
  List<Store> _stores = [];
  List<Product> _products = [];
  List<Product> _filteredProducts = [];
  int? _storeId;
  String _reason = 'receive_items';

  // productId -> current stock at selected store
  final Map<int, int> _currentStock = {};

  // adjustment items: productId, name, sku, current, change, counted, cost, after
  final List<Map<String, dynamic>> _items = [];
  final Map<int, TextEditingController> _qtyControllers = {}; // typed field (change or counted)
  final Map<int, TextEditingController> _costControllers = {}; // cost if receiving

  final Map<String, Map<String, dynamic>> _reasons = const {
    'receive_items': {
      'label': 'Receive Items',
      'icon': Icons.add_circle,
      'color': Colors.green,
    },
    'loss': {
      'label': 'Loss',
      'icon': Icons.remove_circle,
      'color': Colors.red,
    },
    'damage': {
      'label': 'Damage',
      'icon': Icons.broken_image,
      'color': Colors.orange,
    },
  };

  @override
  void initState() {
    super.initState();
    _loadAll();
  }

  @override
  void dispose() {
    _searchController.dispose();
    _notesController.dispose();
    for (final c in _qtyControllers.values) {
      c.dispose();
    }
    for (final c in _costControllers.values) {
      c.dispose();
    }
    super.dispose();
  }

  Future<void> _loadAll() async {
    setState(() => _loading = true);
    try {
      final stores = await DatabaseService.getStores();
      final products = await DatabaseService.getProducts();
      setState(() {
        _stores = stores;
        _products = products;
        _filteredProducts = products;
        _loading = false;
      });
    } catch (e) {
      setState(() => _loading = false);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Failed to load data: $e')),
        );
      }
    }
  }

  Future<void> _loadInventoryForStore(int storeId) async {
    _currentStock.clear();
    try {
      final storeStock = await DatabaseService.getStoreStock(storeId);
      for (final row in storeStock) {
        final dynamic pidRaw = row['product_id'] ?? row['id'];
        final int? pid = pidRaw is int ? pidRaw : int.tryParse(pidRaw?.toString() ?? '');
        if (pid == null) continue;
        final qty = (row['ss_stock_quantity'] ?? row['stock_quantity']) as int? ??
            int.tryParse(row['ss_stock_quantity']?.toString() ?? row['stock_quantity']?.toString() ?? '0') ?? 0;
        _currentStock[pid] = qty;
      }
    } catch (_) {
      // ignore; defaults to 0
    }
  }

  void _filterProducts(String query) {
    if (query.isEmpty) {
      setState(() => _filteredProducts = _products);
    } else {
      final q = query.toLowerCase();
      setState(() {
        _filteredProducts = _products.where((p) {
          return p.name.toLowerCase().contains(q) ||
              p.sku.toLowerCase().contains(q) ||
              (p.barcode?.toLowerCase().contains(q) ?? false);
        }).toList();
      });
    }
  }

  Future<void> _addProduct(Product p) async {
    if (_items.any((it) => it['productId'] == p.id)) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Product already added')));
      return;
    }
    final current = _currentStock[p.id!] ?? 0;
  const initialChange = 0;
    final item = {
      'productId': p.id!,
      'name': p.name,
      'sku': p.sku,
      'current': current,
  'change': initialChange, // used for receive/loss/damage
      'cost': p.cost,
    };
    setState(() {
      _items.add(item);
      _qtyControllers[p.id!] = TextEditingController(text: item['change'].toString());
      if (_reason == 'receive_items') {
        _costControllers[p.id!] = TextEditingController(text: (p.cost ?? 0).toString());
      }
    });
  }

  void _removeItem(int index) {
    final removed = _items.removeAt(index);
    final pid = removed['productId'] as int;
    _qtyControllers.remove(pid)?.dispose();
    _costControllers.remove(pid)?.dispose();
    setState(() {});
  }

  int _computeAfter(Map<String, dynamic> item) {
    final current = item['current'] as int? ?? 0;
    final raw = item['change'] as int? ?? 0;
    int signed;
    if (_reason == 'receive_items') {
      signed = raw.abs();
    } else if (_reason == 'loss' || _reason == 'damage') {
      signed = -raw.abs();
    } else {
      signed = raw;
    }
    final after = current + signed;
    return after < 0 ? 0 : after;
  }

  int _computeChangeForSave(Map<String, dynamic> item) {
    final raw = item['change'] as int? ?? 0;
    if (_reason == 'loss' || _reason == 'damage') {
      // always negative for removal
      return -raw.abs();
    } else if (_reason == 'receive_items') {
      // always positive for receiving
      return raw.abs();
    }
    return raw;
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;
    if (_storeId == null) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Please select a store')));
      return;
    }
    if (_items.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Add at least one product')));
      return;
    }
    setState(() => _saving = true);
    try {
      final employee = Provider.of<AppState>(context, listen: false).currentEmployee;
      final number = await DatabaseService.getNextStockAdjustmentNumber();
      final now = DateTime.now();
      final adjustment = StockAdjustment(
        adjustmentNumber: number,
        reason: _reason,
        status: 'completed',
        storeId: _storeId,
        employeeId: employee?.id,
        notes: _notesController.text.trim().isEmpty ? null : _notesController.text.trim(),
        createdAt: now,
        completedAt: now,
      );
      final adjId = await DatabaseService.insertStockAdjustment(adjustment);

      for (final item in _items) {
        final pid = item['productId'] as int;
        final current = item['current'] as int? ?? 0;
        final change = _computeChangeForSave(item);
        final after = current + change;
        final sai = StockAdjustmentItem(
          adjustmentId: adjId,
          productId: pid,
          quantityBefore: current,
          quantityAfter: after,
          quantityChange: change,
          notes: null,
        );
        await DatabaseService.insertStockAdjustmentItem(sai);
        await DatabaseService.updateProductStock(pid, _storeId!, after);
      }

      setState(() => _saving = false);
      if (!mounted) return;

      // Prompt to download PDF
      final selected = await showDialog<String>(
        context: context,
        builder: (context) => AlertDialog(
          title: const Text('Adjustment Created'),
          content: const Text('Do you want to download a PDF receipt?'),
          actions: [
            TextButton(onPressed: () => Navigator.of(context).pop('done'), child: const Text('Done')),
            ElevatedButton(onPressed: () => Navigator.of(context).pop('download'), child: const Text('Download PDF')),
          ],
        ),
      );

      if (!mounted) return;
      if (selected == 'download') {
        try {
          final adjMap = {
            'id': adjId,
            'adjustment_number': adjustment.adjustmentNumber,
            'reason': adjustment.reason,
            'status': adjustment.status,
            'created_at': adjustment.createdAt.toIso8601String(),
            'store_id': _storeId,
            'store_name': _stores.firstWhere((s) => s.id == _storeId).name,
            'notes': adjustment.notes,
          };
          final pdf = await PdfService.generateStockAdjustmentPdf(adjMap);
          final filename = 'stock_adjustment_${adjustment.adjustmentNumber}.pdf';
          await PdfService.downloadPdf(pdf, filename);
          if (mounted) {
            ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('PDF downloaded')));
          }
        } catch (e) {
          if (mounted) {
            ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('PDF error: $e')));
          }
        }
      }

      if (mounted) Navigator.of(context).pop(true);
    } catch (e) {
      setState(() => _saving = false);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Save failed: $e')));
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Dialog(
      insetPadding: const EdgeInsets.all(24),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: SizedBox(
        width: 1000,
        child: _loading ? _buildLoading() : _buildContent(),
      ),
    );
  }

  Widget _buildLoading() {
    return Padding(
      padding: const EdgeInsets.all(24),
      child: Row(
        children: [
          const CircularProgressIndicator(),
          const SizedBox(width: 16),
          Text('Loading...', style: TextStyle(color: Colors.grey.shade700)),
        ],
      ),
    );
  }

  Widget _buildContent() {
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.all(16),
          child: Row(
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  gradient: const LinearGradient(colors: [Color(0xFFFF8C00), Color(0xFFFF6B35)]),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: const Icon(Icons.tune, color: Colors.white),
              ),
              const SizedBox(width: 12),
              const Expanded(
                child: Text('Create Stock Adjustment', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
              ),
              IconButton(onPressed: () => Navigator.of(context).pop(false), icon: const Icon(Icons.close)),
            ],
          ),
        ),
        const Divider(height: 1),
        Expanded(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Form(
              key: _formKey,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  _buildTopRow(),
                  const SizedBox(height: 16),
                  if (_storeId != null) _buildSearchBox(),
                  const SizedBox(height: 8),
                  if (_storeId != null) _buildSuggestions(),
                  const SizedBox(height: 16),
                  Expanded(child: _buildItemsTable()),
                  const SizedBox(height: 16),
                  TextFormField(
                    controller: _notesController,
                    decoration: const InputDecoration(labelText: 'Notes (optional)', border: OutlineInputBorder()),
                    maxLines: 2,
                  ),
                ],
              ),
            ),
          ),
        ),
        const Divider(height: 1),
        Padding(
          padding: const EdgeInsets.all(16),
          child: Row(
            children: [
              Expanded(
                child: TextButton(
                  onPressed: _saving ? null : () => Navigator.of(context).pop(false),
                  child: const Text('Cancel'),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                flex: 2,
                child: ElevatedButton(
                  onPressed: _saving ? null : _save,
                  style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFFFF8C00), foregroundColor: Colors.white),
                  child: _saving
                      ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                      : const Text('Create Adjustment'),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildTopRow() {
    return Wrap(
      spacing: 12,
      runSpacing: 12,
      children: [
        SizedBox(
          width: 260,
          child: DropdownButtonFormField<String>(
            initialValue: _reason,
            decoration: const InputDecoration(labelText: 'Reason *', border: OutlineInputBorder(), isDense: true),
            items: _reasons.entries.map((e) => DropdownMenuItem(
              value: e.key,
              child: Row(children: [Icon(e.value['icon'], color: e.value['color'], size: 18), const SizedBox(width: 6), Text(e.value['label'])]),
            )).toList(),
            onChanged: (v) {
              if (v == null) return;
              setState(() {
                _reason = v;
                // keep change field
              });
            },
            validator: (v) => v == null ? 'Required' : null,
          ),
        ),
        SizedBox(
          width: 280,
          child: DropdownButtonFormField<int>(
            initialValue: _storeId,
            decoration: const InputDecoration(labelText: 'Store *', border: OutlineInputBorder(), isDense: true),
            items: _stores.map((s) => DropdownMenuItem(value: s.id, child: Text(s.name))).toList(),
            onChanged: (v) async {
              setState(() => _storeId = v);
              _items.clear();
              for (final c in _qtyControllers.values) {
                c.dispose();
              }
              _qtyControllers.clear();
              for (final c in _costControllers.values) {
                c.dispose();
              }
              _costControllers.clear();
              if (v != null) {
                await _loadInventoryForStore(v);
                setState(() {});
              }
            },
            validator: (v) => v == null ? 'Required' : null,
          ),
        ),
      ],
    );
  }

  Widget _buildSearchBox() {
    return Container(
      decoration: BoxDecoration(border: Border.all(color: Colors.grey.shade300), borderRadius: BorderRadius.circular(8)),
      child: TextField(
        controller: _searchController,
        decoration: const InputDecoration(
          hintText: 'Search products...',
          prefixIcon: Icon(Icons.search, color: Color(0xFFFF8C00)),
          border: InputBorder.none,
          contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 10),
        ),
        onChanged: _filterProducts,
      ),
    );
  }

  Widget _buildSuggestions() {
    if (_searchController.text.isEmpty) return const SizedBox.shrink();
    final results = _filteredProducts.take(5).toList();
    if (results.isEmpty) return const SizedBox.shrink();
    return Container(
      margin: const EdgeInsets.only(top: 8),
      decoration: BoxDecoration(color: Colors.white, border: Border.all(color: Colors.grey.shade300), borderRadius: BorderRadius.circular(8)),
      constraints: const BoxConstraints(maxHeight: 220),
      child: ListView.builder(
        shrinkWrap: true,
        itemCount: results.length,
        itemBuilder: (context, index) {
          final p = results[index];
          final isAdded = _items.any((it) => it['productId'] == p.id);
          return ListTile(
            dense: true,
            title: Text(p.name, overflow: TextOverflow.ellipsis),
            subtitle: Text('SKU: ${p.sku}', style: TextStyle(color: Colors.grey.shade600)),
            trailing: isAdded
                ? Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                    decoration: BoxDecoration(color: Colors.green.shade100, borderRadius: BorderRadius.circular(12)),
                    child: Text('Added', style: TextStyle(color: Colors.green.shade700, fontSize: 12)),
                  )
                : null,
            onTap: () async {
              if (!isAdded) {
                await _addProduct(p);
                WidgetsBinding.instance.addPostFrameCallback((_) {
                  if (!mounted) return;
                  _searchController.clear();
                  _filterProducts('');
                });
              }
            },
          );
        },
      ),
    );
  }

  Widget _buildItemsTable() {
    if (_items.isEmpty) {
      return Container(
        height: 200,
        decoration: BoxDecoration(border: Border.all(color: Colors.grey.shade300), borderRadius: BorderRadius.circular(8)),
        child: Center(
          child: Text('No products added yet', style: TextStyle(color: Colors.grey.shade600)),
        ),
      );
    }

    return ListView.separated(
      itemCount: _items.length,
      separatorBuilder: (_, __) => const SizedBox(height: 8),
      itemBuilder: (context, index) {
        final it = _items[index];
        final pid = it['productId'] as int;
        final qtyCtrl = _qtyControllers.putIfAbsent(pid, () => TextEditingController(text: '0'));
        final costCtrl = _costControllers[pid];
        final current = it['current'] as int? ?? 0;
        return Card(
          child: Padding(
            padding: const EdgeInsets.all(12),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Expanded(
                      flex: 3,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(it['name'], style: const TextStyle(fontWeight: FontWeight.w600)),
                          Text('SKU: ${it['sku']} | In Stock: $current', style: TextStyle(color: Colors.grey.shade600, fontSize: 12)),
                        ],
                      ),
                    ),
                    IconButton(onPressed: () => _removeItem(index), icon: const Icon(Icons.delete, color: Colors.red)),
                  ],
                ),
                const SizedBox(height: 12),
                Wrap(
                  spacing: 12,
                  runSpacing: 8,
                  crossAxisAlignment: WrapCrossAlignment.center,
                  children: [
                    ...[
                      _miniLabel('In Stock'),
                      _miniValue(current.toString()),
                      _miniLabel(_reason == 'receive_items' ? 'Add Stock' : 'Remove Stock'),
                      _miniField(qtyCtrl, onChange: (v) {
                        final entered = int.tryParse(v) ?? 0;
                        if (_reason == 'receive_items') {
                          it['change'] = entered.abs();
                        } else if (_reason == 'loss' || _reason == 'damage') {
                          it['change'] = -entered.abs();
                        } else {
                          it['change'] = entered;
                        }
                        setState(() {});
                      }),
                      if (_reason == 'receive_items') ...[
                        _miniLabel('Cost'),
                        _miniField(costCtrl ?? TextEditingController(), isNumber: true, onChange: (v) {
                          it['cost'] = double.tryParse(v) ?? it['cost'] ?? 0.0;
                        }, width: 120),
                      ],
                    ],
                    _miniLabel('Stock After'),
                    _miniValue(_computeAfter(it).toString()),
                  ],
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _miniLabel(String text) => SizedBox(width: 110, child: Text(text, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w500)));
  Widget _miniValue(String text) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
        decoration: BoxDecoration(border: Border.all(color: Colors.grey.shade300), borderRadius: BorderRadius.circular(8), color: Colors.grey.shade50),
        child: Text(text, style: const TextStyle(fontSize: 13)),
      );
  Widget _miniField(TextEditingController controller, {bool isNumber = true, required void Function(String) onChange, double width = 120}) => SizedBox(
        width: width,
        child: TextField(
          controller: controller,
          keyboardType: isNumber ? TextInputType.number : TextInputType.text,
          decoration: const InputDecoration(isDense: true, border: OutlineInputBorder(), contentPadding: EdgeInsets.symmetric(horizontal: 8, vertical: 8)),
          onChanged: onChange,
        ),
      );
}
