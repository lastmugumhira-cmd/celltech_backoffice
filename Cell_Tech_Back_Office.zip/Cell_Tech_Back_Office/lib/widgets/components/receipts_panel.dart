import 'package:flutter/material.dart';
import '../../models/shift.dart';
import '../../models/receipt.dart';
import '../../models/store.dart';
import '../../models/employee.dart';
import '../../services/database_service.dart';
import '../../widgets/components/receipt_details_dialog.dart';

class ReceiptsPanel extends StatefulWidget {
  final Shift? shift;

  const ReceiptsPanel({super.key, required this.shift});

  @override
  State<ReceiptsPanel> createState() => _ReceiptsPanelState();
}

class _ReceiptsPanelState extends State<ReceiptsPanel> {
  List<Receipt> receipts = [];
  bool isLoading = true;
  String selectedFilter = 'All';
  final List<String> filterOptions = ['All', 'Sale', 'Refund'];

  @override
  void initState() {
    super.initState();
    _loadReceipts();
  }

  Future<void> _loadReceipts() async {
    if (widget.shift == null) {
      setState(() => isLoading = false);
      return;
    }

    try {
      // Generate mock receipts for current shift
      final mockReceipts = await _generateMockReceipts();
      setState(() {
        receipts = mockReceipts;
        isLoading = false;
      });
    } catch (e) {
      setState(() => isLoading = false);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Failed to load receipts: $e'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  Future<List<Receipt>> _generateMockReceipts() async {
    final stores = await DatabaseService.getStores();
    final employees = await DatabaseService.getEmployees();
    final customers = await DatabaseService.getCustomers();

    final List<Receipt> mockReceipts = [];
    final now = DateTime.now();

    for (int i = 0; i < 15; i++) {
      final isRefund = i % 7 == 0; // Every 7th receipt is a refund
      mockReceipts.add(Receipt(
        id: i + 1,
        receiptNumber: 'R${now.year}${now.month.toString().padLeft(2, '0')}${now.day.toString().padLeft(2, '0')}-${(1000 + i).toString()}',
        transactionType: isRefund ? 'refund' : 'sale',
        paymentStatus: 'completed',
        totalAmount: isRefund ? -(50.0 + (i * 10)) : (50.0 + (i * 10)),
        subtotal: isRefund ? -(45.0 + (i * 10)) : (45.0 + (i * 10)),
        discountAmount: 5.0,
        taxAmount: 0.0,
        items: [
          {
            'name': 'Sample Product ${i + 1}',
            'quantity': 1 + (i % 3),
            'price': 25.0 + (i * 5),
            'total': (1 + (i % 3)) * (25.0 + (i * 5)),
          }
        ],
        paymentMethod: ['Cash', 'Card', 'Mobile Pay'][i % 3],
        saleDate: now.subtract(Duration(hours: i ~/ 2, minutes: i * 5)),
        storeId: stores.isNotEmpty ? stores.first.id! : 1,
        employeeId: employees.isNotEmpty ? employees.first.id! : 1,
        customerId: i % 4 == 0 && customers.isNotEmpty ? customers.first.id : null,
      ));
    }

    return mockReceipts;
  }

  List<Receipt> get filteredReceipts {
    if (selectedFilter == 'All') return receipts;
    return receipts.where((receipt) => 
        receipt.transactionType.toLowerCase() == selectedFilter.toLowerCase()).toList();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'Current Shift Receipts',
                style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                  fontWeight: FontWeight.bold,
                ),
              ),
              IconButton(
                onPressed: () => Navigator.of(context).pop(),
                icon: const Icon(Icons.close),
              ),
            ],
          ),

          if (widget.shift != null) ...[
            Text(
              'Shift started: ${_formatDateTime(widget.shift!.startTime)}',
              style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                color: Colors.grey[600],
              ),
            ),
            const SizedBox(height: 8),
          ],

          // Filter chips
          SizedBox(
            height: 50,
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              itemCount: filterOptions.length,
              itemBuilder: (context, index) {
                final filter = filterOptions[index];
                final isSelected = selectedFilter == filter;
                return Padding(
                  padding: const EdgeInsets.only(right: 8),
                  child: FilterChip(
                    label: Text(filter),
                    selected: isSelected,
                    onSelected: (selected) {
                      if (selected) {
                        setState(() => selectedFilter = filter);
                      }
                    },
                  ),
                );
              },
            ),
          ),

          const SizedBox(height: 16),

          // Summary stats
          if (!isLoading) _buildSummaryStats(),

          const SizedBox(height: 16),

          // Receipts list
          Expanded(
            child: isLoading
                ? const Center(child: CircularProgressIndicator())
                : filteredReceipts.isEmpty
                    ? Center(
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(
                              Icons.receipt_long,
                              size: 64,
                              color: Colors.grey[400],
                            ),
                            const SizedBox(height: 16),
                            Text(
                              'No receipts found',
                              style: TextStyle(
                                fontSize: 16,
                                color: Colors.grey[600],
                              ),
                            ),
                          ],
                        ),
                      )
                    : ListView.builder(
                        itemCount: filteredReceipts.length,
                        itemBuilder: (context, index) {
                          final receipt = filteredReceipts[index];
                          return _buildReceiptCard(receipt);
                        },
                      ),
          ),
        ],
      ),
    );
  }

  Widget _buildSummaryStats() {
    final totalSales = receipts.where((r) => r.transactionType == 'sale')
        .fold(0.0, (sum, r) => sum + r.totalAmount);
    final totalRefunds = receipts.where((r) => r.transactionType == 'refund')
        .fold(0.0, (sum, r) => sum + r.totalAmount.abs());
    final netSales = totalSales - totalRefunds;

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            _buildStatColumn('Sales', totalSales, Colors.green),
            _buildStatColumn('Refunds', totalRefunds, Colors.red),
            _buildStatColumn('Net', netSales, netSales >= 0 ? Colors.blue : Colors.red),
          ],
        ),
      ),
    );
  }

  Widget _buildStatColumn(String label, double amount, Color color) {
    return Column(
      children: [
        Text(
          label,
          style: TextStyle(
            color: Colors.grey[600],
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 4),
        Text(
          '\$${amount.toStringAsFixed(2)}',
          style: TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.bold,
            color: color,
          ),
        ),
      ],
    );
  }

  Widget _buildReceiptCard(Receipt receipt) {
    final isRefund = receipt.transactionType == 'refund';
    
    return Card(
      margin: const EdgeInsets.only(bottom: 8),
      child: ListTile(
        leading: CircleAvatar(
          backgroundColor: isRefund ? Colors.red : Colors.green,
          child: Icon(
            isRefund ? Icons.remove : Icons.add,
            color: Colors.white,
          ),
        ),
        title: Text(
          receipt.receiptNumber,
          style: const TextStyle(fontWeight: FontWeight.bold),
        ),
        subtitle: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(_formatDateTime(receipt.saleDate)),
            if (receipt.customerId != null)
              Text('Customer ID: ${receipt.customerId}'),
            Text('Payment: ${receipt.paymentMethod}'),
          ],
        ),
        trailing: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            Text(
              '\$${receipt.totalAmount.abs().toStringAsFixed(2)}',
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.bold,
                color: isRefund ? Colors.red : Colors.green,
              ),
            ),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
              decoration: BoxDecoration(
                color: isRefund ? Colors.red[100] : Colors.green[100],
                borderRadius: BorderRadius.circular(12),
              ),
              child: Text(
                isRefund ? 'REFUND' : 'SALE',
                style: TextStyle(
                  fontSize: 10,
                  fontWeight: FontWeight.bold,
                  color: isRefund ? Colors.red[800] : Colors.green[800],
                ),
              ),
            ),
          ],
        ),
        onTap: () => _showReceiptDetails(receipt),
      ),
    );
  }

  void _showReceiptDetails(Receipt receipt) async {
    final stores = await DatabaseService.getStores();
    final employees = await DatabaseService.getEmployees();
    
    // Find the store and employee for this receipt
    final store = stores.firstWhere(
      (s) => s.id == receipt.storeId,
      orElse: () => Store(id: receipt.storeId, name: 'Unknown Store', address: '', phone: ''),
    );
    final employee = employees.firstWhere(
      (e) => e.id == receipt.employeeId,
      orElse: () => Employee(
        id: receipt.employeeId, 
        name: 'Unknown Employee', 
        role: 'Cashier', 
        pin: '', 
        email: '', 
        phone: '', 
        username: 'unknown', 
        passwordHash: '',
      ),
    );
    
    if (!mounted) return;
    
    showDialog(
      context: context,
      builder: (context) => ReceiptDetailsDialog(
        receipt: receipt.toMap(),
        store: store,
        employee: employee,
      ),
    );
  }

  String _formatDateTime(DateTime dateTime) {
    return '${dateTime.hour.toString().padLeft(2, '0')}:${dateTime.minute.toString().padLeft(2, '0')} - ${dateTime.day}/${dateTime.month}/${dateTime.year}';
  }
}