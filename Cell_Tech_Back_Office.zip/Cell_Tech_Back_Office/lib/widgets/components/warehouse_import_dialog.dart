import 'dart:io';
import 'package:csv/csv.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import '../../models/category.dart';
import '../../models/product.dart';
import '../../models/store.dart';
import '../../services/database_service.dart';

enum _WIStatus { idle, uploading, extracting, processing, saving, success, error }

class WarehouseImportDialog extends StatefulWidget {
  final List<Store> stores; // pass only retail stores (not warehouse)
  final VoidCallback onComplete;

  const WarehouseImportDialog({super.key, required this.stores, required this.onComplete});

  @override
  State<WarehouseImportDialog> createState() => _WarehouseImportDialogState();
}

class _WarehouseImportDialogState extends State<WarehouseImportDialog> {
  _WIStatus _status = _WIStatus.idle;
  String? _selectedFilePath;
  String? _selectedFileName;
  String? _error;
  double _progress = 0.0;
  int _processed = 0;
  int _total = 0;

  Future<void> _pickFile() async {
    try {
      final res = await FilePicker.platform.pickFiles(type: FileType.custom, allowedExtensions: ['csv']);
      if (res != null) {
        setState(() {
          _selectedFilePath = res.files.single.path;
          _selectedFileName = res.files.single.name;
          _error = null;
        });
      }
    } catch (e) {
      setState(() => _error = 'Error selecting file: $e');
    }
  }

  Future<void> _import() async {
    if (_selectedFilePath == null) return;
    try {
      setState(() { _status = _WIStatus.uploading; _progress = 0.1; _error = null; });
      final file = File(_selectedFilePath!);
      final content = await file.readAsString();

      // Detect delimiter: prefer tab if present in header, else comma
      setState(() { _status = _WIStatus.extracting; _progress = 0.2; });
      final firstLine = content.split(RegExp(r'\r?\n')).firstWhere((l) => l.trim().isNotEmpty, orElse: () => '');
      final delimiter = firstLine.contains('\t') ? '\t' : ',';

      final converter = CsvToListConverter(fieldDelimiter: delimiter, eol: '\n', shouldParseNumbers: false);
      final rows = converter.convert(content).where((r) => r.isNotEmpty && r.any((c) => (c?.toString().trim() ?? '').isNotEmpty)).toList();
      if (rows.isEmpty) throw Exception('CSV is empty');

      final headers = rows.first.map((e) => e.toString().trim()).toList();
      final data = rows.skip(1).toList();

      setState(() { _status = _WIStatus.processing; _progress = 0.3; _total = data.length; });

      // Ensure categories exist
      final existingCats = await DatabaseService.getCategories();
      final catByName = { for (final c in existingCats) c.name: c };
      final catNameIdx = headers.indexWhere((h) => h.toLowerCase() == 'category');
      final categoryNames = <String>{};
      for (final row in data) {
        if (catNameIdx >= 0 && row.length > catNameIdx) {
          final name = row[catNameIdx]?.toString().trim() ?? '';
          if (name.isNotEmpty) categoryNames.add(name);
        }
      }
      for (final cname in categoryNames) {
        if (!catByName.containsKey(cname)) {
          final id = await DatabaseService.insertCategory(Category(name: cname, color: '#FF9800', description: 'Auto-created during import'));
          catByName[cname] = Category(id: id, name: cname, color: '#FF9800', description: 'Auto-created during import');
        }
      }

      // Get all warehouses for stock data
      final warehouses = await DatabaseService.getWarehouses();

      // Column helpers
      int idxOf(String name) => headers.indexWhere((h) => h.toLowerCase() == name.toLowerCase());
      String? getVal(List row, String name) {
        final i = idxOf(name); if (i < 0 || i >= row.length) return null; return row[i]?.toString();
      }

      setState(() { _status = _WIStatus.saving; _progress = 0.4; _processed = 0; });

      for (int i = 0; i < data.length; i++) {
        final row = data[i];
        try {
          final name = getVal(row, 'Name')?.trim() ?? '';
          if (name.isEmpty) { setState(() { _processed = i + 1; _progress = 0.4 + 0.5 * (i + 1) / data.length; }); continue; }
          final sku = (getVal(row, 'SKU') ?? 'SKU-${DateTime.now().millisecondsSinceEpoch + i}').trim();
          final categoryName = getVal(row, 'Category')?.trim() ?? '';
          final categoryId = catByName[categoryName]?.id ?? 0;
          final description = getVal(row, 'Description')?.trim();
          final price = double.tryParse(getVal(row, 'Default price') ?? getVal(row, 'Price') ?? '0') ?? 0.0;
          final cost = double.tryParse(getVal(row, 'Purchase cost') ?? getVal(row, 'Cost') ?? '0') ?? 0.0;
          final barcode = getVal(row, 'Barcode')?.trim();
          final handle = getVal(row, 'Handle')?.trim();
          final soldByWeight = (getVal(row, 'Sold by weight') ?? '').toUpperCase() == 'Y';

          final product = Product(
            name: name,
            sku: sku,
            categoryId: categoryId,
            description: description,
            price: price,
            cost: cost,
            barcode: barcode,
            handle: handle,
            soldByWeight: soldByWeight,
            trackStock: true,
            active: true,
          );

          // Build store stock map
          final Map<String, dynamic> storeStockData = {};
          
          // Add all warehouses with default 0 stock
          for (final warehouse in warehouses) {
            storeStockData[warehouse.id.toString()] = { 'in_stock': 0, 'low_stock': 0 };
          }
          for (final s in widget.stores) {
            final availableKey = 'Available for sale [${s.name}]';
            final stockKey = 'In stock [${s.name}]';
            final lowKey = 'Low stock [${s.name}]';
            final available = (headers.contains(availableKey) ? (row[headers.indexOf(availableKey)]?.toString().toUpperCase() == 'Y') : true);
            final qty = headers.contains(stockKey) ? int.tryParse(row[headers.indexOf(stockKey)]?.toString() ?? '0') ?? 0 : 0;
            final low = headers.contains(lowKey) ? int.tryParse(row[headers.indexOf(lowKey)]?.toString() ?? '5') ?? 5 : 5;
            storeStockData[s.id.toString()] = { 'in_stock': available ? qty : 0, 'low_stock': low };
          }

          await DatabaseService.insertProduct(product, storeStockData: storeStockData);

          setState(() { _processed = i + 1; _progress = 0.4 + 0.5 * (i + 1) / data.length; });
        } catch (e) {
          // continue with next row
          setState(() { _processed = i + 1; _progress = 0.4 + 0.5 * (i + 1) / data.length; });
        }
      }

      setState(() { _status = _WIStatus.success; _progress = 1.0; });
    } catch (e) {
      setState(() { _status = _WIStatus.error; _error = e.toString(); });
    }
  }

  void _showTemplate() {
    final headers = [
      'Handle','SKU','Name','Category','Description','Sold by weight','Default price','Cost','Barcode','Purchase cost'
    ];
    for (final s in widget.stores) {
      headers.addAll([
        'Available for sale [${s.name}]',
        'In stock [${s.name}]',
        'Low stock [${s.name}]',
      ]);
    }
    final sample = [
      'sample-handle','TS-001','Sample T-Shirt','Clothing','Cotton tee','N','19.99','5.50','1234567890','5.50'
    ];
    for (final _ in widget.stores) { sample.addAll(['Y','10','5']); }

    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('CSV Template'),
        content: SizedBox(
          width: 700,
          height: 400,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('Copy the template below and save as .csv (tab or comma separated supported):', style: TextStyle(fontWeight: FontWeight.w600)),
              const SizedBox(height: 12),
              Expanded(
                child: SingleChildScrollView(
                  child: Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(color: Colors.grey.shade100, borderRadius: BorderRadius.circular(8), border: Border.all(color: Colors.grey.shade300)),
                    child: SelectableText([
                      headers.join('\t'),
                      sample.join('\t'),
                    ].join('\n'), style: const TextStyle(fontFamily: 'monospace', fontSize: 11)),
                  ),
                ),
              ),
            ],
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Close')),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Dialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: Container(
        width: 620,
        constraints: const BoxConstraints(maxHeight: 700),
        padding: const EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text('Import Inventory from CSV', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w700)),
                IconButton(onPressed: () => Navigator.pop(context), icon: const Icon(Icons.close)),
              ],
            ),
            const SizedBox(height: 16),
            Expanded(child: _buildBody()),
          ],
        ),
      ),
    );
  }

  Widget _buildBody() {
    switch (_status) {
      case _WIStatus.idle:
        return _idle();
      case _WIStatus.uploading:
      case _WIStatus.extracting:
      case _WIStatus.processing:
      case _WIStatus.saving:
        return _progressView();
      case _WIStatus.success:
        return _successView();
      case _WIStatus.error:
        return _errorView();
    }
  }

  Widget _idle() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Expanded(
          child: Container(
            width: double.infinity,
            decoration: BoxDecoration(
              border: Border.all(color: _selectedFilePath != null ? const Color(0xFF2563EB) : Colors.grey.shade300, width: 2),
              borderRadius: BorderRadius.circular(12),
              color: _selectedFilePath != null ? const Color(0xFF2563EB).withOpacity(0.05) : Colors.grey.shade50,
            ),
            child: InkWell(
              onTap: _pickFile,
              borderRadius: BorderRadius.circular(12),
              child: Center(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(_selectedFilePath != null ? Icons.check_circle : Icons.cloud_upload_outlined, size: 56, color: _selectedFilePath != null ? const Color(0xFF2563EB) : Colors.grey.shade400),
                    const SizedBox(height: 12),
                    Text(_selectedFilePath != null ? 'File Ready to Import' : 'Drop your CSV here or click to browse', style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
                    const SizedBox(height: 6),
                    Text(_selectedFileName ?? 'Only .csv files are supported', style: TextStyle(color: Colors.grey.shade600)),
                  ],
                ),
              ),
            ),
          ),
        ),
        if (_error != null) ...[
          const SizedBox(height: 12),
          _errorBanner(_error!),
        ],
        const SizedBox(height: 12),
        Row(
          children: [
            Expanded(
              child: OutlinedButton.icon(
                onPressed: _showTemplate,
                icon: const Icon(Icons.download_outlined),
                label: const Text('Download Template'),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: ElevatedButton.icon(
                onPressed: _selectedFilePath != null ? _import : null,
                icon: const Icon(Icons.upload),
                label: const Text('Import Products'),
              ),
            ),
          ],
        ),
      ],
    );
  }

  Widget _progressView() {
    String label;
    switch (_status) {
      case _WIStatus.uploading: label = 'Reading CSV file...'; break;
      case _WIStatus.extracting: label = 'Validating structure...'; break;
      case _WIStatus.processing: label = 'Preparing categories...'; break;
      case _WIStatus.saving: label = 'Importing products ($_processed/$_total)...'; break;
      default: label = 'Processing...';
    }
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        LinearProgressIndicator(value: _progress.clamp(0, 1)),
        const SizedBox(height: 12),
        Center(child: Text(label)),
      ],
    );
  }

  Widget _successView() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        const Icon(Icons.check_circle, color: Colors.green, size: 64),
        const SizedBox(height: 8),
        const Text('Import completed successfully!', textAlign: TextAlign.center, style: TextStyle(fontWeight: FontWeight.w600)),
        const SizedBox(height: 16),
        Row(
          children: [
            Expanded(child: OutlinedButton(onPressed: () => Navigator.pop(context), child: const Text('Close'))),
            const SizedBox(width: 12),
            Expanded(child: ElevatedButton(onPressed: () { widget.onComplete(); Navigator.pop(context); }, child: const Text('Refresh'))),
          ],
        )
      ],
    );
  }

  Widget _errorView() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        _errorBanner(_error ?? 'Unknown error'),
        const SizedBox(height: 12),
        Row(
          children: [
            Expanded(child: OutlinedButton(onPressed: () => Navigator.pop(context), child: const Text('Close'))),
            const SizedBox(width: 12),
            Expanded(child: ElevatedButton(onPressed: () => setState(() { _status = _WIStatus.idle; _error = null; }), child: const Text('Try Again'))),
          ],
        )
      ],
    );
  }

  Widget _errorBanner(String msg) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(color: Colors.red.shade50, border: Border.all(color: Colors.red.shade200), borderRadius: BorderRadius.circular(8)),
      child: Row(children: [
        Icon(Icons.error_outline, color: Colors.red.shade600),
        const SizedBox(width: 8),
        Expanded(child: Text(msg, style: TextStyle(color: Colors.red.shade700))),
      ]),
    );
  }
}
