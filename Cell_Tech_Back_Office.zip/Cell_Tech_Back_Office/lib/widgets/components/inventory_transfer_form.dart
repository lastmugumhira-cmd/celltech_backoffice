import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../../services/database_service.dart';
import '../../models/product.dart';
import '../../models/store.dart';

class InventoryTransferForm extends StatefulWidget {
  final Function(Map<String, dynamic>) onTransfer;
  final VoidCallback? onCancel;

  const InventoryTransferForm({
    super.key,
    required this.onTransfer,
    this.onCancel,
  });

  @override
  State<InventoryTransferForm> createState() => _InventoryTransferFormState();
}

class _InventoryTransferFormState extends State<InventoryTransferForm> {
  final _formKey = GlobalKey<FormState>();
  final _quantityController = TextEditingController();
  final _reasonController = TextEditingController();
  final _searchController = TextEditingController();

  Product? _selectedProduct;
  String? _fromLocation;
  String? _toLocation;
  List<Store> _stores = [];
  List<Store> _warehouses = [];
  List<Product> _products = [];
  List<Product> _filteredProducts = [];
  bool _isLoading = true;
  int _availableStock = 0;

  @override
  void initState() {
    super.initState();
    _loadData();
    _searchController.addListener(_filterProducts);
  }

  @override
  void dispose() {
    _quantityController.dispose();
    _reasonController.dispose();
    _searchController.dispose();
    super.dispose();
  }

  Future<void> _loadData() async {
    try {
      final stores = await DatabaseService.getStores();
      final warehouses = await DatabaseService.getWarehouses();
      final products = await DatabaseService.getProducts();
      
      setState(() {
        _stores = stores;
        _warehouses = warehouses;
        _products = products;
        _filteredProducts = products;
        _isLoading = false;
        // Set default from location to first warehouse if available
        if (_fromLocation == null && warehouses.isNotEmpty) {
          _fromLocation = 'warehouse_${warehouses.first.id}';
        }
      });
    } catch (e) {
      setState(() => _isLoading = false);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error loading data: $e')),
        );
      }
    }
  }

  void _filterProducts() {
    final query = _searchController.text.toLowerCase();
    setState(() {
      _filteredProducts = _products.where((product) {
        return product.name.toLowerCase().contains(query) ||
               product.sku.toLowerCase().contains(query);
      }).toList();
    });
  }

  Future<void> _loadAvailableStock() async {
    if (_selectedProduct == null || _selectedProduct!.id == null || _fromLocation == null) return;

    try {
      int stock = 0;
      if (_fromLocation == 'warehouse') {
        stock = await DatabaseService.getProductStock(_selectedProduct!.id!, null);
      } else {
        final storeId = int.parse(_fromLocation!);
        stock = await DatabaseService.getProductStock(_selectedProduct!.id!, storeId);
      }
      
      setState(() => _availableStock = stock);
    } catch (e) {
      setState(() => _availableStock = 0);
    }
  }

  void _handleSubmit() {
    if (!_formKey.currentState!.validate()) return;

    final quantity = int.parse(_quantityController.text);
    
    if (quantity > _availableStock) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Cannot transfer $quantity units. Only $_availableStock available.'),
          backgroundColor: Colors.red,
        ),
      );
      return;
    }

    final transferData = {
      'product': _selectedProduct!,
      'fromLocation': _fromLocation,
      'toLocation': _toLocation,
      'quantity': quantity,
      'reason': _reasonController.text.trim(),
      'availableStock': _availableStock,
    };

    widget.onTransfer(transferData);
  }

  @override
  Widget build(BuildContext context) {
    return Dialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: Container(
        width: 600,
        constraints: const BoxConstraints(maxHeight: 700),
        padding: const EdgeInsets.all(24),
        child: _isLoading
            ? const Center(child: CircularProgressIndicator())
            : Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _buildHeader(),
                  const SizedBox(height: 24),
                  Expanded(
                    child: Form(
                      key: _formKey,
                      child: SingleChildScrollView(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            _buildProductSelection(),
                            const SizedBox(height: 20),
                            _buildLocationSelection(),
                            const SizedBox(height: 20),
                            _buildQuantityInput(),
                            const SizedBox(height: 20),
                            _buildReasonInput(),
                            if (_selectedProduct != null) ...[
                              const SizedBox(height: 20),
                              _buildStockInfo(),
                            ],
                          ],
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 24),
                  _buildActions(),
                ],
              ),
      ),
    );
  }

  Widget _buildHeader() {
    return Row(
      children: [
        Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: const Color(0xFFFF8C00).withOpacity(0.1),
            borderRadius: BorderRadius.circular(12),
          ),
          child: const Icon(
            Icons.swap_horiz,
            color: Color(0xFFFF8C00),
            size: 24,
          ),
        ),
        const SizedBox(width: 16),
        const Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Transfer Inventory',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Text(
                'Move stock between locations',
                style: TextStyle(
                  color: Colors.grey,
                  fontSize: 14,
                ),
              ),
            ],
          ),
        ),
        IconButton(
          onPressed: widget.onCancel ?? () => Navigator.of(context).pop(),
          icon: const Icon(Icons.close),
        ),
      ],
    );
  }

  Widget _buildProductSelection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'Product *',
          style: TextStyle(fontWeight: FontWeight.w600, fontSize: 16),
        ),
        const SizedBox(height: 8),
        TextFormField(
          controller: _searchController,
          decoration: InputDecoration(
            hintText: 'Search products by name or SKU...',
            prefixIcon: const Icon(Icons.search),
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
            suffixIcon: _searchController.text.isNotEmpty
                ? IconButton(
                    icon: const Icon(Icons.clear),
                    onPressed: () {
                      _searchController.clear();
                      setState(() => _selectedProduct = null);
                    },
                  )
                : null,
          ),
        ),
        if (_filteredProducts.isNotEmpty && _searchController.text.isNotEmpty)
          Container(
            margin: const EdgeInsets.only(top: 8),
            constraints: const BoxConstraints(maxHeight: 200),
            decoration: BoxDecoration(
              border: Border.all(color: Colors.grey.shade300),
              borderRadius: BorderRadius.circular(12),
            ),
            child: ListView.builder(
              shrinkWrap: true,
              itemCount: _filteredProducts.length,
              itemBuilder: (context, index) {
                final product = _filteredProducts[index];
                return ListTile(
                  title: Text(product.name),
                  subtitle: Text('SKU: ${product.sku}'),
                  onTap: () {
                    setState(() {
                      _selectedProduct = product;
                      _searchController.text = '${product.name} (${product.sku})';
                    });
                    _loadAvailableStock();
                  },
                );
              },
            ),
          ),
        if (_selectedProduct != null)
          Container(
            margin: const EdgeInsets.only(top: 8),
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: Colors.green.shade50,
              border: Border.all(color: Colors.green.shade200),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Row(
              children: [
                const Icon(Icons.check_circle, color: Colors.green, size: 20),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    'Selected: ${_selectedProduct!.name} (${_selectedProduct!.sku})',
                    style: const TextStyle(fontWeight: FontWeight.w500),
                  ),
                ),
              ],
            ),
          ),
      ],
    );
  }

  Widget _buildLocationSelection() {
    return Row(
      children: [
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'From Location *',
                style: TextStyle(fontWeight: FontWeight.w600, fontSize: 16),
              ),
              const SizedBox(height: 8),
              DropdownButtonFormField<String>(
                initialValue: _fromLocation,
                decoration: InputDecoration(
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                ),
                validator: (value) => value == null ? 'Please select from location' : null,
                onChanged: (value) {
                  setState(() {
                    _fromLocation = value;
                    if (value == _toLocation) _toLocation = null;
                  });
                  _loadAvailableStock();
                },
                items: [
                  ..._warehouses.map(
                    (warehouse) => DropdownMenuItem(
                      value: 'warehouse_${warehouse.id}',
                      child: Text('${warehouse.name} (Warehouse)'),
                    ),
                  ),
                  ..._stores.map(
                    (store) => DropdownMenuItem(
                      value: store.id.toString(),
                      child: Text('${store.name} (Store)'),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
        const SizedBox(width: 16),
        Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: const Color(0xFFFF8C00).withOpacity(0.1),
            borderRadius: BorderRadius.circular(50),
          ),
          child: const Icon(
            Icons.arrow_forward,
            color: Color(0xFFFF8C00),
          ),
        ),
        const SizedBox(width: 16),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'To Location *',
                style: TextStyle(fontWeight: FontWeight.w600, fontSize: 16),
              ),
              const SizedBox(height: 8),
              DropdownButtonFormField<String>(
                initialValue: _toLocation,
                decoration: InputDecoration(
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                ),
                validator: (value) => value == null ? 'Please select to location' : null,
                onChanged: (value) => setState(() => _toLocation = value),
                items: [
                  ..._warehouses.where((warehouse) => 'warehouse_${warehouse.id}' != _fromLocation).map(
                    (warehouse) => DropdownMenuItem(
                      value: 'warehouse_${warehouse.id}',
                      child: Text('${warehouse.name} (Warehouse)'),
                    ),
                  ),
                  ..._stores.where((store) => store.id.toString() != _fromLocation).map(
                    (store) => DropdownMenuItem(
                      value: store.id.toString(),
                      child: Text('${store.name} (Store)'),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildQuantityInput() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'Quantity *',
          style: TextStyle(fontWeight: FontWeight.w600, fontSize: 16),
        ),
        const SizedBox(height: 8),
        TextFormField(
          controller: _quantityController,
          keyboardType: TextInputType.number,
          inputFormatters: [FilteringTextInputFormatter.digitsOnly],
          decoration: InputDecoration(
            hintText: 'Enter quantity to transfer',
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
            suffixText: 'units',
          ),
          validator: (value) {
            if (value == null || value.isEmpty) return 'Please enter quantity';
            final quantity = int.tryParse(value);
            if (quantity == null || quantity <= 0) return 'Please enter a valid quantity';
            if (quantity > _availableStock) return 'Insufficient stock available';
            return null;
          },
        ),
      ],
    );
  }

  Widget _buildReasonInput() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'Reason/Notes',
          style: TextStyle(fontWeight: FontWeight.w600, fontSize: 16),
        ),
        const SizedBox(height: 8),
        TextFormField(
          controller: _reasonController,
          maxLines: 3,
          decoration: InputDecoration(
            hintText: 'Enter reason for transfer (optional)',
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
          ),
        ),
      ],
    );
  }

  Widget _buildStockInfo() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.blue.shade50,
        border: Border.all(color: Colors.blue.shade200),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        children: [
          const Icon(Icons.info_outline, color: Colors.blue),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'Available Stock',
                  style: TextStyle(fontWeight: FontWeight.w600),
                ),
                Text(
                  '$_availableStock units available at ${_getLocationName(_fromLocation)}',
                  style: TextStyle(color: Colors.grey.shade700),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  String _getLocationName(String? location) {
    if (location == null) return 'Unknown';
    
    // Check if it's a warehouse
    if (location.startsWith('warehouse_')) {
      final warehouseId = int.tryParse(location.substring(10));
      final warehouse = _warehouses.firstWhere(
        (w) => w.id == warehouseId,
        orElse: () => Store(id: 0, name: 'Unknown Warehouse', address: '', phone: ''),
      );
      return warehouse.name;
    }
    
    // Check if it's a store
    final store = _stores.firstWhere(
      (s) => s.id.toString() == location,
      orElse: () => Store(id: 0, name: 'Unknown Store', address: '', phone: ''),
    );
    return store.name;
  }

  Widget _buildActions() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.end,
      children: [
        TextButton(
          onPressed: widget.onCancel ?? () => Navigator.of(context).pop(),
          child: const Text('Cancel'),
        ),
        const SizedBox(width: 12),
        ElevatedButton(
          onPressed: _selectedProduct != null && _fromLocation != null && _toLocation != null
              ? _handleSubmit
              : null,
          style: ElevatedButton.styleFrom(
            backgroundColor: const Color(0xFFFF8C00),
            foregroundColor: Colors.white,
            padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
          ),
          child: const Text('Transfer Stock'),
        ),
      ],
    );
  }
}