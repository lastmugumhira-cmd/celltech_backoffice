import 'package:flutter/material.dart';
import '../../services/database_service.dart';
import '../../services/pdf_service.dart';
import '../../models/store.dart';

class InventoryCountForm extends StatefulWidget {
  final Map<String, dynamic>? existingCount;
  final VoidCallback onSuccess;
  final VoidCallback onCancel;
  const InventoryCountForm({super.key, this.existingCount, required this.onSuccess, required this.onCancel});

  @override
  State<InventoryCountForm> createState() => _InventoryCountFormState();
}

class _InventoryCountFormState extends State<InventoryCountForm> {
  final _formKey = GlobalKey<FormState>();
  List<Store> _stores = [];
  List<Map<String, dynamic>> _items = [];
  int? _storeId;
  String _notes = '';
  bool _loading = true;
  String _countType = 'full_count'; // 'full_count' | 'partial_count'
  final _searchCtrl = TextEditingController();
  int? _draftCountId; // created header id for new counts to avoid re-creating
  String? _draftCountNumber;
  List<Map<String, dynamic>> _searchResults = [];
  bool _searchLoading = false;
  bool _isReadOnly = false; // Track if the count is completed and should be read-only
  String? _currentStatus;

  @override
  void initState() {
    super.initState();
    _searchCtrl.addListener(_onSearchChanged);
    _load();
  }

  @override
  void dispose() {
    _searchCtrl.removeListener(_onSearchChanged);
    _searchCtrl.dispose();
    super.dispose();
  }

  void _onSearchChanged() {
    if (_searchCtrl.text.trim().isEmpty) {
      setState(() {
        _searchResults.clear();
      });
      return;
    }
    _performLiveSearch();
  }

  Future<void> _performLiveSearch() async {
    if (_storeId == null) return;
    
    final query = _searchCtrl.text.trim();
    if (query.isEmpty) {
      setState(() {
        _searchResults.clear();
      });
      return;
    }

    setState(() {
      _searchLoading = true;
    });

    try {
      final results = await DatabaseService.searchProductsInStore(
        storeId: _storeId!,
        query: query,
        limit: 10,
      );
      
      // Filter out products already in the count
      final filteredResults = results.where((product) {
        final productId = product['product_id'] as int;
        return !_items.any((item) => item['product_id'] == productId);
      }).toList();

      setState(() {
        _searchResults = filteredResults;
        _searchLoading = false;
      });
    } catch (e) {
      setState(() {
        _searchResults.clear();
        _searchLoading = false;
      });
    }
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    try {
      print('DEBUG: Starting to load inventory count form...');
      
      // Load stores first with individual error handling
      try {
        print('DEBUG: About to call DatabaseService.getStores()...');
        final stores = await DatabaseService.getStores();
        _stores = stores;
        print('DEBUG: Loaded ${stores.length} stores successfully');
      } catch (e) {
        print('DEBUG: Error loading stores: $e');
        print('DEBUG: Error type: ${e.runtimeType}');
        rethrow;
      }
      
      if (widget.existingCount != null) {
        try {
          print('DEBUG: Loading existing count with ID: ${widget.existingCount!['id']}');
          final c = await DatabaseService.getInventoryCount(widget.existingCount!['id'] as int);
          if (c != null) {
            _storeId = c['store_id'] as int?;
            _notes = c['notes']?.toString() ?? '';
            _countType = c['count_type']?.toString() ?? 'full_count';
            _currentStatus = c['status']?.toString() ?? 'in_progress';
            _isReadOnly = _currentStatus == 'completed'; // Only completed counts are read-only
            print('DEBUG: Loading existing count - Status: $_currentStatus, ReadOnly: $_isReadOnly');
            final items = (c['items'] as List).cast<Map<String, dynamic>>();
            _items = List<Map<String, dynamic>>.from(items
                .map((it) => {
                      'product_id': it['product_id'],
                      'product_name': it['product_name'],
                      'sku': it['sku'],
                      'expected': it['expected_qty'],
                      'counted': it['counted_qty'] ?? it['expected_qty'],
                    }));
            print('DEBUG: Loaded ${_items.length} items for existing count');
          } else {
            print('DEBUG: Existing count not found in database');
          }
        } catch (e) {
          print('DEBUG: Error loading existing count: $e');
          print('DEBUG: Error type: ${e.runtimeType}');
          rethrow;
        }
      } else {
        // New count - never read-only
        _currentStatus = 'in_progress';
        _isReadOnly = false;
        print('DEBUG: Creating new count - ReadOnly: $_isReadOnly');
      }
      
      print('DEBUG: Form loading completed successfully');
      setState(() => _loading = false);
    } catch (e) {
      print('DEBUG: Error loading form: $e');
      print('DEBUG: Error type: ${e.runtimeType}');
      setState(() => _loading = false);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Error loading form: $e'),
            backgroundColor: Colors.red,
            duration: const Duration(seconds: 5),
          ),
        );
      }
    }
  }

  Future<void> _saveProgress() async {
    if (_isReadOnly) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Cannot save - this count is completed and read-only')),
      );
      return;
    }
    try {
      if (widget.existingCount == null) {
        if (_storeId == null) throw 'Please select a store';
        // Create header only once per form session
        if (_draftCountId == null) {
          _draftCountNumber = await DatabaseService.getNextInventoryCountNumber();
          _draftCountId = await DatabaseService.insertInventoryCount(
            countNumber: _draftCountNumber!,
            storeId: _storeId!,
            countType: _countType,
            status: 'in_progress',
            notes: _notes.isEmpty ? null : _notes,
            startedAt: DateTime.now(),
          );
        } else {
          // Keep header updated
          await DatabaseService.updateInventoryCount(
            id: _draftCountId!,
            storeId: _storeId,
            status: 'in_progress',
            notes: _notes,
            countType: _countType,
          );
        }
        // For full count, pre-seed items with expected quantities for all products in store
        if (_countType == 'full_count') {
          final stock = await DatabaseService.getStoreStock(_storeId!);
          _items = List<Map<String, dynamic>>.from(stock
              .map((row) => {
                    'product_id': row['product_id'] as int,
                    'product_name': row['name'],
                    'sku': row['sku'],
                    'expected': (row['ss_stock_quantity'] as int?) ?? 0,
                    'counted': (row['ss_stock_quantity'] as int?) ?? 0,
                  }));
          await DatabaseService.saveInventoryCountItems(_draftCountId!, _items.map((e) => {
                'product_id': e['product_id'],
                'expected_qty': e['expected'],
                'counted_qty': e['counted'],
              }).toList());
        } else {
          // Partial: just persist current working items
          await DatabaseService.saveInventoryCountItems(_draftCountId!, _items.map((e) => {
                'product_id': e['product_id'],
                'expected_qty': e['expected'],
                'counted_qty': e['counted'],
              }).toList());
        }
      } else {
        await DatabaseService.updateInventoryCount(
          id: widget.existingCount!['id'] as int,
          storeId: _storeId,
          status: 'in_progress',
          notes: _notes,
          countType: _countType,
        );
        await DatabaseService.saveInventoryCountItems(widget.existingCount!['id'] as int, _items.map((e) => {
              'product_id': e['product_id'],
              'expected_qty': e['expected'],
              'counted_qty': e['counted'],
            }).toList());
      }
      widget.onSuccess();
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error saving: $e')),
        );
      }
    }
  }

  Future<void> _complete() async {
    if (_isReadOnly) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Cannot complete - this count is already completed')),
      );
      return;
    }
    try {
      // Ensure a header exists and persist items before completing.
      int countId;
      if (widget.existingCount == null) {
        if (_storeId == null) throw 'Please select a store';
        if (_draftCountId == null) {
          _draftCountNumber = await DatabaseService.getNextInventoryCountNumber();
          _draftCountId = await DatabaseService.insertInventoryCount(
            countNumber: _draftCountNumber!,
            storeId: _storeId!,
            countType: _countType,
            status: 'in_progress',
            notes: _notes.isEmpty ? null : _notes,
            startedAt: DateTime.now(),
          );
        } else {
          await DatabaseService.updateInventoryCount(
            id: _draftCountId!,
            status: 'in_progress',
            notes: _notes,
            countType: _countType,
          );
        }
        countId = _draftCountId!;
      } else {
        countId = widget.existingCount!['id'] as int;
        await DatabaseService.updateInventoryCount(
          id: countId,
          status: 'in_progress',
          notes: _notes,
          countType: _countType,
        );
      }
      // Persist items then complete
      await DatabaseService.saveInventoryCountItems(countId, _items.map((e) => {
            'product_id': e['product_id'],
            'expected_qty': e['expected'],
            'counted_qty': e['counted'],
          }).toList());
      await DatabaseService.completeInventoryCount(countId);
      final count = await DatabaseService.getInventoryCount(countId);
      if (count != null) {
        final pdf = await PdfService.generateInventoryCountPdf(count);
        await PdfService.downloadPdf(pdf, '${count['count_number']}.pdf');
      }
      widget.onSuccess();
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error completing: $e')),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Dialog(
      child: SizedBox(
        width: 800,
        height: 600,
        child: _loading
            ? const Center(child: CircularProgressIndicator())
            : Padding(
                padding: const EdgeInsets.all(16),
                child: Form(
                  key: _formKey,
                  child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Row(
                      children: [
                        const Text('Inventory Count', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                        const SizedBox(width: 8),
                        if (_isReadOnly)
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                            decoration: BoxDecoration(
                              color: Colors.orange.withOpacity(0.1),
                              border: Border.all(color: Colors.orange),
                              borderRadius: BorderRadius.circular(12),
                            ),
                            child: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                const Icon(Icons.visibility, size: 14, color: Colors.orange),
                                const SizedBox(width: 4),
                                Text('View Only ($_currentStatus)', style: TextStyle(fontSize: 12, color: Colors.orange.shade700)),
                              ],
                            ),
                          ),
                        // Debug info (remove in production)
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                          decoration: BoxDecoration(
                            color: Colors.blue.withOpacity(0.1),
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: Text(
                            'DEBUG: Status=$_currentStatus, ReadOnly=$_isReadOnly',
                            style: TextStyle(fontSize: 10, color: Colors.blue.shade700),
                          ),
                        ),
                        const Spacer(),
                        IconButton(onPressed: widget.onCancel, icon: const Icon(Icons.close)),
                      ],
                    ),
                    const SizedBox(height: 8),
                    Row(
                      children: [
                        Expanded(
                          child: DropdownButtonFormField<int>(
                            initialValue: _storeId,
                            decoration: InputDecoration(
                              labelText: 'Store', 
                              border: const OutlineInputBorder(),
                              suffixIcon: _isReadOnly ? const Icon(Icons.lock, size: 16) : null,
                            ),
                            items: _stores.map((s) => DropdownMenuItem(value: s.id, child: Text(s.name))).toList(),
                            onChanged: !_isReadOnly ? (v) => setState(() {
                              _storeId = v;
                              _searchResults.clear(); // Clear search when store changes
                            }) : null,
                            validator: (v) => v == null ? 'Required' : null,
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: DropdownButtonFormField<String>(
                            initialValue: _countType,
                            decoration: InputDecoration(
                              labelText: 'Count Type', 
                              border: const OutlineInputBorder(),
                              suffixIcon: _isReadOnly ? const Icon(Icons.lock, size: 16) : null,
                            ),
                            items: const [
                              DropdownMenuItem(value: 'full_count', child: Text('Full Count')),
                              DropdownMenuItem(value: 'partial_count', child: Text('Partial Count')),
                            ],
                            onChanged: !_isReadOnly ? (v) => setState(() {
                              _countType = v ?? 'full_count';
                              _searchResults.clear(); // Clear search when type changes
                            }) : null,
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: TextFormField(
                            initialValue: _notes,
                            decoration: InputDecoration(
                              labelText: 'Notes', 
                              border: const OutlineInputBorder(),
                              suffixIcon: _isReadOnly ? const Icon(Icons.lock, size: 16) : null,
                            ),
                            readOnly: _isReadOnly,
                            onChanged: !_isReadOnly ? (v) => _notes = v : null,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 12),
                    if (_countType == 'partial_count' && !_isReadOnly) _buildPartialToolbar(),
                    Expanded(
                      child: Container(
                        decoration: BoxDecoration(border: Border.all(color: Colors.grey.shade300), borderRadius: BorderRadius.circular(8)),
                        child: _buildItemsList(),
                      ),
                    ),
                    const SizedBox(height: 12),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: [
                        TextButton(
                          onPressed: widget.onCancel, 
                          child: Text(_isReadOnly ? 'Close' : 'Cancel'),
                        ),
                        const SizedBox(width: 8),
                        if (!_isReadOnly) ...[
                          ElevatedButton(onPressed: _saveProgress, child: const Text('Save Progress')),
                          const SizedBox(width: 8),
                          ElevatedButton(onPressed: _complete, child: const Text('Complete Count')),
                        ] else ...[
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                            decoration: BoxDecoration(
                              color: Colors.green.withOpacity(0.1),
                              border: Border.all(color: Colors.green),
                              borderRadius: BorderRadius.circular(4),
                            ),
                            child: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                const Icon(Icons.check_circle, color: Colors.green, size: 16),
                                const SizedBox(width: 4),
                                Text('Completed', style: TextStyle(color: Colors.green.shade700)),
                              ],
                            ),
                          ),
                        ],
                      ],
                    )
                  ],
                ),
              ),
              ),
      ),
    );
  }

  Widget _buildPartialToolbar() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Row(
          children: [
            Expanded(
              child: TextField(
                controller: _searchCtrl,
                decoration: InputDecoration(
                  labelText: 'Search products to add…',
                  border: const OutlineInputBorder(),
                  prefixIcon: const Icon(Icons.search),
                  suffixIcon: _searchLoading 
                    ? const SizedBox(
                        width: 16,
                        height: 16,
                        child: Padding(
                          padding: EdgeInsets.all(12),
                          child: CircularProgressIndicator(strokeWidth: 2),
                        ),
                      )
                    : null,
                ),
              ),
            ),
          ],
        ),
        const SizedBox(height: 8),
        
        // Live search results
        if (_searchResults.isNotEmpty && _storeId != null)
          Container(
            constraints: const BoxConstraints(maxHeight: 150),
            decoration: BoxDecoration(
              border: Border.all(color: Colors.grey.shade300),
              borderRadius: BorderRadius.circular(8),
            ),
            child: ListView.builder(
              shrinkWrap: true,
              itemCount: _searchResults.length,
              itemBuilder: (context, index) {
                final product = _searchResults[index];
                return ListTile(
                  dense: true,
                  title: Text(product['name']?.toString() ?? ''),
                  subtitle: Text('SKU: ${product['sku']} • Stock: ${product['ss_stock_quantity'] ?? 0}'),
                  trailing: IconButton(
                    icon: const Icon(Icons.add_circle, color: Colors.green),
                    onPressed: () => _addProductToCount(product),
                  ),
                );
              },
            ),
          ),
        
        const SizedBox(height: 8),
        Row(
          children: [
            Text('Items: ${_items.length}', style: TextStyle(color: Colors.grey.shade700)),
            const Spacer(),
            if (_searchResults.isNotEmpty)
              Text('${_searchResults.length} results found', 
                   style: TextStyle(color: Colors.blue.shade600, fontSize: 12)),
          ],
        ),
        const SizedBox(height: 4),
      ],
    );
  }

  void _addProductToCount(Map<String, dynamic> product) {
    final productId = product['product_id'] as int;
    
    // Check if already exists
    if (_items.any((item) => item['product_id'] == productId)) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Product already added to count')),
      );
      return;
    }

    // Ensure _items is modifiable
    _items = List<Map<String, dynamic>>.from(_items);
    
    // Add the product
    _items.add({
      'product_id': productId,
      'product_name': product['name'],
      'sku': product['sku'],
      'expected': (product['ss_stock_quantity'] as int?) ?? 0,
      'counted': (product['ss_stock_quantity'] as int?) ?? 0,
    });

    // Clear search
    _searchCtrl.clear();
    _searchResults.clear();
    
    setState(() {});

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('Added ${product['name']} to count')),
    );
  }

  Widget _buildItemsList() {
    if (_items.isEmpty) {
      return Center(
        child: Text(
          _countType == 'full_count' ? 'No items. Save progress to seed all products for the store.' : 'No items yet. Search and add products above.',
          style: TextStyle(color: Colors.grey.shade600),
        ),
      );
    }
    return ListView.separated(
      itemCount: _items.length,
      separatorBuilder: (_, __) => const Divider(height: 1),
      itemBuilder: (context, index) {
        final it = _items[index];
        final expected = it['expected'] as int? ?? 0;
        final counted = it['counted'] as int? ?? expected;
        final diff = counted - expected;
        final diffColor = diff == 0 ? Colors.grey.shade600 : (diff > 0 ? Colors.green : Colors.red);
        return ListTile(
          title: Text(it['product_name']?.toString() ?? ''),
          subtitle: Row(
            children: [
              Text('Expected: $expected'),
              const SizedBox(width: 12),
              Text('Counted: $counted'),
              const SizedBox(width: 12),
              Text('Diff: ${diff > 0 ? '+$diff' : '$diff'}', style: TextStyle(color: diffColor)),
            ],
          ),
          trailing: SizedBox(
            width: 220,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                SizedBox(
                  width: 120,
                  child: TextFormField(
                    key: ValueKey('counted_${it['product_id']}'),
                    initialValue: counted.toString(),
                    decoration: InputDecoration(
                      labelText: 'Counted', 
                      isDense: true,
                      border: const OutlineInputBorder(),
                      suffixIcon: _isReadOnly ? const Icon(Icons.lock, size: 14) : null,
                    ),
                    keyboardType: TextInputType.number,
                    readOnly: _isReadOnly,
                    onChanged: !_isReadOnly ? (v) {
                      final newValue = int.tryParse(v) ?? 0;
                      setState(() {
                        // Ensure _items is modifiable
                        _items = List<Map<String, dynamic>>.from(_items);
                        it['counted'] = newValue;
                      });
                    } : null,
                  ),
                ),
                IconButton(
                  onPressed: !_isReadOnly ? () {
                    setState(() {
                      // Ensure _items is modifiable before removing
                      _items = List<Map<String, dynamic>>.from(_items);
                      _items.removeAt(index);
                    });
                  } : null,
                  icon: Icon(
                    Icons.delete, 
                    color: _isReadOnly ? Colors.grey : Colors.red,
                  ),
                  tooltip: _isReadOnly ? 'Cannot remove (completed count)' : 'Remove',
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}
