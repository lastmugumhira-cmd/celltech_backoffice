import 'package:flutter/material.dart';
import '../../models/store.dart';
import '../../models/employee.dart';
import '../../services/database_service.dart';

class WarehouseFormDialog extends StatefulWidget {
  final Store? warehouse; // null => create, non-null => edit
  final VoidCallback? onSaved; // optional refresh callback
  const WarehouseFormDialog({super.key, this.warehouse, this.onSaved});

  @override
  State<WarehouseFormDialog> createState() => _WarehouseFormDialogState();
}

class _WarehouseFormDialogState extends State<WarehouseFormDialog> {
  final _formKey = GlobalKey<FormState>();
  final _nameCtrl = TextEditingController();
  final _addressCtrl = TextEditingController();
  final _phoneCtrl = TextEditingController();
  final _capacityCtrl = TextEditingController(text: '0');
  int? _managerId;
  bool _active = true;

  List<Employee> _employees = [];
  bool _loading = false;
  String? _error;

  @override
  void initState() {
    super.initState();
    final w = widget.warehouse;
    if (w != null) {
      _nameCtrl.text = w.name;
      _addressCtrl.text = w.address;
      _phoneCtrl.text = w.phone;
      _capacityCtrl.text = (w.capacity ?? 0).toString();
      _managerId = w.managerId;
      _active = w.active;
    }
    _loadEmployees();
  }

  Future<void> _loadEmployees() async {
    try {
      final emps = await DatabaseService.getEmployees(active: true);
      setState(() => _employees = emps.where((e) => e.role == 'Manager' || e.role == 'Administrator').toList());
    } catch (e) {
      setState(() => _error = 'Failed to load employees: $e');
    }
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() { _loading = true; _error = null; });
    final capacity = int.tryParse(_capacityCtrl.text.trim()) ?? 0;
    final store = Store(
      id: widget.warehouse?.id,
      name: _nameCtrl.text.trim(),
      address: _addressCtrl.text.trim(),
      phone: _phoneCtrl.text.trim(),
      managerId: _managerId,
      type: 'warehouse',
      capacity: capacity,
      active: _active,
    );

    try {
      if (widget.warehouse == null) {
        await DatabaseService.insertStore(store);
      } else {
        await DatabaseService.updateStore(store);
      }
      widget.onSaved?.call();
      if (mounted) Navigator.pop(context, true);
    } catch (e) {
      setState(() => _error = 'Failed to save warehouse: $e');
    } finally {
      setState(() => _loading = false);
    }
  }

  @override
  void dispose() {
    _nameCtrl.dispose();
    _addressCtrl.dispose();
    _phoneCtrl.dispose();
    _capacityCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final isEdit = widget.warehouse != null;
    return Dialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 680, maxHeight: 700),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  const Icon(Icons.apartment, color: Colors.blue),
                  const SizedBox(width: 8),
                  Text(isEdit ? 'Edit Warehouse' : 'Add New Warehouse', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
                  const Spacer(),
                  IconButton(onPressed: () => Navigator.pop(context, false), icon: const Icon(Icons.close)),
                ],
              ),
              const SizedBox(height: 12),
              Expanded(
                child: SingleChildScrollView(
                  child: Form(
                    key: _formKey,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(children: [
                          Expanded(
                            child: TextFormField(
                              controller: _nameCtrl,
                              decoration: const InputDecoration(labelText: 'Warehouse Name *', border: OutlineInputBorder()),
                              validator: (v) => (v == null || v.trim().isEmpty) ? 'Required' : null,
                            ),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: InputDecorator(
                              decoration: const InputDecoration(labelText: 'Manager', border: OutlineInputBorder()),
                              child: DropdownButtonHideUnderline(
                                child: DropdownButton<int?>(
                                  isExpanded: true,
                                  value: _managerId,
                                  items: [
                                    const DropdownMenuItem(value: null, child: Text('No manager')),
                                    ..._employees.map((e) => DropdownMenuItem(value: e.id, child: Text(e.name))),
                                  ],
                                  onChanged: (v) => setState(() => _managerId = v),
                                ),
                              ),
                            ),
                          ),
                        ]),
                        const SizedBox(height: 12),
                        TextFormField(
                          controller: _addressCtrl,
                          decoration: const InputDecoration(labelText: 'Address *', border: OutlineInputBorder()),
                          minLines: 2,
                          maxLines: 3,
                          validator: (v) => (v == null || v.trim().isEmpty) ? 'Required' : null,
                        ),
                        const SizedBox(height: 12),
                        Row(children: [
                          Expanded(
                            child: TextFormField(
                              controller: _phoneCtrl,
                              decoration: const InputDecoration(labelText: 'Phone Number', border: OutlineInputBorder()),
                            ),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: TextFormField(
                              controller: _capacityCtrl,
                              keyboardType: TextInputType.number,
                              decoration: const InputDecoration(labelText: 'Capacity (sq ft)', border: OutlineInputBorder()),
                            ),
                          ),
                        ]),
                        const SizedBox(height: 12),
                        SwitchListTile(
                          contentPadding: EdgeInsets.zero,
                          title: const Text('Active Warehouse'),
                          value: _active,
                          onChanged: (v) => setState(() => _active = v),
                        ),
                        if (_error != null) ...[
                          const SizedBox(height: 8),
                          Container(
                            padding: const EdgeInsets.all(12),
                            decoration: BoxDecoration(color: Colors.red.shade50, borderRadius: BorderRadius.circular(8), border: Border.all(color: Colors.red.shade200)),
                            child: Row(children: [Icon(Icons.error_outline, color: Colors.red.shade600), const SizedBox(width: 8), Expanded(child: Text(_error!, style: TextStyle(color: Colors.red.shade700)))]),
                          ),
                        ],
                      ],
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 8),
              Row(
                children: [
                  TextButton(onPressed: _loading ? null : () => Navigator.pop(context, false), child: const Text('Cancel')),
                  const Spacer(),
                  ElevatedButton.icon(
                    onPressed: _loading ? null : _save,
                    icon: _loading ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white)) : const Icon(Icons.save),
                    label: Text(isEdit ? 'Update Warehouse' : 'Create Warehouse'),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
