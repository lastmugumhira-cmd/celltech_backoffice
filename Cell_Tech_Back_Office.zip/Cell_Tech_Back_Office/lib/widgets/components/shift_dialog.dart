import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../../models/store.dart';
import '../../models/employee.dart';
import 'dart:math' as math;

class ShiftDialog extends StatefulWidget {
  final List<Store> stores;
  final List<Employee> employees;
  final Function(Map<String, dynamic>) onSubmit;

  const ShiftDialog({
    super.key,
    required this.stores,
    required this.employees,
    required this.onSubmit,
  });

  @override
  State<ShiftDialog> createState() => _ShiftDialogState();
}

class _ShiftDialogState extends State<ShiftDialog> {
  final _formKey = GlobalKey<FormState>();
  final _posDeviceController = TextEditingController();
  final _startingCashController = TextEditingController();
  final _notesController = TextEditingController();
  
  int? _selectedStoreId;
  int? _selectedEmployeeId;

  @override
  void initState() {
    super.initState();
    // Generate a default POS device ID
    final random = math.Random();
    _posDeviceController.text = 'POS-${100000 + random.nextInt(900000)}';
    _startingCashController.text = '200.00'; // Default starting cash
  }

  @override
  void dispose() {
    _posDeviceController.dispose();
    _startingCashController.dispose();
    _notesController.dispose();
    super.dispose();
  }

  void _submit() {
    if (_formKey.currentState!.validate()) {
      final shiftData = {
        'pos_device': _posDeviceController.text.trim(),
        'store_id': _selectedStoreId,
        'employee_id': _selectedEmployeeId,
        'starting_cash': double.tryParse(_startingCashController.text) ?? 0.0,
        'notes': _notesController.text.trim().isEmpty ? null : _notesController.text.trim(),
      };
      
      widget.onSubmit(shiftData);
      Navigator.of(context).pop();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Dialog(
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
      ),
      child: Container(
        width: 500,
        padding: const EdgeInsets.all(24),
        child: Form(
          key: _formKey,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Header
              Row(
                children: [
                  Icon(
                    Icons.schedule,
                    color: Colors.blue.shade600,
                    size: 28,
                  ),
                  const SizedBox(width: 12),
                  const Text(
                    'Open New Shift',
                    style: TextStyle(
                      fontSize: 22,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const Spacer(),
                  IconButton(
                    onPressed: () => Navigator.of(context).pop(),
                    icon: const Icon(Icons.close),
                    tooltip: 'Close',
                  ),
                ],
              ),
              const SizedBox(height: 24),

              // POS Device ID
              TextFormField(
                controller: _posDeviceController,
                decoration: const InputDecoration(
                  labelText: 'POS Device ID',
                  border: OutlineInputBorder(),
                  prefixIcon: Icon(Icons.computer),
                ),
                validator: (value) {
                  if (value == null || value.trim().isEmpty) {
                    return 'POS Device ID is required';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 16),

              // Store selection
              DropdownButtonFormField<int>(
                initialValue: _selectedStoreId,
                decoration: const InputDecoration(
                  labelText: 'Store',
                  border: OutlineInputBorder(),
                  prefixIcon: Icon(Icons.store),
                ),
                items: widget.stores.map((store) => DropdownMenuItem(
                      value: store.id,
                      child: Text(store.name),
                )).toList(),
                onChanged: (value) {
                  setState(() => _selectedStoreId = value);
                },
                validator: (value) {
                  if (value == null) {
                    return 'Please select a store';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 16),

              // Employee selection
              DropdownButtonFormField<int>(
                initialValue: _selectedEmployeeId,
                decoration: const InputDecoration(
                  labelText: 'Employee',
                  border: OutlineInputBorder(),
                  prefixIcon: Icon(Icons.person),
                ),
                items: widget.employees
                    .where((emp) => emp.active) // Only show active employees
                    .map((employee) => DropdownMenuItem(
                          value: employee.id,
                          child: Text(employee.name),
                    )).toList(),
                onChanged: (value) {
                  setState(() => _selectedEmployeeId = value);
                },
                validator: (value) {
                  if (value == null) {
                    return 'Please select an employee';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 16),

              // Starting cash amount
              TextFormField(
                controller: _startingCashController,
                decoration: const InputDecoration(
                  labelText: 'Starting Cash Amount',
                  border: OutlineInputBorder(),
                  prefixIcon: Icon(Icons.attach_money),
                  prefixText: '\$',
                ),
                keyboardType: const TextInputType.numberWithOptions(decimal: true),
                inputFormatters: [
                  FilteringTextInputFormatter.allow(RegExp(r'^\d*\.?\d{0,2}')),
                ],
                validator: (value) {
                  if (value == null || value.trim().isEmpty) {
                    return 'Starting cash amount is required';
                  }
                  final amount = double.tryParse(value);
                  if (amount == null || amount < 0) {
                    return 'Please enter a valid amount';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 16),

              // Notes
              TextFormField(
                controller: _notesController,
                decoration: const InputDecoration(
                  labelText: 'Notes (Optional)',
                  border: OutlineInputBorder(),
                  prefixIcon: Icon(Icons.note),
                ),
                maxLines: 3,
                maxLength: 500,
              ),
              const SizedBox(height: 24),

              // Action buttons
              Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  TextButton(
                    onPressed: () => Navigator.of(context).pop(),
                    child: const Text('Cancel'),
                  ),
                  const SizedBox(width: 12),
                  ElevatedButton(
                    onPressed: _submit,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.blue,
                      foregroundColor: Colors.white,
                      padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                    ),
                    child: const Text('Open Shift'),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}