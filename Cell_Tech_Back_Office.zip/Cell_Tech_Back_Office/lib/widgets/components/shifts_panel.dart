import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../../models/shift.dart';
import '../../models/store.dart';
import '../../models/employee.dart';


class ShiftsPanel extends StatefulWidget {
  final Employee employee;
  final Store store;
  final Function(Shift?) onShiftChanged;

  const ShiftsPanel({
    super.key,
    required this.employee,
    required this.store,
    required this.onShiftChanged,
  });

  @override
  State<ShiftsPanel> createState() => _ShiftsPanelState();
}

class _ShiftsPanelState extends State<ShiftsPanel> {
  List<Shift> shifts = [];
  bool isLoading = true;
  Shift? activeShift;

  @override
  void initState() {
    super.initState();
    _loadShifts();
  }

  Future<void> _loadShifts() async {
    try {
      // Generate mock shifts for demonstration
      final mockShifts = await _generateMockShifts();
      setState(() {
        shifts = mockShifts;
        activeShift = shifts.firstWhere(
          (s) => s.status == 'Open',
          orElse: () => shifts.isNotEmpty ? shifts.first : _createEmptyShift(),
        );
        isLoading = false;
      });
    } catch (e) {
      setState(() => isLoading = false);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Failed to load shifts: $e'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  Future<List<Shift>> _generateMockShifts() async {
    final List<Shift> mockShifts = [];
    final now = DateTime.now();

    // Add current open shift
    mockShifts.add(Shift(
      id: 1,
      employeeId: widget.employee.id!,
      startTime: now.subtract(const Duration(hours: 3)),
      endTime: null,
      status: 'Open',
      totalSales: 450.75,
      totalTransactions: 23,
      createdAt: now.subtract(const Duration(hours: 3)),
    ));

    // Add some previous closed shifts
    for (int i = 1; i <= 5; i++) {
      final shiftStart = now.subtract(Duration(days: i, hours: 8));
      final shiftEnd = shiftStart.add(const Duration(hours: 8));
      
      mockShifts.add(Shift(
        id: i + 1,
        employeeId: widget.employee.id!,
        startTime: shiftStart,
        endTime: shiftEnd,
        status: 'Closed',
        totalSales: 200.0 + (i * 50.0),
        totalTransactions: 10 + (i * 3),
        createdAt: shiftStart,
      ));
    }

    return mockShifts;
  }

  Shift _createEmptyShift() {
    return Shift(
      id: 0,
      employeeId: widget.employee.id!,
      startTime: DateTime.now(),
      status: 'Closed',
      totalSales: 0.0,
      totalTransactions: 0,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'Shift Management',
                style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                  fontWeight: FontWeight.bold,
                ),
              ),
              IconButton(
                onPressed: () => Navigator.of(context).pop(),
                icon: const Icon(Icons.close),
              ),
            ],
          ),

          Text(
            '${widget.employee.name} • ${widget.store.name}',
            style: Theme.of(context).textTheme.bodyMedium?.copyWith(
              color: Colors.grey[600],
            ),
          ),

          const SizedBox(height: 24),

          // Active shift card
          if (!isLoading) _buildActiveShiftCard(),

          const SizedBox(height: 16),

          // Shift actions
          if (!isLoading) _buildShiftActions(),

          const SizedBox(height: 24),

          // Recent shifts
          Text(
            'Recent Shifts',
            style: Theme.of(context).textTheme.titleMedium?.copyWith(
              fontWeight: FontWeight.bold,
            ),
          ),

          const SizedBox(height: 12),

          // Shifts list
          Expanded(
            child: isLoading
                ? const Center(child: CircularProgressIndicator())
                : shifts.isEmpty
                    ? Center(
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(
                              Icons.access_time,
                              size: 64,
                              color: Colors.grey[400],
                            ),
                            const SizedBox(height: 16),
                            Text(
                              'No shifts found',
                              style: TextStyle(
                                fontSize: 16,
                                color: Colors.grey[600],
                              ),
                            ),
                          ],
                        ),
                      )
                    : ListView.builder(
                        itemCount: shifts.length,
                        itemBuilder: (context, index) {
                          final shift = shifts[index];
                          return _buildShiftCard(shift);
                        },
                      ),
          ),
        ],
      ),
    );
  }

  Widget _buildActiveShiftCard() {
    final hasActiveShift = activeShift != null && activeShift!.status == 'Open';
    
    return Card(
      color: hasActiveShift ? Colors.green[50] : Colors.grey[50],
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(
                  hasActiveShift ? Icons.play_circle : Icons.pause_circle,
                  color: hasActiveShift ? Colors.green : Colors.grey,
                ),
                const SizedBox(width: 8),
                Text(
                  hasActiveShift ? 'Active Shift' : 'No Active Shift',
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: hasActiveShift ? Colors.green[700] : Colors.grey[700],
                  ),
                ),
              ],
            ),
            
            if (hasActiveShift) ...[
              const SizedBox(height: 12),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Started',
                        style: TextStyle(
                          color: Colors.grey[600],
                          fontSize: 12,
                        ),
                      ),
                      Text(
                        _formatDateTime(activeShift!.startTime),
                        style: const TextStyle(fontWeight: FontWeight.bold),
                      ),
                    ],
                  ),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      Text(
                        'Sales',
                        style: TextStyle(
                          color: Colors.grey[600],
                          fontSize: 12,
                        ),
                      ),
                      Text(
                        '\$${activeShift!.totalSales.toStringAsFixed(2)}',
                        style: const TextStyle(
                          fontWeight: FontWeight.bold,
                          color: Colors.green,
                        ),
                      ),
                    ],
                  ),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      Text(
                        'Transactions',
                        style: TextStyle(
                          color: Colors.grey[600],
                          fontSize: 12,
                        ),
                      ),
                      Text(
                        '${activeShift!.totalTransactions}',
                        style: const TextStyle(fontWeight: FontWeight.bold),
                      ),
                    ],
                  ),
                ],
              ),
            ] else ...[
              const SizedBox(height: 8),
              Text(
                'Start a shift to begin processing sales',
                style: TextStyle(color: Colors.grey[600]),
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _buildShiftActions() {
    final hasActiveShift = activeShift != null && activeShift!.status == 'Open';
    
    return Row(
      children: [
        if (!hasActiveShift)
          Expanded(
            child: ElevatedButton.icon(
              onPressed: _startShift,
              icon: const Icon(Icons.play_arrow),
              label: const Text('Start Shift'),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.green,
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(vertical: 12),
              ),
            ),
          )
        else ...[
          Expanded(
            child: ElevatedButton.icon(
              onPressed: _endShift,
              icon: const Icon(Icons.stop),
              label: const Text('End Shift'),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.red,
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(vertical: 12),
              ),
            ),
          ),
          const SizedBox(width: 12),
          ElevatedButton.icon(
            onPressed: _showShiftDetails,
            icon: const Icon(Icons.info_outline),
            label: const Text('Details'),
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.blue,
              foregroundColor: Colors.white,
              padding: const EdgeInsets.symmetric(vertical: 12),
            ),
          ),
        ],
      ],
    );
  }

  Widget _buildShiftCard(Shift shift) {
    final isActive = shift.status == 'Open';
    final duration = shift.endTime != null 
        ? shift.endTime!.difference(shift.startTime)
        : DateTime.now().difference(shift.startTime);
    
    return Card(
      margin: const EdgeInsets.only(bottom: 8),
      child: ListTile(
        leading: CircleAvatar(
          backgroundColor: isActive ? Colors.green : Colors.grey,
          child: Icon(
            isActive ? Icons.play_circle : Icons.stop_circle,
            color: Colors.white,
          ),
        ),
        title: Row(
          children: [
            Text(
              _formatDate(shift.startTime),
              style: const TextStyle(fontWeight: FontWeight.bold),
            ),
            const SizedBox(width: 8),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
              decoration: BoxDecoration(
                color: isActive ? Colors.green[100] : Colors.grey[100],
                borderRadius: BorderRadius.circular(12),
              ),
              child: Text(
                shift.status.toUpperCase(),
                style: TextStyle(
                  fontSize: 10,
                  fontWeight: FontWeight.bold,
                  color: isActive ? Colors.green[800] : Colors.grey[800],
                ),
              ),
            ),
          ],
        ),
        subtitle: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('${_formatTime(shift.startTime)} - ${shift.endTime != null ? _formatTime(shift.endTime!) : 'Active'}'),
            Text('Duration: ${_formatDuration(duration)}'),
          ],
        ),
        trailing: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            Text(
              '\$${shift.totalSales.toStringAsFixed(2)}',
              style: const TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.bold,
                color: Colors.green,
              ),
            ),
            Text(
              '${shift.totalTransactions} transactions',
              style: TextStyle(
                fontSize: 12,
                color: Colors.grey[600],
              ),
            ),
          ],
        ),
        onTap: () => _showShiftDetails(shift: shift),
      ),
    );
  }

  Future<void> _startShift() async {
    try {
      // Create new shift
      final newShift = Shift(
        id: shifts.length + 1,
        employeeId: widget.employee.id!,
        startTime: DateTime.now(),
        status: 'Open',
        totalSales: 0.0,
        totalTransactions: 0,
      );

      setState(() {
        shifts.insert(0, newShift);
        activeShift = newShift;
      });

      widget.onShiftChanged(newShift);

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Shift started successfully'),
            backgroundColor: Colors.green,
          ),
        );

        Navigator.of(context).pop();
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Failed to start shift: $e'),
          backgroundColor: Colors.red,
        ),
      );
    }
  }

  Future<void> _endShift() async {
    if (activeShift == null) return;

    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('End Shift'),
        content: const Text('Are you sure you want to end the current shift?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(false),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () => Navigator.of(context).pop(true),
            style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
            child: const Text('End Shift'),
          ),
        ],
      ),
    );

    if (confirmed != true) return;

    try {
      // Update shift status
      final updatedShift = activeShift!.copyWith(
        endTime: DateTime.now(),
        status: 'Closed',
      );

      setState(() {
        final index = shifts.indexWhere((s) => s.id == activeShift!.id);
        if (index >= 0) {
          shifts[index] = updatedShift;
        }
        activeShift = null;
      });

      widget.onShiftChanged(null);

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Shift ended successfully'),
            backgroundColor: Colors.orange,
          ),
        );

        Navigator.of(context).pop();
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Failed to end shift: $e'),
          backgroundColor: Colors.red,
        ),
      );
    }
  }

  void _showShiftDetails({Shift? shift}) {
    final targetShift = shift ?? activeShift;
    if (targetShift == null) return;

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Shift Details - ${_formatDate(targetShift.startTime)}'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildDetailRow('Status', targetShift.status),
            _buildDetailRow('Employee', widget.employee.name),
            _buildDetailRow('Store', widget.store.name),
            _buildDetailRow('Start Time', _formatDateTime(targetShift.startTime)),
            if (targetShift.endTime != null)
              _buildDetailRow('End Time', _formatDateTime(targetShift.endTime!)),
            _buildDetailRow('Total Sales', '\$${targetShift.totalSales.toStringAsFixed(2)}'),
            _buildDetailRow('Transactions', '${targetShift.totalTransactions}'),
            if (targetShift.endTime != null) ...[
              const SizedBox(height: 8),
              _buildDetailRow('Duration', _formatDuration(targetShift.endTime!.difference(targetShift.startTime))),
            ],
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('Close'),
          ),
        ],
      ),
    );
  }

  Widget _buildDetailRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 100,
            child: Text(
              '$label:',
              style: const TextStyle(fontWeight: FontWeight.bold),
            ),
          ),
          Expanded(child: Text(value)),
        ],
      ),
    );
  }

  String _formatDateTime(DateTime dateTime) {
    return DateFormat('MMM dd, yyyy HH:mm').format(dateTime);
  }

  String _formatDate(DateTime dateTime) {
    return DateFormat('MMM dd, yyyy').format(dateTime);
  }

  String _formatTime(DateTime dateTime) {
    return DateFormat('HH:mm').format(dateTime);
  }

  String _formatDuration(Duration duration) {
    final hours = duration.inHours;
    final minutes = duration.inMinutes.remainder(60);
    return '${hours}h ${minutes}m';
  }
}