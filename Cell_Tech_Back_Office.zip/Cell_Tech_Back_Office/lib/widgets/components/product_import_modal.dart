import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';
import 'dart:io';
import 'package:csv/csv.dart';
import '../../models/store.dart';
import '../../models/category.dart';
import '../../models/product.dart';
import '../../services/database_service.dart';

enum ImportStatus {
  idle,
  uploading,
  extracting,
  processing,
  saving,
  success,
  error
}

class ProductImportModal extends StatefulWidget {
  final List<Store> stores;
  final VoidCallback onComplete;

  const ProductImportModal({
    super.key,
    required this.stores,
    required this.onComplete,
  });

  @override
  State<ProductImportModal> createState() => _ProductImportModalState();
}

class _ProductImportModalState extends State<ProductImportModal> {
  ImportStatus _status = ImportStatus.idle;
  String? _selectedFilePath;
  String? _selectedFileName;
  String? _errorMessage;
  double _progress = 0.0;
  int _processedCount = 0;
  int _totalCount = 0;

  void _pickFile() async {
    try {
      FilePickerResult? result = await FilePicker.platform.pickFiles(
        type: FileType.custom,
        allowedExtensions: ['csv'],
      );

      if (result != null) {
        setState(() {
          _selectedFilePath = result.files.single.path;
          _selectedFileName = result.files.single.name;
          _errorMessage = null;
        });
      }
    } catch (e) {
      setState(() {
        _errorMessage = 'Error picking file: $e';
      });
    }
  }

  void _importProducts() async {
    if (_selectedFilePath == null) return;

    try {
      // Step 1: Uploading (reading file)
      setState(() {
        _status = ImportStatus.uploading;
        _progress = 0.1;
        _errorMessage = null;
      });

      final file = File(_selectedFilePath!);
      final csvString = await file.readAsString();

      // Step 2: Extracting (parsing CSV)
      setState(() {
        _status = ImportStatus.extracting;
        _progress = 0.2;
      });

      final List<List<dynamic>> csvData = const CsvToListConverter().convert(csvString);
      if (csvData.isEmpty) {
        throw Exception('CSV file is empty');
      }

      // Parse the CSV headers (first row)
      csvData.first.map((e) => e.toString()).toList();
      final rows = csvData.skip(1).toList();

      // Step 3: Processing (validating and creating categories)
      setState(() {
        _status = ImportStatus.processing;
        _progress = 0.3;
        _totalCount = rows.length;
      });

      // Get existing categories
      final categories = await DatabaseService.getCategories();
      final categoryMap = {for (var cat in categories) cat.name: cat};

      // Create missing categories
      final categoryNames = rows
          .map((row) => row.length > 3 ? row[3]?.toString().trim() ?? '' : '')
          .where((name) => name.isNotEmpty)
          .toSet();

      for (final categoryName in categoryNames) {
        if (!categoryMap.containsKey(categoryName)) {
          final newCategory = Category(
            name: categoryName,
            color: '#FF9800', // Default orange color
            description: 'Auto-created during import',
          );
          final categoryId = await DatabaseService.insertCategory(newCategory);
          categoryMap[categoryName] = Category(
            id: categoryId,
            name: categoryName,
            color: '#FF9800',
            description: 'Auto-created during import',
          );
        }
      }

      // Step 4: Saving (importing products)
      setState(() {
        _status = ImportStatus.saving;
        _progress = 0.4;
        _processedCount = 0;
      });

      // Get all stores for stock data
      final stores = await DatabaseService.getStores();
      
      for (int i = 0; i < rows.length; i++) {
        final row = rows[i];
        if (row.length < 4) continue; // Skip incomplete rows

        try {
          final product = Product(
            name: row[2]?.toString().trim() ?? '',
            sku: row[1]?.toString().trim() ?? '',
            categoryId: categoryMap[row[3]?.toString().trim()]?.id ?? 0,
            description: row.length > 4 ? row[4]?.toString().trim() ?? '' : '',
            price: row.length > 5 ? double.tryParse(row[5]?.toString().trim() ?? '') ?? 0.0 : 0.0,
            cost: row.length > 6 ? double.tryParse(row[6]?.toString().trim() ?? '') ?? 0.0 : 0.0,
            trackStock: true,
            active: true,
          );

          // Create store stock data for all stores with default values
          final Map<String, dynamic> storeStockData = {};
          for (final store in stores) {
            storeStockData[store.id.toString()] = {
              'in_stock': 0, // Default stock quantity
              'low_stock_threshold': 5, // Default low stock threshold
            };
          }

          await DatabaseService.insertProduct(product, storeStockData: storeStockData);

          setState(() {
            _processedCount = i + 1;
            _progress = 0.4 + (0.5 * (i + 1) / rows.length);
          });
        } catch (e) {
          // Continue with next product if one fails
          continue;
        }
      }

      // Success
      setState(() {
        _status = ImportStatus.success;
        _progress = 1.0;
      });

    } catch (e) {
      setState(() {
        _status = ImportStatus.error;
        _errorMessage = e.toString();
      });
    }
  }

  void _downloadTemplate() {
    // Generate CSV template with basic required headers for import
    final headers = [
      'Handle',      // row[0] - not used but commonly expected
      'SKU',         // row[1] - product SKU
      'Name',        // row[2] - product name (required)
      'Category',    // row[3] - product category (required)
      'Description', // row[4] - product description (optional)
      'Price',       // row[5] - product price (optional, defaults to 0)
      'Cost',        // row[6] - product cost (optional, defaults to 0)
    ];

    final csvContent = headers.join(',');

    // Create a sample row to show the format
    final sampleRow = [
      'sample-product-handle',     // Handle
      'SAMPLE001',                 // SKU
      'Sample Product',            // Name (required)
      'Electronics',               // Category (required)
      'This is a sample product',  // Description
      '29.99',                     // Price
      '15.00',                     // Cost
    ];

    final fullCsvContent = '$csvContent\n${sampleRow.join(',')}';

    // Show template in dialog with download instructions
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('CSV Template'),
        content: SizedBox(
          width: 600,
          height: 400,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'Copy the template below and save it as a .csv file:',
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 12),
              Expanded(
                child: SingleChildScrollView(
                  child: Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: Colors.grey.shade100,
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(color: Colors.grey.shade300),
                    ),
                    child: SelectableText(
                      fullCsvContent,
                      style: const TextStyle(
                        fontFamily: 'monospace',
                        fontSize: 11,
                      ),
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 12),
              const Text(
                'Notes:\n• Use TRUE/FALSE for boolean fields\n• Leave empty cells blank\n• Ensure store names match exactly\n• Price fields should be numeric (e.g., 29.99)',
                style: TextStyle(fontSize: 12, color: Colors.grey),
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('Close'),
          ),
        ],
      ),
    );
  }







  @override
  Widget build(BuildContext context) {
    return Dialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: Container(
        width: 600,
        constraints: const BoxConstraints(maxHeight: 700),
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text(
                  'Import Products from CSV',
                  style: TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                IconButton(
                  icon: const Icon(Icons.close),
                  onPressed: () => Navigator.of(context).pop(),
                ),
              ],
            ),
            const SizedBox(height: 24),
            Expanded(
              child: _buildContent(),
            ),
          ],
        ),
      ),
    );
  }



  Widget _buildContent() {
    switch (_status) {
      case ImportStatus.idle:
        return _buildIdleState();
      case ImportStatus.success:
        return _buildSuccessState();
      case ImportStatus.error:
        return _buildErrorState();
      default:
        return _buildProgressState();
    }
  }

  Widget _buildIdleState() {
    return Column(
      children: [
        // Drop Zone
        Expanded(
          child: Container(
            width: double.infinity,
            margin: const EdgeInsets.only(bottom: 24),
            decoration: BoxDecoration(
              border: Border.all(
                color: _selectedFilePath != null
                    ? const Color(0xFFFF8C00)
                    : Colors.grey.shade300,
                width: 2,
                style: BorderStyle.solid,
              ),
              borderRadius: BorderRadius.circular(16),
              color: _selectedFilePath != null
                  ? const Color(0xFFFF8C00).withOpacity(0.05)
                  : Colors.grey.shade50,
            ),
            child: InkWell(
              onTap: _pickFile,
              borderRadius: BorderRadius.circular(16),
              child: Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Container(
                      padding: const EdgeInsets.all(24),
                      decoration: BoxDecoration(
                        color: _selectedFilePath != null
                            ? const Color(0xFFFF8C00).withOpacity(0.1)
                            : Colors.grey.shade100,
                        shape: BoxShape.circle,
                      ),
                      child: Icon(
                        _selectedFilePath != null
                            ? Icons.check_circle
                            : Icons.cloud_upload_outlined,
                        size: 64,
                        color: _selectedFilePath != null
                            ? const Color(0xFFFF8C00)
                            : Colors.grey.shade400,
                      ),
                    ),
                    const SizedBox(height: 24),
                    Text(
                      _selectedFilePath != null
                          ? 'File Ready to Import'
                          : 'Drop your CSV file here',
                      style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.w600,
                        color: _selectedFilePath != null
                            ? const Color(0xFFFF8C00)
                            : Colors.grey.shade700,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      _selectedFilePath != null
                          ? _selectedFileName ?? _selectedFilePath!.split(Platform.pathSeparator).last
                          : 'or click to browse files',
                      style: TextStyle(
                        fontSize: 16,
                        color: Colors.grey.shade600,
                      ),
                    ),
                    if (_selectedFilePath == null) ...[
                      const SizedBox(height: 16),
                      Text(
                        'Only .csv files are supported',
                        style: TextStyle(
                          fontSize: 14,
                          color: Colors.grey.shade500,
                        ),
                      ),
                    ],
                  ],
                ),
              ),
            ),
          ),
        ),

        // Error Message
        if (_errorMessage != null) ...[
          Container(
            margin: const EdgeInsets.only(bottom: 24),
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Colors.red.shade50,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: Colors.red.shade200),
            ),
            child: Row(
              children: [
                Icon(Icons.error_outline, color: Colors.red.shade600, size: 24),
                const SizedBox(width: 12),
                Expanded(
                  child: Text(
                    _errorMessage!,
                    style: TextStyle(
                      color: Colors.red.shade700,
                      fontSize: 14,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],

        // Action Buttons
        Row(
          children: [
            Expanded(
              child: OutlinedButton.icon(
                onPressed: _downloadTemplate,
                icon: const Icon(Icons.download_outlined, size: 20),
                label: const Text('Download Template'),
                style: OutlinedButton.styleFrom(
                  foregroundColor: const Color(0xFFFF8C00),
                  side: const BorderSide(color: Color(0xFFFF8C00)),
                  padding: const EdgeInsets.symmetric(vertical: 16),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
              ),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: ElevatedButton.icon(
                onPressed: _selectedFilePath != null ? _importProducts : null,
                icon: const Icon(Icons.upload, size: 20),
                label: const Text('Import Products'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFFFF8C00),
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(vertical: 16),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                  disabledBackgroundColor: Colors.grey.shade300,
                  disabledForegroundColor: Colors.grey.shade600,
                ),
              ),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildProgressState() {
    String statusText;
    switch (_status) {
      case ImportStatus.uploading:
        statusText = 'Reading CSV file...';
        break;
      case ImportStatus.extracting:
        statusText = 'Validating data structure...';
        break;
      case ImportStatus.processing:
        statusText = 'Creating categories...';
        break;
      case ImportStatus.saving:
        statusText = 'Importing products ($_processedCount/$_totalCount)...';
        break;
      default:
        statusText = 'Processing...';
    }

    return Column(
      children: [
        const CircularProgressIndicator(
          color: Color(0xFFFF8C00),
          strokeWidth: 3,
        ),
        const SizedBox(height: 24),
        Text(
          statusText,
          style: const TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.w500,
          ),
        ),
        const SizedBox(height: 16),
        LinearProgressIndicator(
          value: _progress,
          backgroundColor: Colors.grey.shade200,
          valueColor: const AlwaysStoppedAnimation<Color>(Color(0xFFFF8C00)),
        ),
        const SizedBox(height: 8),
        Text(
          '${(_progress * 100).toInt()}% complete',
          style: TextStyle(
            fontSize: 12,
            color: Colors.grey.shade600,
          ),
        ),
        if (_status == ImportStatus.saving && _totalCount > 0) ...[
          const SizedBox(height: 8),
          Text(
            'Processed $_processedCount of $_totalCount products',
            style: TextStyle(
              fontSize: 12,
              color: Colors.grey.shade600,
            ),
          ),
        ],
      ],
    );
  }

  Widget _buildSuccessState() {
    return Column(
      children: [
        Expanded(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                padding: const EdgeInsets.all(24),
                decoration: BoxDecoration(
                  color: Colors.green.shade50,
                  shape: BoxShape.circle,
                ),
                child: Icon(
                  Icons.check_circle,
                  size: 64,
                  color: Colors.green.shade600,
                ),
              ),
              const SizedBox(height: 24),
              const Text(
                'Import Successful!',
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.w600,
                  color: Colors.green,
                ),
              ),
              const SizedBox(height: 12),
              Text(
                '$_processedCount products have been imported successfully.',
                style: TextStyle(
                  fontSize: 16,
                  color: Colors.grey.shade600,
                ),
                textAlign: TextAlign.center,
              ),
            ],
          ),
        ),
        ElevatedButton(
          onPressed: () {
            Navigator.of(context).pop();
            widget.onComplete();
          },
          style: ElevatedButton.styleFrom(
            backgroundColor: Colors.green,
            foregroundColor: Colors.white,
            padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 16),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
            ),
          ),
          child: const Text('Close'),
        ),
      ],
    );
  }

  Widget _buildErrorState() {
    return Column(
      children: [
        Expanded(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                padding: const EdgeInsets.all(24),
                decoration: BoxDecoration(
                  color: Colors.red.shade50,
                  shape: BoxShape.circle,
                ),
                child: Icon(
                  Icons.error,
                  size: 64,
                  color: Colors.red.shade600,
                ),
              ),
              const SizedBox(height: 24),
              const Text(
                'Import Failed',
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.w600,
                  color: Colors.red,
                ),
              ),
              const SizedBox(height: 12),
              Text(
                _errorMessage ?? 'An unknown error occurred',
                style: TextStyle(
                  fontSize: 16,
                  color: Colors.grey.shade600,
                ),
                textAlign: TextAlign.center,
              ),
            ],
          ),
        ),
        Row(
          children: [
            Expanded(
              child: OutlinedButton(
                onPressed: () {
                  setState(() {
                    _status = ImportStatus.idle;
                    _progress = 0.0;
                    _errorMessage = null;
                    _processedCount = 0;
                    _totalCount = 0;
                  });
                },
                style: OutlinedButton.styleFrom(
                  foregroundColor: const Color(0xFFFF8C00),
                  side: const BorderSide(color: Color(0xFFFF8C00)),
                  padding: const EdgeInsets.symmetric(vertical: 16),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
                child: const Text('Try Again'),
              ),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: ElevatedButton(
                onPressed: () => Navigator.of(context).pop(),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.grey.shade600,
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(vertical: 16),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
                child: const Text('Close'),
              ),
            ),
          ],
        ),
      ],
    );
  }


}
