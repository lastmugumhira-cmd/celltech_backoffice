import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'screens/splash_screen.dart';
import 'screens/login/login_screen.dart';
import 'screens/back_office/dashboard_screen.dart';
import 'screens/back_office/products_screen.dart';
import 'screens/back_office/categories_screen.dart';
import 'screens/back_office/inventory_screen.dart';
import 'screens/back_office/inventory_overview_screen.dart';
import 'screens/back_office/inventory_counts_screen.dart';
import 'screens/back_office/stock_adjustments_screen.dart';
import 'screens/back_office/inventory_history_screen.dart';
import 'screens/back_office/inventory_valuation_screen.dart';
import 'screens/back_office/productions_screen.dart';
import 'screens/back_office/purchase_order_create_screen.dart';
import 'screens/back_office/warehouse_manager_screen.dart';
import 'screens/back_office/warehouse_history_screen.dart';
import 'screens/back_office/employees_screen.dart';
import 'screens/back_office/customers_screen.dart';
import 'screens/back_office/pos_devices_screen.dart';
import 'screens/back_office/sales_summary_screen.dart';
import 'screens/back_office/sales_by_payment_screen.dart';
import 'screens/back_office/sales_by_employee_screen.dart';
import 'screens/back_office/sales_by_category_screen.dart';
import 'screens/back_office/sales_by_product_screen.dart';
import 'screens/back_office/discounts_screen.dart';
import 'screens/back_office/shifts_screen.dart';
import 'screens/back_office/receipts_screen.dart';
import 'screens/back_office/stores_screen.dart';
import 'screens/back_office/settings_screen.dart';
import 'screens/pos/store_selection_screen.dart';
import 'screens/pos/pin_login_screen.dart';
import 'screens/pos/main_pos_screen.dart';
import 'screens/pos/full_pos_screen.dart';
import 'screens/pos/modern_sales_screen.dart';
import 'services/database_service.dart';
import 'models/employee.dart';
import 'models/store.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  
  // Initialize database
  await DatabaseService.database;
  
  // Add sample data for demo purposes
  await DatabaseService.addSampleData();
  
  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => AppState()),
      ],
      child: const MyApp(),
    ),
  );
}

class AppState extends ChangeNotifier {
  Employee? _currentEmployee;
  Store? _currentStore;
  int? _currentShiftId;

  Employee? get currentEmployee => _currentEmployee;
  Store? get currentStore => _currentStore;
  int? get currentShiftId => _currentShiftId;

  void setEmployee(Employee employee) {
    _currentEmployee = employee;
    notifyListeners();
  }

  void setStore(Store store) {
    _currentStore = store;
    notifyListeners();
  }

  void setShiftId(int? shiftId) {
    _currentShiftId = shiftId;
    notifyListeners();
  }

  void logout() {
    _currentEmployee = null;
    _currentStore = null;
    _currentShiftId = null;
    notifyListeners();
  }
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Cell Tech POS System',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFFFF5F1F), // Updated orange theme
        ),
        useMaterial3: true,
        appBarTheme: const AppBarTheme(
          backgroundColor: Color(0xFFFF5F1F),
          foregroundColor: Colors.white,
          elevation: 0,
        ),
        elevatedButtonTheme: ElevatedButtonThemeData(
          style: ElevatedButton.styleFrom(
            backgroundColor: const Color(0xFFFF5F1F),
            foregroundColor: Colors.white,
          ),
        ),
        floatingActionButtonTheme: const FloatingActionButtonThemeData(
          backgroundColor: Color(0xFFFF5F1F),
          foregroundColor: Colors.white,
        ),
      ),
      initialRoute: '/',
      routes: {
        '/': (context) => const SplashScreen(),
        '/login': (context) => const LoginScreen(),
        '/backoffice/dashboard': (context) => const DashboardScreen(),
        '/backoffice/products': (context) => const ProductsScreen(),
        '/backoffice/categories': (context) => const CategoriesScreen(),
        '/backoffice/inventory': (context) => const InventoryScreen(),
        '/backoffice/inventory/overview': (context) => const InventoryOverviewScreen(),
  '/backoffice/inventory/counts': (context) => const InventoryCountsScreen(),
        '/backoffice/inventory/history': (context) => const InventoryHistoryScreen(),
        '/backoffice/inventory/valuation': (context) => const InventoryValuationScreen(),
        '/backoffice/inventory/productions': (context) => const ProductionsScreen(),
        '/backoffice/inventory/purchase-orders': (context) => const InventoryOverviewScreen(), // Redirect to overview for now
        '/backoffice/inventory/purchase-orders/create': (context) => const PurchaseOrderCreateScreen(),
        '/backoffice/inventory/transfers': (context) => const InventoryOverviewScreen(), // Redirect to overview for now
        '/backoffice/inventory/adjustments': (context) => const StockAdjustmentsScreen(),
        '/backoffice/inventory/suppliers': (context) => const InventoryOverviewScreen(), // Redirect to overview for now
        '/backoffice/warehouse-manager': (context) => const WarehouseManagerScreen(),
  '/backoffice/warehouse-history': (context) => const WarehouseHistoryScreen(),
        '/backoffice/employees': (context) => const EmployeesScreen(),
        '/backoffice/customers': (context) => const CustomersScreen(),
        '/backoffice/pos-devices': (context) => const PosDevicesScreen(),
        '/backoffice/sales-reports': (context) => const SalesSummaryScreen(),
        '/backoffice/sales-summary': (context) => const SalesSummaryScreen(),
        '/backoffice/sales-by-payment': (context) => const SalesByPaymentScreen(),
        '/backoffice/sales-by-employee': (context) => const SalesByEmployeeScreen(),
        '/backoffice/sales-by-category': (context) => const SalesByCategoryScreen(),
        '/backoffice/sales-by-product': (context) => const SalesByProductScreen(),
        '/backoffice/discounts': (context) => const DiscountsScreen(),
        '/backoffice/shifts': (context) => const ShiftsScreen(),
        '/backoffice/receipts': (context) => const ReceiptsScreen(),
        '/backoffice/stores': (context) => const StoresScreen(),
        '/backoffice/settings': (context) => const SettingsScreen(),
        '/pos/store-selection': (context) => const StoreSelectionScreen(),
        '/pos/pin-login': (context) => const PinLoginScreen(),
        '/pos/main': (context) => const MainPosScreen(),
        '/pos/full': (context) => const FullPOSScreen(),
        '/pos/modern': (context) {
          final args = ModalRoute.of(context)!.settings.arguments as Map<String, dynamic>;
          return ModernSalesScreen(
            employee: args['employee'] as Employee,
            store: args['store'] as Store,
          );
        },
      },
    );
  }
}
